# Design Decisions & Token Mapping — Design Engineering System

Running log of implementation decisions, token mappings, and every deviation from
the Figma source. Maintained by `/sync-tokens`. If a value in the codebase differs
from what Figma specifies, it is documented here — there are no silent deviations.

- **Source:** Figma file *Design Engineering System* (`ojko9pGfsDAvmUf2DA38d2`), collection group `Tokens`.
- **Token file:** `src/styles/tokens.css` → consumed through `tailwind.config.js` → referenced by `*.variants.ts`.
- **Last sync:** 2026-07-06 — first sync run against the authoritative Figma **Variables API** (Desktop Bridge). Prior syncs used Dev Mode sampling.

---

## How tokens flow

```
Figma Variable / Text Style
        │  (name preserved in a tokens.css comment)
        ▼
src/styles/tokens.css   --custom-property: value
        │
        ▼
tailwind.config.js      alias: var(--custom-property)
        │
        ▼
*.variants.ts (CVA)     utility class (bg-primary, px-3, text-h1 …)
```

No component uses inline `style={{}}` or hardcoded hex/px for design-system values.
Verified: `grep -rn '#[0-9a-fA-F]\{3,8\}\|[0-9]\+px' src/components` returns matches in
comments only.

---

## Token mapping (implemented subset)

| Tailwind alias | CSS var | Figma path | Value |
|---|---|---|---|
| `primary` | `--theme-primary` | `color/brand/primary` | `#087990` |
| `primary-hover` | `--button-primary-background-hover` | `component/button/primary/background/hover` | `#066173` |
| `secondary` | `--theme-secondary` | `color/brand/secondary` | `#e07b39` |
| `secondary-emphasis` | `--color-status-secondary-emphasis` | `color/status/secondary/emphasis` | `#864a22` |
| `success` / `danger` / `warning` / `info` | `--color-status-*` | `color/status/*` | `#198754` / `#dc3545` / `#ffc107` / `#0dcaf0` |
| `warning-emphasis` / `info-emphasis` | `--color-status-*-emphasis` | `color/status/*/emphasis` | `#7a6100` / `#0a6c8a` |
| `neutral-100` / `neutral-600` | `--color-neutral-*` | `color/neutral/*` | `#f8f9fa` / `#6c757d` |
| `text` | `--color-text-default` | `color/text/default` | `#212529` |
| `text-muted` | `--color-text-muted` | *(alias of `color/neutral/600`)* | `#6c757d` |
| `white` / `black` / `near-black` | `--primitive-neutral-*` | `primitive/neutral/*` | `#ffffff` / `#000000` / `#1a1916` |
| `yellow-{100,200,800}` | `--primitive-yellow-*` | `primitive/yellow/*` | `#fff3cd` / `#ffe69c` / `#664d03` |
| spacing `0,1,1.5,2,2.5,3,4,5,6` | `--spacing-{0,4,6,8,10,12,16,20,24}` | `spacing/*` | `0,4,6,8,10,12,16,20,24 px` |
| `rounded-sm` / `rounded` / `rounded-md` | `--radius-{4,8}` | `radius/{4,8}` | `4px` / `8px` |
| `border-1` | `--stroke-width-1` | `stroke-width/1` | `1px` |
| `font-base` / `font-sans` | `--font-family-base` | Text Style *Roboto* | `Roboto, …` |
| `font-mono` | `--font-family-mono` | *(no Figma counterpart — see D2)* | `ui-monospace, …` |
| `text-h1…h6` / `text-body` | `--font-size-{h1…h6,body}` | Text Styles *Heading/H1…H6*, *Body/Regular* | `40/32/28/24/20/16/16 px` |
| `leading-heading` / `leading-body` | `--line-height-{heading,body}` | Text Styles | `1.2` / `1.5` |
| `font-regular` | `--font-weight-regular` | Text Style *Roboto Regular* | `400` |
| `opacity-disabled` | `--opacity-disabled` | *(Bootstrap default — see D5)* | `0.65` |

---

## Token deviations

Every place the codebase diverges from the raw Figma Variable set.

### D1 — `spacing/6` and `spacing/12` value correction *(fixed 2026-07-06)*
The pre-2026-07-06 token file carried `--spacing-6: 7px` and `--spacing-12: 13px`,
sampled from Dev Mode design-context measurements. The authoritative Figma Variables
API reports `spacing/6 = 6` and `spacing/12 = 12` (matching Bootstrap's button padding
`0.375rem / 0.75rem`). Both were corrected to `6px` / `12px`.
- **Impact:** `py-1.5`/`p-1.5` and `px-3`/`p-3` shift by 1px — Button, IconWrapper,
  Callout, CodeBlock padding. Now pixel-accurate to Figma. **Re-run `/visual-verify`.**

### D2 — `--font-family-mono` created during implementation
CodeBlock renders monospace (`font-mono`). Figma defines **no** monospace Text Style or
Variable, so there was no source token; `font-mono` was silently resolving to Tailwind's
built-in default stack. Added `--font-family-mono` to `tokens.css` and `fontFamily.mono`
to the Tailwind config so the utility is token-backed. No Figma counterpart exists to
sync back to; this token originates in code by design.

### D3 — Button hover uses a brightness filter, not Figma's explicit hover Variables
Figma defines exact per-type hover/active colors
(`component/button/{danger,success,info,warning,secondary,dark,light}/background/hover`,
plus `.../border/*`). The implementation intentionally uses `hover:brightness-95` /
`active:brightness-90` (and `brightness-125/150` for `dark`) instead, to keep the token
surface small. **Only `primary` uses its explicit Figma hover token**
(`--button-primary-background-hover`).
- **Consequence:** non-primary hover colors are close to, but not pixel-identical to,
  Figma's specified hover values (e.g. `danger` hover ≈ `brightness-95` of `#dc3545`
  vs Figma `#bb2d3b`). Accepted per visual-verify. The unused explicit hover/border
  Variables are catalogued in `specs/token-gaps.md`; adopt them if exact parity is required.

### D4 — `text-muted` is an alias of `color/neutral/600`
Figma has no `color/text/muted` Variable. `--color-text-muted` reuses the
`color/neutral/600` value (`#6c757d`) for muted body text (Text/Paragraph `muted`).

### D5 — `opacity-disabled` has no Figma Variable
`--opacity-disabled: 0.65` is Bootstrap's `$btn-disabled-opacity`. Figma encodes disabled
state visually, not as a Variable. Kept in code for the `disabled:` utility.

### D6 — `tokens.css` is a scoped subset of the Figma system
The token file contains only what the 11 built components consume. Figma's full system
(extended brand ramps, default shadow, extra spacing/radius steps, accent/cyan/red/green
primitives) is **not** mirrored yet. Full inventory of the gap: `specs/token-gaps.md`.

---

## Component inventory (11) → token dependencies

| Component | Tier | Notable tokens |
|---|---|---|
| Button | atom | brand/status colors, `primary-hover`, spacing 6/8/12/16, radius 4/8, stroke-1, `opacity-disabled` |
| Text | atom | `text`, `text-muted`, `primary`, body type |
| Paragraph | atom | `text`, `text-muted`, body type |
| Icon | atom | spacing 16/20/24 (sizing), `currentColor` |
| IconWrapper | atom | `neutral-100`, `primary`, `secondary`, `near-black`, spacing 8/10/12, radius 8 |
| Logo | atom | `primary`, Heading type H3/H5/H6 |
| Title | molecule | `text`, Heading type H1–H6, spacing 4 |
| PageTitle | molecule | Heading + Body type, spacing 8 |
| Callout | molecule | status + `*-emphasis` colors, `neutral-100`, spacing 8/12, radius 8, stroke-1 |
| CodeBlock | molecule | `neutral-100`, `near-black`, `text`, `white`, **`font-mono`**, spacing 12, radius 8 |
| Header | organism | `white`, `neutral` border, spacing 8/16, stroke-1 |

---

## Figma Variable collections (authoritative, read 2026-07-06)

| Collection | Count | Mirrored in `tokens.css`? |
|---|---|---|
| Primitive / Color | 18 (brand ramps 100–900) | Partial — only `-500` steps + `primary/600` |
| Semantic / Color | 47 | Partial — status, neutral, brand, text, button-primary-hover |
| Primitive / Spacing | 20 | Partial — 9 of 20 steps used |
| Primitive / Radius | 5 | Partial — `4`, `8` (not `none`, `5`, `6`) |
| Primitive / Stroke | 1 | Yes — `stroke-width/1` |
| Primitive / Effects | 4 (default shadow) | **No** — no shadow token in code yet |

Typography is not modelled as Variables in this file — it lives in Text Styles
(Heading/H1–H6, Body/Regular) and is mirrored under the `--font-*` / `--line-height-*`
tokens.
</content>
</invoke>
