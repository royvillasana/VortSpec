---
version: alpha
name: Design Engineering System
description: >-
  Bootstrap-derived, teal-and-orange design system for documentation and
  product UI. Tokens are verified 1:1 against the Figma Variables API; 34
  React + TypeScript components (CVA + cn() + forwardRef) consume them through
  a Tailwind theme mapping. Token file of record: src/styles/tokens.css.

colors:
  # --- Brand / theme -------------------------------------------------------
  primary: "#087990"
  primary-hover: "#066173"
  secondary: "#e07b39"
  secondary-emphasis: "#864a22"
  # --- Status / semantic ---------------------------------------------------
  success: "#198754"
  danger: "#dc3545"
  warning: "#ffc107"
  info: "#0dcaf0"
  warning-emphasis: "#7a6100"
  info-emphasis: "#0a6c8a"
  secondary-dark: "#2d190b"
  secondary-light: "#f3cab0"
  info-light: "#3dd5f3"
  info-medium: "#25cff2"
  warning-light: "#ffcd39"
  # --- Neutral scale -------------------------------------------------------
  neutral-100: "#f8f9fa"
  neutral-300: "#dee2e6"
  neutral-600: "#6c757d"
  neutral-900: "#1a1e21"
  neutral-muted: "#babbbc"
  # --- Text ----------------------------------------------------------------
  text: "#212529"
  text-muted: "#6c757d"
  # --- Primitive neutrals --------------------------------------------------
  white: "#ffffff"
  black: "#000000"
  near-black: "#1a1916"
  # --- Yellow ramp ---------------------------------------------------------
  yellow-100: "#fff3cd"
  yellow-200: "#ffe69c"
  yellow-800: "#664d03"
  # --- Brand primary ramp --------------------------------------------------
  brand-primary-100: "#e6f2f4"
  brand-primary-200: "#9cc9d3"
  brand-primary-300: "#6bafbc"
  brand-primary-400: "#3994a6"
  brand-primary-500: "#087990"
  brand-primary-600: "#066173"
  brand-primary-700: "#054956"
  brand-primary-800: "#03303a"
  brand-primary-900: "#02181d"
  # --- Brand secondary ramp ------------------------------------------------
  brand-secondary-100: "#fcf2eb"
  brand-secondary-200: "#f3cab0"
  brand-secondary-300: "#ecb088"
  brand-secondary-400: "#e69561"
  brand-secondary-500: "#e07b39"
  brand-secondary-600: "#b3622e"
  brand-secondary-700: "#864a22"
  brand-secondary-800: "#5a3117"
  brand-secondary-900: "#2d190b"
  # --- Accent + status primitives -----------------------------------------
  accent-purple: "#7b61ff"
  red-600: "#b02a37"
  green-600: "#146c43"
  cyan-100: "#cff4fc"
  cyan-200: "#9eeaf9"
  cyan-800: "#055160"
  purple-500: "#6f42c1"
  # --- Explicit Button per-type hover/border (catalogued; see Design Decisions D3) ---
  button-secondary-hover: "#5c636a"
  button-success-hover: "#157347"
  button-danger-hover: "#bb2d3b"
  button-warning-hover: "#ffca2c"
  button-info-hover: "#31d2f2"
  button-light-hover: "#d3d4d5"
  button-dark-hover: "#1c1f23"
  button-secondary-border-hover: "#b3622e"
  button-secondary-border-active: "#51585e"
  button-success-border-active: "#13653f"
  button-danger-border-active: "#a52834"
  button-warning-border-hover: "#ffc720"

typography:
  h1:
    fontFamily: 'Roboto, system-ui, -apple-system, "Segoe UI", sans-serif'
    fontSize: 40px
    fontWeight: 400
    lineHeight: 1.2
  h2:
    fontFamily: 'Roboto, system-ui, -apple-system, "Segoe UI", sans-serif'
    fontSize: 32px
    fontWeight: 400
    lineHeight: 1.2
  h3:
    fontFamily: 'Roboto, system-ui, -apple-system, "Segoe UI", sans-serif'
    fontSize: 28px
    fontWeight: 400
    lineHeight: 1.2
  h4:
    fontFamily: 'Roboto, system-ui, -apple-system, "Segoe UI", sans-serif'
    fontSize: 24px
    fontWeight: 400
    lineHeight: 1.2
  h5:
    fontFamily: 'Roboto, system-ui, -apple-system, "Segoe UI", sans-serif'
    fontSize: 20px
    fontWeight: 400
    lineHeight: 1.2
  h6:
    fontFamily: 'Roboto, system-ui, -apple-system, "Segoe UI", sans-serif'
    fontSize: 16px
    fontWeight: 400
    lineHeight: 1.2
  body:
    fontFamily: 'Roboto, system-ui, -apple-system, "Segoe UI", sans-serif'
    fontSize: 16px
    fontWeight: 400
    lineHeight: 1.5
  code:
    fontFamily: 'ui-monospace, "SFMono-Regular", "SF Mono", Menlo, Consolas, "Liberation Mono", monospace'
    fontSize: 16px
    fontWeight: 400
    lineHeight: 1.5

rounded:
  none: 0px
  sm: 4px
  "5": 5px
  "6": 6px
  md: 8px
  full: 9999px

spacing:
  base: 16px
  "0": 0px
  "4": 4px
  "6": 6px
  "8": 8px
  "10": 10px
  "12": 12px
  "16": 16px
  "18": 18px
  "19": 19px
  "20": 20px
  "24": 24px
  "28": 28px
  "32": 32px
  "50": 50px
  "72": 72px
  "80": 80px
  "82": 82px
  "100": 100px
  "190": 190px
  "225": 225px

components:
  # ---- Atoms --------------------------------------------------------------
  button:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.white}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
  button-hover:
    backgroundColor: "{colors.primary-hover}"
    textColor: "{colors.white}"
  button-outline:
    backgroundColor: "transparent"
    textColor: "{colors.primary}"
    rounded: "{rounded.md}"
  button-warning:
    backgroundColor: "{colors.warning}"
    textColor: "{colors.near-black}"
  button-link:
    backgroundColor: "transparent"
    textColor: "{colors.primary}"
  icon:
    textColor: "{colors.text}"
    size: 20px
  icon-wrapper:
    backgroundColor: "{colors.neutral-100}"
    textColor: "{colors.text}"
    rounded: "{rounded.md}"
    padding: 10px
  icon-wrapper-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.white}"
  text:
    textColor: "{colors.text}"
    typography: "{typography.body}"
  text-muted:
    textColor: "{colors.text-muted}"
  text-link:
    textColor: "{colors.primary}"
  paragraph:
    textColor: "{colors.text}"
    typography: "{typography.body}"
  logo:
    textColor: "{colors.primary}"
    typography: "{typography.h5}"
  tag:
    backgroundColor: "{colors.neutral-600}"
    textColor: "{colors.white}"
    typography: "{typography.body}"
    rounded: "{rounded.sm}"
  tag-danger:
    backgroundColor: "{colors.danger}"
    textColor: "{colors.white}"
  tag-warning:
    backgroundColor: "{colors.warning}"
    textColor: "{colors.near-black}"
  textarea:
    backgroundColor: "{colors.white}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
  checkbox:
    backgroundColor: "{colors.white}"
    rounded: "{rounded.sm}"
    size: 20px
  checkbox-checked:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.white}"
  radio:
    backgroundColor: "{colors.white}"
    rounded: "{rounded.full}"
    size: 20px
  radio-checked:
    backgroundColor: "{colors.primary}"
  switch:
    backgroundColor: "{colors.neutral-300}"
    rounded: "{rounded.full}"
    width: 32px
    height: 20px
  switch-checked:
    backgroundColor: "{colors.primary}"
  slider:
    textColor: "{colors.primary}"
    rounded: "{rounded.md}"
    height: 20px
  rating:
    textColor: "{colors.warning}"
    size: 20px
  # ---- Molecules ----------------------------------------------------------
  title:
    textColor: "{colors.text}"
    typography: "{typography.h2}"
  page-title:
    textColor: "{colors.text}"
    typography: "{typography.h1}"
  callout:
    backgroundColor: "{colors.neutral-100}"
    textColor: "{colors.info-emphasis}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
    padding: 12px
  callout-warning:
    textColor: "{colors.warning-emphasis}"
  callout-danger:
    textColor: "{colors.danger}"
  callout-success:
    textColor: "{colors.success}"
  code-block:
    backgroundColor: "{colors.neutral-100}"
    textColor: "{colors.text}"
    typography: "{typography.code}"
    rounded: "{rounded.md}"
    padding: 12px
  code-block-dark:
    backgroundColor: "{colors.near-black}"
    textColor: "{colors.white}"
  input:
    backgroundColor: "{colors.white}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
  input-number:
    backgroundColor: "{colors.white}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
  select:
    backgroundColor: "{colors.white}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
  date-picker:
    backgroundColor: "{colors.white}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
  time-picker:
    backgroundColor: "{colors.white}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
  file-input:
    textColor: "{colors.text}"
    typography: "{typography.body}"
  form-floating:
    backgroundColor: "{colors.white}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
  nav-item:
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
  nav-item-active:
    backgroundColor: "{colors.brand-primary-100}"
    textColor: "{colors.primary}"
  breadcrumb:
    textColor: "{colors.text}"
    typography: "{typography.body}"
  dropdown-menu:
    backgroundColor: "{colors.white}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.sm}"
  dropdown-menu-active:
    backgroundColor: "{colors.brand-primary-100}"
    textColor: "{colors.primary}"
  list-group:
    textColor: "{colors.text}"
    typography: "{typography.body}"
  list-group-active:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.white}"
  accordion:
    backgroundColor: "{colors.white}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
  # ---- Organisms ----------------------------------------------------------
  header:
    backgroundColor: "{colors.white}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
  navbar:
    backgroundColor: "{colors.white}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
  tabs:
    textColor: "{colors.text-muted}"
    typography: "{typography.body}"
  tab-active:
    textColor: "{colors.primary}"
  table:
    textColor: "{colors.text}"
    typography: "{typography.body}"
  table-header:
    backgroundColor: "{colors.neutral-100}"
    textColor: "{colors.text}"
  upload:
    backgroundColor: "{colors.neutral-100}"
    textColor: "{colors.text}"
    rounded: "{rounded.md}"
    padding: 24px
  upload-drag-active:
    backgroundColor: "{colors.brand-primary-100}"
    textColor: "{colors.primary}"
---

# Design Engineering System

The AI hand-off manifest for this design system. The YAML frontmatter above is
the machine-readable token + component contract; the prose below is the intent,
usage, and file index. Every component entry points to real, implemented files
in `src/components`. Read this before composing any screen.

- **Framework:** React + TypeScript · **Styling:** Tailwind CSS
- **Token file of record:** `src/styles/tokens.css`
- **Design source:** Figma — *Design Engineering System* (`ojko9pGfsDAvmUf2DA38d2`)
- **Component pattern:** CVA variants (`*.variants.ts`) + `cn()` merge + `forwardRef`
- **Decisions log:** `.sdd-de/design-decisions.md` (token mappings + every deviation)

## Overview

The Design Engineering System is a **Bootstrap-derived documentation and product
UI kit** re-skinned around a customized teal primary (`#087990`) and a warm
orange secondary (`#e07b39`). It should feel **clean, technical, and
trustworthy** — the voice of engineering documentation rather than marketing.
Surfaces are light and high-contrast, chrome is minimal (1px borders and tinted
neutral fills instead of heavy shadows), and interactive accents are reserved so
the single teal action color always reads as "the thing to click." The system
favors **density with breathing room**: compact controls on a disciplined
spacing rhythm, generous line-height for long-form reading, and Roboto
throughout for a neutral, screen-optimized tone.

## Colors

The palette is rooted in a high-contrast neutral scale with two brand accents
and a full Bootstrap-aligned status set.

- **Primary — Deep Teal (`#087990`):** The sole driver of interaction — primary
  buttons, links, active states, focus rings, checked form controls. `primary-hover`
  (`#066173`) is the one explicitly-tokenized hover (see Design Decision D3).
- **Secondary — Burnt Orange (`#e07b39`):** Supporting brand accent for subtitles,
  secondary emphasis, and the `secondary` control type. `secondary-emphasis`
  (`#864a22`) is the readable text-on-tint variant.
- **Status — success / danger / warning / info:** Standard Bootstrap semantics
  (`#198754` / `#dc3545` / `#ffc107` / `#0dcaf0`). Each has an `-emphasis` or
  tint variant for readable text on subtle backgrounds (used by Callout, Tag,
  outline Buttons).
- **Neutral scale (`neutral-100 → neutral-900`):** Warm grays for surfaces,
  borders (`neutral-300`), and muted text (`neutral-600`). `neutral-100` is the
  default subtle surface (code blocks, header/table headers, icon wrappers).
- **Text:** `text` (`#212529`) for body and headings; `text-muted` (`#6c757d`,
  an alias of `neutral-600` — see D4) for secondary copy.
- **Brand ramps (`brand-primary-*`, `brand-secondary-*`):** Full 100–900 tints
  for future use; `brand-primary-100` powers active/selected surfaces on
  NavItem, DropdownMenu, ListGroup, and the Upload drag-over state.

**Usage:** one primary action per view; status colors only for their semantic
meaning; neutrals carry structure. `color/brand/*` semantic aliases exist in
Figma but resolve to the same values as `primary`/`secondary`.

## Typography

A single family — **Roboto** (with a system-ui fallback stack) — carries the
entire UI. Type roles are expressed as size + line-height rather than weight;
everything is Roboto Regular (`400`).

- **Headings (`h1`–`h6`, 40 → 16px):** Line-height `1.2`. Used by Title (H1–H6),
  PageTitle (H1 + an uppercase H6 eyebrow), and Logo (H3/H5/H6 by size).
- **Body (`body`, 16px / 1.5):** The workhorse for all controls, labels, links,
  paragraphs, and table cells. Line-height `1.5` optimizes long-form reading.
- **Code (`code`, 16px / 1.5, monospace):** A code-only monospace stack used by
  CodeBlock. No Figma counterpart exists — this token originates in code (D2).

Weight is intentionally uniform (`400`); hierarchy comes from size, color, and
spacing, not boldness.

## Layout

Spacing follows a **Bootstrap-aligned pixel scale** rooted on a `16px` base with
sub-steps for control padding (`4 / 6 / 8 / 10 / 12`) and larger steps for page
rhythm (`16 / 20 / 24 …` up to `225`). The scale is effectively linear with
practical half-steps rather than a strict geometric ratio.

- **Control padding:** small `4–8px`, medium `8–12px`, large `12–16px`. Buttons,
  inputs, selects, and pickers share this density ladder via mirrored `size`
  axes (`small | medium | large`).
- **Component gaps:** `4–8px` inside atoms, `12–16px` between grouped elements
  and section chrome (header `px-16 py-8`, table cells `px-12 py-8`).
- **Containers:** the Upload dragger and page sections use `24px` internal
  padding for an approachable, uncramped feel.

Only the subset of the scale that components consume is bound to Tailwind;
the full scale (up to `225px`) is documented for layout composition.

## Elevation & Depth

Depth is **almost entirely flat** — hierarchy is conveyed with 1px
`neutral-300` borders, tinted `neutral-100` surfaces, and color contrast rather
than shadows. This keeps the documentation aesthetic crisp and technical.

One shadow token exists for genuinely floating surfaces (menus, overlays):

```
--shadow-default: 0px 8px 16px 0px rgba(0, 0, 0, 0.15);
```

(offset-x 0, offset-y 8px, blur 16px, spread 0, color `#00000026`). The Switch
thumb uses a light built-in `shadow` for lift; most components use borders
instead of elevation.

## Shapes

Corners are gently rounded, never sharp-cornered and never fully pill unless the
control is inherently circular.

- **`sm` (4px):** Small/compact controls and focusable inline affordances —
  small Buttons, Tags, Checkbox boxes, focus-ring wrappers, DropdownMenu items.
- **`md` (8px):** The default surface radius — medium/large Buttons, inputs,
  selects, pickers, Callout, CodeBlock, IconWrapper, Accordion, Upload dragger,
  NavItem.
- **`full` (9999px):** Circular/pill controls only — Radio, Switch track + thumb.
  This is Tailwind's pill radius, not a Figma variable.
- **`none` (0px):** Full-bleed chrome (Header, Navbar) has square edges.
- **`5px` / `6px`** exist in the token set (from Figma) but are not currently
  consumed by components.

## Components

Every entry references the **actual files in the project**. When composing
screens, import from the `@/components` barrel, check variants in the linked
`*.variants.ts` file, and preview in Storybook (`npm run storybook` →
`http://localhost:6006`). Story titles are flat, so the canonical docs path is
`/docs/<componentname>--docs`; the category-scoped URLs below match the
atomic tier.

### Atoms

#### Button

Primary interactive control; mirrors the Figma Button set 1:1.

| | |
|---|---|
| **Component** | `src/components/ui/Button.tsx` |
| **Variants** | `src/components/ui/button.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/atoms-button |
| **Spec** | `specs/button/button-component-spec.md` |

- `variant`: base · primary · secondary · success · danger · warning · info · light · dark · link
- `size`: small · medium · large
- `outline`: true · false · `iconOnly`: true · false
- **Default:** `variant="primary"` `size="medium"`

```tsx
import { Button } from '@/components';

<Button variant="primary" size="medium">Save</Button>
<Button variant="danger" outline size="small">Delete</Button>
<Button variant="secondary" iconOnly aria-label="Settings" className="ml-2" />
```

**Tokens:** `{colors.primary}`, `{colors.primary-hover}`, `{colors.white}`, status colors, `{typography.body}`, `{rounded.md}`, `{rounded.sm}`.

#### Icon

Single-glyph SVG; sized via `size`, colored via `currentColor`.

| | |
|---|---|
| **Component** | `src/components/ui/Icon.tsx` |
| **Variants** | `src/components/ui/icon.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/atoms-icon |
| **Spec** | `specs/icon/icon-component-spec.md` |

- `size`: small (16px) · medium (20px) · large (24px)
- `name`: registered glyph name (`IconName`); `label` sets an accessible name (else decorative).

```tsx
import { Icon } from '@/components';

<Icon name="chevron-right" size="small" label="Next" />
<Icon name="star-fill" className="text-warning" />
```

**Tokens:** inherits `currentColor` (e.g. `{colors.text}`), spacing-based sizing.

#### IconWrapper

Fixed square container placing an Icon on a tinted surface.

| | |
|---|---|
| **Component** | `src/components/ui/IconWrapper.tsx` |
| **Variants** | `src/components/ui/icon-wrapper.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/atoms-iconwrapper |
| **Spec** | `specs/icon-wrapper/icon-wrapper-component-spec.md` |

- `size`: small · medium · large · `tone`: default · primary · secondary · dark
- **Default:** `size="medium"` `tone="default"`

```tsx
import { IconWrapper, Icon } from '@/components';

<IconWrapper tone="primary"><Icon name="mail" label="Email" /></IconWrapper>
```

**Tokens:** `{colors.neutral-100}`, `{colors.primary}`, `{colors.secondary}`, `{colors.near-black}`, `{rounded.md}`, spacing padding.

#### Text

Single-line body / link text with optional leading/trailing icon.

| | |
|---|---|
| **Component** | `src/components/ui/Text.tsx` |
| **Variants** | `src/components/ui/text.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/atoms-text |
| **Spec** | `specs/text/text-component-spec.md` |

- `variant`: primary · muted · link · bullet — **Default:** `variant="primary"`

```tsx
import { Text } from '@/components';

<Text>Inline label</Text>
<Text variant="link" href="/docs">Read the docs</Text>
```

**Tokens:** `{colors.text}`, `{colors.text-muted}`, `{colors.primary}`, `{typography.body}`.

#### Paragraph

Multi-line body copy that fills its container width (distinct from single-line Text).

| | |
|---|---|
| **Component** | `src/components/ui/Paragraph.tsx` |
| **Variants** | `src/components/ui/paragraph.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/atoms-paragraph |
| **Spec** | `specs/paragraph/paragraph-component-spec.md` |

- `tone`: default · muted — **Default:** `tone="default"`

```tsx
import { Paragraph } from '@/components';

<Paragraph>Long-form body copy that wraps and fills its column.</Paragraph>
<Paragraph tone="muted">Secondary supporting text.</Paragraph>
```

**Tokens:** `{colors.text}`, `{colors.text-muted}`, `{typography.body}`.

#### Logo

Brand/product mark; scales with Heading typography.

| | |
|---|---|
| **Component** | `src/components/ui/Logo.tsx` |
| **Variants** | `src/components/ui/logo.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/atoms-logo |
| **Spec** | `specs/logo/logo-component-spec.md` |

- `size`: small (H6) · medium (H5) · large (H3) — **Default:** `size="medium"`

```tsx
import { Logo } from '@/components';

<Logo size="small" href="/" />
```

**Tokens:** `{colors.primary}`, `{colors.white}` (inner mark), `{typography.h5}`.

#### Tag

Small inline label/chip; color set mirrors Button types.

| | |
|---|---|
| **Component** | `src/components/ui/Tag.tsx` |
| **Variants** | `src/components/ui/tag.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/atoms-tag |
| **Spec** | `specs/tag/tag-component-spec.md` |

- `variant`: base · primary · secondary · success · danger · warning · info · light · dark
- `size`: small · medium — **Default:** `variant="base"` `size="medium"`

```tsx
import { Tag } from '@/components';

<Tag variant="success" size="small">Active</Tag>
<Tag variant="danger">Error</Tag>
```

**Tokens:** `{colors.neutral-600}`, status colors, `{colors.white}`, `{colors.near-black}`, `{rounded.sm}`, `{typography.body}`.

#### Textarea

Styled native `<textarea>` for multi-line editing.

| | |
|---|---|
| **Component** | `src/components/ui/Textarea.tsx` |
| **Variants** | `src/components/ui/textarea.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/atoms-textarea |
| **Spec** | `specs/textarea/textarea-component-spec.md` |

- `size`: small · medium · large · `invalid`: true · false — **Default:** `size="medium"` `invalid={false}`

```tsx
import { Textarea } from '@/components';

<Textarea size="medium" placeholder="Notes…" />
<Textarea invalid aria-label="Bio" />
```

**Tokens:** `{colors.white}`, `{colors.text}`, `{colors.neutral-300}` (border), `{colors.danger}` (invalid), `{rounded.md}`, `{typography.body}`.

#### Checkbox

Custom visual box mirroring a native `<input type="checkbox">` peer.

| | |
|---|---|
| **Component** | `src/components/ui/Checkbox.tsx` |
| **Variants** | `src/components/ui/checkbox.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/atoms-checkbox |
| **Spec** | `specs/checkbox/checkbox-component-spec.md` |

- `size`: small (16px) · medium (20px) · large (24px); supports checked / indeterminate — **Default:** `size="medium"`

```tsx
import { Checkbox } from '@/components';

<Checkbox label="Accept terms" />
<Checkbox indeterminate label="Select all" />
```

**Tokens:** `{colors.white}`, `{colors.primary}` (checked), `{colors.neutral-300}` (border), `{rounded.sm}`.

#### Radio

Styled native `<input type="radio">` with circle + inner dot.

| | |
|---|---|
| **Component** | `src/components/ui/Radio.tsx` |
| **Variants** | `src/components/ui/radio.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/atoms-radio |
| **Spec** | `specs/radio/radio-component-spec.md` |

- `size`: small · medium · large — **Default:** `size="medium"`

```tsx
import { Radio } from '@/components';

<Radio name="plan" value="pro" label="Pro" defaultChecked />
```

**Tokens:** `{colors.white}`, `{colors.primary}` (checked), `{colors.neutral-300}`, `{rounded.full}`.

#### Switch

Accessible on/off toggle (`role="switch"`) on a real checkbox.

| | |
|---|---|
| **Component** | `src/components/ui/Switch.tsx` |
| **Variants** | `src/components/ui/switch.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/atoms-switch |
| **Spec** | `specs/switch/switch-component-spec.md` |

- `size`: small · medium · large — **Default:** `size="medium"`

```tsx
import { Switch } from '@/components';

<Switch label="Email notifications" defaultChecked />
```

**Tokens:** `{colors.neutral-300}` (track off), `{colors.primary}` (on), `{colors.white}` (thumb), `{rounded.full}`, `--shadow-default`.

#### Slider

Styled native `<input type="range">` (accent-colored track/handle).

| | |
|---|---|
| **Component** | `src/components/ui/Slider.tsx` |
| **Variants** | `src/components/ui/slider.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/atoms-slider |
| **Spec** | `specs/slider/slider-component-spec.md` |

- `size`: small · medium · large — **Default:** `size="medium"`

```tsx
import { Slider } from '@/components';

<Slider min={0} max={100} defaultValue={50} aria-label="Volume" />
```

**Tokens:** `{colors.primary}` (`accent-color`), `{rounded.md}`.

#### Rating

Star rating control (`radiogroup` of star buttons).

| | |
|---|---|
| **Component** | `src/components/ui/Rating.tsx` |
| **Variants** | `src/components/ui/rating.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/atoms-rating |
| **Spec** | `specs/rating/rating-component-spec.md` |

- `size`: small · medium · large; `max` stars configurable — **Default:** `size="medium"`

```tsx
import { Rating } from '@/components';

<Rating max={5} defaultValue={4} onChange={(v) => console.log(v)} />
```

**Tokens:** `{colors.warning}` (filled), `{colors.neutral-300}` (empty).

### Molecules

#### Title

**Composes:** Icon, (optional) Tag. Heading text with optional subtitle, badge, and icons.

| | |
|---|---|
| **Component** | `src/components/modules/Title.tsx` |
| **Variants** | `src/components/modules/title.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-title |
| **Spec** | `specs/title/title-component-spec.md` |

- `level`: 1–6 (H1–H6) · `fillContainer`: true · false — **Default:** `level={2}` `fillContainer={false}`

```tsx
import { Title } from '@/components';

<Title level={2} subtitle="Overview">Getting started</Title>
```

**Tokens:** `{colors.text}`, `{colors.secondary}` (subtitle), `{typography.h2}`.

#### PageTitle

The large page-heading block: uppercase eyebrow (H6) + H1 + muted description.

| | |
|---|---|
| **Component** | `src/components/modules/PageTitle.tsx` |
| **Variants** | `src/components/modules/page-title.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-pagetitle |
| **Spec** | `specs/page-title/page-title-component-spec.md` |

- `align`: left · center — **Default:** `align="left"`

```tsx
import { PageTitle } from '@/components';

<PageTitle title="Components" description="The building blocks of the system.">
  Design tokens
</PageTitle>
```

**Tokens:** `{colors.text}`, `{colors.text-muted}` (eyebrow/description), `{typography.h1}`, `{typography.h6}`.

#### Callout

**Composes:** Icon. Status message box on a tinted neutral surface with status border.

| | |
|---|---|
| **Component** | `src/components/modules/Callout.tsx` |
| **Variants** | `src/components/modules/callout.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-callout |
| **Spec** | `specs/callout/callout-component-spec.md` |

- `status`: info · warning · success · danger · secondary — **Default:** `status="info"`

```tsx
import { Callout } from '@/components';

<Callout status="warning" title="Heads up">This action can't be undone.</Callout>
```

**Tokens:** `{colors.neutral-100}`, status border colors, `{colors.info-emphasis}`/`{colors.warning-emphasis}`/etc., `{rounded.md}`, `{typography.body}`.

#### CodeBlock

Formatted code snippet surface (monospace).

| | |
|---|---|
| **Component** | `src/components/modules/CodeBlock.tsx` |
| **Variants** | `src/components/modules/code-block.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-codeblock |
| **Spec** | `specs/code-block/code-block-component-spec.md` |

- `tone`: neutral · dark — **Default:** `tone="neutral"`

```tsx
import { CodeBlock } from '@/components';

<CodeBlock tone="neutral">{`npm install`}</CodeBlock>
<CodeBlock tone="dark">{`git commit -m "feat"`}</CodeBlock>
```

**Tokens:** `{colors.neutral-100}`, `{colors.near-black}` (dark), `{colors.text}`, `{colors.white}`, `{typography.code}`, `{rounded.md}`.

#### Input

**Composes:** label + native `<input>` + hint/error. Labeled text field.

| | |
|---|---|
| **Component** | `src/components/modules/Input.tsx` |
| **Variants** | `src/components/modules/input.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-input |
| **Spec** | `specs/input/input-component-spec.md` |

- `size`: small · medium · large · `orientation`: vertical · horizontal (via `error` prop → invalid) — **Default:** `size="medium"` `orientation="vertical"`

```tsx
import { Input } from '@/components';

<Input label="Email" hint="We'll never share it." />
<Input label="Email" error="Invalid address" orientation="horizontal" />
```

**Tokens:** `{colors.white}`, `{colors.text}`, `{colors.neutral-300}`, `{colors.danger}` (invalid), `{rounded.md}`, `{typography.body}`.

#### InputNumber

**Composes:** label + native `<input type="number">` stepper.

| | |
|---|---|
| **Component** | `src/components/modules/InputNumber.tsx` |
| **Variants** | `src/components/modules/input-number.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-inputnumber |
| **Spec** | `specs/input-number/input-number-component-spec.md` |

- `size`: small · medium · large · `invalid`: true · false — **Default:** `size="medium"`

```tsx
import { InputNumber } from '@/components';

<InputNumber label="Quantity" min={0} max={10} defaultValue={1} />
```

**Tokens:** `{colors.white}`, `{colors.text}`, `{colors.neutral-300}`, `{colors.danger}`, `{rounded.md}`, `{typography.body}`.

#### Select

**Composes:** Icon (caret) + native `<select>`. Single/multiple dropdown field.

| | |
|---|---|
| **Component** | `src/components/modules/Select.tsx` |
| **Variants** | `src/components/modules/select.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-select |
| **Spec** | `specs/select/select-component-spec.md` |

- `size`: small · medium · large · `invalid`: true · false; requires `options: SelectOption[]` — **Default:** `size="medium"`

```tsx
import { Select } from '@/components';

<Select
  label="Framework"
  placeholder="Choose one"
  options={[{ value: 'react', label: 'React' }, { value: 'vue', label: 'Vue' }]}
/>
```

**Tokens:** `{colors.white}`, `{colors.text}`, `{colors.neutral-300}`, `{rounded.md}`, `{typography.body}`.

#### DatePicker

**Composes:** Icon (calendar) + native `<input type="date">`.

| | |
|---|---|
| **Component** | `src/components/modules/DatePicker.tsx` |
| **Variants** | `src/components/modules/date-picker.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-datepicker |
| **Spec** | `specs/date-picker/date-picker-component-spec.md` |

- `size`: small · medium · large · `invalid`: true · false — **Default:** `size="medium"`

```tsx
import { DatePicker } from '@/components';

<DatePicker label="Start date" />
```

**Tokens:** `{colors.white}`, `{colors.text}`, `{colors.neutral-300}`, `{colors.danger}`, `{rounded.md}`, `{typography.body}`.

#### TimePicker

**Composes:** Icon (clock) + native `<input type="time">`.

| | |
|---|---|
| **Component** | `src/components/modules/TimePicker.tsx` |
| **Variants** | `src/components/modules/time-picker.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-timepicker |
| **Spec** | `specs/time-picker/time-picker-component-spec.md` |

- `size`: small · medium · large · `invalid`: true · false — **Default:** `size="medium"`

```tsx
import { TimePicker } from '@/components';

<TimePicker label="Reminder" />
```

**Tokens:** `{colors.white}`, `{colors.text}`, `{colors.neutral-300}`, `{rounded.md}`, `{typography.body}`.

#### FileInput

**Composes:** Button (trigger). File-chooser field; `size` mirrors Button.

| | |
|---|---|
| **Component** | `src/components/modules/FileInput.tsx` |
| **Variants** | `src/components/modules/file-input.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-fileinput |
| **Spec** | `specs/file-input/file-input-component-spec.md` |

- `size`: small · medium · large — **Default:** `size="medium"`

```tsx
import { FileInput } from '@/components';

<FileInput label="Attachment" accept=".pdf" />
```

**Tokens:** `{colors.text}`, Button tokens (trigger), `{typography.body}`.

#### FormFloating

**Composes:** floating `<label>` over `<input>`/`<textarea>`/`<select>`.

| | |
|---|---|
| **Component** | `src/components/modules/FormFloating.tsx` |
| **Variants** | `src/components/modules/form-floating.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-formfloating |
| **Spec** | `specs/form-floating/form-floating-component-spec.md` |

- `error`: true · false; `as`: input · textarea · select — **Default:** `error={false}`

```tsx
import { FormFloating } from '@/components';

<FormFloating label="Email" type="email" />
<FormFloating label="Bio" as="textarea" error />
```

**Tokens:** `{colors.white}`, `{colors.text}`, `{colors.neutral-300}`, `{colors.danger}`, `{rounded.md}`, `{typography.body}`.

#### NavItem

Single navigation link across orientations and depths.

| | |
|---|---|
| **Component** | `src/components/modules/NavItem.tsx` |
| **Variants** | `src/components/modules/nav-item.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-navitem |
| **Spec** | `specs/nav-item/nav-item-component-spec.md` |

- `orientation`: horizontal · vertical · inline · `level`: 1 · 2 · 3 · `active` / `disabled`: boolean — **Default:** `orientation="horizontal"` `level={1}`

```tsx
import { NavItem } from '@/components';

<NavItem href="/docs" active>Docs</NavItem>
<NavItem orientation="inline" level={2} href="/docs/tokens">Tokens</NavItem>
```

**Tokens:** `{colors.text}`, `{colors.primary}` (active), `{colors.brand-primary-100}` (vertical/inline active surface), `{colors.neutral-100}` (hover), `{rounded.md}`.

#### Breadcrumb

**Composes:** Icon (separator), Text. Ordered navigation trail.

| | |
|---|---|
| **Component** | `src/components/modules/Breadcrumb.tsx` |
| **Variants** | `src/components/modules/breadcrumb.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-breadcrumb |
| **Spec** | `specs/breadcrumb/breadcrumb-component-spec.md` |

- `size`: md; requires `items: BreadcrumbItem[]` — **Default:** `size="md"`

```tsx
import { Breadcrumb } from '@/components';

<Breadcrumb items={[
  { label: 'Home', href: '/' },
  { label: 'Docs', href: '/docs' },
  { label: 'Buttons' },
]} />
```

**Tokens:** `{colors.text}`, `{colors.text-muted}` (separator), `{colors.primary}` (links), `{typography.body}`.

#### DropdownMenu

**Composes:** Icon. Presentational menu surface (`role="menu"`) of items, separators, group labels.

| | |
|---|---|
| **Component** | `src/components/modules/DropdownMenu.tsx` |
| **Variants** | `src/components/modules/dropdown-menu.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-dropdownmenu |
| **Spec** | `specs/dropdown-menu/dropdown-menu-component-spec.md` |

- Item state: `active` · `disabled` (per entry); requires `items: DropdownMenuEntry[]`

```tsx
import { DropdownMenu } from '@/components';

<DropdownMenu items={[
  { type: 'group-label', label: 'Account' },
  { type: 'item', label: 'Profile', href: '/me' },
  { type: 'separator' },
  { type: 'item', label: 'Sign out', onSelect: () => {}, active: true },
]} />
```

**Tokens:** `{colors.white}`, `{colors.text}`, `{colors.brand-primary-100}` + `{colors.primary}` (active), `{colors.neutral-100}` (hover), `{rounded.sm}`.

#### ListGroup

**Composes:** Tag/Icon (optional slots). Bordered vertical list of static or action rows.

| | |
|---|---|
| **Component** | `src/components/modules/ListGroup.tsx` |
| **Variants** | `src/components/modules/list-group.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-listgroup |
| **Spec** | `specs/list-group/list-group-component-spec.md` |

- Per-item: `active` · `disabled` · `href`/`onClick` (interactive); requires `items: ListGroupItem[]`

```tsx
import { ListGroup, Tag } from '@/components';

<ListGroup items={[
  { label: 'Inbox', badge: <Tag variant="primary" size="small">12</Tag>, active: true },
  { label: 'Archive', href: '/archive' },
]} />
```

**Tokens:** `{colors.text}`, `{colors.primary}` + `{colors.white}` (active), `{colors.neutral-100}` (hover), `{colors.neutral-300}` (border), `{typography.body}`.

#### Accordion

Stack of collapsible panels built on native `<details>`/`<summary>`.

| | |
|---|---|
| **Component** | `src/components/modules/Accordion.tsx` |
| **Variants** | `src/components/modules/accordion.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/molecules-accordion |
| **Spec** | `specs/accordion/accordion-component-spec.md` |

- `allowMultiple`: boolean (default true); per-item `defaultOpen` · `disabled`; requires `items: AccordionItem[]`

```tsx
import { Accordion } from '@/components';

<Accordion allowMultiple items={[
  { id: 'ship', title: 'Shipping & delivery', content: '…' },
  { id: 'ret', title: 'Returns & refunds', content: '…', defaultOpen: true },
]} />
```

**Tokens:** `{colors.white}`, `{colors.text}`, `{colors.neutral-100}` (hover), `{colors.neutral-300}` (dividers/border), `{rounded.md}`, `{typography.body}`.

### Organisms

#### Header

**Composes:** Logo, Text (nav links), Button (CTA). Documentation top bar.

| | |
|---|---|
| **Component** | `src/components/sections/Header.tsx` |
| **Variants** | `src/components/sections/header.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/organisms-header |
| **Spec** | `specs/header/header-component-spec.md` |

- `sticky`: true · false — **Default:** `sticky={false}`

```tsx
import { Header, Button } from '@/components';

<Header
  sticky
  navItems={[{ label: 'Docs', href: '/docs' }, { label: 'API', href: '/api' }]}
  cta={<Button size="small">Sign in</Button>}
/>
```

**Tokens:** `{colors.white}`, `{colors.neutral-300}` (bottom border), `{colors.text}`, `{typography.body}`.

#### Navbar

**Composes:** Logo, NavItem, Button. Responsive top navigation (brand + toggler + collapse).

| | |
|---|---|
| **Component** | `src/components/sections/Navbar.tsx` |
| **Variants** | `src/components/sections/navbar.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/organisms-navbar |
| **Spec** | `specs/navbar/navbar-component-spec.md` |

- `sticky`: true · false — **Default:** `sticky={false}`

```tsx
import { Navbar } from '@/components';

<Navbar sticky navItems={[{ label: 'Home', href: '/' }, { label: 'Docs', href: '/docs' }]} />
```

**Tokens:** `{colors.white}`, `{colors.neutral-300}`, `{colors.text}`, `{typography.body}`.

#### Tabs

Accessible tabbed interface (WAI-ARIA Tabs pattern).

| | |
|---|---|
| **Component** | `src/components/sections/Tabs.tsx` |
| **Variants** | `src/components/sections/tabs.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/organisms-tabs |
| **Spec** | `specs/tabs/tabs-component-spec.md` |

- `orientation`: top · left; per-tab `disabled`; requires `tabs: TabItem[]` — **Default:** `orientation="top"`

```tsx
import { Tabs } from '@/components';

<Tabs tabs={[
  { id: 'a', label: 'Overview', content: <p>…</p> },
  { id: 'b', label: 'Usage', content: <p>…</p> },
]} />
```

**Tokens:** `{colors.text-muted}` (inactive), `{colors.primary}` (active + indicator), `{colors.neutral-300}` (rule), `{typography.body}`.

#### Table

**Composes:** Checkbox (selectable), Icon (sort), Tag. Data table with sort + selection.

| | |
|---|---|
| **Component** | `src/components/sections/Table.tsx` |
| **Variants** | `src/components/sections/table.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/organisms-table |
| **Spec** | `specs/table/table-component-spec.md` |

- Per-column: `align` · `sortable` · `render`/`accessor`; table: `selectable`; requires `columns`, `data`, `rowKey`

```tsx
import { Table } from '@/components';

<Table
  columns={[
    { key: 'name', header: 'Name', sortable: true },
    { key: 'role', header: 'Role', align: 'right' },
  ]}
  data={[{ name: 'Ada', role: 'Eng' }]}
  rowKey={(r) => r.name}
  selectable
/>
```

**Tokens:** `{colors.text}`, `{colors.neutral-100}` (header), `{colors.neutral-300}` (row borders), `{colors.primary}` (sort/focus), `{typography.body}`.

#### Upload

**Composes:** Button (trigger), Icon. File upload with button + dragger variants.

| | |
|---|---|
| **Component** | `src/components/sections/Upload.tsx` |
| **Variants** | `src/components/sections/upload.variants.ts` |
| **Storybook** | http://localhost:6006/?path=/docs/organisms-upload |
| **Spec** | `specs/upload/upload-component-spec.md` |

- `variant`: button · dragger; runtime `dragActive` · `disabled` — **Default:** `variant="button"`

```tsx
import { Upload } from '@/components';

<Upload variant="dragger" accept="image/*" multiple />
```

**Tokens:** `{colors.neutral-100}`, `{colors.neutral-300}` (dashed border), `{colors.brand-primary-100}` + `{colors.primary}` (drag-over), `{rounded.md}`, `{typography.body}`.

## Do's and Don'ts

- **Do** reference a token for every color, spacing, radius, and font value — no hardcoded hex or px.
- **Do** import from the `@/components` barrel and pass `className` last for layout-only overrides.
- **Do** use `primary` for the single most important action per screen; keep status colors semantic.
- **Do** compose molecules/organisms from existing atoms rather than re-styling from scratch.
- **Don't** add `style={{}}` for design-system values or introduce non-token colors.
- **Don't** use fully-round (`full`) corners on rectangular surfaces — reserve it for Radio/Switch.
- **Don't** rely on shadows for hierarchy; prefer 1px borders and `neutral-100` tinted surfaces.
- **Don't** assume exact per-type Button hover parity with Figma — non-primary hovers use a brightness filter (see D3).

## Responsive Behavior

Breakpoint strategy: **375px (mobile) · 768px (tablet) · 1440px (desktop)**.

- **Typography** holds a fixed px scale across breakpoints; hierarchy is preserved by size, not fluid scaling.
- **Spacing** uses the shared scale; sections tighten toward the `12–16px` steps on mobile and open to `24px+` on desktop.
- **Navbar** collapses its links behind a toggler below the tablet breakpoint (`navbar/responsive`); **Header** keeps its inline nav on wider viewports.
- **Table** scrolls horizontally within its container on narrow viewports rather than reflowing columns.
- Form controls (`Input`, `Select`, pickers, `Textarea`) are full-width (`w-full`) and adapt to their column.

## Accessibility

Baseline target: **WCAG 2.1 AA**.

- **Contrast:** brand and status text/background pairings meet 4.5:1 for normal text; `-emphasis` tints exist specifically to keep status text readable on subtle surfaces.
- **Focus:** every interactive component renders a visible token-driven focus ring (`focus-visible:ring-2 ring-primary ring-offset-2`); focus is never suppressed without a replacement.
- **Semantics:** native elements are used wherever possible — `<details>`/`<summary>` (Accordion), native `<select>`/`<input>` (form controls), `role="switch"`/`radiogroup`/`role="menu"`/WAI-ARIA Tabs — so keyboard and AT behavior come for free.
- **Keyboard:** Tabs implement roving `tabindex` with Arrow/Home/End; disabled items are skipped. Icons are `aria-hidden` when decorative and take an accessible `label` otherwise.
- **State:** invalid form controls set `aria-invalid` and associate `aria-describedby` with the error message; disabled rows use `aria-disabled`.

## Design Decisions

Folded from `.sdd-de/design-decisions.md` (the running `/sync-tokens` log). The
Figma Variables API is the source of truth; every code deviation is recorded
there and summarized here.

- **D1 — Spacing value correction.** Pre-2026-07-06 tokens carried `spacing/6 = 7px`
  and `spacing/12 = 13px` (Dev Mode sampling error). Corrected to the authoritative
  `6px` / `12px`, matching Bootstrap button padding. Affects Button, IconWrapper,
  Callout, CodeBlock padding.
- **D2 — Monospace family created in code.** Figma defines no monospace Text Style
  or Variable, so `--font-family-mono` (exposed here as `typography.code`) originates
  in code to back CodeBlock's `font-mono`. No Figma counterpart to sync back to.
- **D3 — Button hover uses a brightness filter, not explicit per-type hover tokens.**
  Only `primary` uses its explicit Figma hover token (`primary-hover`). Non-primary
  types use `hover:brightness-95` / `active:brightness-90` (and `brightness-125/150`
  for `dark`) to keep the token surface small — so non-primary hover colors are close
  to, but not pixel-identical to, Figma's specified values (e.g. `danger` hover vs
  `#bb2d3b`). The canonical explicit hover/border colors are catalogued as `colors`
  tokens (`button-*-hover`, `button-*-border-*`) for any component needing exact parity.
- **D4 — `text-muted` aliases `neutral-600`.** Figma has no `color/text/muted`
  Variable; `text-muted` reuses `color/neutral/600` (`#6c757d`) for muted body text.
- **D5 — `opacity-disabled` has no Figma Variable.** `--opacity-disabled: 0.65` is
  Bootstrap's `$btn-disabled-opacity`, kept in code for the `disabled:` utility.
- **D6 — Full token reconcile (2026-07-06).** `tokens.css` now mirrors the full Figma
  system — extended brand ramps, the default shadow, additional spacing/radius steps,
  and the explicit per-type button hover/border colors were all pulled in. No value
  drift: every pre-existing token still matches its authoritative Figma Variable.
- **Scope note.** `rounded.5` / `rounded.6` and the larger spacing steps (`28`–`225`)
  are documented from Figma but not yet consumed by components. `rounded.full` is
  Tailwind's pill radius (Radio/Switch), not a Figma variable.
