import * as React from 'react';
import { Button, Icon, Logo, Text, ListingCard } from '@/components';

/* ------------------------------------------------------------------ *
 * Airbnb-style landing page.
 *
 * Replicates the Airbnb homepage LAYOUT with the Design Engineering
 * System's components and tokens. Airbnb's coral brand color is not a
 * system token, so the screen is themed with system tokens instead
 * (teal `primary`, gold `warning` star, neutral scale). Listing imagery
 * comes from Unsplash. Spec: specs/airbnb-landing/.
 * ------------------------------------------------------------------ */

/* --- Inline glyphs (Bootstrap-Icons paths) for chrome not in the Icon set --- */
const GlobeGlyph = (
  <path d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm7.5-6.923c-.67.204-1.335.82-1.887 1.855A7.97 7.97 0 0 0 5.145 4H7.5V1.077zM4.09 4a9.267 9.267 0 0 1 .64-1.539 6.7 6.7 0 0 1 .597-.933A7.025 7.025 0 0 0 2.255 4H4.09zm-.582 3.5c.03-.877.138-1.718.312-2.5H1.674a6.958 6.958 0 0 0-.656 2.5h2.49zM4.847 5a12.5 12.5 0 0 0-.338 2.5H7.5V5H4.847zM8.5 5v2.5h2.99a12.495 12.495 0 0 0-.337-2.5H8.5zM4.51 8.5a12.5 12.5 0 0 0 .337 2.5H7.5V8.5H4.51zm3.99 0V11h2.653c.187-.765.306-1.608.338-2.5H8.5zM5.145 12c.138.386.295.744.468 1.068.552 1.035 1.218 1.65 1.887 1.855V12H5.145zm.182 2.472a6.696 6.696 0 0 1-.597-.933A9.268 9.268 0 0 1 4.09 12H2.255a7.024 7.024 0 0 0 3.072 2.472zM3.82 11a13.652 13.652 0 0 1-.312-2.5h-2.49c.062.89.291 1.733.656 2.5H3.82zm6.853 3.472A7.024 7.024 0 0 0 13.745 12H11.91a9.27 9.27 0 0 1-.64 1.539 6.688 6.688 0 0 1-.597.933zM8.5 12v2.923c.67-.204 1.335-.82 1.887-1.855.173-.324.33-.682.468-1.068H8.5zm3.68-1h2.146c.365-.767.594-1.61.656-2.5h-2.49a13.65 13.65 0 0 1-.312 2.5zm2.802-3.5a6.959 6.959 0 0 0-.656-2.5H12.18c.174.782.282 1.623.312 2.5h2.49zM11.27 2.461c.247.464.462.98.64 1.539h1.835a7.024 7.024 0 0 0-3.072-2.472c.218.284.418.598.597.933zM10.855 4a7.966 7.966 0 0 0-.468-1.068C9.835 1.897 9.17 1.282 8.5 1.077V4h2.355z" />
);
const PersonGlyph = (
  <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z" />
);
const SlidersGlyph = (
  <path d="M11.5 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM9.05 3a2.5 2.5 0 0 1 4.9 0H16v1h-2.05a2.5 2.5 0 0 1-4.9 0H0V3h9.05zM4.5 7a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM2.05 8a2.5 2.5 0 0 1 4.9 0H16v1H6.95a2.5 2.5 0 0 1-4.9 0H0V8h2.05zm9.45 4a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zm-2.45 1a2.5 2.5 0 0 1 4.9 0H16v1h-2.05a2.5 2.5 0 0 1-4.9 0H0v-1h9.05z" />
);

/* --- Category glyphs --- */
const HouseGlyph = (
  <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h9a1.5 1.5 0 0 0 1.5-1.5V8.207l.646.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5z" />
);
const FireGlyph = (
  <path d="M8 16c3.314 0 6-2 6-5.5 0-1.5-.5-4-2.5-6 .25 1.5-1.25 2-1.25 2C11 4 9 .5 6 0c.357 2 .5 4-2 6-1.25 1-2 2.729-2 4.5C2 14 4.686 16 8 16zm0-1c-1.657 0-3-1-3-2.75 0-.75.25-2 1.25-3C6.125 10 7 10.5 7 10.5c-.375-1.25.5-3.25 2-3.5-.179 1-.25 2 1 3 .625.5 1 1.364 1 2.25C11 14 9.657 15 8 15z" />
);
const WaterGlyph = (
  <path d="M8 16a6 6 0 0 0 6-6c0-1.655-1.122-2.904-2.432-4.362C10.254 4.176 8.75 2.503 8 1c-.75 1.503-2.254 3.176-3.568 4.638C3.122 7.096 2 8.345 2 10a6 6 0 0 0 6 6zM6.646 4.646l.708.708C6.16 6.65 5.5 7.9 5.5 9.5a.5.5 0 0 1-1 0c0-1.9.755-3.404 2.146-4.854z" />
);
const TreeGlyph = (
  <path d="M8.416.223a.5.5 0 0 0-.832 0l-3 4.5A.5.5 0 0 0 5 5.5h.098L3.076 8.735A.5.5 0 0 0 3.5 9.5h.191l-1.638 3.276a.5.5 0 0 0 .447.724H7V16h2v-2.5h4.5a.5.5 0 0 0 .447-.724L12.31 9.5h.191a.5.5 0 0 0 .424-.765L10.902 5.5H11a.5.5 0 0 0 .416-.777l-3-4.5z" />
);
const KeyGlyph = (
  <path d="M0 8a4 4 0 0 1 7.465-2H14a.5.5 0 0 1 .354.146l1.5 1.5a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0L13 9.207l-.646.647a.5.5 0 0 1-.708 0L11 9.207l-.646.647a.5.5 0 0 1-.708 0L9 9.207l-.646.647A.5.5 0 0 1 8 10h-.535A4 4 0 0 1 0 8zm4-3a3 3 0 1 0 0 6 3 3 0 0 0 0-6zm0 2a1 1 0 1 0 0 2 1 1 0 0 0 0-2z" />
);
const BuildingGlyph = (
  <path d="M6.5 2.5a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1A.5.5 0 0 1 5 4V3a.5.5 0 0 1 .5-.5h1zm3 0a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1A.5.5 0 0 1 8 4V3a.5.5 0 0 1 .5-.5h1zm-3 3a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1A.5.5 0 0 1 5 7V6a.5.5 0 0 1 .5-.5h1zm3 0a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1A.5.5 0 0 1 8 7V6a.5.5 0 0 1 .5-.5h1zM2 1a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v14h.5a.5.5 0 0 1 0 1H.5a.5.5 0 0 1 0-1H2V1zm2 0v14h8V1H4z" />
);

type Category = { label: string; glyph: React.ReactNode; active?: boolean };

const CATEGORIES: Category[] = [
  { label: 'Amazing views', glyph: HouseGlyph, active: true },
  { label: 'Beachfront', glyph: WaterGlyph },
  { label: 'Cabins', glyph: TreeGlyph },
  { label: 'Trending', glyph: FireGlyph },
  { label: 'Rooms', glyph: KeyGlyph },
  { label: 'City', glyph: BuildingGlyph },
  { label: 'Tiny homes', glyph: HouseGlyph },
  { label: 'Top rated', glyph: <path d="" /> },
  { label: 'Countryside', glyph: TreeGlyph },
  { label: 'Design', glyph: BuildingGlyph },
  { label: 'Islands', glyph: WaterGlyph },
];

type Listing = {
  image: string;
  imageAlt: string;
  title: string;
  location: string;
  meta: string;
  price: string;
  rating: number;
  badge?: string;
  favorite?: boolean;
};

const LISTINGS: Listing[] = [
  {
    image:
      'https://images.unsplash.com/photo-1568605114967-8130f3a36994?auto=format&fit=crop&w=800&q=80',
    imageAlt: 'Modern hillside home with large windows',
    title: 'Malibu, California',
    location: 'Ocean views · Hosted by Ana',
    meta: 'Nov 5 – 10',
    price: '$412',
    rating: 4.98,
    badge: 'Guest favourite',
  },
  {
    image:
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80',
    imageAlt: 'Suburban house with manicured lawn',
    title: 'Aspen, Colorado',
    location: 'Mountain retreat',
    meta: 'Dec 1 – 6',
    price: '$328',
    rating: 4.91,
  },
  {
    image:
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=800&q=80',
    imageAlt: 'Bright minimalist living room interior',
    title: 'Lisbon, Portugal',
    location: 'Design loft in Alfama',
    meta: 'Oct 18 – 23',
    price: '$164',
    rating: 4.86,
  },
  {
    image:
      'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80',
    imageAlt: 'Contemporary apartment with warm lighting',
    title: 'Barcelona, Spain',
    location: 'Central apartment',
    meta: 'Jan 8 – 14',
    price: '$198',
    rating: 4.94,
    badge: 'Guest favourite',
  },
  {
    image:
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80',
    imageAlt: 'Modern white house with pool at dusk',
    title: 'Tulum, Mexico',
    location: 'Beachfront villa',
    meta: 'Feb 2 – 9',
    price: '$540',
    rating: 5.0,
  },
  {
    image:
      'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=800&q=80',
    imageAlt: 'Cozy bedroom with soft natural light',
    title: 'Kyoto, Japan',
    location: 'Traditional machiya',
    meta: 'Mar 12 – 17',
    price: '$233',
    rating: 4.89,
  },
  {
    image:
      'https://images.unsplash.com/photo-1493809842364-78817add7ffb?auto=format&fit=crop&w=800&q=80',
    imageAlt: 'Wooden cabin interior with lounge chairs',
    title: 'Lake Tahoe, Nevada',
    location: 'Forest cabin',
    meta: 'Nov 20 – 25',
    price: '$276',
    rating: 4.92,
  },
  {
    image:
      'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=800&q=80',
    imageAlt: 'Stylish living room with green sofa',
    title: 'Amsterdam, Netherlands',
    location: 'Canal-side studio',
    meta: 'Dec 15 – 20',
    price: '$187',
    rating: 4.83,
  },
];

/* --------------------------------- Chrome --------------------------------- */

function GlyphIcon({
  glyph,
  size = 'medium',
  className,
}: {
  glyph: React.ReactNode;
  size?: 'small' | 'medium' | 'large';
  className?: string;
}) {
  return (
    <Icon size={size} className={className} aria-hidden>
      {glyph}
    </Icon>
  );
}

function SearchBar() {
  return (
    <div
      data-component="SearchBar"
      className="flex items-center gap-0 rounded-full border border-1 border-neutral-300 bg-white py-1 pl-6 pr-2 shadow"
    >
      <button
        type="button"
        className="rounded-full py-1 pr-4 font-base text-body font-regular leading-body text-text focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
      >
        Anywhere
      </button>
      <span className="h-6 border-l border-1 border-neutral-300" />
      <button
        type="button"
        className="rounded-full px-4 py-1 font-base text-body font-regular leading-body text-text focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
      >
        Any week
      </button>
      <span className="h-6 border-l border-1 border-neutral-300" />
      <button
        type="button"
        className="rounded-full px-4 py-1 font-base text-body font-regular leading-body text-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
      >
        Add guests
      </button>
      <Button iconOnly aria-label="Search" className="rounded-full">
        <Icon name="search" aria-hidden />
      </Button>
    </div>
  );
}

function TopBar() {
  return (
    <header
      data-component="TopBar"
      className="sticky top-0 z-20 border-b border-1 border-neutral-300 bg-white"
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-6 py-4">
        <Logo
          size="medium"
          withWordmark
          wordmark="staybnb"
          href="#"
          label="staybnb home"
          className="text-primary"
        />

        <div className="hidden md:block">
          <SearchBar />
        </div>

        <div className="flex items-center gap-1">
          <Button variant="link" className="hidden sm:inline-flex">
            Become a host
          </Button>
          <Button variant="light" iconOnly aria-label="Choose language and region" className="rounded-full">
            <GlyphIcon glyph={GlobeGlyph} />
          </Button>
          <button
            type="button"
            aria-label="Main menu"
            className="flex items-center gap-2 rounded-full border border-1 border-neutral-300 py-1 pl-3 pr-1 text-text hover:shadow focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
          >
            <Icon name="list" size="small" aria-hidden />
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-neutral-600 text-white">
              <GlyphIcon glyph={PersonGlyph} size="small" />
            </span>
          </button>
        </div>
      </div>

      {/* Mobile search */}
      <div className="px-6 pb-4 md:hidden">
        <SearchBar />
      </div>

      <CategoryStrip />
    </header>
  );
}

function CategoryStrip() {
  return (
    <div className="border-t border-1 border-neutral-100">
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-6 py-3">
        <div className="flex flex-1 items-center gap-8 overflow-x-auto">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.label}
              type="button"
              data-component="CategoryPill"
              className={
                'flex shrink-0 flex-col items-center gap-1 border-b pb-2 font-base text-body font-regular leading-body focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 ' +
                (cat.active
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted hover:text-text')
              }
            >
              {cat.label === 'Top rated' ? (
                <Icon name="star-fill" aria-hidden />
              ) : (
                <GlyphIcon glyph={cat.glyph} />
              )}
              <span className="whitespace-nowrap">{cat.label}</span>
            </button>
          ))}
        </div>

        <Button variant="light" outline size="small" className="shrink-0">
          <span className="flex items-center gap-2">
            <GlyphIcon glyph={SlidersGlyph} size="small" />
            Filters
          </span>
        </Button>
      </div>
    </div>
  );
}

function Footer() {
  const columns: { heading: string; links: string[] }[] = [
    {
      heading: 'Support',
      links: ['Help Centre', 'AirCover', 'Anti-discrimination', 'Cancellation options'],
    },
    {
      heading: 'Hosting',
      links: ['List your home', 'AirCover for Hosts', 'Hosting resources', 'Community forum'],
    },
    {
      heading: 'staybnb',
      links: ['Newsroom', 'New features', 'Careers', 'Investors'],
    },
  ];

  return (
    <footer data-component="Footer" className="border-t border-1 border-neutral-300 bg-neutral-100">
      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-3">
          {columns.map((col) => (
            <div key={col.heading} className="flex flex-col gap-3">
              <span className="font-base text-body font-regular leading-body text-text">
                {col.heading}
              </span>
              {col.links.map((link) => (
                <Text key={link} variant="muted" href="#" className="hover:text-text">
                  {link}
                </Text>
              ))}
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-start justify-between gap-4 border-t border-1 border-neutral-300 pt-6 sm:flex-row sm:items-center">
          <Text variant="muted">© 2026 staybnb, Inc. · Privacy · Terms · Sitemap</Text>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-2 font-base text-body font-regular leading-body text-text">
              <GlyphIcon glyph={GlobeGlyph} size="small" />
              English (US)
            </span>
            <span className="font-base text-body font-regular leading-body text-text">$ USD</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ---------------------------------- Page ---------------------------------- */

export default function App() {
  return (
    <div className="min-h-screen bg-white font-base text-text">
      <TopBar />

      <main className="mx-auto max-w-7xl px-6 py-8">
        <h1 className="m-0 mb-6 font-base text-h4 font-regular leading-heading text-text">
          Stays in popular destinations
        </h1>

        <div className="grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {LISTINGS.map((listing) => (
            <ListingCard
              key={listing.title}
              image={listing.image}
              imageAlt={listing.imageAlt}
              title={listing.title}
              location={listing.location}
              meta={listing.meta}
              price={listing.price}
              rating={listing.rating}
              badge={listing.badge}
            />
          ))}
        </div>

        <div className="mt-12 flex justify-center">
          <Button size="large">Show more stays</Button>
        </div>
      </main>

      <Footer />
    </div>
  );
}
