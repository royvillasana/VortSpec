import type { Meta, StoryObj } from '@storybook/react';
import { Upload } from './Upload';

const meta: Meta<typeof Upload> = {
  title: 'Upload',
  component: Upload,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'File-upload organism composing a hidden native file input with either a Button trigger (variant="button") or a dashed, keyboard-activatable drop zone (variant="dragger"), plus a removable list of selected files.',
      },
    },
  },
  argTypes: {
    variant: {
      control: 'select',
      options: ['button', 'dragger'],
      description: 'Button trigger or dashed drop zone.',
    },
    multiple: {
      control: 'boolean',
      description: 'Allow selecting/dropping more than one file.',
    },
    disabled: {
      control: 'boolean',
      description: 'Disable the trigger and drop zone.',
    },
    buttonLabel: {
      control: 'text',
      description: 'Text inside the button variant trigger.',
    },
  },
  args: {
    variant: 'button',
    multiple: false,
    disabled: false,
  },
};

export default meta;
type Story = StoryObj<typeof Upload>;

export const Default: Story = {};

export const ButtonTrigger: Story = {
  args: {
    variant: 'button',
    buttonLabel: 'Upload file',
  },
};

export const Dragger: Story = {
  args: {
    variant: 'dragger',
    multiple: true,
  },
};

export const Disabled: Story = {
  args: {
    variant: 'dragger',
    disabled: true,
  },
};
