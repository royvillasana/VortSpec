import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Navbar — responsive top navigation bar spanning the page width.
 * Surface + 1px bottom border from tokens; `sticky` pins it to the top.
 * Mirrors `header.variants.ts` (same `sticky` boolean axis).
 */
export const navbarVariants = cva(
  'w-full border-b border-1 border-neutral-300 bg-white px-4 py-2',
  {
    variants: {
      sticky: {
        true: 'sticky top-0 z-10',
        false: '',
      },
    },
    defaultVariants: {
      sticky: false,
    },
  }
);

export type NavbarVariants = VariantProps<typeof navbarVariants>;
