import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Tabs — accessible tabbed interface (WAI-ARIA Tabs pattern).
 * Three token-pure CVAs:
 *   `tabsVariants`    → outer container layout (tablist ↔ panel arrangement)
 *   `tabListVariants` → the `role="tablist"` track + its dividing rule
 *   `tabVariants`     → each `role="tab"` button, with active/disabled/orientation axes
 *
 * The active indicator is a 1px accent border (`border-b`/`border-r` +
 * `border-primary`) so it stays token-backed via `borderWidth.DEFAULT`
 * (`--stroke-width-1`). Every color/spacing/radius resolves to a design token.
 */

/** Outer container — arranges the tablist relative to the panel region. */
export const tabsVariants = cva('flex gap-4', {
  variants: {
    orientation: {
      // Tablist row above, panel below.
      top: 'flex-col',
      // Tablist column beside the panel.
      left: 'flex-row',
    },
  },
  defaultVariants: {
    orientation: 'top',
  },
});

/** The `role="tablist"` track, with a dividing rule along its flow axis. */
export const tabListVariants = cva('flex', {
  variants: {
    orientation: {
      top: 'flex-row border-b border-neutral-300',
      left: 'flex-col border-r border-neutral-300',
    },
  },
  defaultVariants: {
    orientation: 'top',
  },
});

/** A single `role="tab"` button. */
export const tabVariants = cva(
  'inline-flex items-center gap-2 whitespace-nowrap font-base font-regular text-body leading-body ' +
    'px-4 py-2 cursor-pointer select-none transition-colors ' +
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 rounded-sm',
  {
    variants: {
      orientation: {
        // Accent indicator hugs the shared rule of the tablist.
        top: 'border-b',
        left: 'border-r',
      },
      active: {
        true: 'text-primary border-primary',
        false: 'text-muted border-transparent hover:text-text',
      },
      disabled: {
        true: 'opacity-disabled pointer-events-none cursor-not-allowed',
        false: '',
      },
    },
    defaultVariants: {
      orientation: 'top',
      active: false,
      disabled: false,
    },
  }
);

export type TabsVariants = VariantProps<typeof tabsVariants>;
