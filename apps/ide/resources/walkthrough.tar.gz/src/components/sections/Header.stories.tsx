import type { Meta, StoryObj } from '@storybook/react';
import { Header } from './Header';
import { Button } from '@/components/ui/Button';

const NAV_ITEMS = [
  { label: 'Docs', href: '#docs' },
  { label: 'Components', href: '#components' },
  { label: 'Tokens', href: '#tokens' },
];

const meta: Meta<typeof Header> = {
  title: 'Header',
  component: Header,
  tags: ['autodocs'],
  // Header spans the full page width — render edge-to-edge.
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component:
          'Documentation top bar spanning the page width, composing the Logo, primary navigation, and an optional title + CTA.',
      },
    },
  },
  argTypes: {
    sticky: { control: 'boolean', description: 'Pin the header to the top of the viewport.' },
    navItems: { control: 'object', description: 'Primary navigation links.' },
  },
  args: {
    sticky: false,
    navItems: NAV_ITEMS,
  },
};

export default meta;
type Story = StoryObj<typeof Header>;

export const Default: Story = {};

export const WithCta: Story = {
  args: {
    navItems: NAV_ITEMS,
    cta: (
      <Button variant="primary" size="small">
        Get started
      </Button>
    ),
  },
};

export const WithTitle: Story = {
  args: {
    navItems: NAV_ITEMS,
    title: <span className="text-body text-muted">Documentation</span>,
  },
};

export const Sticky: Story = {
  args: {
    sticky: true,
    navItems: NAV_ITEMS,
  },
  render: (args) => (
    <div style={{ height: 640 }}>
      <Header {...args} />
      <div style={{ padding: 24 }}>Scroll — the header stays pinned to the top.</div>
    </div>
  ),
};
