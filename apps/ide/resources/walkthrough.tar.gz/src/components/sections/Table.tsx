import * as React from 'react';
import { cn } from '@/lib/utils';
import { Icon } from '@/components/ui/Icon';
import { Checkbox } from '@/components/ui/Checkbox';
import { tableCellVariants, sortButtonClasses } from './table.variants';

type SortDir = 'asc' | 'desc';

/**
 * Column descriptor for the generic {@link Table}. `render` owns the cell's
 * JSX; `accessor` supplies a value for both display (when no `render`) and
 * sorting. When neither is given, the raw `row[key]` value is used.
 */
export interface TableColumn<T> {
  /** Stable column identifier; also the fallback data key (`row[key]`). */
  key: string;
  /** Header cell content. */
  header: React.ReactNode;
  /** Horizontal alignment for this column's header and body cells. */
  align?: 'left' | 'center' | 'right';
  /** When true, the header becomes a sort toggle button. */
  sortable?: boolean;
  /** Custom body-cell renderer. Wins over `accessor` for display. */
  render?: (row: T, rowIndex: number) => React.ReactNode;
  /** Value accessor used for display (no `render`) and for client-side sort. */
  accessor?: (row: T) => React.ReactNode;
}

export interface TableProps<T>
  extends Omit<React.HTMLAttributes<HTMLTableElement>, 'children'> {
  /** Column definitions, in render order. */
  columns: TableColumn<T>[];
  /** Row data. */
  data: T[];
  /** Stable key for each row (used for React keys and selection identity). */
  rowKey: (row: T, i: number) => React.Key;
  /** Adds a leading checkbox column with a select-all header checkbox. */
  selectable?: boolean;
  /** Optional `<caption>` content. */
  caption?: React.ReactNode;
  /** Fired after a sortable header toggles: `(key, dir)`. */
  onSortChange?: (key: string, dir: SortDir) => void;
  /** Fired after the selected row-key set changes. */
  onSelectionChange?: (keys: React.Key[]) => void;
}

/** Numeric compare when both are numbers, otherwise locale string compare. */
function compareValues(a: unknown, b: unknown): number {
  if (a == null && b == null) return 0;
  // Null-safe: nulls sort last in ascending order (spec edge case "last-ascending").
  if (a == null) return 1;
  if (b == null) return -1;
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  return String(a).localeCompare(String(b));
}

/**
 * Table — a semantic, generic data table (organism).
 *
 * Renders a real `<table>` with `<thead>` / `<tbody>`, `<th scope="col">`
 * header cells, and token-driven surfaces. Supports per-column alignment,
 * client-side sorting (via `accessor` or `row[key]`), and optional row
 * selection with an indeterminate select-all checkbox.
 *
 * Implemented as a **generic function component** (not `forwardRef`): generics
 * do not compose cleanly with `React.forwardRef`, and a data table rarely needs
 * a forwarded `<table>` ref. A consumer `className` is still accepted and merged
 * LAST onto the `<table>` for layout overrides.
 */
function Table<T>({
  columns,
  data,
  rowKey,
  selectable = false,
  caption,
  onSortChange,
  onSelectionChange,
  className,
  ...props
}: TableProps<T>) {
  const [sort, setSort] = React.useState<{ key: string; dir: SortDir } | null>(null);
  const [selected, setSelected] = React.useState<Set<React.Key>>(() => new Set());

  const sortedData = React.useMemo(() => {
    if (!sort) return data;
    const col = columns.find((c) => c.key === sort.key);
    if (!col) return data;
    const getVal = (row: T): unknown =>
      col.accessor ? col.accessor(row) : (row as Record<string, unknown>)[col.key];
    const copy = [...data];
    copy.sort((ra, rb) => {
      const res = compareValues(getVal(ra), getVal(rb));
      return sort.dir === 'asc' ? res : -res;
    });
    return copy;
  }, [data, sort, columns]);

  const rowKeys = React.useMemo(
    () => sortedData.map((row, i) => rowKey(row, i)),
    [sortedData, rowKey]
  );

  const allSelected = rowKeys.length > 0 && rowKeys.every((k) => selected.has(k));
  const someSelected = rowKeys.some((k) => selected.has(k));
  const indeterminate = someSelected && !allSelected;

  const handleSort = (key: string) => {
    const dir: SortDir = sort && sort.key === key && sort.dir === 'asc' ? 'desc' : 'asc';
    setSort({ key, dir });
    onSortChange?.(key, dir);
  };

  const emitSelection = (next: Set<React.Key>) => {
    setSelected(next);
    onSelectionChange?.([...next]);
  };

  const toggleAll = () => {
    const next = new Set(selected);
    if (allSelected) rowKeys.forEach((k) => next.delete(k));
    else rowKeys.forEach((k) => next.add(k));
    emitSelection(next);
  };

  const toggleRow = (key: React.Key) => {
    const next = new Set(selected);
    if (next.has(key)) next.delete(key);
    else next.add(key);
    emitSelection(next);
  };

  const renderCell = (col: TableColumn<T>, row: T, rowIndex: number): React.ReactNode => {
    if (col.render) return col.render(row, rowIndex);
    if (col.accessor) return col.accessor(row);
    return (row as Record<string, React.ReactNode>)[col.key];
  };

  const colCount = columns.length + (selectable ? 1 : 0);

  return (
    <table className={cn('w-full border-collapse text-body', className)} {...props}>
      {caption != null && <caption className="text-body text-text-muted">{caption}</caption>}
      <thead>
        <tr>
          {selectable && (
            <th scope="col" className={cn(tableCellVariants({ align: 'center', head: true }))}>
              <Checkbox
                checked={allSelected}
                indeterminate={indeterminate}
                onChange={toggleAll}
                aria-label="Select all rows"
              />
            </th>
          )}
          {columns.map((col) => {
            const ariaSort = col.sortable
              ? sort?.key === col.key
                ? sort.dir === 'asc'
                  ? 'ascending'
                  : 'descending'
                : 'none'
              : undefined;
            const iconName =
              sort?.key === col.key
                ? sort.dir === 'asc'
                  ? 'chevron-up'
                  : 'chevron-down'
                : 'chevron-expand';
            return (
              <th
                key={col.key}
                scope="col"
                aria-sort={ariaSort}
                className={cn(tableCellVariants({ align: col.align, head: true }))}
              >
                {col.sortable ? (
                  <button
                    type="button"
                    onClick={() => handleSort(col.key)}
                    className={sortButtonClasses}
                  >
                    {col.header}
                    <Icon name={iconName} size="small" aria-hidden />
                  </button>
                ) : (
                  col.header
                )}
              </th>
            );
          })}
        </tr>
      </thead>
      <tbody>
        {sortedData.length === 0 ? (
          <tr>
            <td
              colSpan={colCount}
              className={cn(tableCellVariants({ align: 'center' }), 'text-text-muted')}
            >
              No data
            </td>
          </tr>
        ) : (
          sortedData.map((row, i) => {
            const key = rowKeys[i];
            return (
              <tr key={key} className="hover:bg-neutral-100">
                {selectable && (
                  <td className={cn(tableCellVariants({ align: 'center' }))}>
                    <Checkbox
                      checked={selected.has(key)}
                      onChange={() => toggleRow(key)}
                      aria-label="Select row"
                    />
                  </td>
                )}
                {columns.map((col) => (
                  <td key={col.key} className={cn(tableCellVariants({ align: col.align }))}>
                    {renderCell(col, row, i)}
                  </td>
                ))}
              </tr>
            );
          })
        )}
      </tbody>
    </table>
  );
}
Table.displayName = 'Table';

export { Table };
