import type { Meta, StoryObj } from '@storybook/react';
import { Navbar } from './Navbar';
import { Button } from '@/components/ui/Button';

const NAV_ITEMS = [
  { label: 'Home', href: '#home', active: true },
  { label: 'Features', href: '#features' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'About', href: '#about' },
];

const meta: Meta<typeof Navbar> = {
  title: 'Navbar',
  component: Navbar,
  tags: ['autodocs'],
  // Navbar is a full-width top navigation bar — render edge-to-edge.
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component:
          'Responsive top navigation organism composing a brand Logo, a set of NavItem links, an optional trailing CTA, and a mobile toggler that reveals a stacked panel below the md breakpoint.',
      },
    },
  },
  argTypes: {
    sticky: {
      control: 'boolean',
      description: 'Pin the navbar to the top of the viewport.',
    },
    items: { control: 'object', description: 'Primary navigation links.' },
  },
  args: {
    sticky: false,
    items: NAV_ITEMS,
  },
};

export default meta;
type Story = StoryObj<typeof Navbar>;

export const Default: Story = {};

export const WithCta: Story = {
  args: {
    items: NAV_ITEMS,
    cta: (
      <Button variant="primary" size="small">
        Sign up
      </Button>
    ),
  },
};

export const Sticky: Story = {
  args: {
    sticky: true,
    items: NAV_ITEMS,
    cta: (
      <Button variant="primary" size="small">
        Sign up
      </Button>
    ),
  },
  render: (args) => (
    <div style={{ height: 640 }}>
      <Navbar {...args} />
      <div style={{ padding: 24 }}>Scroll — the navbar stays pinned to the top.</div>
    </div>
  ),
};
