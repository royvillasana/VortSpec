import type { Meta, StoryObj } from '@storybook/react';
import { Tabs } from './Tabs';

const TABS = [
  { id: 'overview', label: 'Overview', content: 'A high-level summary of the project.' },
  { id: 'specs', label: 'Specs', content: 'Detailed component and interaction specs.' },
  { id: 'activity', label: 'Activity', content: 'Recent changes and commits.' },
  { id: 'archived', label: 'Archived', content: 'Archived items.', disabled: true },
];

const meta: Meta<typeof Tabs> = {
  title: 'Tabs',
  component: Tabs,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Accessible tabbed interface implementing the WAI-ARIA Tabs pattern with roving tabindex, arrow/Home/End keyboard navigation, and skipped disabled tabs.',
      },
    },
  },
  argTypes: {
    orientation: {
      control: 'select',
      options: ['top', 'left'],
      description: 'Arrange the tablist above (top) or beside (left) the panel.',
    },
    defaultTabId: {
      control: 'text',
      description: 'Initially active tab (uncontrolled).',
    },
  },
  args: {
    tabs: TABS,
    orientation: 'top',
  },
};

export default meta;
type Story = StoryObj<typeof Tabs>;

export const Default: Story = {};

export const Top: Story = {
  args: {
    orientation: 'top',
  },
};

export const Left: Story = {
  args: {
    orientation: 'left',
  },
};

export const WithDisabledTab: Story = {
  args: {
    defaultTabId: 'specs',
  },
};
