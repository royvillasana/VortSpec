import * as React from 'react';
import { cn } from '@/lib/utils';
import { Logo } from '@/components/ui/Logo';
import { Text } from '@/components/ui/Text';
import { headerVariants, type HeaderVariants } from './header.variants';

export interface HeaderNavItem {
  label: string;
  href: string;
}

export interface HeaderProps
  extends Omit<React.HTMLAttributes<HTMLElement>, 'title'>,
    HeaderVariants {
  /** Brand mark. Defaults to the system `Logo`. */
  logo?: React.ReactNode;
  /** Optional page title / breadcrumb rendered next to the logo. */
  title?: React.ReactNode;
  /** Primary navigation links. */
  navItems?: HeaderNavItem[];
  /** Trailing call-to-action (e.g. a Button). */
  cta?: React.ReactNode;
}

/**
 * Header — documentation top bar composing Logo, navigation, and an optional
 * title + CTA.
 */
const Header = React.forwardRef<HTMLElement, HeaderProps>(
  ({ className, sticky, logo, title, navItems = [], cta, ...props }, ref) => (
    <header ref={ref} className={cn(headerVariants({ sticky }), className)} {...props}>
      <div className="flex items-center gap-4">
        {logo ?? <Logo size="small" href="/" />}
        {title}
      </div>
      <nav aria-label="Primary" className="flex items-center gap-4">
        {navItems.map((item) => (
          <Text key={item.href} variant="link" href={item.href}>
            {item.label}
          </Text>
        ))}
        {cta}
      </nav>
    </header>
  )
);
Header.displayName = 'Header';

export { Header };
