import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Header — top navigation/documentation bar spanning the page width.
 * Surface + 1px bottom border from tokens; `sticky` pins it to the top.
 */
export const headerVariants = cva(
  'flex w-full items-center justify-between gap-4 border-b border-1 border-neutral-300 bg-white px-4 py-2',
  {
    variants: {
      sticky: {
        true: 'sticky top-0 z-10',
        false: '',
      },
    },
    defaultVariants: {
      sticky: false,
    },
  }
);

export type HeaderVariants = VariantProps<typeof headerVariants>;
