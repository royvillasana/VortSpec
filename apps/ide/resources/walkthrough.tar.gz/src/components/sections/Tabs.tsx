import * as React from 'react';
import { cn } from '@/lib/utils';
import {
  tabsVariants,
  tabListVariants,
  tabVariants,
  type TabsVariants,
} from './tabs.variants';

/** A single tab and its associated panel. */
export interface TabItem {
  /** Stable unique key — used to build the tab/panel element ids. */
  id: string;
  /** Tab label rendered inside the `role="tab"` button. */
  label: React.ReactNode;
  /** Panel content revealed when the tab is active. */
  content: React.ReactNode;
  /** Non-interactive, dimmed tab — skipped by keyboard navigation. */
  disabled?: boolean;
}

export interface TabsProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'>,
    TabsVariants {
  /** The tabs to render, in order. */
  tabs: TabItem[];
  /** Initially active tab (uncontrolled). Defaults to the first non-disabled tab. */
  defaultTabId?: string;
  /** Fired with the tab id whenever the active tab changes. */
  onTabChange?: (id: string) => void;
}

/**
 * Tabs — an accessible tabbed interface implementing the WAI-ARIA Tabs pattern.
 * Automatic activation (selection follows focus): Arrow keys move between tabs,
 * Home/End jump to first/last, roving `tabindex` keeps a single tab stop, and
 * disabled tabs are skipped. Fully token-styled via CVA + `cn()`.
 */
const Tabs = React.forwardRef<HTMLDivElement, TabsProps>(
  ({ className, orientation = 'top', tabs, defaultTabId, onTabChange, ...props }, ref) => {
    const uid = React.useId();
    const tabId = (id: string) => `${uid}-tab-${id}`;
    const panelId = (id: string) => `${uid}-panel-${id}`;

    const firstEnabledId = tabs.find((t) => !t.disabled)?.id;
    const [activeId, setActiveId] = React.useState<string | undefined>(
      defaultTabId ?? firstEnabledId
    );

    const tabRefs = React.useRef<Array<HTMLButtonElement | null>>([]);

    const activate = React.useCallback(
      (index: number) => {
        const tab = tabs[index];
        if (!tab || tab.disabled) return;
        setActiveId(tab.id);
        onTabChange?.(tab.id);
        tabRefs.current[index]?.focus();
      },
      [tabs, onTabChange]
    );

    const handleKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
      const nextKey = orientation === 'left' ? 'ArrowDown' : 'ArrowRight';
      const prevKey = orientation === 'left' ? 'ArrowUp' : 'ArrowLeft';

      // Indices of the tabs that can receive focus, in DOM order.
      const enabled = tabs.reduce<number[]>((acc, tab, i) => {
        if (!tab.disabled) acc.push(i);
        return acc;
      }, []);
      if (enabled.length === 0) return;

      const currentIndex = tabs.findIndex((t) => t.id === activeId);
      const currentPos = enabled.indexOf(currentIndex);

      let targetIndex: number | null = null;
      if (event.key === nextKey) {
        targetIndex = enabled[(currentPos + 1 + enabled.length) % enabled.length];
      } else if (event.key === prevKey) {
        targetIndex = enabled[(currentPos - 1 + enabled.length) % enabled.length];
      } else if (event.key === 'Home') {
        targetIndex = enabled[0];
      } else if (event.key === 'End') {
        targetIndex = enabled[enabled.length - 1];
      }

      if (targetIndex !== null) {
        event.preventDefault();
        activate(targetIndex);
      }
    };

    return (
      <div ref={ref} className={cn(tabsVariants({ orientation }), className)} {...props}>
        <div
          role="tablist"
          aria-orientation={orientation === 'left' ? 'vertical' : 'horizontal'}
          onKeyDown={handleKeyDown}
          className={tabListVariants({ orientation })}
        >
          {tabs.map((tab, i) => {
            const selected = tab.id === activeId;
            return (
              <button
                key={tab.id}
                ref={(el) => {
                  tabRefs.current[i] = el;
                }}
                role="tab"
                type="button"
                id={tabId(tab.id)}
                aria-selected={selected}
                aria-controls={panelId(tab.id)}
                tabIndex={selected ? 0 : -1}
                disabled={tab.disabled}
                aria-disabled={tab.disabled || undefined}
                onClick={() => activate(i)}
                className={tabVariants({
                  orientation,
                  active: selected,
                  disabled: !!tab.disabled,
                })}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        <div className={orientation === 'left' ? 'flex-1' : undefined}>
          {tabs.map((tab) => {
            const selected = tab.id === activeId;
            return (
              <div
                key={tab.id}
                role="tabpanel"
                id={panelId(tab.id)}
                aria-labelledby={tabId(tab.id)}
                tabIndex={0}
                hidden={!selected}
                className="py-2 font-base text-body leading-body text-text focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 rounded-sm"
              >
                {tab.content}
              </div>
            );
          })}
        </div>
      </div>
    );
  }
);
Tabs.displayName = 'Tabs';

export { Tabs };
