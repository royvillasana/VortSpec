import type { Meta, StoryObj } from '@storybook/react';
import { Table, type TableColumn } from './Table';

interface Person {
  id: number;
  name: string;
  role: string;
  age: number;
}

const DATA: Person[] = [
  { id: 1, name: 'Ada Lovelace', role: 'Engineer', age: 36 },
  { id: 2, name: 'Alan Turing', role: 'Researcher', age: 41 },
  { id: 3, name: 'Grace Hopper', role: 'Admiral', age: 85 },
  { id: 4, name: 'Katherine Johnson', role: 'Mathematician', age: 101 },
];

const COLUMNS: TableColumn<Person>[] = [
  { key: 'name', header: 'Name', sortable: true },
  { key: 'role', header: 'Role' },
  {
    key: 'age',
    header: 'Age',
    align: 'right',
    sortable: true,
    accessor: (row) => row.age,
  },
];

const meta: Meta<typeof Table<Person>> = {
  title: 'Table',
  component: Table,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Semantic, generic data table organism with per-column alignment, client-side sorting, and optional row selection with an indeterminate select-all checkbox.',
      },
    },
  },
  argTypes: {
    selectable: {
      control: 'boolean',
      description: 'Adds a leading checkbox column with a select-all header checkbox.',
    },
    caption: { control: 'text', description: 'Optional <caption> content.' },
  },
  args: {
    columns: COLUMNS,
    data: DATA,
    rowKey: (row: Person) => row.id,
    selectable: false,
  },
};

export default meta;
type Story = StoryObj<typeof Table<Person>>;

export const Default: Story = {};

export const Selectable: Story = {
  args: {
    selectable: true,
  },
};

export const WithCaption: Story = {
  args: {
    caption: 'Notable computer scientists',
  },
};

export const Empty: Story = {
  args: {
    data: [],
  },
};
