import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Upload variants — the file-upload control surface (organism).
 *   Variant → `variant` (button | dragger)
 *     button  → a thin wrapper; the visible trigger is a Button atom.
 *     dragger → a large dashed drop zone (clickable + keyboard-activatable).
 *
 * The drag-over highlight (`border-primary bg-brand-primary-100`) is applied
 * imperatively in the component, not here, since it is a transient runtime state.
 * Every color/spacing/radius/border utility resolves to a design token via the
 * Tailwind theme mapping (tailwind.config.js). No hardcoded values.
 */
export const uploadVariants = cva('flex flex-col gap-3', {
  variants: {
    variant: {
      button: '',
      dragger: '',
    },
  },
  defaultVariants: {
    variant: 'button',
  },
});

/**
 * Drop-zone surface for the `dragger` variant. Split out so the drag-over
 * highlight can be composed on top at runtime via `cn()`.
 */
export const draggerZone = cva(
  'flex flex-col items-center gap-2 text-center w-full ' +
    'border border-1 border-dashed border-neutral-300 rounded bg-neutral-100 p-6 ' +
    'cursor-pointer transition-[background-color,border-color] duration-150 ease-out ' +
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2',
  {
    variants: {
      dragActive: {
        true: 'border-primary bg-brand-primary-100',
        false: '',
      },
      disabled: {
        true: 'opacity-disabled pointer-events-none cursor-not-allowed',
        false: '',
      },
    },
    defaultVariants: {
      dragActive: false,
      disabled: false,
    },
  }
);

export type UploadVariants = VariantProps<typeof uploadVariants>;
