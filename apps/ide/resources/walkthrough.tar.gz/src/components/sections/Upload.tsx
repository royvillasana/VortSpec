import * as React from 'react';
import { cn } from '@/lib/utils';
import { Icon } from '@/components/ui/Icon';
import { Button } from '@/components/ui/Button';
import {
  uploadVariants,
  draggerZone,
  type UploadVariants,
} from './upload.variants';

export interface UploadProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'>,
    UploadVariants {
  /** Native file-type filter, forwarded to the hidden `<input type="file">`. */
  accept?: string;
  /** Allow selecting/dropping more than one file. */
  multiple?: boolean;
  /** Disable the control (trigger + drop zone become non-interactive). */
  disabled?: boolean;
  /** Text inside the `button` variant trigger. Defaults to `Upload`. */
  buttonLabel?: string;
  /** Primary prompt line inside the `dragger` drop zone. */
  promptText?: React.ReactNode;
  /** Secondary muted hint line inside the `dragger` drop zone. */
  hintText?: React.ReactNode;
  /** Called with the full file list on every add/remove. */
  onFilesChange?: (files: File[]) => void;
}

/**
 * Upload — file-upload organism composing a hidden native `<input type="file">`
 * with either a Button trigger (`variant="button"`) or a dashed drop zone
 * (`variant="dragger"`), plus a removable list of selected files.
 *
 * The real input keeps native file-picker semantics + keyboard behaviour; the
 * dragger is a keyboard-activatable `role="button"`. Selection state lives in
 * `useState`; adds append (respecting `multiple`) and removes splice, with every
 * change reported through `onFilesChange`. Consumer `className` merges last onto
 * the outer wrapper.
 */
const Upload = React.forwardRef<HTMLDivElement, UploadProps>(
  (
    {
      className,
      variant = 'button',
      accept,
      multiple,
      disabled,
      buttonLabel = 'Upload',
      promptText = 'Drag and drop files here, or click to browse',
      hintText = 'Any file type is accepted',
      onFilesChange,
      ...props
    },
    ref
  ) => {
    const inputRef = React.useRef<HTMLInputElement>(null);
    const [files, setFiles] = React.useState<File[]>([]);
    const [dragActive, setDragActive] = React.useState(false);

    const handleAdd = React.useCallback(
      (list: FileList | null) => {
        if (!list || list.length === 0) return;
        const incoming = Array.from(list);
        setFiles((prev) => {
          const next = multiple ? [...prev, ...incoming] : incoming.slice(0, 1);
          onFilesChange?.(next);
          return next;
        });
      },
      [multiple, onFilesChange]
    );

    const handleRemove = React.useCallback(
      (index: number) => {
        setFiles((prev) => {
          const next = prev.filter((_, i) => i !== index);
          onFilesChange?.(next);
          return next;
        });
      },
      [onFilesChange]
    );

    const openDialog = React.useCallback(() => {
      if (disabled) return;
      inputRef.current?.click();
    }, [disabled]);

    const handleInputChange = React.useCallback(
      (event: React.ChangeEvent<HTMLInputElement>) => {
        handleAdd(event.target.files);
        // Reset so selecting the same file again still fires `change`.
        event.target.value = '';
      },
      [handleAdd]
    );

    const handleDrop = React.useCallback(
      (event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        setDragActive(false);
        if (disabled) return;
        handleAdd(event.dataTransfer.files);
      },
      [disabled, handleAdd]
    );

    const handleDragOver = React.useCallback(
      (event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        if (disabled) return;
        setDragActive(true);
      },
      [disabled]
    );

    const handleDragLeave = React.useCallback(
      (event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        setDragActive(false);
      },
      []
    );

    const handleKeyDown = React.useCallback(
      (event: React.KeyboardEvent<HTMLDivElement>) => {
        if (disabled) return;
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          openDialog();
        }
      },
      [disabled, openDialog]
    );

    return (
      <div ref={ref} className={cn(uploadVariants({ variant }), className)} {...props}>
        <input
          ref={inputRef}
          type="file"
          accept={accept}
          multiple={multiple}
          disabled={disabled}
          onChange={handleInputChange}
          className="sr-only"
          tabIndex={-1}
        />

        {variant === 'button' ? (
          <Button
            type="button"
            variant="light"
            disabled={disabled}
            onClick={openDialog}
            className="self-start"
          >
            <Icon name="upload" size="small" aria-hidden />
            {buttonLabel}
          </Button>
        ) : (
          <div
            role="button"
            tabIndex={disabled ? -1 : 0}
            aria-label={typeof promptText === 'string' ? promptText : 'Upload files'}
            aria-disabled={disabled || undefined}
            onClick={openDialog}
            onKeyDown={handleKeyDown}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={draggerZone({ dragActive, disabled: !!disabled })}
          >
            <Icon name="upload" size="large" aria-hidden className="text-muted" />
            <span className="text-body font-regular leading-body text-text">
              {promptText}
            </span>
            <span className="text-body font-regular leading-body text-muted">
              {hintText}
            </span>
          </div>
        )}

        {files.length > 0 && (
          <ul className="flex flex-col gap-1 w-full">
            {files.map((file, index) => (
              <li
                key={`${file.name}-${index}`}
                className="flex items-center gap-2 rounded-sm bg-neutral-100 px-2 py-1"
              >
                <Icon name="file-earmark" size="small" aria-hidden className="text-muted" />
                <span className="text-body font-regular leading-body text-text">
                  {file.name}
                </span>
                <button
                  type="button"
                  aria-label="Remove file"
                  disabled={disabled}
                  onClick={() => handleRemove(index)}
                  className={cn(
                    'ml-auto inline-flex items-center justify-center rounded-sm p-1 text-muted cursor-pointer',
                    'transition-[color] duration-150 ease-out hover:text-danger',
                    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2',
                    'disabled:opacity-disabled disabled:pointer-events-none disabled:cursor-not-allowed'
                  )}
                >
                  <Icon name="x" size="small" aria-hidden />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    );
  }
);
Upload.displayName = 'Upload';

export { Upload };
