import * as React from 'react';
import { cn } from '@/lib/utils';
import { Logo } from '@/components/ui/Logo';
import { Icon } from '@/components/ui/Icon';
import { NavItem } from '@/components/modules/NavItem';
import { navbarVariants, type NavbarVariants } from './navbar.variants';

export interface NavbarNavItem {
  label: string;
  href: string;
  active?: boolean;
}

export interface NavbarProps
  extends React.HTMLAttributes<HTMLElement>,
    NavbarVariants {
  /** Brand mark. Defaults to the system `Logo`. */
  brand?: React.ReactNode;
  /** Primary navigation links. */
  items?: NavbarNavItem[];
  /** Trailing call-to-action (e.g. a Button). */
  cta?: React.ReactNode;
}

let navbarPanelId = 0;

/**
 * Navbar — responsive top navigation organism composing a brand (`Logo`),
 * a set of `NavItem` links, an optional trailing `cta`, and a mobile toggler.
 * On small screens the horizontal links + cta collapse behind a toggler that
 * reveals a stacked panel; from `md` up the links render inline.
 */
const Navbar = React.forwardRef<HTMLElement, NavbarProps>(
  ({ className, sticky, brand, items = [], cta, ...props }, ref) => {
    const [open, setOpen] = React.useState(false);
    const panelId = React.useMemo(() => `navbar-panel-${navbarPanelId++}`, []);

    const links = (orientation: 'horizontal' | 'vertical') =>
      items.map((item) => (
        <NavItem
          key={item.href}
          href={item.href}
          orientation={orientation}
          active={item.active}
        >
          {item.label}
        </NavItem>
      ));

    return (
      <header ref={ref} className={cn(navbarVariants({ sticky }), className)} {...props}>
        <nav aria-label="Primary" className="flex w-full items-center justify-between gap-4">
          {brand ?? <Logo size="small" href="/" />}

          {/* Desktop: inline links + cta */}
          <div className="hidden items-center gap-4 md:flex">
            {links('horizontal')}
            {cta}
          </div>

          {/* Mobile: toggler */}
          <button
            type="button"
            aria-label="Toggle navigation"
            aria-expanded={open}
            aria-controls={panelId}
            onClick={() => setOpen((prev) => !prev)}
            className="inline-flex items-center justify-center rounded p-2 text-text hover:bg-neutral-100 md:hidden focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
          >
            <Icon name={open ? 'x' : 'list'} />
          </button>
        </nav>

        {/* Mobile: collapsible stacked panel */}
        {open && (
          <div id={panelId} className="flex flex-col gap-1 pt-2 md:hidden">
            {links('vertical')}
            {cta && <div className="pt-2">{cta}</div>}
          </div>
        )}
      </header>
    );
  }
);
Navbar.displayName = 'Navbar';

export { Navbar };
