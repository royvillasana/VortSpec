import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Table cell variants — shared base classes for `<th>` and `<td>` plus
 * per-column horizontal alignment. Every color/spacing/border/font utility
 * resolves to a design token via the Tailwind theme mapping (tailwind.config.js).
 * No hardcoded values.
 *
 *   align → text-left | text-center | text-right (per-column `align`)
 *   head  → header cell surface (`bg-neutral-100` + `font-regular`)
 */
export const tableCellVariants = cva(
  'px-3 py-2 border-b border-neutral-300 text-text font-base leading-body align-middle',
  {
    variants: {
      align: {
        left: 'text-left',
        center: 'text-center',
        right: 'text-right',
      },
      head: {
        true: 'bg-neutral-100 font-regular',
        false: '',
      },
    },
    defaultVariants: {
      align: 'left',
      head: false,
    },
  }
);

export type TableCellVariants = VariantProps<typeof tableCellVariants>;

/**
 * Focus ring shared by interactive sort header buttons — visible keyboard
 * focus with a token-driven primary ring.
 */
export const sortButtonClasses =
  'inline-flex items-center gap-1 rounded-sm cursor-pointer ' +
  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2';
