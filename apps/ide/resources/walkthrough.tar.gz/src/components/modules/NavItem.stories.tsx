import type { Meta, StoryObj } from '@storybook/react';
import { NavItem } from './NavItem';
import { Icon } from '@/components/ui/Icon';

const meta: Meta<typeof NavItem> = {
  title: 'NavItem',
  component: NavItem,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A single navigation link. Renders an anchor when href is provided, otherwise a button. Supports horizontal/vertical/inline orientations, nested levels, and active/disabled states.',
      },
    },
  },
  argTypes: {
    orientation: {
      control: 'select',
      options: ['horizontal', 'vertical', 'inline'],
      description: 'Layout context; drives chevron direction and active surface.',
    },
    level: {
      control: 'select',
      options: [1, 2, 3],
      description: 'Nesting depth; adds left indent for inline/vertical layouts.',
    },
    active: {
      control: 'boolean',
      description: 'Marks the current item — sets aria-current="page" and active styling.',
    },
    disabled: {
      control: 'boolean',
      description: 'Disables interaction — dims the item and blocks pointer events.',
    },
    hasChildren: {
      control: 'boolean',
      description: 'Renders a trailing chevron indicating a submenu.',
    },
    href: { control: 'text', description: 'When set, renders as an anchor.' },
    children: { control: 'text', description: 'The link label.' },
  },
  args: {
    children: 'Dashboard',
    href: '#',
    orientation: 'horizontal',
    level: 1,
  },
};

export default meta;
type Story = StoryObj<typeof NavItem>;

export const Default: Story = {};

// --- Orientation ---
export const Horizontal: Story = {
  args: { orientation: 'horizontal', children: 'Home' },
};
export const Vertical: Story = {
  args: { orientation: 'vertical', children: 'Reports' },
};
export const Inline: Story = {
  args: { orientation: 'inline', children: 'Settings' },
};

// --- States ---
export const Active: Story = {
  args: { active: true, children: 'Current page' },
};
export const Disabled: Story = {
  args: { disabled: true, children: 'Unavailable' },
};

// --- Composition ---
export const WithIcon: Story = {
  args: { icon: <Icon name="star" />, children: 'Favorites' },
};
export const HasChildren: Story = {
  args: { hasChildren: true, children: 'Products' },
};
export const NestedLevel: Story = {
  args: { orientation: 'vertical', level: 2, children: 'Sub-item' },
};
