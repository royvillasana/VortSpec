import { cva, type VariantProps } from 'class-variance-authority';

/**
 * ListingCard — a browse/discovery card composing an image, favourite toggle,
 * rating, title, meta, and price. Every value maps to a design token; layout
 * spacing uses the token-backed Tailwind scale.
 */
export const listingCardVariants = cva('group flex flex-col gap-1.5 text-left', {
  variants: {
    width: {
      /** Fills its grid column. */
      auto: 'w-full',
      /** Fixed comfortable reading width for standalone use. */
      fixed: 'w-full max-w-xs',
    },
  },
  defaultVariants: {
    width: 'auto',
  },
});

export type ListingCardVariants = VariantProps<typeof listingCardVariants>;
