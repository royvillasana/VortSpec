import type { Meta, StoryObj } from '@storybook/react';
import { Select } from './Select';

const sampleOptions = [
  { value: 'us', label: 'United States' },
  { value: 'ca', label: 'Canada' },
  { value: 'mx', label: 'Mexico' },
  { value: 'uk', label: 'United Kingdom' },
];

const meta: Meta<typeof Select> = {
  title: 'Select',
  component: Select,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Form field wrapping a styled native select. Renders label / control / hint / error with an overlaid caret, keeping full keyboard and assistive-tech semantics.',
      },
    },
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'Control padding/density.',
    },
    label: { control: 'text', description: 'Visible field label.' },
    hint: { control: 'text', description: 'Helper text shown below the control.' },
    error: {
      control: 'text',
      description: 'Error message; enables invalid styling + aria-invalid.',
    },
    placeholder: {
      control: 'text',
      description: 'Disabled first option (single-select only).',
    },
    required: { control: 'boolean', description: 'Marks the field as required.' },
    multiple: { control: 'boolean', description: 'Renders a native multi-select listbox.' },
    disabled: { control: 'boolean', description: 'Disables the control.' },
  },
  args: {
    label: 'Country',
    options: sampleOptions,
    placeholder: 'Select a country',
    size: 'medium',
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 320 }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof Select>;

export const Default: Story = {};

// --- Sizes ---
export const Small: Story = { args: { size: 'small', label: 'Small select' } };
export const Medium: Story = { args: { size: 'medium', label: 'Medium select' } };
export const Large: Story = { args: { size: 'large', label: 'Large select' } };

// --- States ---
export const WithHint: Story = {
  args: { label: 'Country', hint: 'Where should we ship your order?' },
};

export const WithError: Story = {
  args: { label: 'Country', error: 'Please choose a country.' },
};

export const Required: Story = {
  args: { label: 'Country', required: true },
};

export const Disabled: Story = {
  args: { label: 'Country', disabled: true },
};

export const WithDisabledOption: Story = {
  args: {
    label: 'Plan',
    placeholder: 'Choose a plan',
    options: [
      { value: 'free', label: 'Free' },
      { value: 'pro', label: 'Pro' },
      { value: 'enterprise', label: 'Enterprise (contact sales)', disabled: true },
    ],
  },
};

export const Multiple: Story = {
  args: {
    label: 'Countries',
    multiple: true,
    placeholder: undefined,
    hint: 'Hold Cmd/Ctrl to select multiple.',
  },
};
