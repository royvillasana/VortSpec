import * as React from 'react';
import { cn } from '@/lib/utils';
import { Icon } from '@/components/ui/Icon';
import { accordionSummaryVariants, accordionBodyVariants } from './accordion.variants';

/** A single collapsible panel within an `Accordion`. */
export interface AccordionItem {
  /** Stable unique key for the panel. */
  id: string;
  /** Header content rendered in the always-visible summary row. */
  title: React.ReactNode;
  /** Body content revealed when the panel is expanded. */
  content: React.ReactNode;
  /** Render the panel expanded on mount. */
  defaultOpen?: boolean;
  /** Disable toggling for this panel (non-interactive, dimmed). */
  disabled?: boolean;
}

export interface AccordionProps extends React.HTMLAttributes<HTMLDivElement> {
  /** The collapsible panels to render, top to bottom. */
  items: AccordionItem[];
  /**
   * Allow multiple panels open at once (default). When `false`, panels share a
   * `name` so the browser keeps only one open at a time (exclusive accordion).
   */
  allowMultiple?: boolean;
}

/**
 * Accordion — a stack of collapsible panels built on native `<details>`/
 * `<summary>` for button semantics, expanded state, and keyboard toggling
 * (Enter/Space) with no JS state. A chevron rotates to reflect open state.
 */
const Accordion = React.forwardRef<HTMLDivElement, AccordionProps>(
  ({ className, items, allowMultiple = true, ...props }, ref) => {
    // Stable group name shared by all panels when exclusive (single-open).
    const groupName = React.useId();
    return (
      <div
        ref={ref}
        className={cn(
          'rounded border border-1 border-neutral-300 divide-y divide-neutral-300 overflow-hidden',
          className
        )}
        {...props}
      >
        {items.map((item) => {
          const chevron = (
            <Icon
              name="chevron-down"
              size="small"
              aria-hidden
              className="transition-transform group-open:rotate-180"
            />
          );

          // Disabled panels render a non-interactive summary-like row so they
          // cannot be toggled by mouse OR keyboard (native <summary> would still
          // toggle on Enter/Space). No <details>, so it stays collapsed.
          if (item.disabled) {
            return (
              <div key={item.id} className="group">
                <div
                  className={accordionSummaryVariants({ disabled: true })}
                  aria-disabled="true"
                >
                  <span>{item.title}</span>
                  {chevron}
                </div>
              </div>
            );
          }

          return (
            <details
              key={item.id}
              className="group"
              open={item.defaultOpen}
              name={allowMultiple ? undefined : groupName}
            >
              <summary className={accordionSummaryVariants({ disabled: false })}>
                <span>{item.title}</span>
                {chevron}
              </summary>
              <div className={accordionBodyVariants()}>{item.content}</div>
            </details>
          );
        })}
      </div>
    );
  }
);
Accordion.displayName = 'Accordion';

export { Accordion };
