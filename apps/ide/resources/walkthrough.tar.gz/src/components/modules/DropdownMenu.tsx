import * as React from 'react';
import { cn } from '@/lib/utils';
import { dropdownMenuItemVariants } from './dropdown-menu.variants';

/** A selectable/actionable row. Renders as `<a>` when `href` is set, else `<button>`. */
export interface DropdownMenuItemEntry {
  type: 'item';
  /** Row label (text or node). */
  label: React.ReactNode;
  /** Optional leading icon slot, rendered before the label. */
  icon?: React.ReactNode;
  /** When set, the row renders as an anchor pointing here. */
  href?: string;
  /** Dims the row and blocks interaction (`aria-disabled`). */
  disabled?: boolean;
  /** Marks the row as the current/highlighted selection. */
  active?: boolean;
  /** Invoked when the row is chosen (click / Enter). */
  onSelect?: () => void;
}

/** A horizontal divider between item groups. */
export interface DropdownMenuSeparatorEntry {
  type: 'separator';
}

/** A non-interactive label heading a group of items. */
export interface DropdownMenuGroupLabelEntry {
  type: 'group-label';
  label: React.ReactNode;
}

/** Discriminated union of every entry the menu can render. */
export type DropdownMenuEntry =
  | DropdownMenuItemEntry
  | DropdownMenuSeparatorEntry
  | DropdownMenuGroupLabelEntry;

export interface DropdownMenuProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Ordered list of entries (items, separators, group labels) to render. */
  items: DropdownMenuEntry[];
}

/**
 * DropdownMenu — a presentational menu surface (`role="menu"`) listing items,
 * separators, and group labels. Open/close state and focus management are the
 * parent's responsibility; this renders the panel and its rows only.
 */
const DropdownMenu = React.forwardRef<HTMLDivElement, DropdownMenuProps>(
  ({ className, items, ...props }, ref) => {
    return (
      <div
        ref={ref}
        role="menu"
        className={cn(
          'min-w-20 rounded border border-1 border-neutral-300 bg-white p-1 shadow-md ' +
            'font-base text-body leading-body',
          className
        )}
        {...props}
      >
        {items.map((entry, index) => {
          if (entry.type === 'separator') {
            return (
              <hr key={index} role="separator" className="my-1 border-neutral-300" />
            );
          }

          if (entry.type === 'group-label') {
            return (
              <div key={index} className="px-3 py-1 text-body text-muted">
                {entry.label}
              </div>
            );
          }

          const { label, icon, href, disabled, active, onSelect } = entry;
          const itemClassName = dropdownMenuItemVariants({
            active: Boolean(active),
            disabled: Boolean(disabled),
          });
          const content = (
            <>
              {icon != null && (
                <span className="flex shrink-0 items-center">{icon}</span>
              )}
              <span>{label}</span>
            </>
          );

          if (href) {
            return (
              <a
                key={index}
                role="menuitem"
                href={disabled ? undefined : href}
                aria-disabled={disabled || undefined}
                aria-current={active ? 'true' : undefined}
                className={itemClassName}
                onClick={disabled ? undefined : onSelect}
              >
                {content}
              </a>
            );
          }

          return (
            <button
              key={index}
              type="button"
              role="menuitem"
              disabled={disabled}
              aria-disabled={disabled || undefined}
              aria-current={active ? 'true' : undefined}
              className={itemClassName}
              onClick={onSelect}
            >
              {content}
            </button>
          );
        })}
      </div>
    );
  }
);
DropdownMenu.displayName = 'DropdownMenu';

export { DropdownMenu };
