import * as React from 'react';
import { cn } from '@/lib/utils';
import { Paragraph } from '@/components/ui/Paragraph';
import { pageTitleVariants, type PageTitleVariants } from './page-title.variants';

export interface PageTitleProps
  extends React.HTMLAttributes<HTMLElement>,
    PageTitleVariants {
  /** Small overline label above the title. */
  eyebrow?: React.ReactNode;
  /** Supporting description below the title. */
  description?: React.ReactNode;
}

/**
 * PageTitle — primary page heading block (eyebrow + H1 + description).
 */
const PageTitle = React.forwardRef<HTMLElement, PageTitleProps>(
  ({ className, align, eyebrow, description, children, ...props }, ref) => (
    <header ref={ref} className={cn(pageTitleVariants({ align }), className)} {...props}>
      {eyebrow && (
        <span className="font-base text-h6 font-regular uppercase leading-body text-muted">
          {eyebrow}
        </span>
      )}
      <h1 className="m-0 font-base text-h1 font-regular leading-heading text-text">{children}</h1>
      {description && <Paragraph tone="muted">{description}</Paragraph>}
    </header>
  )
);
PageTitle.displayName = 'PageTitle';

export { PageTitle };
