import { cva, type VariantProps } from 'class-variance-authority';

/**
 * NavItem — a single navigation link across orientations (horizontal bar,
 * vertical rail, inline tree) and depths. Deeper `level` values add left indent
 * for inline/vertical layouts; the `active` item takes the primary text color
 * and, for vertical/inline, a subtle brand surface. Every value resolves to a
 * design token (no hardcoded colors, spacing, or radius).
 */
export const navItemVariants = cva(
  'inline-flex items-center gap-2 rounded px-3 py-2 font-base text-body leading-body font-regular cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2',
  {
    variants: {
      orientation: {
        horizontal: '',
        vertical: '',
        inline: '',
      },
      level: {
        1: '',
        2: '',
        3: '',
      },
      active: {
        true: 'text-primary',
        false: 'text-text hover:bg-neutral-100 hover:text-primary',
      },
      disabled: {
        true: 'opacity-disabled pointer-events-none',
        false: '',
      },
    },
    compoundVariants: [
      // Left indent per depth (inline/vertical only — horizontal ignores level)
      { orientation: 'vertical', level: 2, className: 'pl-4' },
      { orientation: 'inline', level: 2, className: 'pl-4' },
      { orientation: 'vertical', level: 3, className: 'pl-6' },
      { orientation: 'inline', level: 3, className: 'pl-6' },
      // Active surface — vertical/inline get a subtle brand-tinted row
      { orientation: 'vertical', active: true, className: 'bg-brand-primary-100' },
      { orientation: 'inline', active: true, className: 'bg-brand-primary-100' },
    ],
    defaultVariants: {
      orientation: 'horizontal',
      level: 1,
      active: false,
      disabled: false,
    },
  }
);

export type NavItemVariants = VariantProps<typeof navItemVariants>;
