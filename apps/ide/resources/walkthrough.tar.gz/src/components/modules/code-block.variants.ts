import { cva, type VariantProps } from 'class-variance-authority';

/**
 * CodeBlock — formatted snippet surface. Neutral background + default text
 * tokens; monospace family is intentional for code legibility.
 */
export const codeBlockVariants = cva(
  'block w-full overflow-x-auto rounded p-3 font-mono text-body leading-body',
  {
    variants: {
      tone: {
        neutral: 'bg-neutral-100 text-text',
        dark: 'bg-near-black text-white',
      },
    },
    defaultVariants: {
      tone: 'neutral',
    },
  }
);

export type CodeBlockVariants = VariantProps<typeof codeBlockVariants>;
