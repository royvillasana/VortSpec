import { cva, type VariantProps } from 'class-variance-authority';

/**
 * FileInput variants — the size axis is mirrored 1:1 to `buttonVariants` so the
 * styled trigger `<label>` matches Button sizing exactly. The CVA here drives the
 * outer wrapper's vertical rhythm (gap between label / trigger / filename / hint).
 *   Size → `size` (small | medium | large)
 *
 * Every spacing/font utility resolves to a design token via the Tailwind theme
 * mapping (tailwind.config.js). No hardcoded values.
 */
export const fileInputVariants = cva(
  'flex flex-col font-base font-regular text-body leading-body',
  {
    variants: {
      size: {
        small: 'gap-1',
        medium: 'gap-1.5',
        large: 'gap-2',
      },
    },
    defaultVariants: {
      size: 'medium',
    },
  }
);

export type FileInputVariants = VariantProps<typeof fileInputVariants>;
