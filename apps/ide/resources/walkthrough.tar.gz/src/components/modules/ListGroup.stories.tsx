import type { Meta, StoryObj } from '@storybook/react';
import { ListGroup } from './ListGroup';
import { Icon } from '@/components/ui/Icon';
import { Tag } from '@/components/ui/Tag';

const meta: Meta<typeof ListGroup> = {
  title: 'ListGroup',
  component: ListGroup,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Bordered vertical list. Each item is a static row, or an action row (link/button) when it has href/onClick, supporting a leading icon, trailing badge, and active/disabled states.',
      },
    },
  },
  args: {
    items: [
      { label: 'Dashboard' },
      { label: 'Projects' },
      { label: 'Settings' },
    ],
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 320 }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof ListGroup>;

export const Default: Story = {};

export const WithIcons: Story = {
  args: {
    items: [
      { label: 'Overview', icon: <Icon name="list" /> },
      { label: 'Calendar', icon: <Icon name="calendar" /> },
      { label: 'Search', icon: <Icon name="search" /> },
    ],
  },
};

export const WithBadges: Story = {
  args: {
    items: [
      { label: 'Inbox', badge: <Tag>12</Tag> },
      { label: 'Drafts', badge: <Tag>3</Tag> },
      { label: 'Archive', badge: <Tag>99+</Tag> },
    ],
  },
};

export const ActionRows: Story = {
  args: {
    items: [
      { label: 'Home', href: '#home' },
      { label: 'Profile', onClick: () => {} },
      { label: 'Log out', onClick: () => {} },
    ],
  },
};

export const WithActiveItem: Story = {
  args: {
    items: [
      { label: 'Dashboard', onClick: () => {}, active: true },
      { label: 'Reports', onClick: () => {} },
      { label: 'Settings', onClick: () => {} },
    ],
  },
};

export const WithDisabledItem: Story = {
  args: {
    items: [
      { label: 'Available', onClick: () => {} },
      { label: 'Disabled', onClick: () => {}, disabled: true },
      { label: 'Available', onClick: () => {} },
    ],
  },
};

export const RichRows: Story = {
  args: {
    items: [
      { label: 'Team', icon: <Icon name="star" />, badge: <Tag>New</Tag>, onClick: () => {}, active: true },
      { label: 'Billing', icon: <Icon name="calendar" />, onClick: () => {} },
      { label: 'Integrations', icon: <Icon name="link" />, badge: <Tag>4</Tag>, onClick: () => {} },
    ],
  },
};
