import * as React from 'react';
import { cn } from '@/lib/utils';
import {
  titleVariants,
  titleHeadingVariants,
  type TitleVariants,
  type TitleLevel,
} from './title.variants';

export interface TitleProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title'>,
    TitleVariants {
  /** Heading level (1–6) — sets both the semantic tag and the size token. */
  level?: TitleLevel;
  /** Subtitle rendered below the heading in the secondary theme color. */
  subtitle?: React.ReactNode;
  /** Inline badge rendered after the heading text. */
  badge?: React.ReactNode;
  leadingIcon?: React.ReactNode;
  trailingIcon?: React.ReactNode;
}

/**
 * Title — heading composed with optional subtitle, badge, and left/right icons.
 */
const Title = React.forwardRef<HTMLDivElement, TitleProps>(
  (
    { className, level = 2, fillContainer, subtitle, badge, leadingIcon, trailingIcon, children, ...props },
    ref
  ) => {
    const Heading = `h${level}` as React.ElementType;
    return (
      <div ref={ref} className={cn(titleVariants({ fillContainer }), className)} {...props}>
        <div className="flex items-center gap-2">
          {leadingIcon}
          <Heading className={titleHeadingVariants({ level: String(level) as '1' })}>
            {children}
          </Heading>
          {badge}
          {trailingIcon}
        </div>
        {subtitle && (
          <span className="font-base text-body font-regular leading-body text-secondary">
            {subtitle}
          </span>
        )}
      </div>
    );
  }
);
Title.displayName = 'Title';

export { Title };
