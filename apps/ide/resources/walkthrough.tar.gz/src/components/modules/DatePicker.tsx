import * as React from 'react';
import { cn } from '@/lib/utils';
import { Icon } from '@/components/ui/Icon';
import { datePickerVariants, type DatePickerVariants } from './date-picker.variants';

export interface DatePickerProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'>,
    DatePickerVariants {
  /** Field label rendered above the control and associated via `htmlFor`. */
  label?: React.ReactNode;
  /** Helper text shown below the control (hidden when `error` is set). */
  hint?: string;
  /** Error message shown below the control; also flips the control to invalid. */
  error?: string;
  /** Marks the field required (native + a visual asterisk on the label). */
  required?: boolean;
  /** Render a start + end date-range pair instead of a single date input. */
  range?: boolean;
  /** Range-mode callback fired with the current start/end values on change. */
  onRangeChange?: (start: string, end: string) => void;
}

/**
 * DatePicker — a labeled date-selection field that wraps the NATIVE
 * `<input type="date">`.
 *
 * We deliberately wrap the native date input rather than build a custom calendar
 * popover: the native control ships its own accessible picker + keyboard support
 * across platforms, and it keeps the component fully token-pure and robust. A
 * leading calendar Icon adornment sits inside a `relative` container (the input
 * gets `pl-8` to make room). `range` mode renders two date inputs — start and
 * end — separated by a short en-dash, each named via `aria-label`.
 *
 * Single mode spreads native `...props` (value/onChange/min/max/...) onto the
 * input. Range mode manages its own start/end state and reports changes through
 * `onRangeChange`; the remaining native props (min/max/disabled/...) are spread
 * onto both inputs, while value/onChange are handled internally.
 */
const DatePicker = React.forwardRef<HTMLInputElement, DatePickerProps>(
  (
    {
      className,
      size,
      invalid,
      label,
      hint,
      error,
      required,
      range = false,
      onRangeChange,
      id,
      ...props
    },
    ref
  ) => {
    const reactId = React.useId();
    const fieldId = id ?? reactId;
    const hintId = hint ? `${fieldId}-hint` : undefined;
    const errorId = error ? `${fieldId}-error` : undefined;
    const isInvalid = invalid ?? !!error;
    const describedBy =
      [props['aria-describedby'], hintId, errorId].filter(Boolean).join(' ') || undefined;

    const [start, setStart] = React.useState('');
    const [end, setEnd] = React.useState('');

    const leadingIcon = (
      <Icon
        name="calendar"
        size="small"
        aria-hidden
        className="pointer-events-none absolute left-2 top-1/2 -translate-y-1/2 text-muted"
      />
    );

    let control: React.ReactNode;

    if (range) {
      // Range mode: internal state + onRangeChange. Exclude single-input value
      // handlers from the spread so both inputs stay controlled internally.
      const { value: _value, defaultValue: _defaultValue, onChange: _onChange, ...rangeProps } =
        props;

      const handleStart = (event: React.ChangeEvent<HTMLInputElement>) => {
        const next = event.target.value;
        setStart(next);
        onRangeChange?.(next, end);
      };
      const handleEnd = (event: React.ChangeEvent<HTMLInputElement>) => {
        const next = event.target.value;
        setEnd(next);
        onRangeChange?.(start, next);
      };

      control = (
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            {leadingIcon}
            <input
              {...rangeProps}
              ref={ref}
              id={fieldId}
              type="date"
              required={required}
              aria-label="Start date"
              aria-invalid={isInvalid || undefined}
              aria-describedby={describedBy}
              value={start}
              onChange={handleStart}
              className={cn(datePickerVariants({ size, invalid: isInvalid }))}
            />
          </div>
          <span aria-hidden className="text-muted">
            –
          </span>
          <div className="relative flex-1">
            {leadingIcon}
            <input
              {...rangeProps}
              type="date"
              required={required}
              aria-label="End date"
              aria-invalid={isInvalid || undefined}
              aria-describedby={describedBy}
              value={end}
              onChange={handleEnd}
              className={cn(datePickerVariants({ size, invalid: isInvalid }))}
            />
          </div>
        </div>
      );
    } else {
      control = (
        <div className="relative">
          {leadingIcon}
          <input
            {...props}
            ref={ref}
            id={fieldId}
            type="date"
            required={required}
            aria-invalid={isInvalid || undefined}
            aria-describedby={describedBy}
            className={cn(datePickerVariants({ size, invalid: isInvalid }))}
          />
        </div>
      );
    }

    return (
      <div className={cn('flex flex-col gap-1 font-base', className)}>
        {label != null && (
          <label htmlFor={fieldId} className="text-body font-regular text-text">
            {label}
            {required && (
              <span aria-hidden className="text-danger">
                {' '}
                *
              </span>
            )}
          </label>
        )}
        {control}
        {hint && !error && (
          <span id={hintId} className="text-body text-muted">
            {hint}
          </span>
        )}
        {error && (
          <span id={errorId} role="alert" className="text-body text-danger">
            {error}
          </span>
        )}
      </div>
    );
  }
);
DatePicker.displayName = 'DatePicker';

export { DatePicker };
