import * as React from 'react';
import { cn } from '@/lib/utils';
import { Icon } from '@/components/ui/Icon';
import { breadcrumbVariants } from './breadcrumb.variants';

export interface BreadcrumbItem {
  /** Visible crumb label. */
  label: React.ReactNode;
  /** When set, the crumb renders as a link. The last crumb is never linked. */
  href?: string;
}

export interface BreadcrumbProps extends React.HTMLAttributes<HTMLElement> {
  /** Ordered trail of crumbs; the last item is the current page. */
  items: BreadcrumbItem[];
  /** Override the separator between crumbs (decorative). Defaults to a chevron. */
  separator?: React.ReactNode;
}

/**
 * Breadcrumb — navigation trail of crumbs inside a labelled `<nav>`.
 * Intermediate crumbs render as links (or plain text when they have no `href`);
 * the last crumb renders as the current page (`aria-current="page"`, no link).
 * Separators are decorative (`aria-hidden`) and never wrap a link.
 */
const Breadcrumb = React.forwardRef<HTMLElement, BreadcrumbProps>(
  ({ className, items, separator, ...props }, ref) => {
    const sep = separator ?? (
      <Icon name="chevron-right" size="small" aria-hidden className="text-muted" />
    );
    const lastIndex = items.length - 1;

    return (
      <nav ref={ref} aria-label="Breadcrumb" className={cn(className)} {...props}>
        <ol className={breadcrumbVariants()}>
          {items.map((item, index) => {
            const isLast = index === lastIndex;
            return (
              <li key={index} className="inline-flex items-center gap-2">
                {isLast ? (
                  <span aria-current="page" className="text-text">
                    {item.label}
                  </span>
                ) : item.href ? (
                  <a
                    href={item.href}
                    className="text-muted hover:text-primary underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 rounded-sm"
                  >
                    {item.label}
                  </a>
                ) : (
                  <span className="text-muted">{item.label}</span>
                )}
                {!isLast && (
                  <span aria-hidden className="inline-flex items-center text-muted">
                    {sep}
                  </span>
                )}
              </li>
            );
          })}
        </ol>
      </nav>
    );
  }
);
Breadcrumb.displayName = 'Breadcrumb';

export { Breadcrumb };
