import * as React from 'react';
import { cn } from '@/lib/utils';
import { Icon } from '@/components/ui/Icon';
import { timePickerVariants, type TimePickerVariants } from './time-picker.variants';

export interface TimePickerProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'>,
    TimePickerVariants {
  /** Optional field label associated with the input via `htmlFor`. */
  label?: React.ReactNode;
  /** Helper text shown below the field (hidden when `error` is present). */
  hint?: string;
  /** Error message shown below the field; sets `aria-invalid` + danger styling. */
  error?: string;
}

/**
 * TimePicker — a labeled field wrapping the native `<input type="time">`.
 *
 * The native control is used deliberately: it keeps built-in accessibility,
 * keyboard behaviour, and locale-aware time entry for free, and stays fully
 * token-pure. A leading, decorative clock `Icon` is overlaid inside a
 * `relative` container (the input reserves `pl-8` for it). The field follows
 * the same label / hint / error / aria pattern as the Input molecule:
 * `error` drives `aria-invalid` and the danger border, and hint/error are
 * wired to the input through `aria-describedby`. Native attributes
 * (`value`, `onChange`, `min`, `max`, `step`, …) spread onto the input.
 */
const TimePicker = React.forwardRef<HTMLInputElement, TimePickerProps>(
  (
    { className, size, invalid, label, hint, error, required, id, disabled, ...props },
    ref
  ) => {
    const reactId = React.useId();
    const inputId = id ?? reactId;
    const hintId = `${inputId}-hint`;
    const errorId = `${inputId}-error`;

    const isInvalid = invalid ?? Boolean(error);
    const describedBy = error ? errorId : hint ? hintId : undefined;

    return (
      <div className={cn('flex flex-col gap-1', className)}>
        {label != null && (
          <label htmlFor={inputId} className="text-body font-regular text-text">
            {label}
            {required && <span className="text-danger"> *</span>}
          </label>
        )}
        <div className="relative">
          <Icon
            name="clock"
            size="small"
            aria-hidden
            className="pointer-events-none absolute left-2 top-1/2 -translate-y-1/2 text-muted"
          />
          <input
            ref={ref}
            id={inputId}
            type="time"
            required={required}
            disabled={disabled}
            aria-invalid={isInvalid || undefined}
            aria-describedby={describedBy}
            className={cn(timePickerVariants({ size, invalid: isInvalid }))}
            {...props}
          />
        </div>
        {error ? (
          <p id={errorId} className="text-body text-danger">
            {error}
          </p>
        ) : hint ? (
          <p id={hintId} className="text-body text-muted">
            {hint}
          </p>
        ) : null}
      </div>
    );
  }
);
TimePicker.displayName = 'TimePicker';

export { TimePicker };
