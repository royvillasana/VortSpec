import type { Meta, StoryObj } from '@storybook/react';
import { Breadcrumb } from './Breadcrumb';

const sampleItems = [
  { label: 'Home', href: '/' },
  { label: 'Products', href: '/products' },
  { label: 'Footwear', href: '/products/footwear' },
  { label: 'Running Shoes' },
];

const meta: Meta<typeof Breadcrumb> = {
  title: 'Breadcrumb',
  component: Breadcrumb,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Navigation trail of crumbs inside a labelled <nav>. Intermediate crumbs are links; the last crumb is the current page (aria-current="page").',
      },
    },
  },
  argTypes: {
    items: {
      control: false,
      description: 'Ordered trail of crumbs; the last item is the current page.',
    },
    separator: {
      control: 'text',
      description: 'Override the decorative separator between crumbs. Defaults to a chevron.',
    },
  },
  args: {
    items: sampleItems,
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 560 }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof Breadcrumb>;

export const Default: Story = {};

// A short two-level trail.
export const TwoLevels: Story = {
  args: {
    items: [{ label: 'Dashboard', href: '/' }, { label: 'Settings' }],
  },
};

// Custom text separator instead of the default chevron.
export const CustomSeparator: Story = {
  args: {
    separator: '/',
  },
};

// A crumb without href renders as plain (non-link) text.
export const WithNonLinkCrumb: Story = {
  args: {
    items: [
      { label: 'Home', href: '/' },
      { label: 'Archived' },
      { label: 'Q3 Report' },
    ],
  },
};
