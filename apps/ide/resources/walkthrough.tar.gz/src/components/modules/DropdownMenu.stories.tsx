import type { Meta, StoryObj } from '@storybook/react';
import { DropdownMenu, type DropdownMenuEntry } from './DropdownMenu';
import { Icon } from '@/components/ui/Icon';

const sampleItems: DropdownMenuEntry[] = [
  { type: 'group-label', label: 'Account' },
  { type: 'item', label: 'Favorites', icon: <Icon name="star" size="small" aria-hidden /> },
  { type: 'item', label: 'Options', icon: <Icon name="list" size="small" aria-hidden /> },
  { type: 'separator' },
  { type: 'item', label: 'Documentation', href: '#docs' },
  { type: 'item', label: 'Disabled action', disabled: true },
  { type: 'separator' },
  { type: 'item', label: 'Sign out', icon: <Icon name="x-circle" size="small" aria-hidden /> },
];

const meta: Meta<typeof DropdownMenu> = {
  title: 'DropdownMenu',
  component: DropdownMenu,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A presentational menu surface (role="menu") that renders items, separators, and group labels. Open/close state and focus management are the parent\'s responsibility.',
      },
    },
  },
  argTypes: {
    items: {
      control: false,
      description: 'Ordered list of entries (items, separators, group labels) to render.',
    },
  },
  args: {
    items: sampleItems,
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 240 }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof DropdownMenu>;

export const Default: Story = {};

// A minimal action-only menu.
export const ItemsOnly: Story = {
  args: {
    items: [
      { type: 'item', label: 'Edit' },
      { type: 'item', label: 'Duplicate' },
      { type: 'item', label: 'Delete' },
    ],
  },
};

// Highlighted/current selection via the active flag.
export const WithActiveItem: Story = {
  args: {
    items: [
      { type: 'item', label: 'Light', active: true },
      { type: 'item', label: 'Dark' },
      { type: 'item', label: 'System' },
    ],
  },
};

// A disabled, non-interactive row.
export const WithDisabledItem: Story = {
  args: {
    items: [
      { type: 'item', label: 'Available' },
      { type: 'item', label: 'Unavailable', disabled: true },
    ],
  },
};
