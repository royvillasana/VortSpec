import { cva, type VariantProps } from 'class-variance-authority';

/**
 * TimePicker control variants — styles the native `<input type="time">` that
 * sits inside a labeled field. Mirrors the Input molecule's field treatment.
 *   Size    → `size` (small | medium | large) controls vertical padding
 *   Invalid → `invalid` (boolean) swaps the border + focus ring to danger
 *   State   → CSS pseudo-classes (:focus-visible, :disabled)
 *
 * `pl-8` reserves room for the leading clock Icon adornment. Every
 * color/spacing/radius/font utility resolves to a design token via the
 * Tailwind theme mapping (tailwind.config.js). No hardcoded values.
 */
export const timePickerVariants = cva(
  'w-full rounded border border-1 border-neutral-300 bg-white text-text text-body font-base font-regular leading-body pl-8 ' +
    'transition-colors duration-150 ease-out ' +
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 ' +
    'disabled:opacity-disabled disabled:cursor-not-allowed disabled:bg-neutral-100',
  {
    variants: {
      size: {
        small: 'pr-2 py-1',
        medium: 'pr-2.5 py-2',
        large: 'pr-3 py-2.5',
      },
      invalid: {
        true: 'border-danger focus-visible:ring-danger',
        false: 'focus-visible:ring-primary',
      },
    },
    defaultVariants: {
      size: 'medium',
      invalid: false,
    },
  }
);

export type TimePickerVariants = VariantProps<typeof timePickerVariants>;
