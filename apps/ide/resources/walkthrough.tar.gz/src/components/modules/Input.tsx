import * as React from 'react';
import { cn } from '@/lib/utils';
import { inputVariants, fieldVariants, type InputVariants } from './input.variants';

export interface InputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'>,
    InputVariants {
  /** Visible label, associated with the control via `htmlFor`/`id`. */
  label?: React.ReactNode;
  /** Muted help text rendered beneath the control; wired via `aria-describedby`. */
  hint?: string;
  /** Error message; sets the danger state + `aria-invalid` and is announced via `aria-describedby`. */
  error?: string;
}

/**
 * Input — a labeled single-line text field. Composes a `<label>`, the native
 * `<input>` control, and a help/error line, wiring accessibility (htmlFor/id,
 * aria-invalid, aria-describedby) automatically. Styles are token-referenced and
 * fully encapsulated; consumers pass semantic props plus an optional `className`
 * (merged last on the outer wrapper) for layout overrides.
 */
const Input = React.forwardRef<HTMLInputElement, InputProps>(
  (
    { className, size, orientation, label, hint, error, id, required, disabled, ...props },
    ref
  ) => {
    const generatedId = React.useId();
    const inputId = id ?? generatedId;
    const hintId = `${inputId}-hint`;
    const errorId = `${inputId}-error`;
    const invalid = Boolean(error);
    const describedBy =
      [hint ? hintId : null, error ? errorId : null].filter(Boolean).join(' ') || undefined;

    return (
      <div className={cn('flex flex-col gap-1', className)}>
        <div className={fieldVariants({ orientation })}>
          {label && (
            <label htmlFor={inputId} className="text-body text-text">
              {label}
              {required && (
                <span className="text-danger" aria-hidden>
                  {' '}
                  *
                </span>
              )}
            </label>
          )}
          <input
            ref={ref}
            id={inputId}
            required={required}
            disabled={disabled}
            aria-invalid={invalid || undefined}
            aria-describedby={describedBy}
            className={inputVariants({ size, invalid })}
            {...props}
          />
        </div>
        {hint && (
          <span id={hintId} className="text-muted text-body">
            {hint}
          </span>
        )}
        {error && (
          <span id={errorId} className="text-danger text-body">
            {error}
          </span>
        )}
      </div>
    );
  }
);
Input.displayName = 'Input';

export { Input };
