import type { Meta, StoryObj } from '@storybook/react';
import { TimePicker } from './TimePicker';

const meta: Meta<typeof TimePicker> = {
  title: 'TimePicker',
  component: TimePicker,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Labeled field wrapping the native time input, with a leading clock icon and the same label / hint / error / aria pattern as the Input molecule.',
      },
    },
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'Control padding/density.',
    },
    invalid: {
      control: 'boolean',
      description: 'Forces the danger border/ring (also inferred from error).',
    },
    label: { control: 'text', description: 'Optional field label.' },
    hint: { control: 'text', description: 'Helper text shown below the field.' },
    error: {
      control: 'text',
      description: 'Error message; sets aria-invalid + danger styling.',
    },
    required: { control: 'boolean', description: 'Marks the field as required.' },
    disabled: { control: 'boolean', description: 'Disables the control.' },
  },
  args: {
    label: 'Start time',
    defaultValue: '09:30',
    size: 'medium',
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 280 }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof TimePicker>;

export const Default: Story = {};

// --- Sizes ---
export const Small: Story = { args: { size: 'small', label: 'Small' } };
export const Medium: Story = { args: { size: 'medium', label: 'Medium' } };
export const Large: Story = { args: { size: 'large', label: 'Large' } };

// --- States ---
export const WithHint: Story = {
  args: { label: 'Meeting time', hint: 'Times are in your local timezone.' },
};

export const WithError: Story = {
  args: { label: 'Start time', error: 'Please choose a valid time.' },
};

export const Invalid: Story = {
  args: { label: 'End time', invalid: true, defaultValue: '17:00' },
};

export const Required: Story = {
  args: { label: 'Departure', required: true },
};

export const Disabled: Story = {
  args: { label: 'Locked time', disabled: true, defaultValue: '12:00' },
};
