import { cva, type VariantProps } from 'class-variance-authority';

/**
 * DropdownMenu item variants — one interactive row inside the menu surface.
 *   Active   → `active` (boolean: highlighted/current item)
 *   Disabled → `disabled` (boolean: non-interactive, dimmed)
 *   Hover / focus states → CSS pseudo-classes (:hover, :focus-visible)
 *
 * Every color/spacing/radius utility resolves to a design token via the
 * Tailwind theme mapping (tailwind.config.js). No hardcoded values.
 */
export const dropdownMenuItemVariants = cva(
  'flex items-center gap-2 w-full rounded-sm px-3 py-2 font-base text-body leading-body text-left ' +
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2',
  {
    variants: {
      active: {
        true: 'bg-brand-primary-100 text-primary',
        false: 'text-text hover:bg-neutral-100',
      },
      disabled: {
        true: 'opacity-disabled pointer-events-none',
        false: '',
      },
    },
    defaultVariants: {
      active: false,
      disabled: false,
    },
  }
);

export type DropdownMenuVariants = VariantProps<typeof dropdownMenuItemVariants>;
