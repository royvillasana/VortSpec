import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Callout — status message box. Neutral surface with a 1px status-colored
 * border; icon and text inherit the status/emphasis color token. Every color
 * resolves to a design token (no computed tints).
 */
export const calloutVariants = cva(
  'flex items-start gap-2 rounded border border-1 bg-neutral-100 p-3 font-base text-body leading-body',
  {
    variants: {
      status: {
        info: 'border-info text-info-emphasis',
        warning: 'border-warning text-warning-emphasis',
        success: 'border-success text-success',
        danger: 'border-danger text-danger',
        secondary: 'border-secondary text-secondary-emphasis',
      },
    },
    defaultVariants: {
      status: 'info',
    },
  }
);

export type CalloutVariants = VariantProps<typeof calloutVariants>;
export type CalloutStatus = NonNullable<CalloutVariants['status']>;
