import * as React from 'react';
import { cn } from '@/lib/utils';
import { formFloatingVariants } from './form-floating.variants';

export interface FormFloatingProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'as'> {
  /** Field label. Floats over the control when empty, up on focus/fill. */
  label: React.ReactNode;
  /** Which control to render. Defaults to `input`. */
  as?: 'input' | 'textarea' | 'select';
  /** Options for `as="select"`. */
  options?: { value: string; label: string }[];
  /** Error message. Sets `aria-invalid` + `aria-describedby` and danger styling. */
  error?: string;
}

/**
 * FormFloating — a floating-label form field (molecule). The label sits over the
 * control when empty/unfocused and shrinks up to the top edge when the control is
 * focused or filled, using the Tailwind `peer` + `peer-placeholder-shown` +
 * `peer-focus` technique (no JS state). Renders an `<input>`, `<textarea>`, or
 * `<select>`; the label is always programmatically associated via `htmlFor`/`id`.
 * Consumer `className` merges last on the wrapper for layout overrides.
 */
const FormFloating = React.forwardRef<HTMLInputElement, FormFloatingProps>(
  ({ className, label, as = 'input', options, error, id, ...props }, ref) => {
    const reactId = React.useId();
    const controlId = id ?? reactId;
    const errorId = `${controlId}-error`;
    const hasError = Boolean(error);
    const controlClass = formFloatingVariants({ error: hasError });

    // Shared native props for whichever control is rendered.
    const shared = {
      id: controlId,
      className: controlClass,
      'aria-invalid': hasError || undefined,
      'aria-describedby': hasError ? errorId : undefined,
      ...props,
    };

    const labelClass = cn(
      'pointer-events-none absolute left-3 top-1 text-body transition-all',
      hasError ? 'text-danger' : 'text-muted',
      as === 'select'
        ? // Selects don't expose :placeholder-shown reliably — keep the label floated.
          'peer-focus:text-primary'
        : // Empty + unfocused → label drops down + larger; focus/fill → floats back up.
          'peer-placeholder-shown:top-4 peer-placeholder-shown:text-body ' +
            'peer-focus:top-1 peer-focus:text-body peer-focus:text-primary'
    );

    return (
      <div className={cn('relative', className)}>
        {as === 'textarea' ? (
          <textarea
            ref={ref as React.Ref<HTMLTextAreaElement>}
            placeholder=" "
            {...(shared as React.TextareaHTMLAttributes<HTMLTextAreaElement>)}
          />
        ) : as === 'select' ? (
          <select
            ref={ref as React.Ref<HTMLSelectElement>}
            {...(shared as React.SelectHTMLAttributes<HTMLSelectElement>)}
          >
            {options?.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
        ) : (
          <input ref={ref} placeholder=" " {...shared} />
        )}
        <label htmlFor={controlId} className={labelClass}>
          {label}
        </label>
        {hasError && (
          <p id={errorId} className="mt-1 text-body text-danger">
            {error}
          </p>
        )}
      </div>
    );
  }
);
FormFloating.displayName = 'FormFloating';

export { FormFloating };
