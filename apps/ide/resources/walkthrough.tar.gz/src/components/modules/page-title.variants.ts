import { cva, type VariantProps } from 'class-variance-authority';

/**
 * PageTitle — the large primary heading block for a documentation page body.
 * Alignment variant; typography comes from the Heading + Body tokens.
 */
export const pageTitleVariants = cva('flex w-full flex-col gap-1.5 pt-[56px]', {
  variants: {
    align: {
      left: 'items-start text-left',
      center: 'items-center text-center',
    },
  },
  defaultVariants: {
    align: 'left',
  },
});

export type PageTitleVariants = VariantProps<typeof pageTitleVariants>;
