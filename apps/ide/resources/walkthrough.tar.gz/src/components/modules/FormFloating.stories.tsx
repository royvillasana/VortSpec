import type { Meta, StoryObj } from '@storybook/react';
import { FormFloating } from './FormFloating';

const meta: Meta<typeof FormFloating> = {
  title: 'FormFloating',
  component: FormFloating,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A floating-label form field: the label sits over the control when empty and shrinks to the top edge on focus or fill, using the Tailwind peer technique (no JS state). Renders an input, textarea, or select.',
      },
    },
  },
  argTypes: {
    label: { control: 'text', description: 'Field label that floats over/above the control.' },
    as: {
      control: 'select',
      options: ['input', 'textarea', 'select'],
      description: 'Which control to render.',
    },
    error: {
      control: 'text',
      description: 'Error message; sets aria-invalid + aria-describedby and danger styling.',
    },
    options: { control: false, description: 'Options for as="select".' },
  },
  args: {
    label: 'Full name',
    as: 'input',
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 360 }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof FormFloating>;

export const Default: Story = {};

// Textarea control variant.
export const Textarea: Story = {
  args: { label: 'Message', as: 'textarea' },
};

// Select control variant with options.
export const Select: Story = {
  args: {
    label: 'Country',
    as: 'select',
    options: [
      { value: 'us', label: 'United States' },
      { value: 'ca', label: 'Canada' },
      { value: 'mx', label: 'Mexico' },
    ],
  },
};

// Error state.
export const WithError: Story = {
  args: { label: 'Email', error: 'Please enter a valid email address.' },
};
