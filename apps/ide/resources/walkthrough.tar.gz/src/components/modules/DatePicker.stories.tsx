import type { Meta, StoryObj } from '@storybook/react';
import { DatePicker } from './DatePicker';

const meta: Meta<typeof DatePicker> = {
  title: 'DatePicker',
  component: DatePicker,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A labeled date-selection field wrapping the native <input type="date"> with a leading calendar icon, hint/error text, and an optional start/end range mode.',
      },
    },
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'Controls vertical + right padding of the control.',
    },
    invalid: {
      control: 'boolean',
      description: 'Swaps the border and focus ring to danger (also implied by error).',
    },
    label: { control: 'text', description: 'Field label rendered above the control.' },
    hint: { control: 'text', description: 'Helper text below the control (hidden when error is set).' },
    error: { control: 'text', description: 'Error message; also flips the control to invalid.' },
    required: { control: 'boolean', description: 'Marks the field required (native + asterisk).' },
    range: { control: 'boolean', description: 'Render a start + end date-range pair.' },
    disabled: { control: 'boolean', description: 'Disable the control.' },
  },
  args: {
    label: 'Departure date',
    size: 'medium',
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 360 }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof DatePicker>;

export const Default: Story = {};

// --- Sizes ---
export const Small: Story = { args: { size: 'small' } };
export const Large: Story = { args: { size: 'large' } };

// --- States ---
export const WithHint: Story = {
  args: { hint: 'Choose any date after today.' },
};

export const Required: Story = {
  args: { required: true },
};

export const WithError: Story = {
  args: { error: 'Please select a valid date.' },
};

export const Invalid: Story = {
  args: { invalid: true },
};

export const Disabled: Story = {
  args: { disabled: true },
};

// --- Range mode ---
export const Range: Story = {
  args: { label: 'Trip dates', range: true },
};
