import type { Meta, StoryObj } from '@storybook/react';
import { Callout } from './Callout';

const meta: Meta<typeof Callout> = {
  title: 'Callout',
  component: Callout,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Alert/callout box combining a status icon and message text on a tinted status surface (info/warning/success/danger/secondary).',
      },
    },
  },
  argTypes: {
    status: {
      control: 'select',
      options: ['info', 'warning', 'success', 'danger', 'secondary'],
      description: 'Status color of the callout.',
    },
    title: { control: 'text', description: 'Optional heading rendered above the message.' },
    children: { control: 'text', description: 'Message content.' },
  },
  args: {
    status: 'info',
    children: 'This is an informational callout message.',
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 480 }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof Callout>;

export const Default: Story = {};

// --- Statuses ---
export const Info: Story = { args: { status: 'info', children: 'Something you should know.' } };
export const Warning: Story = {
  args: { status: 'warning', children: 'Proceed with caution.' },
};
export const Success: Story = {
  args: { status: 'success', children: 'That worked as expected.' },
};
export const Danger: Story = {
  args: { status: 'danger', children: 'Something went wrong.' },
};
export const Secondary: Story = {
  args: { status: 'secondary', children: 'A neutral, secondary note.' },
};

// --- Composition ---
export const WithTitle: Story = {
  args: {
    status: 'warning',
    title: 'Heads up',
    children: 'This action cannot be undone.',
  },
};

export const NoIcon: Story = {
  args: {
    status: 'info',
    icon: null,
    children: 'A callout rendered without its status icon.',
  },
};
