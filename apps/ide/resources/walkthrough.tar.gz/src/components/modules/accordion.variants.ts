import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Accordion — collapsible panels built on native `<details>`/`<summary>`.
 * Two minimal CVAs: the clickable `summary` header row and the expandable
 * `body`. Every value resolves to a design token (no computed values).
 */

/** Summary (header) row — the clickable disclosure trigger. */
export const accordionSummaryVariants = cva(
  'flex items-center justify-between gap-2 cursor-pointer px-4 py-3 font-base text-body leading-body text-text list-none [&::-webkit-details-marker]:hidden hover:bg-neutral-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-inset',
  {
    variants: {
      disabled: {
        true: 'opacity-disabled pointer-events-none cursor-default',
        false: '',
      },
    },
    defaultVariants: {
      disabled: false,
    },
  }
);

/** Panel body — the revealed content region. */
export const accordionBodyVariants = cva(
  'px-4 py-3 font-base text-body leading-body text-text'
);

export type AccordionSummaryVariants = VariantProps<typeof accordionSummaryVariants>;
export type AccordionVariants = AccordionSummaryVariants;
