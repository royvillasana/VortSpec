import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Input control variants — the native `<input>` inside the Input molecule.
 *   Size    → padding (small | medium | large); all sizes use `text-body`
 *   Invalid → swaps the border + focus ring to danger (driven by the `error` prop)
 *   State   → CSS pseudo-classes (:focus-visible, :disabled)
 *
 * Every color/spacing/radius/font utility resolves to a design token via the
 * Tailwind theme mapping (tailwind.config.js). No hardcoded values.
 */
export const inputVariants = cva(
  'w-full rounded border border-1 border-neutral-300 bg-white text-text text-body font-base font-regular leading-body ' +
    'placeholder:text-muted transition-colors ' +
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 ' +
    'disabled:opacity-disabled disabled:cursor-not-allowed disabled:bg-neutral-100',
  {
    variants: {
      size: {
        small: 'px-2 py-1',
        medium: 'px-2.5 py-2',
        large: 'px-3 py-2.5',
      },
      invalid: {
        true: 'border-danger focus-visible:ring-danger',
        false: 'focus-visible:ring-primary',
      },
    },
    defaultVariants: {
      size: 'medium',
      invalid: false,
    },
  }
);

/**
 * Field wrapper variants — arranges the label relative to the control.
 *   vertical   → label stacked above the control (`gap-1`)
 *   horizontal → label beside the control (`items-center gap-3`)
 */
export const fieldVariants = cva('flex', {
  variants: {
    orientation: {
      vertical: 'flex-col gap-1',
      horizontal: 'items-center gap-3',
    },
  },
  defaultVariants: {
    orientation: 'vertical',
  },
});

/** Public variant props: `size` (control) + `orientation` (layout). */
export type InputVariants = Pick<VariantProps<typeof inputVariants>, 'size'> &
  VariantProps<typeof fieldVariants>;
