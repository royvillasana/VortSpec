import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Breadcrumb — ordered list of navigation crumbs. The base styles the `<ol>`
 * track: inline, wrapping row of items with a consistent gap and body
 * typography. Every value resolves to a design token (no hardcoded units).
 */
export const breadcrumbVariants = cva(
  'inline-flex flex-wrap items-center gap-2 m-0 p-0 list-none font-base text-body leading-body font-regular',
  {
    variants: {
      size: {
        md: 'text-body',
      },
    },
    defaultVariants: {
      size: 'md',
    },
  }
);

export type BreadcrumbVariants = VariantProps<typeof breadcrumbVariants>;
