import type { Meta, StoryObj } from '@storybook/react';
import { PageTitle } from './PageTitle';

const meta: Meta<typeof PageTitle> = {
  title: 'PageTitle',
  component: PageTitle,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'The large primary heading block for a documentation page body: an optional eyebrow overline, the H1, and a supporting description.',
      },
    },
  },
  argTypes: {
    align: {
      control: 'radio',
      options: ['left', 'center'],
      description: 'Horizontal alignment of the block.',
    },
    eyebrow: { control: 'text', description: 'Small overline label above the title.' },
    description: { control: 'text', description: 'Supporting description below the title.' },
    children: { control: 'text', description: 'The page title text (rendered as H1).' },
  },
  args: {
    align: 'left',
    eyebrow: 'Components',
    children: 'Getting started',
    description: 'Everything you need to compose pages with the Design Engineering System.',
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 640 }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof PageTitle>;

export const Default: Story = {};

export const Left: Story = { args: { align: 'left' } };
export const Center: Story = { args: { align: 'center' } };

export const TitleOnly: Story = {
  args: { eyebrow: undefined, description: undefined, children: 'Just a title' },
};
