import { cva, type VariantProps } from 'class-variance-authority';

/**
 * DatePicker control variants — the styled native `<input type="date">` inside
 * the DatePicker molecule. Left padding (`pl-8`) reserves room for the leading
 * calendar Icon adornment.
 *   Size    → `size` (small | medium | large) controls vertical + right padding
 *   Invalid → `invalid` (boolean) swaps the border + focus ring to danger
 *   State   → CSS pseudo-classes (:focus-visible, :disabled)
 *
 * Every color/spacing/radius/font utility resolves to a design token via the
 * Tailwind theme mapping (tailwind.config.js). No hardcoded values.
 */
export const datePickerVariants = cva(
  'w-full rounded border border-1 border-neutral-300 bg-white text-text text-body font-base font-regular ' +
    'pl-8 transition-colors duration-150 ease-out ' +
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 ' +
    'disabled:opacity-disabled disabled:cursor-not-allowed disabled:bg-neutral-100',
  {
    variants: {
      size: {
        small: 'py-1 pr-2',
        medium: 'py-2 pr-2.5',
        large: 'py-2.5 pr-3',
      },
      invalid: {
        true: 'border-danger focus-visible:ring-danger',
        false: 'focus-visible:ring-primary',
      },
    },
    defaultVariants: {
      size: 'medium',
      invalid: false,
    },
  }
);

export type DatePickerVariants = VariantProps<typeof datePickerVariants>;
