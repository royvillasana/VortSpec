import * as React from 'react';
import { cn } from '@/lib/utils';
import { Icon } from '@/components/ui/Icon';
import { Tag } from '@/components/ui/Tag';
import { listingCardVariants, type ListingCardVariants } from './listing-card.variants';

/** Bootstrap-style heart glyph, used for the favourite affordance. */
const HeartPath = (
  <path d="M8 2.748l-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.885.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748z" />
);

export interface ListingCardProps
  extends Omit<React.HTMLAttributes<HTMLElement>, 'title'>,
    ListingCardVariants {
  /** Listing image URL. */
  image: string;
  /** Accessible alt text for the image. */
  imageAlt: string;
  /** Primary line (e.g. location / property name). */
  title: React.ReactNode;
  /** Secondary line (e.g. host or distance). */
  location?: React.ReactNode;
  /** Tertiary muted line (e.g. available dates). */
  meta?: React.ReactNode;
  /** Price value, already formatted (e.g. "$128"). */
  price: React.ReactNode;
  /** Unit rendered after the price. */
  priceUnit?: string;
  /** Rating value shown beside a star (e.g. 4.95). */
  rating?: number;
  /** Optional corner badge (e.g. "Guest favourite"). */
  badge?: React.ReactNode;
  /** Initial favourite state (uncontrolled). */
  defaultFavorite?: boolean;
}

/**
 * ListingCard — image-led browse card (rating, title, meta, price) with a
 * favourite toggle. Composes Icon and Tag; fully token-referenced.
 */
const ListingCard = React.forwardRef<HTMLElement, ListingCardProps>(
  (
    {
      className,
      width,
      image,
      imageAlt,
      title,
      location,
      meta,
      price,
      priceUnit = 'night',
      rating,
      badge,
      defaultFavorite = false,
      ...props
    },
    ref
  ) => {
    const [favorite, setFavorite] = React.useState(defaultFavorite);

    return (
      <article
        ref={ref as React.Ref<HTMLElement>}
        data-component="ListingCard"
        className={cn(listingCardVariants({ width }), className)}
        {...props}
      >
        <div className="relative aspect-square w-full overflow-hidden rounded-md bg-neutral-100">
          <img
            src={image}
            alt={imageAlt}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />

          {badge && (
            <Tag variant="light" size="small" className="absolute left-2 top-2 shadow">
              {badge}
            </Tag>
          )}

          <button
            type="button"
            aria-label={favorite ? 'Remove from wishlist' : 'Save to wishlist'}
            aria-pressed={favorite}
            onClick={() => setFavorite((prev) => !prev)}
            className="absolute right-2 top-2 inline-flex items-center justify-center rounded-full p-1.5 text-white/90 transition hover:scale-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
          >
            <Icon
              size="medium"
              aria-hidden
              className={cn('drop-shadow', favorite ? 'text-danger' : 'fill-black/50')}
            >
              {HeartPath}
            </Icon>
          </button>
        </div>

        <div className="flex items-start justify-between gap-2 pt-0.5">
          <span className="font-base text-body font-regular leading-body text-text">
            {title}
          </span>
          {rating !== undefined && (
            <span
              className="flex shrink-0 items-center gap-1 font-base text-body font-regular leading-body text-text"
              aria-label={`Rated ${rating} out of 5`}
            >
              <Icon name="star-fill" size="small" className="text-warning" aria-hidden />
              {rating.toFixed(2)}
            </span>
          )}
        </div>

        {location && (
          <span className="font-base text-body font-regular leading-body text-muted">
            {location}
          </span>
        )}
        {meta && (
          <span className="font-base text-body font-regular leading-body text-muted">
            {meta}
          </span>
        )}

        <span className="pt-0.5 font-base text-body font-regular leading-body text-text">
          {price} <span className="text-muted">{priceUnit}</span>
        </span>
      </article>
    );
  }
);
ListingCard.displayName = 'ListingCard';

export { ListingCard };
