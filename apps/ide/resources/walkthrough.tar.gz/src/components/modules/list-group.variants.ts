import { cva, type VariantProps } from 'class-variance-authority';

/**
 * ListGroup item variants — a single row in a bordered vertical list group.
 *   interactive → row is an action (`<a>`/`<button>`): adds full-width layout,
 *                 left alignment, hover surface, and a visible focus ring.
 *   active      → selected/current row: primary surface with white foreground.
 *   disabled    → dimmed + non-interactive (`aria-disabled` on the element).
 *
 * Every color/spacing/font utility resolves to a design token via the Tailwind
 * theme mapping (tailwind.config.js). No hardcoded values.
 */
export const listGroupItemVariants = cva(
  'flex items-center gap-2 px-3 py-2 font-base text-body leading-body',
  {
    variants: {
      interactive: {
        true:
          'w-full text-left focus-visible:outline-none focus-visible:ring-2 ' +
          'focus-visible:ring-primary focus-visible:ring-inset',
        false: '',
      },
      active: {
        true: 'bg-primary text-white',
        false: 'text-text',
      },
      disabled: {
        true: 'opacity-disabled pointer-events-none',
        false: '',
      },
    },
    compoundVariants: [
      // Hover surface only for interactive rows that are not active.
      {
        interactive: true,
        active: false,
        class: 'hover:bg-neutral-100',
      },
    ],
    defaultVariants: {
      interactive: false,
      active: false,
      disabled: false,
    },
  }
);

export type ListGroupVariants = VariantProps<typeof listGroupItemVariants>;
