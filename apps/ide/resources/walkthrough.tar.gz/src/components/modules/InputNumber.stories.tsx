import type { Meta, StoryObj } from '@storybook/react';
import { InputNumber } from './InputNumber';

const meta: Meta<typeof InputNumber> = {
  title: 'InputNumber',
  component: InputNumber,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Numeric stepper field: a decrement button, a native number input, and an increment button joined inline, with optional label and hint/error. Respects step, min, max, and disabled.',
      },
    },
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'Control + stepper button padding/density.',
    },
    invalid: {
      control: 'boolean',
      description: 'Forces the danger border/ring (also inferred from error).',
    },
    label: { control: 'text', description: 'Field label rendered above the stepper group.' },
    hint: { control: 'text', description: 'Helper text shown below the control.' },
    error: {
      control: 'text',
      description: 'Error text shown below; sets aria-invalid + danger styling.',
    },
    required: { control: 'boolean', description: 'Marks the field as required.' },
    disabled: { control: 'boolean', description: 'Disables the input and both steppers.' },
    min: { control: 'number', description: 'Minimum value (clamps on step).' },
    max: { control: 'number', description: 'Maximum value (clamps on step).' },
    step: { control: 'number', description: 'Increment/decrement amount.' },
  },
  args: {
    label: 'Quantity',
    defaultValue: 1,
    min: 0,
    max: 10,
    step: 1,
    size: 'medium',
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 280 }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof InputNumber>;

export const Default: Story = {};

// --- Sizes ---
export const Small: Story = { args: { size: 'small', label: 'Small' } };
export const Medium: Story = { args: { size: 'medium', label: 'Medium' } };
export const Large: Story = { args: { size: 'large', label: 'Large' } };

// --- States ---
export const WithHint: Story = {
  args: { label: 'Guests', hint: 'Between 0 and 10.' },
};

export const WithError: Story = {
  args: { label: 'Quantity', error: 'Value is out of range.', defaultValue: 99 },
};

export const Invalid: Story = {
  args: { label: 'Amount', invalid: true, defaultValue: 3 },
};

export const Required: Story = {
  args: { label: 'Seats', required: true },
};

export const Disabled: Story = {
  args: { label: 'Locked', disabled: true, defaultValue: 5 },
};

export const CustomStep: Story = {
  args: { label: 'Volume', min: 0, max: 100, step: 5, defaultValue: 50 },
};
