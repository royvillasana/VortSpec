import { cva, type VariantProps } from 'class-variance-authority';

/** Title wrapper — optionally fills its container width. */
export const titleVariants = cva('flex flex-col gap-1', {
  variants: {
    fillContainer: {
      true: 'w-full',
      false: '',
    },
  },
  defaultVariants: {
    fillContainer: false,
  },
});

/** Heading element sizing — one class per Heading token (H1–H6). */
export const titleHeadingVariants = cva(
  'm-0 font-base font-regular leading-heading text-text',
  {
    variants: {
      level: {
        '1': 'text-h1',
        '2': 'text-h2',
        '3': 'text-h3',
        '4': 'text-h4',
        '5': 'text-h5',
        '6': 'text-h6',
      },
    },
    defaultVariants: {
      level: '2',
    },
  }
);

export type TitleVariants = VariantProps<typeof titleVariants>;
export type TitleLevel = 1 | 2 | 3 | 4 | 5 | 6;
