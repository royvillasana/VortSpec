import * as React from 'react';
import { cn } from '@/lib/utils';
import { listGroupItemVariants } from './list-group.variants';

/** A single entry in a {@link ListGroup}. */
export interface ListGroupItem {
  /** Row content (text or arbitrary node). */
  label: React.ReactNode;
  /** Optional leading icon node (inherits the row foreground color). */
  icon?: React.ReactNode;
  /** Optional trailing badge node (e.g. a `<Tag>`); pushed to the far right. */
  badge?: React.ReactNode;
  /** Marks the row as selected/current (primary surface, `aria-current`). */
  active?: boolean;
  /** Dims the row and blocks interaction (`aria-disabled`). */
  disabled?: boolean;
  /** Renders the row as a link (`<a>`). */
  href?: string;
  /** Renders the row as a button and fires on activation. */
  onClick?: () => void;
}

export interface ListGroupProps extends React.HTMLAttributes<HTMLUListElement> {
  /** The rows to render, top to bottom. */
  items: ListGroupItem[];
}

/** Inner row content shared by static and action rows. */
function ItemContent({ item }: { item: ListGroupItem }) {
  return (
    <>
      {item.icon && <span className="inline-flex shrink-0">{item.icon}</span>}
      <span className="min-w-0">{item.label}</span>
      {item.badge && <span className="ml-auto inline-flex shrink-0">{item.badge}</span>}
    </>
  );
}

/**
 * ListGroup — a bordered vertical list. Each item is a static row, or an
 * "action" row (link/button) when it has `href`/`onClick`. Rows support
 * leading icon, trailing badge, plus `active` and `disabled` states. Styles are
 * encapsulated; consumers pass an optional `className` merged last via cn().
 */
const ListGroup = React.forwardRef<HTMLUListElement, ListGroupProps>(
  ({ className, items, ...props }, ref) => {
    return (
      <ul
        ref={ref}
        className={cn(
          'overflow-hidden rounded border border-1 border-neutral-300',
          'divide-y divide-neutral-300 bg-white font-base',
          className
        )}
        {...props}
      >
        {items.map((item, index) => {
          const isAction = Boolean(item.href || item.onClick);
          const isDisabled = Boolean(item.disabled);
          const isActive = Boolean(item.active);
          const rowClass = listGroupItemVariants({
            interactive: isAction && !isDisabled,
            active: isActive,
            disabled: isDisabled,
          });

          // Disabled action rows degrade to a non-interactive element.
          if (isAction && !isDisabled) {
            if (item.href) {
              return (
                <li key={index}>
                  <a
                    href={item.href}
                    className={rowClass}
                    aria-current={isActive ? 'true' : undefined}
                  >
                    <ItemContent item={item} />
                  </a>
                </li>
              );
            }
            return (
              <li key={index}>
                <button
                  type="button"
                  onClick={item.onClick}
                  className={rowClass}
                  aria-current={isActive ? 'true' : undefined}
                >
                  <ItemContent item={item} />
                </button>
              </li>
            );
          }

          return (
            <li key={index}>
              <div
                className={rowClass}
                aria-current={isActive ? 'true' : undefined}
                aria-disabled={isDisabled || undefined}
              >
                <ItemContent item={item} />
              </div>
            </li>
          );
        })}
      </ul>
    );
  }
);
ListGroup.displayName = 'ListGroup';

export { ListGroup };
