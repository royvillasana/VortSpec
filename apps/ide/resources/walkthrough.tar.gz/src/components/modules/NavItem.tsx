import * as React from 'react';
import { cn } from '@/lib/utils';
import { Icon } from '@/components/ui/Icon';
import { navItemVariants, type NavItemVariants } from './nav-item.variants';

export interface NavItemProps
  extends Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, 'children'>,
    NavItemVariants {
  /** Optional leading icon rendered before the label. */
  icon?: React.ReactNode;
  /** When true, renders a trailing chevron indicating a submenu. */
  hasChildren?: boolean;
  /** Marks the current item — sets `aria-current="page"` and active styling. */
  active?: boolean;
  /** Disables interaction — dims the item and blocks pointer events. */
  disabled?: boolean;
  /** The link label. */
  children?: React.ReactNode;
}

/**
 * NavItem — a single navigation link. Renders `<a>` when `href` is provided,
 * otherwise a `<button type="button">`. Supports horizontal/vertical/inline
 * orientations and nested levels, with active and disabled states.
 */
const NavItem = React.forwardRef<HTMLAnchorElement, NavItemProps>(
  (
    {
      className,
      orientation,
      level,
      active = false,
      disabled = false,
      icon,
      hasChildren,
      href,
      children,
      ...props
    },
    ref
  ) => {
    const isLink = href != null;
    const Comp: React.ElementType = isLink ? 'a' : 'button';
    const chevron =
      orientation === 'inline' || orientation === 'vertical'
        ? 'chevron-right'
        : 'chevron-down';
    const elementProps = isLink
      ? { href }
      : { type: 'button' as const, disabled: disabled || undefined };

    return (
      <Comp
        ref={ref as React.Ref<never>}
        aria-current={active ? 'page' : undefined}
        aria-disabled={disabled || undefined}
        className={cn(
          navItemVariants({ orientation, level, active, disabled }),
          className
        )}
        {...elementProps}
        {...(props as Record<string, unknown>)}
      >
        {icon}
        <span>{children}</span>
        {hasChildren && <Icon name={chevron} size="small" aria-hidden />}
      </Comp>
    );
  }
);
NavItem.displayName = 'NavItem';

export { NavItem };
