import type { Meta, StoryObj } from '@storybook/react';
import type { ReactNode } from 'react';
import { Title } from './Title';
import { Icon } from '@/components/ui/Icon';

/** Lightweight inline badge used only to demonstrate the `badge` slot. */
const Badge = ({ children }: { children: ReactNode }) => (
  <span className="rounded-sm bg-primary px-2 py-1 text-body text-white">{children}</span>
);

const meta: Meta<typeof Title> = {
  title: 'Title',
  component: Title,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Heading text composed with an optional subtitle, badge, and left/right icons. `level` sets both the semantic tag (h1–h6) and the size token.',
      },
    },
  },
  argTypes: {
    level: {
      control: 'select',
      options: [1, 2, 3, 4, 5, 6],
      description: 'Heading level — sets the semantic tag and size token.',
    },
    fillContainer: { control: 'boolean', description: 'Fill the container width.' },
    subtitle: { control: 'text', description: 'Subtitle rendered below the heading.' },
    children: { control: 'text', description: 'Heading text.' },
  },
  args: {
    level: 2,
    fillContainer: false,
    children: 'Section title',
  },
};

export default meta;
type Story = StoryObj<typeof Title>;

export const Default: Story = {};

// --- Levels ---
export const Level1: Story = { args: { level: 1, children: 'Heading level 1' } };
export const Level2: Story = { args: { level: 2, children: 'Heading level 2' } };
export const Level3: Story = { args: { level: 3, children: 'Heading level 3' } };
export const Level4: Story = { args: { level: 4, children: 'Heading level 4' } };
export const Level5: Story = { args: { level: 5, children: 'Heading level 5' } };
export const Level6: Story = { args: { level: 6, children: 'Heading level 6' } };

// --- Composition ---
export const WithSubtitle: Story = {
  args: { children: 'Design tokens', subtitle: 'The single source of truth for styling' },
};

export const WithBadge: Story = {
  args: { children: 'Buttons', badge: <Badge>New</Badge> },
};

export const WithLeadingIcon: Story = {
  args: { children: 'Documentation', leadingIcon: <Icon name="list" size="medium" /> },
};

export const FillContainer: Story = {
  args: { fillContainer: true, children: 'Full-width title' },
  decorators: [
    (Story) => (
      <div style={{ width: 480 }}>
        <Story />
      </div>
    ),
  ],
};
