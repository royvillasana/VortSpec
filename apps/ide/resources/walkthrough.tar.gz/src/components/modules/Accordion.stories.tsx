import type { Meta, StoryObj } from '@storybook/react';
import { Accordion } from './Accordion';

const sampleItems = [
  {
    id: 'shipping',
    title: 'Shipping & delivery',
    content:
      'Orders ship within 1–2 business days. Standard delivery takes 3–5 business days.',
  },
  {
    id: 'returns',
    title: 'Returns & refunds',
    content: 'Return any item within 30 days for a full refund, no questions asked.',
  },
  {
    id: 'warranty',
    title: 'Warranty',
    content: 'Every product includes a two-year limited manufacturer warranty.',
  },
];

const meta: Meta<typeof Accordion> = {
  title: 'Accordion',
  component: Accordion,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A stack of collapsible panels built on native <details>/<summary> for accessible, JS-free expand/collapse with a rotating chevron.',
      },
    },
  },
  argTypes: {
    items: { control: false, description: 'The collapsible panels to render, top to bottom.' },
    allowMultiple: {
      control: 'boolean',
      description:
        'Allow multiple panels open at once (default). When false, panels behave exclusively (one open at a time).',
    },
  },
  args: {
    items: sampleItems,
    allowMultiple: true,
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 480 }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof Accordion>;

export const Default: Story = {};

// Exclusive mode — only one panel open at a time.
export const Exclusive: Story = {
  args: { allowMultiple: false },
};

// One panel expanded on mount via defaultOpen.
export const WithDefaultOpen: Story = {
  args: {
    items: [
      { ...sampleItems[0], defaultOpen: true },
      sampleItems[1],
      sampleItems[2],
    ],
  },
};

// A disabled, non-interactive panel.
export const WithDisabledItem: Story = {
  args: {
    items: [
      sampleItems[0],
      { ...sampleItems[1], disabled: true },
      sampleItems[2],
    ],
  },
};
