import * as React from 'react';
import { cn } from '@/lib/utils';
import { Icon, type IconName } from '@/components/ui/Icon';
import { calloutVariants, type CalloutVariants, type CalloutStatus } from './callout.variants';

const DEFAULT_ICON: Record<CalloutStatus, IconName> = {
  info: 'info',
  warning: 'exclamation-triangle',
  success: 'check-circle',
  danger: 'x-circle',
  secondary: 'info',
};

export interface CalloutProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title'>,
    CalloutVariants {
  /** Optional heading rendered above the message. */
  title?: React.ReactNode;
  /** Override the default status icon (or pass `null` to hide it). */
  icon?: React.ReactNode;
}

/**
 * Callout — icon + message on a tinted status surface (info/warning/etc.).
 */
const Callout = React.forwardRef<HTMLDivElement, CalloutProps>(
  ({ className, status, title, icon, children, role = 'note', ...props }, ref) => {
    const resolved: CalloutStatus = status ?? 'info';
    return (
    <div ref={ref} role={role} className={cn(calloutVariants({ status: resolved }), className)} {...props}>
      {icon !== null &&
        (icon ?? <Icon name={DEFAULT_ICON[resolved]} size="medium" aria-hidden />)}
      <div className="flex flex-col gap-1">
        {title && <span className="font-regular">{title}</span>}
        <div className="text-text">{children}</div>
      </div>
    </div>
    );
  }
);
Callout.displayName = 'Callout';

export { Callout };
