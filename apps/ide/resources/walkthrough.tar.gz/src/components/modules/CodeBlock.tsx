import * as React from 'react';
import { cn } from '@/lib/utils';
import { codeBlockVariants, type CodeBlockVariants } from './code-block.variants';

export interface CodeBlockProps
  extends React.HTMLAttributes<HTMLElement>,
    CodeBlockVariants {
  /** Code string to render. Falls back to `children` when omitted. */
  code?: string;
  /** Optional filename/label shown above the snippet. */
  filename?: string;
}

/**
 * CodeBlock — neutral-surface code snippet container for documentation.
 */
const CodeBlock = React.forwardRef<HTMLElement, CodeBlockProps>(
  ({ className, tone, code, filename, children, ...props }, ref) => (
    <figure className={cn('m-0 flex w-full flex-col gap-1', className)}>
      {filename && (
        <figcaption className="font-base text-body font-regular leading-body text-muted">
          {filename}
        </figcaption>
      )}
      <pre ref={ref as React.Ref<HTMLPreElement>} className={codeBlockVariants({ tone })} {...props}>
        <code>{code ?? children}</code>
      </pre>
    </figure>
  )
);
CodeBlock.displayName = 'CodeBlock';

export { CodeBlock };
