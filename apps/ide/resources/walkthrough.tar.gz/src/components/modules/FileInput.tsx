import * as React from 'react';
import { cn } from '@/lib/utils';
import { Icon } from '@/components/ui/Icon';
import { buttonVariants } from '@/components/ui/button.variants';
import { fileInputVariants, type FileInputVariants } from './file-input.variants';

export interface FileInputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size' | 'type'>,
    FileInputVariants {
  /** Field label rendered above the trigger and associated via `htmlFor`. */
  label?: React.ReactNode;
  /** Helper text rendered below the control (hidden when `error` is present). */
  hint?: string;
  /** Error message. When set, shows danger text and toggles `aria-invalid`. */
  error?: string;
  /** Text inside the trigger button. Defaults to `Choose file`. */
  buttonLabel?: string;
}

/**
 * FileInput — an accessible, token-driven file chooser molecule.
 *
 * A real native `<input type="file">` is rendered visually hidden (`peer sr-only`)
 * so it keeps built-in file-picker semantics and keyboard behaviour, while an
 * associated `<label htmlFor>` styled with `buttonVariants` acts as the visible,
 * clickable trigger. Keyboard focus on the input surfaces a visible ring on the
 * label via `peer-focus-visible:*`. The selected filename(s) render next to the
 * label, and the label / hint / error pattern wraps the whole control. The
 * forwarded ref points at the file input; consumer `className` merges last onto
 * the outer wrapper.
 */
const FileInput = React.forwardRef<HTMLInputElement, FileInputProps>(
  (
    {
      className,
      size,
      label,
      hint,
      error,
      buttonLabel = 'Choose file',
      required,
      disabled,
      multiple,
      id,
      onChange,
      ...props
    },
    ref
  ) => {
    const reactId = React.useId();
    const inputId = id ?? reactId;
    const hintId = `${inputId}-hint`;
    const errorId = `${inputId}-error`;

    const [fileNames, setFileNames] = React.useState<string[]>([]);

    const handleChange = React.useCallback(
      (event: React.ChangeEvent<HTMLInputElement>) => {
        const files = event.target.files;
        setFileNames(files ? Array.from(files).map((file) => file.name) : []);
        onChange?.(event);
      },
      [onChange]
    );

    const hasError = !!error;
    // The hint element is suppressed while an error is shown, so only reference
    // its id when it actually renders — otherwise aria-describedby would point at
    // a non-existent node (dangling idref).
    const describedBy =
      [hasError ? errorId : null, !hasError && hint ? hintId : null]
        .filter(Boolean)
        .join(' ') || undefined;

    const selectionText =
      fileNames.length === 0
        ? null
        : fileNames.length === 1
          ? fileNames[0]
          : `${fileNames.length} files selected`;

    return (
      <div className={cn(fileInputVariants({ size }), className)}>
        {label != null && (
          <label htmlFor={inputId} className="text-text font-regular">
            {label}
            {required && (
              <span className="text-danger" aria-hidden="true">
                {' '}
                *
              </span>
            )}
          </label>
        )}

        <div className="flex flex-wrap items-center gap-2">
          <input
            ref={ref}
            id={inputId}
            type="file"
            required={required}
            disabled={disabled}
            multiple={multiple}
            aria-invalid={hasError || undefined}
            aria-describedby={describedBy}
            onChange={handleChange}
            className="peer sr-only"
            {...props}
          />
          <label
            htmlFor={inputId}
            className={cn(
              buttonVariants({ variant: 'light', size }),
              'cursor-pointer',
              'peer-focus-visible:ring-2 peer-focus-visible:ring-primary peer-focus-visible:ring-offset-2',
              disabled && 'opacity-disabled pointer-events-none cursor-not-allowed'
            )}
          >
            <Icon name="upload" size="small" aria-hidden />
            {buttonLabel}
          </label>
          {selectionText && (
            <span className="text-muted text-body">{selectionText}</span>
          )}
        </div>

        {hasError ? (
          <span id={errorId} className="text-danger text-body">
            {error}
          </span>
        ) : (
          hint && (
            <span id={hintId} className="text-muted text-body">
              {hint}
            </span>
          )
        )}
      </div>
    );
  }
);
FileInput.displayName = 'FileInput';

export { FileInput };
