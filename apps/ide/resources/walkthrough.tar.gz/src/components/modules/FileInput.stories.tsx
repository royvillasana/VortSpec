import type { Meta, StoryObj } from '@storybook/react';
import { FileInput } from './FileInput';

const meta: Meta<typeof FileInput> = {
  title: 'FileInput',
  component: FileInput,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'An accessible, token-driven file chooser: a visually hidden native <input type="file"> paired with a styled button label, plus selected-filename display and hint/error text.',
      },
    },
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'Trigger button + wrapper sizing (mirrors Button sizes).',
    },
    label: { control: 'text', description: 'Field label rendered above the trigger.' },
    hint: { control: 'text', description: 'Helper text below the control (hidden when error is present).' },
    error: { control: 'text', description: 'Error message; shows danger text and toggles aria-invalid.' },
    buttonLabel: { control: 'text', description: 'Text inside the trigger button.' },
    required: { control: 'boolean', description: 'Marks the field required (native + asterisk).' },
    disabled: { control: 'boolean', description: 'Disable the file chooser.' },
    multiple: { control: 'boolean', description: 'Allow selecting more than one file.' },
  },
  args: {
    label: 'Upload document',
    size: 'medium',
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 360 }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof FileInput>;

export const Default: Story = {};

// --- Sizes ---
export const Small: Story = { args: { size: 'small' } };
export const Large: Story = { args: { size: 'large' } };

// --- States ---
export const WithHint: Story = {
  args: { hint: 'PDF or DOCX, up to 10 MB.' },
};

export const CustomButtonLabel: Story = {
  args: { buttonLabel: 'Browse files' },
};

export const Required: Story = {
  args: { required: true },
};

export const WithError: Story = {
  args: { error: 'A file is required.' },
};

export const Multiple: Story = {
  args: { label: 'Upload attachments', multiple: true, buttonLabel: 'Choose files' },
};

export const Disabled: Story = {
  args: { disabled: true },
};
