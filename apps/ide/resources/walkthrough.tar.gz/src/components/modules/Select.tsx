import * as React from 'react';
import { cn } from '@/lib/utils';
import { Icon } from '@/components/ui/Icon';
import { selectVariants, type SelectVariants } from './select.variants';

/** A single `<option>` descriptor rendered by the Select. */
export interface SelectOption {
  /** Submitted value. */
  value: string;
  /** Visible option text. */
  label: string;
  /** Renders the option non-selectable. */
  disabled?: boolean;
}

export interface SelectProps
  extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, 'size'>,
    SelectVariants {
  /** Visible field label, associated via `htmlFor`. */
  label?: React.ReactNode;
  /** Helper text shown below the control (hidden when `error` is present). */
  hint?: string;
  /** Error message; enables invalid styling + `aria-invalid` + `aria-describedby`. */
  error?: string;
  /** Options rendered as `<option>` elements. */
  options: SelectOption[];
  /** Optional disabled first option (`value=""`), shown for single-select only. */
  placeholder?: string;
}

/**
 * Select — a form field wrapping a styled native `<select>`.
 *
 * Renders label / control / hint / error with the same field pattern as Input.
 * The native `<select>` keeps full keyboard and assistive-tech semantics while
 * `appearance-none` lets us overlay a caret Icon. In `multiple` mode the native
 * listbox renders and the caret is hidden. Styles are fully encapsulated;
 * consumers pass semantic props plus an optional `className` for layout
 * overrides on the outer wrapper (merged last via cn()).
 */
const Select = React.forwardRef<HTMLSelectElement, SelectProps>(
  (
    {
      className,
      size,
      label,
      hint,
      error,
      options,
      placeholder,
      required,
      multiple,
      id,
      'aria-describedby': ariaDescribedBy,
      ...props
    },
    ref
  ) => {
    const reactId = React.useId();
    const selectId = id ?? reactId;
    const invalid = Boolean(error);
    // Only reference the hint id when the hint element actually renders
    // (it is suppressed while an error is shown), avoiding a dangling idref.
    const hintId = hint && !error ? `${selectId}-hint` : undefined;
    const errorId = error ? `${selectId}-error` : undefined;
    const describedBy =
      [ariaDescribedBy, errorId, hintId].filter(Boolean).join(' ') || undefined;

    return (
      <div className={cn('flex flex-col gap-1', className)}>
        {label != null && (
          <label htmlFor={selectId} className="text-body font-base font-regular text-text">
            {label}
            {required && (
              <span aria-hidden className="text-danger">
                {' '}
                *
              </span>
            )}
          </label>
        )}

        <div className="relative">
          <select
            ref={ref}
            id={selectId}
            required={required}
            multiple={multiple}
            aria-invalid={invalid || undefined}
            aria-describedby={describedBy}
            className={cn(selectVariants({ size, invalid }), !multiple && 'pr-8')}
            {...props}
          >
            {placeholder && !multiple && (
              <option value="" disabled>
                {placeholder}
              </option>
            )}
            {options.map((option) => (
              <option key={option.value} value={option.value} disabled={option.disabled}>
                {option.label}
              </option>
            ))}
          </select>

          {!multiple && (
            <Icon
              name="caret-down-fill"
              size="small"
              aria-hidden
              className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-muted"
            />
          )}
        </div>

        {hint && !error && (
          <p id={hintId} className="text-body text-muted">
            {hint}
          </p>
        )}
        {error && (
          <p id={errorId} className="text-body text-danger">
            {error}
          </p>
        )}
      </div>
    );
  }
);
Select.displayName = 'Select';

export { Select };
