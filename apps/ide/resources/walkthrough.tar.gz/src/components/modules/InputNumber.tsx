import * as React from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/Button';
import { Icon } from '@/components/ui/Icon';
import { inputNumberVariants, type InputNumberVariants } from './input-number.variants';

export interface InputNumberProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size' | 'onChange'>,
    InputNumberVariants {
  /** Field label rendered above the stepper group and associated via `htmlFor`. */
  label?: React.ReactNode;
  /** Helper text shown below the control (hidden when `error` is present). */
  hint?: string;
  /** Error text shown below the control; sets `aria-invalid` + danger styling. */
  error?: string;
  /** Convenience callback with the parsed numeric value on every change/step. */
  onValueChange?: (value: number) => void;
  /** Native change handler (fires on typing, arrow keys, and stepper clicks). */
  onChange?: React.ChangeEventHandler<HTMLInputElement>;
}

/** Assign an element to both a forwarded ref and a local ref. */
function useMergedRef<T>(
  forwarded: React.ForwardedRef<T>,
  local: React.MutableRefObject<T | null>
) {
  return React.useCallback(
    (node: T | null) => {
      local.current = node;
      if (typeof forwarded === 'function') forwarded(node);
      else if (forwarded) forwarded.current = node;
    },
    [forwarded, local]
  );
}

/** Set an input's value through the native setter so React's onChange fires. */
function setNativeValue(el: HTMLInputElement, value: string) {
  const setter = Object.getOwnPropertyDescriptor(
    window.HTMLInputElement.prototype,
    'value'
  )?.set;
  setter?.call(el, value);
  el.dispatchEvent(new Event('input', { bubbles: true }));
}

/**
 * InputNumber — numeric stepper field: a decrement Button, a native
 * `<input type="number">`, and an increment Button, joined inline, with an
 * optional label and hint/error. Works controlled (`value`) or uncontrolled
 * (`defaultValue`). Steppers respect `step`, `min`, `max`, and `disabled`, and
 * clamp on step. Fires the native `onChange` plus a convenience `onValueChange`.
 */
const InputNumber = React.forwardRef<HTMLInputElement, InputNumberProps>(
  (
    {
      className,
      size,
      invalid,
      label,
      hint,
      error,
      required,
      id,
      value,
      defaultValue,
      min,
      max,
      step = 1,
      disabled,
      onChange,
      onValueChange,
      ...props
    },
    ref
  ) => {
    const reactId = React.useId();
    const inputId = id ?? reactId;
    const descId = `${inputId}-desc`;

    const inputRef = React.useRef<HTMLInputElement>(null);
    const setRefs = useMergedRef(ref, inputRef);

    const isControlled = value !== undefined;
    const hasError = !!error;
    const isInvalid = invalid ?? hasError;
    const description = error ?? hint;

    const minN = min != null && min !== '' ? Number(min) : undefined;
    const maxN = max != null && max !== '' ? Number(max) : undefined;
    const stepN = Number(step) || 1;

    // Track the current numeric value only to disable steppers at the bounds.
    const parse = (raw: unknown): number | null => {
      const n = raw != null ? parseFloat(String(raw)) : NaN;
      return Number.isNaN(n) ? null : n;
    };
    const [numericValue, setNumericValue] = React.useState<number | null>(() =>
      parse(value ?? defaultValue)
    );
    React.useEffect(() => {
      if (isControlled) setNumericValue(parse(value));
    }, [isControlled, value]);

    const clamp = (n: number) => {
      let next = n;
      if (minN !== undefined && next < minN) next = minN;
      if (maxN !== undefined && next > maxN) next = maxN;
      return next;
    };

    const handleStep = (dir: 1 | -1) => {
      const el = inputRef.current;
      if (!el || disabled) return;
      const base = parse(el.value) ?? minN ?? 0;
      setNativeValue(el, String(clamp(base + dir * stepN)));
    };

    const handleChange: React.ChangeEventHandler<HTMLInputElement> = (event) => {
      setNumericValue(parse(event.target.value));
      onChange?.(event);
      const n = parseFloat(event.target.value);
      if (!Number.isNaN(n)) onValueChange?.(n);
    };

    const atMin = numericValue !== null && minN !== undefined && numericValue <= minN;
    const atMax = numericValue !== null && maxN !== undefined && numericValue >= maxN;

    return (
      <div className={cn('flex flex-col gap-1.5', className)}>
        {label != null && (
          <label htmlFor={inputId} className="text-body font-base font-regular text-text">
            {label}
            {required && (
              <span className="text-danger" aria-hidden="true">
                {' '}
                *
              </span>
            )}
          </label>
        )}

        <div className="inline-flex items-stretch gap-1">
          <Button
            variant="light"
            size={size}
            iconOnly
            aria-label="Decrease"
            disabled={disabled || atMin}
            tabIndex={-1}
            onClick={() => handleStep(-1)}
          >
            <Icon name="dash" />
          </Button>

          <input
            {...props}
            ref={setRefs}
            id={inputId}
            type="number"
            inputMode="decimal"
            value={isControlled ? value : undefined}
            defaultValue={!isControlled ? defaultValue : undefined}
            min={min}
            max={max}
            step={step}
            required={required}
            disabled={disabled}
            aria-invalid={isInvalid || undefined}
            aria-describedby={description ? descId : undefined}
            onChange={handleChange}
            className={inputNumberVariants({ size, invalid: isInvalid })}
          />

          <Button
            variant="light"
            size={size}
            iconOnly
            aria-label="Increase"
            disabled={disabled || atMax}
            tabIndex={-1}
            onClick={() => handleStep(1)}
          >
            <Icon name="plus" />
          </Button>
        </div>

        {description && (
          <p
            id={descId}
            className={cn('text-body', hasError ? 'text-danger' : 'text-muted')}
          >
            {description}
          </p>
        )}
      </div>
    );
  }
);
InputNumber.displayName = 'InputNumber';

export { InputNumber };
