import { cva, type VariantProps } from 'class-variance-authority';

/**
 * InputNumber variants — the styled native `<input type="number">` at the center
 * of the numeric stepper group. Mirrors the Figma `form-item` input-number
 * component set.
 *   Size    → `size` (small | medium | large) controls padding / density
 *   Invalid → `invalid` (boolean) swaps the border + focus ring to danger
 *   State   → CSS pseudo-classes (:focus-visible, :disabled)
 *
 * Every color/spacing/radius/font utility resolves to a design token via the
 * Tailwind theme mapping (tailwind.config.js). No hardcoded values.
 */
export const inputNumberVariants = cva(
  'w-full min-w-0 rounded border border-1 border-neutral-300 bg-white text-text text-center ' +
    'text-body font-base font-regular leading-body transition-colors duration-150 ease-out ' +
    'placeholder:text-muted ' +
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 ' +
    'disabled:opacity-disabled disabled:cursor-not-allowed disabled:bg-neutral-100',
  {
    variants: {
      size: {
        small: 'px-2 py-1',
        medium: 'px-2.5 py-2',
        large: 'px-3 py-2.5',
      },
      invalid: {
        true: 'border-danger focus-visible:ring-danger',
        false: 'focus-visible:ring-primary',
      },
    },
    defaultVariants: {
      size: 'medium',
      invalid: false,
    },
  }
);

export type InputNumberVariants = VariantProps<typeof inputNumberVariants>;
