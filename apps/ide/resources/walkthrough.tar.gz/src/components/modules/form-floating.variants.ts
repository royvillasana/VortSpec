import { cva, type VariantProps } from 'class-variance-authority';

/**
 * FormFloating control variants — the shared base classes for the underlying
 * `<input>` / `<textarea>` / `<select>` in a floating-label field.
 *
 * The control carries the `peer` class and a `placeholder=" "` (single space) so
 * the sibling `<label>` can float via Tailwind's `peer-placeholder-shown` /
 * `peer-focus` variants (no JS state). Extra top padding (`pt-5`) reserves room
 * for the floated label; `pb-1` keeps the text baseline low.
 *
 *   Error → `error` (boolean) swaps the border + focus ring to danger.
 *   State → CSS pseudo-classes (:focus-visible, :disabled, :placeholder-shown).
 *
 * Every color/spacing/radius/font utility resolves to a design token via the
 * Tailwind theme mapping (tailwind.config.js). No hardcoded values.
 */
export const formFloatingVariants = cva(
  'peer w-full rounded border border-1 bg-white text-text text-body font-base font-regular ' +
    'px-3 pt-5 pb-1 transition-colors ' +
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 ' +
    'disabled:opacity-disabled disabled:cursor-not-allowed disabled:bg-neutral-100',
  {
    variants: {
      error: {
        true: 'border-danger focus-visible:ring-danger',
        false: 'border-neutral-300 focus-visible:ring-primary',
      },
    },
    defaultVariants: {
      error: false,
    },
  }
);

export type FormFloatingVariants = VariantProps<typeof formFloatingVariants>;
