import type { Meta, StoryObj } from '@storybook/react';
import { CodeBlock } from './CodeBlock';

const SAMPLE = `import { Button } from '@/components';

export function Example() {
  return <Button variant="primary">Save changes</Button>;
}`;

const meta: Meta<typeof CodeBlock> = {
  title: 'CodeBlock',
  component: CodeBlock,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Formatted code-snippet container with a neutral surface, used throughout the documentation pages to show usage examples.',
      },
    },
  },
  argTypes: {
    tone: {
      control: 'radio',
      options: ['neutral', 'dark'],
      description: 'Surface tone of the snippet.',
    },
    code: { control: 'text', description: 'Code string to render.' },
    filename: { control: 'text', description: 'Optional filename/label shown above the snippet.' },
  },
  args: {
    tone: 'neutral',
    code: SAMPLE,
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 520 }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof CodeBlock>;

export const Default: Story = {};

export const Neutral: Story = { args: { tone: 'neutral' } };
export const Dark: Story = { args: { tone: 'dark' } };

export const WithFilename: Story = {
  args: { filename: 'Example.tsx', tone: 'neutral' },
};
