import type { Meta, StoryObj } from '@storybook/react';
import { Input } from './Input';

const meta: Meta<typeof Input> = {
  title: 'Input',
  component: Input,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Labeled single-line text field that composes a label, native input, and hint/error line, wiring accessibility (htmlFor/id, aria-invalid, aria-describedby) automatically.',
      },
    },
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'Control padding/density.',
    },
    orientation: {
      control: 'select',
      options: ['vertical', 'horizontal'],
      description: 'Places the label above (vertical) or beside (horizontal) the control.',
    },
    label: { control: 'text', description: 'Visible label associated with the control.' },
    hint: { control: 'text', description: 'Muted help text rendered beneath the control.' },
    error: {
      control: 'text',
      description: 'Error message; sets the danger state + aria-invalid.',
    },
    placeholder: { control: 'text', description: 'Native placeholder text.' },
    required: { control: 'boolean', description: 'Marks the field as required.' },
    disabled: { control: 'boolean', description: 'Disables the control.' },
  },
  args: {
    label: 'Email',
    placeholder: 'you@example.com',
    size: 'medium',
    orientation: 'vertical',
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 360 }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof Input>;

export const Default: Story = {};

// --- Sizes ---
export const Small: Story = { args: { size: 'small', label: 'Small input' } };
export const Medium: Story = { args: { size: 'medium', label: 'Medium input' } };
export const Large: Story = { args: { size: 'large', label: 'Large input' } };

// --- Orientation ---
export const Horizontal: Story = {
  args: { orientation: 'horizontal', label: 'Name' },
};

// --- States ---
export const WithHint: Story = {
  args: { label: 'Username', hint: 'This will be visible on your profile.' },
};

export const WithError: Story = {
  args: { label: 'Email', error: 'Please enter a valid email address.', defaultValue: 'nope' },
};

export const Required: Story = {
  args: { label: 'Full name', required: true },
};

export const Disabled: Story = {
  args: { label: 'Locked field', disabled: true, defaultValue: 'Cannot edit' },
};
