import type { Meta, StoryObj } from '@storybook/react';
import { Tag } from './Tag';
import { Icon } from './Icon';

const meta: Meta<typeof Tag> = {
  title: 'Tag',
  component: Tag,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Small inline label/chip for statuses, categories, or metadata. Rendered as a `<span>`; when `removable`, a real `<button>` handles dismissal with a visible focus ring. Supports an optional leading icon.',
      },
    },
  },
  argTypes: {
    variant: {
      control: 'select',
      options: [
        'base',
        'primary',
        'secondary',
        'success',
        'danger',
        'warning',
        'info',
        'light',
        'dark',
      ],
      description: 'Color variant (mirrors the Button color types).',
    },
    size: {
      control: 'select',
      options: ['small', 'medium'],
      description: 'Padding size.',
    },
    removable: {
      control: 'boolean',
      description: 'When true, render a trailing dismiss button that calls `onRemove`.',
    },
    children: { control: 'text', description: 'Tag label content.' },
  },
  args: {
    variant: 'base',
    size: 'medium',
    children: 'Label',
  },
};

export default meta;
type Story = StoryObj<typeof Tag>;

export const Default: Story = {};

// --- Variants ---
export const Base: Story = { args: { variant: 'base', children: 'Base' } };
export const Primary: Story = { args: { variant: 'primary', children: 'Primary' } };
export const Secondary: Story = { args: { variant: 'secondary', children: 'Secondary' } };
export const Success: Story = { args: { variant: 'success', children: 'Success' } };
export const Danger: Story = { args: { variant: 'danger', children: 'Danger' } };
export const Warning: Story = { args: { variant: 'warning', children: 'Warning' } };
export const Info: Story = { args: { variant: 'info', children: 'Info' } };
export const Light: Story = { args: { variant: 'light', children: 'Light' } };
export const Dark: Story = { args: { variant: 'dark', children: 'Dark' } };

// --- Sizes ---
export const Small: Story = { args: { size: 'small', children: 'Small' } };
export const Medium: Story = { args: { size: 'medium', children: 'Medium' } };

// --- Features ---
export const Removable: Story = { args: { removable: true, children: 'Removable' } };
export const WithLeadingIcon: Story = {
  args: { children: 'Featured', leadingIcon: <Icon name="star-fill" size="small" aria-hidden /> },
};
