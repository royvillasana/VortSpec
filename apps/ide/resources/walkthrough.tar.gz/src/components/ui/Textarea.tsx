import * as React from 'react';
import { cn } from '@/lib/utils';
import { textareaVariants, type TextareaVariants } from './textarea.variants';

export interface TextareaProps
  extends Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, 'size'>,
    TextareaVariants {
  /** Resize affordance. Defaults to `vertical` (`resize-y`). */
  resize?: 'none' | 'vertical' | 'both';
}

const resizeClasses = {
  none: 'resize-none',
  vertical: 'resize-y',
  both: 'resize',
} as const;

/**
 * Textarea — the design system's multi-line plain-text editing control.
 * Renders a styled native `<textarea>`. Styles are fully encapsulated; consumers
 * pass semantic props plus an optional `className` for layout overrides (merged
 * last via cn()). Label association is the consumer's responsibility; the element
 * supports `aria-invalid` (set automatically from `invalid`) and `aria-describedby`.
 */
const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, size, invalid, resize = 'vertical', ...props }, ref) => {
    return (
      <textarea
        ref={ref}
        aria-invalid={invalid || undefined}
        className={cn(textareaVariants({ size, invalid }), resizeClasses[resize], className)}
        {...props}
      />
    );
  }
);
Textarea.displayName = 'Textarea';

export { Textarea };
