import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Textarea variants — a styled native `<textarea>` for multi-line plain-text
 * editing. Mirrors the Figma Textarea component set 1:1.
 *   Size    → `size` (small | medium | large) controls padding
 *   Invalid → `invalid` (boolean) swaps the border + focus ring to danger
 *   State   → CSS pseudo-classes (:focus-visible, :disabled)
 *
 * Every color/spacing/radius/font utility resolves to a design token via the
 * Tailwind theme mapping (tailwind.config.js). No hardcoded values.
 */
export const textareaVariants = cva(
  'w-full rounded border border-neutral-300 bg-white text-text text-body font-base font-regular ' +
    'placeholder:text-muted transition-colors duration-150 ease-out ' +
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 ' +
    'disabled:opacity-disabled disabled:cursor-not-allowed disabled:bg-neutral-100',
  {
    variants: {
      size: {
        small: 'px-2 py-1',
        medium: 'px-2.5 py-2',
        large: 'px-3 py-2.5',
      },
      invalid: {
        true: 'border-danger focus-visible:ring-danger',
        false: 'focus-visible:ring-primary',
      },
    },
    defaultVariants: {
      size: 'medium',
      invalid: false,
    },
  }
);

export type TextareaVariants = VariantProps<typeof textareaVariants>;
