import * as React from 'react';
import { cn } from '@/lib/utils';
import { iconWrapperVariants, type IconWrapperVariants } from './icon-wrapper.variants';

export interface IconWrapperProps
  extends React.HTMLAttributes<HTMLDivElement>,
    IconWrapperVariants {}

/**
 * IconWrapper — square tinted container that frames an Icon child.
 */
const IconWrapper = React.forwardRef<HTMLDivElement, IconWrapperProps>(
  ({ className, size, tone, children, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(iconWrapperVariants({ size, tone }), className)}
      {...props}
    >
      {children}
    </div>
  )
);
IconWrapper.displayName = 'IconWrapper';

export { IconWrapper };
