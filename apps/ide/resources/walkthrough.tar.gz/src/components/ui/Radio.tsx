import * as React from 'react';
import { cn } from '@/lib/utils';
import {
  radioVariants,
  radioBoxClasses,
  radioDotVariants,
  type RadioVariants,
} from './radio.variants';

export interface RadioProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size' | 'type'>,
    RadioVariants {
  /** Optional label rendered to the right of the control. */
  label?: React.ReactNode;
}

/**
 * Radio — the design system's single-choice control.
 * Renders a real native `<input type="radio">` (visually hidden as the `peer`)
 * next to a custom circular box with an inner filled dot. Grouping, keyboard
 * arrow navigation, and single-selection are handled natively by the browser
 * for inputs that share the same `name`. Styles are fully encapsulated; consumers
 * pass semantic props plus an optional `className` for layout overrides (merged
 * last via cn() on the outer label).
 */
const Radio = React.forwardRef<HTMLInputElement, RadioProps>(
  ({ className, size, label, disabled, ...props }, ref) => {
    return (
      <label
        className={cn(
          'inline-flex items-center gap-2 select-none',
          disabled ? 'cursor-not-allowed' : 'cursor-pointer',
          className
        )}
      >
        <span className={cn(radioVariants({ size }))}>
          <input
            ref={ref}
            type="radio"
            disabled={disabled}
            className="peer sr-only"
            {...props}
          />
          <span aria-hidden="true" className={radioBoxClasses} />
          <span aria-hidden="true" className={cn(radioDotVariants({ size }))} />
        </span>
        {label != null && (
          <span className="text-body leading-body text-text">{label}</span>
        )}
      </label>
    );
  }
);
Radio.displayName = 'Radio';

export { Radio };
