import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Icon sizing — square glyph boxes. Dimensions map to token-backed spacing
 * utilities (h-4 = --spacing-16, h-5 = --spacing-20). Color is inherited via
 * `currentColor`, so an Icon takes the text color token of its context.
 */
export const iconVariants = cva('inline-block shrink-0 fill-current', {
  variants: {
    size: {
      small: 'h-4 w-4',
      medium: 'h-5 w-5',
      large: 'h-6 w-6',
    },
  },
  defaultVariants: {
    size: 'medium',
  },
});

export type IconVariants = VariantProps<typeof iconVariants>;
