import type { Meta, StoryObj } from '@storybook/react';
import { Radio } from './Radio';

const meta: Meta<typeof Radio> = {
  title: 'Radio',
  component: Radio,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Single-choice control built on a real native `<input type="radio">` (visually hidden as the peer) with a custom circular box and inner dot. Grouping and keyboard navigation are handled natively for inputs sharing the same `name`.',
      },
    },
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'Outer circle and inner dot size.',
    },
    label: { control: 'text', description: 'Optional label rendered to the right of the control.' },
    checked: { control: 'boolean', description: 'Controlled checked state.' },
    disabled: { control: 'boolean', description: 'Disables the control.' },
    name: { control: 'text', description: 'Group name for single-selection.' },
  },
  args: {
    size: 'medium',
    label: 'Option one',
    name: 'example',
    checked: false,
  },
};

export default meta;
type Story = StoryObj<typeof Radio>;

export const Default: Story = {};

export const Checked: Story = { args: { checked: true, label: 'Selected option' } };

export const Unchecked: Story = { args: { checked: false, label: 'Unselected option' } };

export const Disabled: Story = { args: { disabled: true, label: 'Disabled' } };

export const DisabledChecked: Story = {
  args: { disabled: true, checked: true, label: 'Disabled selected' },
};

// --- Sizes ---
export const Small: Story = { args: { size: 'small', label: 'Small' } };
export const Medium: Story = { args: { size: 'medium', label: 'Medium' } };
export const Large: Story = { args: { size: 'large', label: 'Large' } };
