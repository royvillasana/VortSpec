import { cva, type VariantProps } from 'class-variance-authority';

/**
 * IconWrapper — fixed square container for an Icon (contact/social affordances).
 * The square size is built from padding tokens around the inner Icon, so every
 * dimension resolves to a spacing token (no magic 48px). Tone sets the surface.
 */
export const iconWrapperVariants = cva(
  'inline-flex items-center justify-center rounded aspect-square',
  {
    variants: {
      size: {
        small: 'p-2',
        medium: 'p-2.5',
        large: 'p-3',
      },
      tone: {
        default: 'bg-neutral-100 text-text',
        primary: 'bg-primary text-white',
        secondary: 'bg-secondary text-white',
        dark: 'bg-near-black text-white',
      },
    },
    defaultVariants: {
      size: 'medium',
      tone: 'default',
    },
  }
);

export type IconWrapperVariants = VariantProps<typeof iconWrapperVariants>;
