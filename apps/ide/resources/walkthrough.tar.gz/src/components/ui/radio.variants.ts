import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Radio variants — a styled native `<input type="radio">`.
 *   Size    → `size` (small | medium | large) controls the outer circle + inner dot
 *   State   → CSS pseudo-classes on the peer input (:checked, :focus-visible, :disabled)
 *
 * The visible circle and dot are siblings of the visually-hidden (`peer sr-only`)
 * input, so `peer-checked:` / `peer-focus-visible:` / `peer-disabled:` reach both.
 * Every color/spacing/radius/stroke utility resolves to a design token via the
 * Tailwind theme mapping (tailwind.config.js). No hardcoded values.
 */

// Sizing wrapper — establishes the positioning context for the circle + dot.
export const radioVariants = cva('relative inline-flex shrink-0 items-center justify-center', {
  variants: {
    size: {
      small: 'h-4 w-4',
      medium: 'h-5 w-5',
      large: 'h-6 w-6',
    },
  },
  defaultVariants: {
    size: 'medium',
  },
});

// The visible circular box — background/border swap on the peer input's checked state.
export const radioBoxClasses =
  'absolute inset-0 rounded-full border border-1 bg-white border-neutral-300 ' +
  'transition-colors duration-150 ease-out ' +
  'peer-checked:bg-primary peer-checked:border-primary ' +
  'peer-focus-visible:ring-2 peer-focus-visible:ring-primary peer-focus-visible:ring-offset-2 ' +
  'peer-disabled:opacity-disabled peer-disabled:cursor-not-allowed';

// The inner filled dot — hidden until the peer input is checked.
export const radioDotVariants = cva(
  'relative hidden rounded-full bg-white peer-checked:block',
  {
    variants: {
      size: {
        small: 'h-1.5 w-1.5',
        medium: 'h-2 w-2',
        large: 'h-2.5 w-2.5',
      },
    },
    defaultVariants: {
      size: 'medium',
    },
  }
);

export type RadioVariants = VariantProps<typeof radioVariants>;
