import * as React from 'react';
import { cn } from '@/lib/utils';
import { Icon } from './Icon';
import { tagVariants, type TagVariants } from './tag.variants';

export interface TagProps
  extends Omit<React.HTMLAttributes<HTMLSpanElement>, 'color'>,
    TagVariants {
  /** When true, render a trailing dismiss button that calls `onRemove`. */
  removable?: boolean;
  /** Invoked when the dismiss button is activated. */
  onRemove?: () => void;
  /** Optional decorative icon rendered before the label. */
  leadingIcon?: React.ReactNode;
}

/**
 * Tag — small inline label/chip for statuses, categories, or metadata.
 * Rendered as a `<span>`; when `removable`, a real `<button>` handles dismissal
 * with a visible focus ring. Styles are encapsulated; consumers pass an optional
 * `className` for layout overrides (merged last via cn()).
 */
const Tag = React.forwardRef<HTMLSpanElement, TagProps>(
  ({ className, variant, size, removable, onRemove, leadingIcon, children, ...props }, ref) => {
    return (
      <span ref={ref} className={cn(tagVariants({ variant, size }), className)} {...props}>
        {leadingIcon}
        {children}
        {removable && (
          <button
            type="button"
            aria-label="Remove"
            onClick={onRemove}
            className={cn(
              'inline-flex items-center justify-center rounded-sm cursor-pointer',
              'transition-[filter] duration-150 ease-out hover:brightness-95 active:brightness-90',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2'
            )}
          >
            <Icon name="x" size="small" aria-hidden />
          </button>
        )}
      </span>
    );
  }
);
Tag.displayName = 'Tag';

export { Tag };
