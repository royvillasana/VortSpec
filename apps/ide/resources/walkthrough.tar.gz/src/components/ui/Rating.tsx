import * as React from 'react';
import { cn } from '@/lib/utils';
import { Icon } from './Icon';
import { ratingVariants, ratingStarVariants, type RatingVariants } from './rating.variants';

export interface RatingProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange' | 'defaultValue'>,
    RatingVariants {
  /** Controlled rating value (1..max). */
  value?: number;
  /** Initial value for uncontrolled usage. */
  defaultValue?: number;
  /** Number of stars to render. */
  max?: number;
  /** Fired with the newly selected value when a star is activated. */
  onChange?: (value: number) => void;
  /** Renders a non-interactive, read-only display. */
  readOnly?: boolean;
  /** Custom filled-star icon (the "custom-icon" variant). Overrides `star-fill`. */
  icon?: React.ReactNode;
  /** Custom empty-star icon. Overrides `star`. */
  emptyIcon?: React.ReactNode;
}

/**
 * Rating — a star rating control. Interactive by default (a `radiogroup` of real
 * `<button>`s); pass `readOnly` for a static `role="img"` display. Supports both
 * controlled (`value`) and uncontrolled (`defaultValue`) usage, with an optional
 * hover preview. Custom `icon` / `emptyIcon` enable the custom-icon variant.
 */
const Rating = React.forwardRef<HTMLDivElement, RatingProps>(
  (
    {
      className,
      size,
      value,
      defaultValue,
      max = 5,
      onChange,
      readOnly,
      icon,
      emptyIcon,
      ...props
    },
    ref
  ) => {
    const isControlled = value !== undefined;
    const [internalValue, setInternalValue] = React.useState(defaultValue ?? 0);
    const [hoverValue, setHoverValue] = React.useState<number | null>(null);

    const currentValue = isControlled ? (value as number) : internalValue;
    const displayValue = hoverValue ?? currentValue;

    const renderStar = (index: number) => {
      const filled = index <= displayValue;
      if (filled) {
        return icon ?? <Icon name="star-fill" size={size} className="text-warning" aria-hidden />;
      }
      return emptyIcon ?? <Icon name="star" size={size} className="text-neutral-300" aria-hidden />;
    };

    if (readOnly) {
      return (
        <span
          ref={ref as React.Ref<never>}
          role="img"
          aria-label={`Rated ${currentValue} out of ${max}`}
          className={cn(ratingVariants({ size }), className)}
          {...props}
        >
          {Array.from({ length: max }, (_, i) => (
            <span key={i + 1}>{renderStar(i + 1)}</span>
          ))}
        </span>
      );
    }

    const select = (next: number) => {
      if (!isControlled) setInternalValue(next);
      onChange?.(next);
    };

    return (
      <div
        ref={ref}
        role="radiogroup"
        aria-label="Rating"
        className={cn(ratingVariants({ size }), className)}
        {...props}
      >
        {Array.from({ length: max }, (_, i) => {
          const starValue = i + 1;
          return (
            <button
              key={starValue}
              type="button"
              role="radio"
              aria-checked={currentValue === starValue}
              aria-label={`${starValue} star${starValue === 1 ? '' : 's'}`}
              className={ratingStarVariants({ size })}
              onClick={() => select(starValue)}
              onMouseEnter={() => setHoverValue(starValue)}
              onMouseLeave={() => setHoverValue(null)}
              onFocus={() => setHoverValue(starValue)}
              onBlur={() => setHoverValue(null)}
            >
              {renderStar(starValue)}
            </button>
          );
        })}
      </div>
    );
  }
);
Rating.displayName = 'Rating';

export { Rating };
