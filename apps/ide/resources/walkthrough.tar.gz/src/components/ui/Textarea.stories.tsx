import type { Meta, StoryObj } from '@storybook/react';
import { Textarea } from './Textarea';

const meta: Meta<typeof Textarea> = {
  title: 'Textarea',
  component: Textarea,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Multi-line plain-text editing control rendered as a styled native `<textarea>`. Supports size and invalid variants, a configurable resize affordance, and `aria-invalid` set automatically from `invalid`.',
      },
    },
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'Padding size.',
    },
    invalid: {
      control: 'boolean',
      description: 'Swaps the border and focus ring to danger and sets `aria-invalid`.',
    },
    resize: {
      control: 'select',
      options: ['none', 'vertical', 'both'],
      description: 'Resize affordance. Defaults to `vertical`.',
    },
    placeholder: { control: 'text', description: 'Placeholder text.' },
    disabled: { control: 'boolean', description: 'Disables the control.' },
    rows: { control: 'number', description: 'Number of visible text rows.' },
  },
  args: {
    size: 'medium',
    placeholder: 'Enter your message...',
    rows: 4,
  },
};

export default meta;
type Story = StoryObj<typeof Textarea>;

export const Default: Story = {};

export const WithValue: Story = {
  args: { defaultValue: 'The quick brown fox jumps over the lazy dog.' },
};

export const Invalid: Story = {
  args: { invalid: true, defaultValue: 'This value is invalid.' },
};

export const Disabled: Story = { args: { disabled: true, defaultValue: 'Disabled textarea' } };

export const NoResize: Story = { args: { resize: 'none' } };

// --- Sizes ---
export const Small: Story = { args: { size: 'small' } };
export const Medium: Story = { args: { size: 'medium' } };
export const Large: Story = { args: { size: 'large' } };
