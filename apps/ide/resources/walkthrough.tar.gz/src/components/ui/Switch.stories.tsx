import type { Meta, StoryObj } from '@storybook/react';
import { Switch } from './Switch';

const meta: Meta<typeof Switch> = {
  title: 'Switch',
  component: Switch,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Accessible on/off toggle built on a real native `<input type="checkbox" role="switch">` (visually hidden as the peer) with a custom pill track and sliding thumb driven purely by peer pseudo-classes.',
      },
    },
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'Track and thumb size.',
    },
    label: { control: 'text', description: 'Optional label rendered to the right of the control.' },
    checked: { control: 'boolean', description: 'Controlled on/off state.' },
    disabled: { control: 'boolean', description: 'Disables the control.' },
  },
  args: {
    size: 'medium',
    label: 'Enable notifications',
    checked: false,
  },
};

export default meta;
type Story = StoryObj<typeof Switch>;

export const Default: Story = {};

export const On: Story = { args: { checked: true, label: 'On' } };

export const Off: Story = { args: { checked: false, label: 'Off' } };

export const Disabled: Story = { args: { disabled: true, label: 'Disabled' } };

export const DisabledOn: Story = {
  args: { disabled: true, checked: true, label: 'Disabled on' },
};

// --- Sizes ---
export const Small: Story = { args: { size: 'small', label: 'Small' } };
export const Medium: Story = { args: { size: 'medium', label: 'Medium' } };
export const Large: Story = { args: { size: 'large', label: 'Large' } };
