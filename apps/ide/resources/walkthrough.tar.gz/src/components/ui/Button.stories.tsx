import type { Meta, StoryObj } from '@storybook/react';
import { Button } from './Button';
import { Icon } from './Icon';

const meta: Meta<typeof Button> = {
  title: 'Button',
  component: Button,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          "The design system's primary action control. Mirrors the Figma Button set: Type, Size, Outline, and Icon Only, with states driven by CSS pseudo-classes.",
      },
    },
  },
  argTypes: {
    variant: {
      control: 'select',
      options: [
        'base',
        'primary',
        'secondary',
        'success',
        'danger',
        'warning',
        'info',
        'light',
        'dark',
        'link',
      ],
      description: 'Semantic button type (maps to Figma "Type").',
    },
    size: {
      control: 'radio',
      options: ['small', 'medium', 'large'],
      description: 'Control size.',
    },
    outline: { control: 'boolean', description: 'Render the outlined (ghost) treatment.' },
    iconOnly: {
      control: 'boolean',
      description: 'Square icon-only button (requires an aria-label).',
    },
    disabled: { control: 'boolean', description: 'Disable the button.' },
    children: { control: 'text', description: 'Button label content.' },
  },
  args: {
    children: 'Button',
    variant: 'primary',
    size: 'medium',
    outline: false,
    iconOnly: false,
    disabled: false,
  },
};

export default meta;
type Story = StoryObj<typeof Button>;

export const Default: Story = {};

// --- Variants (Figma "Type") ---
export const Base: Story = { args: { variant: 'base', children: 'Base' } };
export const Primary: Story = { args: { variant: 'primary', children: 'Primary' } };
export const Secondary: Story = { args: { variant: 'secondary', children: 'Secondary' } };
export const Success: Story = { args: { variant: 'success', children: 'Success' } };
export const Danger: Story = { args: { variant: 'danger', children: 'Danger' } };
export const Warning: Story = { args: { variant: 'warning', children: 'Warning' } };
export const Info: Story = { args: { variant: 'info', children: 'Info' } };
export const Light: Story = { args: { variant: 'light', children: 'Light' } };
export const Dark: Story = { args: { variant: 'dark', children: 'Dark' } };
export const Link: Story = { args: { variant: 'link', children: 'Link' } };

// --- Sizes ---
export const Small: Story = { args: { size: 'small', children: 'Small' } };
export const Medium: Story = { args: { size: 'medium', children: 'Medium' } };
export const Large: Story = { args: { size: 'large', children: 'Large' } };

// --- Modifiers / states ---
export const Outline: Story = {
  args: { outline: true, variant: 'primary', children: 'Outline' },
};

export const Disabled: Story = {
  args: { disabled: true, children: 'Disabled' },
};

export const IconOnly: Story = {
  args: { iconOnly: true, variant: 'primary', 'aria-label': 'Close' },
  render: (args) => (
    <Button {...args}>
      <Icon name="x" />
    </Button>
  ),
};

export const WithLeadingIcon: Story = {
  args: { variant: 'primary', children: 'Continue' },
  render: (args) => (
    <Button {...args}>
      <Icon name="chevron-right" />
      {args.children}
    </Button>
  ),
};
