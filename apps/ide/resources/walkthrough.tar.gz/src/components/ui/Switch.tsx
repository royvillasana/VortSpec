import * as React from 'react';
import { cn } from '@/lib/utils';
import {
  switchTrackVariants,
  switchThumbVariants,
  type SwitchVariants,
} from './switch.variants';

export interface SwitchProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size' | 'type'>,
    SwitchVariants {
  /** Optional label rendered to the right of the control. */
  label?: React.ReactNode;
}

/**
 * Switch — accessible on/off toggle.
 * Renders a real native `<input type="checkbox" role="switch">` visually-hidden
 * (`peer sr-only`) so it stays fully keyboard-operable and form-associable, with
 * a custom pill track + sliding thumb driven purely by peer pseudo-classes.
 * Consumers pass semantic props plus an optional `className` (merged last on the
 * outer `<label>` for layout overrides).
 */
const Switch = React.forwardRef<HTMLInputElement, SwitchProps>(
  ({ className, size, label, disabled, ...props }, ref) => {
    return (
      <label
        className={cn(
          'inline-flex items-center gap-2 font-base font-regular text-body leading-body text-text select-none',
          disabled ? 'cursor-not-allowed' : 'cursor-pointer',
          className
        )}
      >
        <span className="relative inline-flex shrink-0">
          <input
            ref={ref}
            type="checkbox"
            role="switch"
            disabled={disabled}
            className="peer sr-only"
            {...props}
          />
          <span className={cn(switchTrackVariants({ size }))} aria-hidden="true" />
          <span className={cn(switchThumbVariants({ size }))} aria-hidden="true" />
        </span>
        {label != null && <span>{label}</span>}
      </label>
    );
  }
);
Switch.displayName = 'Switch';

export { Switch };
