import * as React from 'react';
import { cn } from '@/lib/utils';
import { Icon } from './Icon';
import {
  checkboxBoxVariants,
  checkboxIconVariants,
  type CheckboxVariants,
} from './checkbox.variants';

export interface CheckboxProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size' | 'type'>,
    CheckboxVariants {
  /** Reflects the DOM `indeterminate` property (a mixed, third state). */
  indeterminate?: boolean;
  /** Optional label rendered to the right of the box. */
  label?: React.ReactNode;
}

/**
 * Checkbox — an accessible, token-driven checkbox atom.
 *
 * A real native `<input type="checkbox">` is rendered visually hidden
 * (`peer sr-only`) so it keeps built-in semantics and keyboard behaviour,
 * while sibling elements reflect its state via Tailwind `peer-*` variants
 * (`peer-checked`, `peer-indeterminate`, `peer-focus-visible`,
 * `peer-disabled`). The custom box and the check / dash Icons are all
 * siblings of the input — the Icons overlay the box (`absolute inset-0`) so
 * they can respond to the peer state. The whole control is wrapped in a
 * `<label>` for a full click target. `indeterminate` is a DOM property (not
 * an attribute), so it is set imperatively through a merged ref effect.
 */
const Checkbox = React.forwardRef<HTMLInputElement, CheckboxProps>(
  ({ className, size, indeterminate, label, disabled, ...props }, ref) => {
    const inputRef = React.useRef<HTMLInputElement | null>(null);

    // Merge the forwarded ref with our internal ref so we can drive the
    // `indeterminate` DOM property while still exposing the node to consumers.
    const setRefs = React.useCallback(
      (node: HTMLInputElement | null) => {
        inputRef.current = node;
        if (typeof ref === 'function') ref(node);
        else if (ref) (ref as React.MutableRefObject<HTMLInputElement | null>).current = node;
      },
      [ref]
    );

    React.useEffect(() => {
      if (inputRef.current) inputRef.current.indeterminate = !!indeterminate;
    }, [indeterminate]);

    return (
      <label
        className={cn(
          'inline-flex items-center gap-2 select-none',
          disabled ? 'cursor-not-allowed' : 'cursor-pointer',
          className
        )}
      >
        <span className="relative inline-flex shrink-0">
          <input
            ref={setRefs}
            type="checkbox"
            disabled={disabled}
            className="peer sr-only"
            {...props}
          />
          <span aria-hidden="true" className={cn(checkboxBoxVariants({ size }))} />
          <Icon
            name="check"
            aria-hidden
            className={cn(
              'pointer-events-none absolute inset-0 m-auto text-white',
              'hidden peer-checked:block peer-indeterminate:hidden',
              checkboxIconVariants({ size })
            )}
          />
          <Icon
            name="dash"
            aria-hidden
            className={cn(
              'pointer-events-none absolute inset-0 m-auto text-white',
              'hidden peer-indeterminate:block',
              checkboxIconVariants({ size })
            )}
          />
        </span>
        {label != null && (
          <span className={cn('text-body text-text', disabled && 'opacity-disabled')}>
            {label}
          </span>
        )}
      </label>
    );
  }
);
Checkbox.displayName = 'Checkbox';

export { Checkbox };
