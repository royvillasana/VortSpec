import * as React from 'react';
import { cn } from '@/lib/utils';
import { logoVariants, type LogoVariants } from './logo.variants';

export interface LogoProps
  extends Omit<React.HTMLAttributes<HTMLElement>, 'color'>,
    LogoVariants {
  /** Accessible name for the brand mark. */
  label?: string;
  /** Render the wordmark text beside the mark. */
  withWordmark?: boolean;
  /** Wordmark text. */
  wordmark?: string;
  /** When set, renders as a link (`<a>`). */
  href?: string;
}

/**
 * Logo — brand/product mark used on the Cover and Header.
 * The mark is `1em`-sized so it tracks the size variant's font token.
 */
const Logo = React.forwardRef<HTMLElement, LogoProps>(
  (
    {
      className,
      size,
      label = 'Design Engineering System',
      withWordmark = false,
      wordmark = 'DE System',
      href,
      ...props
    },
    ref
  ) => {
    const Comp: React.ElementType = href ? 'a' : 'span';
    return (
      <Comp
        ref={ref as React.Ref<never>}
        href={href}
        role={href ? undefined : 'img'}
        aria-label={label}
        className={cn(logoVariants({ size }), className)}
        {...props}
      >
        <svg
          viewBox="0 0 24 24"
          className="h-[1em] w-[1em] shrink-0 fill-current"
          aria-hidden
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect x="1" y="1" width="22" height="22" rx="6" />
          <path d="M7 7h5a5 5 0 0 1 0 10H7V7zm3 3v4h2a2 2 0 0 0 0-4h-2z" className="fill-white" />
        </svg>
        {withWordmark && <span>{wordmark}</span>}
      </Comp>
    );
  }
);
Logo.displayName = 'Logo';

export { Logo };
