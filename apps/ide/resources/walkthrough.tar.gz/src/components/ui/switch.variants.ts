import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Switch variants — accessible on/off toggle built on a real native
 * `<input type="checkbox" role="switch">` rendered visually-hidden (`peer sr-only`)
 * beside a custom pill track + sliding thumb.
 *   Size  → `size` (small | medium | large)
 *   State → CSS pseudo-classes driven by the peer input
 *           (peer-checked, peer-focus-visible, peer-disabled)
 *
 * Every color/spacing/radius/shadow utility resolves to a design token via the
 * Tailwind theme mapping (tailwind.config.js). No hardcoded values.
 */
export const switchTrackVariants = cva(
  'block shrink-0 rounded-full bg-neutral-300 transition-colors duration-150 ease-out ' +
    'peer-checked:bg-primary ' +
    'peer-focus-visible:ring-2 peer-focus-visible:ring-primary peer-focus-visible:ring-offset-2 ' +
    'peer-disabled:opacity-disabled peer-disabled:cursor-not-allowed',
  {
    variants: {
      size: {
        small: 'w-6 h-4',
        medium: 'w-8 h-5',
        large: 'w-8 h-6',
      },
    },
    defaultVariants: {
      size: 'medium',
    },
  }
);

/**
 * Thumb variants — the sliding knob. Absolutely positioned inside the relative
 * control wrapper (inset `left-1`/`top-1` = 4px on every side). Slides right on
 * `peer-checked` via a size-tuned `translate-x-*`.
 */
export const switchThumbVariants = cva(
  'pointer-events-none absolute left-1 top-1 rounded-full bg-white shadow ' +
    'transition-transform duration-150 ease-out',
  {
    variants: {
      size: {
        small: 'w-2 h-2 peer-checked:translate-x-2',
        medium: 'w-3 h-3 peer-checked:translate-x-3',
        large: 'w-4 h-4 peer-checked:translate-x-2',
      },
    },
    defaultVariants: {
      size: 'medium',
    },
  }
);

export type SwitchVariants = VariantProps<typeof switchTrackVariants>;
