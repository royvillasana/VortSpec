import type { Meta, StoryObj } from '@storybook/react';
import { Logo } from './Logo';

const meta: Meta<typeof Logo> = {
  title: 'Logo',
  component: Logo,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Brand/product mark used on the Cover and Header. The mark and wordmark scale together with the size token (rendered in the primary theme color).',
      },
    },
  },
  argTypes: {
    size: {
      control: 'radio',
      options: ['small', 'medium', 'large'],
      description: 'Logo size (maps to Heading typography tokens).',
    },
    withWordmark: { control: 'boolean', description: 'Show the wordmark text beside the mark.' },
    wordmark: { control: 'text', description: 'Wordmark text.' },
    label: { control: 'text', description: 'Accessible name for the brand mark.' },
    href: { control: 'text', description: 'When set, renders as a link.' },
  },
  args: {
    size: 'medium',
    withWordmark: true,
    wordmark: 'DE System',
  },
};

export default meta;
type Story = StoryObj<typeof Logo>;

export const Default: Story = {};

// --- Sizes ---
export const Small: Story = { args: { size: 'small' } };
export const Medium: Story = { args: { size: 'medium' } };
export const Large: Story = { args: { size: 'large' } };

// --- Modes ---
export const MarkOnly: Story = { args: { withWordmark: false } };
export const AsLink: Story = { args: { href: '#' } };
