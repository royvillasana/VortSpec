import type { Meta, StoryObj } from '@storybook/react';
import { Rating } from './Rating';

const meta: Meta<typeof Rating> = {
  title: 'Rating',
  component: Rating,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Star rating control. Interactive by default (a `radiogroup` of real `<button>`s with hover preview); pass `readOnly` for a static `role="img"` display. Supports controlled (`value`) and uncontrolled (`defaultValue`) usage.',
      },
    },
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'Row gap and star icon size.',
    },
    value: { control: 'number', description: 'Controlled rating value (1..max).' },
    defaultValue: { control: 'number', description: 'Initial value for uncontrolled usage.' },
    max: { control: 'number', description: 'Number of stars to render.' },
    readOnly: { control: 'boolean', description: 'Renders a non-interactive, read-only display.' },
  },
  args: {
    size: 'medium',
    defaultValue: 3,
    max: 5,
  },
};

export default meta;
type Story = StoryObj<typeof Rating>;

export const Default: Story = {};

export const ReadOnly: Story = { args: { value: 4, readOnly: true } };

export const Empty: Story = { args: { defaultValue: 0 } };

export const Full: Story = { args: { defaultValue: 5 } };

export const TenStars: Story = { args: { max: 10, defaultValue: 7 } };

// --- Sizes ---
export const Small: Story = { args: { size: 'small', defaultValue: 3 } };
export const Medium: Story = { args: { size: 'medium', defaultValue: 3 } };
export const Large: Story = { args: { size: 'large', defaultValue: 3 } };
