import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Text — single-line body/link text. Hierarchy variants map to text color
 * tokens; the `link` variant adds interactive underline affordance and the
 * `bullet` variant renders a leading marker. Body typography (16px / 1.5).
 */
export const textVariants = cva(
  'inline-flex items-center gap-2 font-base text-body leading-body font-regular align-middle',
  {
    variants: {
      variant: {
        primary: 'text-text',
        muted: 'text-muted',
        link:
          'text-primary underline-offset-4 hover:underline active:text-primary-hover cursor-pointer rounded-sm ' +
          'transition-[color,text-decoration-color] duration-150 ease-out ' +
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2',
        bullet: 'text-text',
      },
    },
    defaultVariants: {
      variant: 'primary',
    },
  }
);

export type TextVariants = VariantProps<typeof textVariants>;
