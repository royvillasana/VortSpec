import * as React from 'react';
import { cn } from '@/lib/utils';
import { Icon } from './Icon';
import { textVariants, type TextVariants } from './text.variants';

export interface TextProps
  extends Omit<React.HTMLAttributes<HTMLElement>, 'color'>,
    TextVariants {
  /** Optional icon rendered before the label. */
  leadingIcon?: React.ReactNode;
  /** Optional icon rendered after the label. */
  trailingIcon?: React.ReactNode;
  /** When set, renders as an anchor (`<a>`) instead of `<span>`. */
  href?: string;
}

/**
 * Text — inline single-line text with optional leading/trailing icons.
 * Renders `<a>` when `href` is provided, otherwise `<span>`.
 */
const Text = React.forwardRef<HTMLElement, TextProps>(
  ({ className, variant, leadingIcon, trailingIcon, href, children, ...props }, ref) => {
    const Comp: React.ElementType = href ? 'a' : 'span';
    return (
      <Comp
        ref={ref as React.Ref<never>}
        href={href}
        className={cn(textVariants({ variant }), className)}
        {...props}
      >
        {variant === 'bullet' && <Icon name="dot" size="small" aria-hidden />}
        {leadingIcon}
        <span>{children}</span>
        {trailingIcon}
      </Comp>
    );
  }
);
Text.displayName = 'Text';

export { Text };
