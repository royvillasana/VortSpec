import type { Meta, StoryObj } from '@storybook/react';
import { Slider } from './Slider';

const meta: Meta<typeof Slider> = {
  title: 'Slider',
  component: Slider,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Accessible, token-driven range control atom built on a styled native `<input type="range">` — keeping the built-in slider role and full keyboard support. Optional evenly-distributed tick marks render beneath the track.',
      },
    },
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'Height of the control row.',
    },
    min: { control: 'number', description: 'Minimum value.' },
    max: { control: 'number', description: 'Maximum value.' },
    step: { control: 'number', description: 'Step increment.' },
    defaultValue: { control: 'number', description: 'Initial value (uncontrolled).' },
    disabled: { control: 'boolean', description: 'Disables the control.' },
  },
  args: {
    size: 'medium',
    min: 0,
    max: 100,
    step: 1,
    defaultValue: 50,
  },
};

export default meta;
type Story = StoryObj<typeof Slider>;

export const Default: Story = {};

export const Disabled: Story = { args: { disabled: true } };

export const WithMarks: Story = {
  args: {
    min: 0,
    max: 100,
    step: 25,
    defaultValue: 50,
    marks: [
      { value: 0, label: '0%' },
      { value: 25, label: '25%' },
      { value: 50, label: '50%' },
      { value: 75, label: '75%' },
      { value: 100, label: '100%' },
    ],
  },
};

// --- Sizes ---
export const Small: Story = { args: { size: 'small' } };
export const Medium: Story = { args: { size: 'medium' } };
export const Large: Story = { args: { size: 'large' } };
