import type { Meta, StoryObj } from '@storybook/react';
import { Checkbox } from './Checkbox';

const meta: Meta<typeof Checkbox> = {
  title: 'Checkbox',
  component: Checkbox,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Accessible, token-driven checkbox atom built on a real native `<input type="checkbox">` with a custom box and check / dash icons driven by peer state. Supports an indeterminate third state and an optional label.',
      },
    },
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'Box (and inner icon) size.',
    },
    label: { control: 'text', description: 'Optional label rendered to the right of the box.' },
    checked: { control: 'boolean', description: 'Controlled checked state.' },
    indeterminate: {
      control: 'boolean',
      description: 'Reflects the DOM `indeterminate` property (a mixed, third state).',
    },
    disabled: { control: 'boolean', description: 'Disables the control.' },
  },
  args: {
    size: 'medium',
    label: 'Accept terms and conditions',
    checked: false,
  },
};

export default meta;
type Story = StoryObj<typeof Checkbox>;

export const Default: Story = {};

export const Checked: Story = { args: { checked: true, label: 'Checked' } };

export const Unchecked: Story = { args: { checked: false, label: 'Unchecked' } };

export const Indeterminate: Story = { args: { indeterminate: true, label: 'Indeterminate' } };

export const Disabled: Story = { args: { disabled: true, label: 'Disabled' } };

export const DisabledChecked: Story = {
  args: { disabled: true, checked: true, label: 'Disabled checked' },
};

// --- Sizes ---
export const Small: Story = { args: { size: 'small', label: 'Small' } };
export const Medium: Story = { args: { size: 'medium', label: 'Medium' } };
export const Large: Story = { args: { size: 'large', label: 'Large' } };
