import type { Meta, StoryObj } from '@storybook/react';
import { IconWrapper } from './IconWrapper';
import { Icon } from './Icon';

const meta: Meta<typeof IconWrapper> = {
  title: 'IconWrapper',
  component: IconWrapper,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Square tinted container that frames an Icon child — used for contact/social affordances on the Cover and elsewhere.',
      },
    },
  },
  argTypes: {
    size: {
      control: 'radio',
      options: ['small', 'medium', 'large'],
      description: 'Container size (padding-token driven).',
    },
    tone: {
      control: 'select',
      options: ['default', 'primary', 'secondary', 'dark'],
      description: 'Surface tone.',
    },
  },
  args: {
    size: 'medium',
    tone: 'default',
  },
  render: (args) => (
    <IconWrapper {...args}>
      <Icon name="link" size="medium" />
    </IconWrapper>
  ),
};

export default meta;
type Story = StoryObj<typeof IconWrapper>;

export const Default: Story = {};

// --- Tones ---
export const DefaultTone: Story = { args: { tone: 'default' } };
export const Primary: Story = { args: { tone: 'primary' } };
export const Secondary: Story = { args: { tone: 'secondary' } };
export const Dark: Story = { args: { tone: 'dark' } };

// --- Sizes ---
export const Small: Story = { args: { size: 'small' } };
export const Medium: Story = { args: { size: 'medium' } };
export const Large: Story = { args: { size: 'large' } };
