import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Rating variants — a horizontal row of star controls.
 *   Size → `size` (small | medium | large) drives the row gap and the Icon size.
 *   State → CSS pseudo-classes on the star buttons (:hover, :active, :focus-visible).
 *
 * Every spacing/color/radius utility resolves to a design token via the Tailwind
 * theme mapping (tailwind.config.js). No hardcoded values.
 */
export const ratingVariants = cva('inline-flex items-center', {
  variants: {
    size: {
      small: 'gap-1',
      medium: 'gap-1.5',
      large: 'gap-2',
    },
  },
  defaultVariants: {
    size: 'medium',
  },
});

/**
 * Star control — the interactive `<button>` wrapping a single star glyph.
 * Transparent, tight box with a token-backed focus ring and a brightness hover cue.
 */
export const ratingStarVariants = cva(
  'inline-flex items-center justify-center bg-transparent border-0 p-0 cursor-pointer ' +
    'transition-[filter] duration-150 ease-out hover:brightness-95 active:brightness-90 ' +
    'rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary ' +
    'focus-visible:ring-offset-2',
  {
    variants: {
      size: {
        small: '',
        medium: '',
        large: '',
      },
    },
    defaultVariants: {
      size: 'medium',
    },
  }
);

export type RatingVariants = VariantProps<typeof ratingVariants>;
