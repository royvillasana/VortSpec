import type { Meta, StoryObj } from '@storybook/react';
import { Paragraph } from './Paragraph';

const SAMPLE =
  'Paragraph renders multi-line body copy that fills its container width, using Body/Regular typography (16px, line-height 1.5). It is distinct from Text, which is single-line.';

const meta: Meta<typeof Paragraph> = {
  title: 'Paragraph',
  component: Paragraph,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: 'Block-level, multi-line body copy that fills its container width.',
      },
    },
  },
  argTypes: {
    tone: {
      control: 'radio',
      options: ['default', 'muted'],
      description: 'Text color tone.',
    },
    children: { control: 'text', description: 'Paragraph content.' },
  },
  args: {
    tone: 'default',
    children: SAMPLE,
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 480 }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof Paragraph>;

export const Default: Story = {};

export const DefaultTone: Story = { args: { tone: 'default' } };
export const Muted: Story = { args: { tone: 'muted' } };
