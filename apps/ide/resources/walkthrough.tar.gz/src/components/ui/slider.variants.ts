import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Slider variants — a styled native `<input type="range">` for accessible,
 * keyboard-operable value selection. Mirrors the Figma Slider component 1:1.
 *   Size  → `size` (small | medium | large) controls the height of the control row
 *   State → CSS pseudo-classes (:focus-visible, :disabled)
 *
 * The track and handle are colored with the `accent-primary` utility
 * (`accent-color: var(--theme-primary)`), which is token-backed. Every other
 * color/spacing/radius/opacity utility resolves to a design token via the
 * Tailwind theme mapping (tailwind.config.js). No hardcoded values.
 */
export const sliderVariants = cva(
  'w-full accent-primary cursor-pointer rounded ' +
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 ' +
    'disabled:opacity-disabled disabled:cursor-not-allowed',
  {
    variants: {
      size: {
        small: 'h-4',
        medium: 'h-5',
        large: 'h-6',
      },
    },
    defaultVariants: {
      size: 'medium',
    },
  }
);

export type SliderVariants = VariantProps<typeof sliderVariants>;
