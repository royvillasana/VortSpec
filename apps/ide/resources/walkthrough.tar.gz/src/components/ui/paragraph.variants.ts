import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Paragraph — multi-line body copy that fills its container width.
 * Body/Regular typography (16px, line-height 1.5), text/default color.
 * Distinct from Text, which is single-line.
 */
export const paragraphVariants = cva(
  'w-full font-base text-body leading-body font-regular',
  {
    variants: {
      tone: {
        default: 'text-text',
        muted: 'text-muted',
      },
    },
    defaultVariants: {
      tone: 'default',
    },
  }
);

export type ParagraphVariants = VariantProps<typeof paragraphVariants>;
