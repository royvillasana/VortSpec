import * as React from 'react';
import { cn } from '@/lib/utils';
import { paragraphVariants, type ParagraphVariants } from './paragraph.variants';

export interface ParagraphProps
  extends React.HTMLAttributes<HTMLParagraphElement>,
    ParagraphVariants {}

/**
 * Paragraph — block-level multi-line body copy.
 */
const Paragraph = React.forwardRef<HTMLParagraphElement, ParagraphProps>(
  ({ className, tone, ...props }, ref) => (
    <p ref={ref} className={cn(paragraphVariants({ tone }), className)} {...props} />
  )
);
Paragraph.displayName = 'Paragraph';

export { Paragraph };
