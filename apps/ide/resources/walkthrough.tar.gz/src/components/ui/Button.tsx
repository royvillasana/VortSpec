import * as React from 'react';
import { cn } from '@/lib/utils';
import { buttonVariants, type ButtonVariants } from './button.variants';

export interface ButtonProps
  extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'color'>,
    ButtonVariants {}

/**
 * Button — the design system's primary action control.
 * Styles are fully encapsulated; consumers pass semantic props plus an optional
 * `className` for layout overrides (merged last via cn()).
 */
const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, outline, iconOnly, type, disabled, ...props }, ref) => {
    if (
      import.meta.env.DEV &&
      iconOnly &&
      !props['aria-label'] &&
      !props['aria-labelledby']
    ) {
      // eslint-disable-next-line no-console
      console.warn('[Button] iconOnly buttons require an `aria-label` for accessibility.');
    }

    return (
      <button
        ref={ref}
        type={type ?? 'button'}
        disabled={disabled}
        aria-disabled={disabled || undefined}
        className={cn(buttonVariants({ variant, size, outline, iconOnly }), className)}
        {...props}
      />
    );
  }
);
Button.displayName = 'Button';

export { Button };
