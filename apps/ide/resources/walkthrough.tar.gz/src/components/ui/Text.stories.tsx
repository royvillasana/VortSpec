import type { Meta, StoryObj } from '@storybook/react';
import { Text } from './Text';
import { Icon } from './Icon';

const meta: Meta<typeof Text> = {
  title: 'Text',
  component: Text,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Inline single-line body/link text with optional leading/trailing icons. Renders as an `<a>` when `href` is set, otherwise a `<span>`. Distinct from Paragraph, which is multi-line.',
      },
    },
  },
  argTypes: {
    variant: {
      control: 'select',
      options: ['primary', 'muted', 'link', 'bullet'],
      description: 'Text hierarchy / affordance.',
    },
    href: { control: 'text', description: 'When set, renders as an anchor link.' },
    children: { control: 'text', description: 'Text content.' },
  },
  args: {
    variant: 'primary',
    children: 'The quick brown fox',
  },
};

export default meta;
type Story = StoryObj<typeof Text>;

export const Default: Story = {};

// --- Variants ---
export const Primary: Story = { args: { variant: 'primary', children: 'Primary text' } };
export const Muted: Story = { args: { variant: 'muted', children: 'Muted text' } };
export const Link: Story = {
  args: { variant: 'link', href: '#', children: 'Link text' },
};
export const Bullet: Story = { args: { variant: 'bullet', children: 'Bullet list item' } };

// --- With icons ---
export const WithLeadingIcon: Story = {
  args: { variant: 'primary', children: 'Documentation', leadingIcon: <Icon name="link" size="small" /> },
};

export const WithTrailingIcon: Story = {
  args: {
    variant: 'link',
    href: '#',
    children: 'Read more',
    trailingIcon: <Icon name="chevron-right" size="small" />,
  },
};
