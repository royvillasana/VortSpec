import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Checkbox variants — the custom visual box that mirrors the native
 * `<input type="checkbox">` peer state, plus the sizing of the check / dash
 * Icon rendered inside it.
 *
 *   Size  → `size` (small | medium | large) → box 16 / 20 / 24px
 *   State → CSS peer pseudo-classes on the sibling input
 *           (:checked, :indeterminate, :focus-visible, :disabled)
 *
 * Every color / spacing / radius / stroke / opacity utility resolves to a
 * design token via the Tailwind theme mapping (tailwind.config.js). No
 * hardcoded values.
 */
export const checkboxBoxVariants = cva(
  'inline-flex shrink-0 items-center justify-center border border-1 rounded-sm ' +
    'bg-white border-neutral-300 text-white ' +
    'transition-[background-color,border-color,color] duration-150 ease-out ' +
    'peer-checked:bg-primary peer-checked:border-primary ' +
    'peer-indeterminate:bg-primary peer-indeterminate:border-primary ' +
    'peer-focus-visible:ring-2 peer-focus-visible:ring-primary peer-focus-visible:ring-offset-2 ' +
    'peer-disabled:opacity-disabled peer-disabled:cursor-not-allowed',
  {
    variants: {
      size: {
        small: 'h-4 w-4',
        medium: 'h-5 w-5',
        large: 'h-6 w-6',
      },
    },
    defaultVariants: {
      size: 'medium',
    },
  }
);

/**
 * Icon sizing inside the box — one tier smaller footprint than the box so the
 * glyph reads with breathing room at every size.
 */
export const checkboxIconVariants = cva('', {
  variants: {
    size: {
      small: 'h-3 w-3',
      medium: 'h-4 w-4',
      large: 'h-5 w-5',
    },
  },
  defaultVariants: {
    size: 'medium',
  },
});

export type CheckboxVariants = VariantProps<typeof checkboxBoxVariants>;
