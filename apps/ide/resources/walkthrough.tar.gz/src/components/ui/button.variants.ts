import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Button variants — mirrors the Figma Buttons page 1:1.
 *   Type    → `variant` (10 values)
 *   Size    → `size` (small | medium | large)
 *   Outline → `outline` (boolean)
 *   IconOnly→ `iconOnly` (boolean)
 *   State   → CSS pseudo-classes (:hover, :active, :disabled, :focus-visible)
 *
 * Every color/spacing/radius/stroke utility resolves to a design token via the
 * Tailwind theme mapping (tailwind.config.js). No hardcoded values.
 */
export const buttonVariants = cva(
  'inline-flex items-center justify-center gap-2 whitespace-nowrap font-base font-regular ' +
    'border border-1 border-transparent transition-[background-color,border-color,color,filter] ' +
    'duration-150 ease-out cursor-pointer select-none ' +
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 ' +
    'disabled:opacity-disabled disabled:pointer-events-none disabled:cursor-not-allowed',
  {
    variants: {
      variant: {
        base: 'bg-neutral-600 text-white hover:brightness-95 active:brightness-90',
        primary: 'bg-primary text-white hover:bg-primary-hover active:bg-primary-hover',
        secondary: 'bg-secondary text-white hover:brightness-95 active:brightness-90',
        success: 'bg-success text-white hover:brightness-95 active:brightness-90',
        danger: 'bg-danger text-white hover:brightness-95 active:brightness-90',
        warning: 'bg-warning text-near-black hover:brightness-95 active:brightness-90',
        info: 'bg-info text-near-black hover:brightness-95 active:brightness-90',
        light: 'bg-neutral-100 text-near-black hover:brightness-95 active:brightness-90',
        dark: 'bg-near-black text-white hover:brightness-125 active:brightness-150',
        link: 'bg-transparent text-primary underline-offset-4 hover:underline active:text-primary-hover',
      },
      size: {
        small: 'text-body rounded-sm px-2 py-1',
        medium: 'text-body rounded px-3 py-1.5',
        large: 'text-body rounded px-4 py-2',
      },
      outline: {
        true: 'bg-transparent',
        false: '',
      },
      iconOnly: {
        true: 'aspect-square',
        false: '',
      },
    },
    compoundVariants: [
      // Outline overrides per type (link excluded — outline is a no-op for link).
      { variant: 'base', outline: true, class: 'text-text border-neutral-600 hover:bg-neutral-600 hover:text-white hover:brightness-100' },
      { variant: 'primary', outline: true, class: 'text-primary border-primary hover:bg-primary hover:text-white hover:brightness-100' },
      { variant: 'secondary', outline: true, class: 'text-secondary border-secondary hover:bg-secondary hover:text-white hover:brightness-100' },
      { variant: 'success', outline: true, class: 'text-success border-success hover:bg-success hover:text-white hover:brightness-100' },
      { variant: 'danger', outline: true, class: 'text-danger border-danger hover:bg-danger hover:text-white hover:brightness-100' },
      { variant: 'warning', outline: true, class: 'text-warning-emphasis border-warning hover:bg-warning hover:text-near-black hover:brightness-100' },
      { variant: 'info', outline: true, class: 'text-info-emphasis border-info hover:bg-info hover:text-near-black hover:brightness-100' },
      { variant: 'light', outline: true, class: 'text-text border-neutral-100 hover:bg-neutral-100 hover:text-near-black hover:brightness-100' },
      { variant: 'dark', outline: true, class: 'text-near-black border-near-black hover:bg-near-black hover:text-white hover:brightness-100' },
      // Symmetric padding for icon-only.
      { iconOnly: true, size: 'small', class: 'p-1' },
      { iconOnly: true, size: 'medium', class: 'p-1.5' },
      { iconOnly: true, size: 'large', class: 'p-2' },
    ],
    defaultVariants: {
      variant: 'primary',
      size: 'medium',
      outline: false,
      iconOnly: false,
    },
  }
);

export type ButtonVariants = VariantProps<typeof buttonVariants>;
