import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Logo — brand/product mark. Size variants map to Heading typography tokens;
 * the mark and wordmark scale with the resolved font size (`1em`), so a single
 * token drives both. Rendered in the primary theme color.
 */
export const logoVariants = cva(
  'inline-flex items-center gap-2 rounded-sm font-base font-regular text-primary leading-heading whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2',
  {
    variants: {
      size: {
        small: 'text-h6',
        medium: 'text-h5',
        large: 'text-h3',
      },
    },
    defaultVariants: {
      size: 'medium',
    },
  }
);

export type LogoVariants = VariantProps<typeof logoVariants>;
