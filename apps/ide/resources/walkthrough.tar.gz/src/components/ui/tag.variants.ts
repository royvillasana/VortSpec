import { cva, type VariantProps } from 'class-variance-authority';

/**
 * Tag variants — small inline label/chip for statuses, categories, or metadata.
 *   Variant → `variant` (color, 9 values — mirrors the Button color types)
 *   Size    → `size` (small | medium)
 *
 * Solid tinted background + readable label. Every color/spacing/radius/font
 * utility resolves to a design token via the Tailwind theme mapping
 * (tailwind.config.js). No hardcoded values.
 */
export const tagVariants = cva(
  'inline-flex items-center gap-1 rounded-sm font-base font-regular text-body leading-body ' +
    'whitespace-nowrap align-middle select-none',
  {
    variants: {
      variant: {
        base: 'bg-neutral-600 text-white',
        primary: 'bg-primary text-white',
        secondary: 'bg-secondary text-white',
        success: 'bg-success text-white',
        danger: 'bg-danger text-white',
        warning: 'bg-warning text-near-black',
        info: 'bg-info text-near-black',
        light: 'bg-neutral-100 text-text',
        dark: 'bg-near-black text-white',
      },
      size: {
        small: 'px-2 py-1',
        medium: 'px-2.5 py-1',
      },
    },
    defaultVariants: {
      variant: 'base',
      size: 'medium',
    },
  }
);

export type TagVariants = VariantProps<typeof tagVariants>;
