import type { Meta, StoryObj } from '@storybook/react';
import { Icon, iconGlyphs } from './Icon';

const glyphNames = Object.keys(iconGlyphs) as (keyof typeof iconGlyphs)[];

const meta: Meta<typeof Icon> = {
  title: 'Icon',
  component: Icon,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Single-glyph SVG atom. Sized via `size`, colored via `currentColor` (inherits its context text color). Pass a registered `name`, or provide custom `children` paths.',
      },
    },
  },
  argTypes: {
    name: {
      control: 'select',
      options: glyphNames,
      description: 'Registered glyph name.',
    },
    size: {
      control: 'radio',
      options: ['small', 'medium', 'large'],
      description: 'Glyph box size (token-backed).',
    },
    label: {
      control: 'text',
      description: 'Accessible name. When omitted the icon is decorative (aria-hidden).',
    },
  },
  args: {
    name: 'info',
    size: 'medium',
  },
};

export default meta;
type Story = StoryObj<typeof Icon>;

export const Default: Story = {};

export const Small: Story = { args: { size: 'small' } };
export const Medium: Story = { args: { size: 'medium' } };
export const Large: Story = { args: { size: 'large' } };

export const Labeled: Story = {
  args: { name: 'check-circle', label: 'Success' },
};

export const Decorative: Story = {
  args: { name: 'exclamation-triangle' },
};

export const AllGlyphs: Story = {
  parameters: { controls: { disable: true } },
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 24, maxWidth: 480 }}>
      {glyphNames.map((name) => (
        <div
          key={name}
          style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, width: 96 }}
        >
          <Icon name={name} size="large" label={name} />
          <span style={{ fontSize: 12 }}>{name}</span>
        </div>
      ))}
    </div>
  ),
};
