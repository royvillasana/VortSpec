import * as React from 'react';
import { cn } from '@/lib/utils';
import { sliderVariants, type SliderVariants } from './slider.variants';

export interface SliderProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size' | 'type'>,
    SliderVariants {
  /** Optional tick marks rendered beneath the track, evenly distributed. */
  marks?: { value: number; label?: string }[];
}

/**
 * Slider — an accessible, token-driven range control atom.
 *
 * Renders a styled native `<input type="range">` so it keeps the built-in
 * slider role plus full keyboard support (arrows adjust value, Home/End jump to
 * min/max) for free. The track and handle are colored via the token-backed
 * `accent-primary` utility. When `marks` are provided, the input and a row of
 * evenly-distributed labels are wrapped in a `<div>`; the consumer `className`
 * lands on that wrapper (or directly on the input when there are no marks).
 */
const Slider = React.forwardRef<HTMLInputElement, SliderProps>(
  ({ className, size, marks, ...props }, ref) => {
    const hasMarks = !!marks && marks.length > 0;

    const input = (
      <input
        ref={ref}
        type="range"
        className={cn(sliderVariants({ size }), hasMarks ? undefined : className)}
        {...props}
      />
    );

    if (!hasMarks) return input;

    return (
      <div className={cn('flex flex-col gap-1', className)}>
        {input}
        <div className="flex justify-between text-body leading-body text-muted">
          {marks.map((mark, index) => (
            <span key={`${mark.value}-${index}`}>{mark.label ?? mark.value}</span>
          ))}
        </div>
      </div>
    );
  }
);
Slider.displayName = 'Slider';

export { Slider };
