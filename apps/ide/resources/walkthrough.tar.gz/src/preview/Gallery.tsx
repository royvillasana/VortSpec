import * as React from 'react';
import {
  Button,
  Icon,
  IconWrapper,
  Text,
  Paragraph,
  Logo,
  Title,
  PageTitle,
  Callout,
  CodeBlock,
  Header,
  type IconName,
} from '@/components';

/* ------------------------------------------------------------------ *
 * Live component preview harness
 *
 * Default view: the full component gallery (every component from
 * components.json across its main variants/states, styled with the
 * project's design tokens).
 *
 * VortSpec live-control protocol:
 *   - On load, posts { source: 'vortspec-preview', type: 'ready' } to
 *     window.parent.
 *   - Listens for { source: 'vortspec-preview', type: 'render',
 *     component, props } and renders ONLY that component with those props.
 * ------------------------------------------------------------------ */

type PropBag = Record<string, unknown>;

/** Pull a well-typed value out of a loosely-typed live-control prop bag. */
function pick<T>(props: PropBag, key: string, fallback: T): T {
  const v = props[key];
  return v === undefined ? fallback : (v as T);
}

/**
 * Registry: component name (matching components.json) → a `render(props)`
 * that maps the live-control prop bag onto the real component's
 * props/variants. Text-bearing components fall back to sample content so a
 * bare `{ type: 'render', component }` message still shows something useful.
 */
const registry: Record<string, (props: PropBag) => React.ReactNode> = {
  Icon: (p) => {
    const { children: _children, ...rest } = p;
    return <Icon name={pick<IconName>(p, 'name', 'info')} {...rest} />;
  },

  IconWrapper: (p) => {
    const { children: _c, icon, ...rest } = p;
    return (
      <IconWrapper {...rest}>
        <Icon name={pick<IconName>(p, 'icon', 'link')} aria-hidden />
      </IconWrapper>
    );
  },

  Text: (p) => {
    const { children, icon, ...rest } = p;
    return (
      <Text {...rest}>{pick<React.ReactNode>(p, 'children', 'Text label')}</Text>
    );
  },

  Paragraph: (p) => {
    const { children, ...rest } = p;
    return (
      <Paragraph {...rest}>
        {pick<React.ReactNode>(
          p,
          'children',
          'A multi-line body copy block that fills its container width, built on the Body typography token.'
        )}
      </Paragraph>
    );
  },

  Button: (p) => {
    const { children, icon, ...rest } = p;
    const iconOnly = pick<boolean>(p, 'iconOnly', false);
    return (
      <Button {...rest}>
        {iconOnly ? (
          <Icon name={pick<IconName>(p, 'icon', 'chevron-right')} aria-hidden />
        ) : (
          pick<React.ReactNode>(p, 'children', 'Button')
        )}
      </Button>
    );
  },

  Logo: (p) => <Logo {...p} />,

  Title: (p) => {
    const { children, ...rest } = p;
    return (
      <Title {...rest}>{pick<React.ReactNode>(p, 'children', 'Section title')}</Title>
    );
  },

  PageTitle: (p) => {
    const { children, ...rest } = p;
    return (
      <PageTitle {...rest}>
        {pick<React.ReactNode>(p, 'children', 'Page title')}
      </PageTitle>
    );
  },

  Callout: (p) => {
    const { children, ...rest } = p;
    return (
      <Callout {...rest}>
        {pick<React.ReactNode>(p, 'children', 'This is a callout message.')}
      </Callout>
    );
  },

  CodeBlock: (p) => {
    const { children, ...rest } = p;
    return (
      <CodeBlock {...rest}>
        {pick<React.ReactNode>(p, 'code', pick<React.ReactNode>(p, 'children', 'npm install @de/system'))}
      </CodeBlock>
    );
  },

  Header: (p) => {
    const navItems = pick(p, 'navItems', [
      { label: 'Docs', href: '#docs' },
      { label: 'Components', href: '#components' },
      { label: 'Tokens', href: '#tokens' },
    ]);
    return (
      <div className="w-full max-w-4xl">
        <Header
          navItems={navItems as { label: string; href: string }[]}
          cta={<Button size="small">Get started</Button>}
          {...p}
        />
      </div>
    );
  },
};

/* ---------------------------- Gallery chrome ---------------------------- */

function Section({
  title,
  level,
  description,
  children,
}: {
  title: string;
  level: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <section className="flex flex-col gap-4 border-b border-1 border-neutral-100 py-6">
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <h2 className="m-0 font-base text-h4 font-regular leading-heading text-text">
            {title}
          </h2>
          <span className="rounded-sm bg-neutral-100 px-2 py-1 font-base text-body font-regular leading-body text-muted">
            {level}
          </span>
        </div>
        <p className="m-0 font-base text-body font-regular leading-body text-muted">
          {description}
        </p>
      </div>
      {children}
    </section>
  );
}

/** A labelled swatch row so each variant/state is legible. */
function Row({ children }: { children: React.ReactNode }) {
  return <div className="flex flex-wrap items-center gap-4">{children}</div>;
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col items-start gap-1">
      <span className="font-base text-body font-regular leading-body text-muted">
        {label}
      </span>
      {children}
    </div>
  );
}

const BUTTON_TYPES = [
  'base',
  'primary',
  'secondary',
  'success',
  'danger',
  'warning',
  'info',
  'light',
  'dark',
  'link',
] as const;

const CALLOUT_STATUSES = ['info', 'warning', 'success', 'danger', 'secondary'] as const;

function FullGallery() {
  return (
    <div className="min-h-screen bg-white font-base text-text">
      <div className="mx-auto flex max-w-4xl flex-col px-6 pb-16">
        <header className="flex flex-col gap-2 py-8">
          <span className="font-base text-h6 font-regular uppercase leading-body text-muted">
            Live Preview
          </span>
          <h1 className="m-0 font-base text-h1 font-regular leading-heading text-text">
            Design Engineering System
          </h1>
          <p className="m-0 font-base text-body font-regular leading-body text-muted">
            Every component from the inventory, across its main variants and states.
          </p>
        </header>

        {/* ---------------------------- Atoms ---------------------------- */}

        <Section
          title="Icon"
          level="atom"
          description="Single-glyph SVG, sized via `size`, colored via currentColor."
        >
          <Field label="Sizes (small / medium / large)">
            <Row>
              <Icon name="info" size="small" label="info small" />
              <Icon name="info" size="medium" label="info medium" />
              <Icon name="info" size="large" label="info large" />
            </Row>
          </Field>
          <Field label="Glyphs">
            <Row>
              {(
                ['info', 'exclamation-triangle', 'check-circle', 'x-circle', 'x', 'list', 'chevron-right', 'link', 'dot'] as IconName[]
              ).map((n) => (
                <Icon key={n} name={n} size="medium" label={n} />
              ))}
            </Row>
          </Field>
        </Section>

        <Section
          title="IconWrapper"
          level="atom"
          description="Square tinted container framing an Icon (contact/social affordances)."
        >
          <Field label="Tones">
            <Row>
              {(['default', 'primary', 'secondary', 'dark'] as const).map((tone) => (
                <IconWrapper key={tone} tone={tone}>
                  <Icon name="link" aria-hidden />
                </IconWrapper>
              ))}
            </Row>
          </Field>
          <Field label="Sizes">
            <Row>
              {(['small', 'medium', 'large'] as const).map((size) => (
                <IconWrapper key={size} size={size}>
                  <Icon name="chevron-right" aria-hidden />
                </IconWrapper>
              ))}
            </Row>
          </Field>
        </Section>

        <Section
          title="Text"
          level="atom"
          description="Single-line text with optional icons; primary / muted / link / bullet."
        >
          <Row>
            <Text variant="primary">Primary text</Text>
            <Text variant="muted">Muted text</Text>
            <Text variant="link" href="#">
              Link text
            </Text>
          </Row>
          <Row>
            <Text variant="bullet">Bullet list item</Text>
            <Text leadingIcon={<Icon name="check-circle" size="small" aria-hidden />}>
              With leading icon
            </Text>
            <Text trailingIcon={<Icon name="chevron-right" size="small" aria-hidden />}>
              With trailing icon
            </Text>
          </Row>
        </Section>

        <Section
          title="Paragraph"
          level="atom"
          description="Multi-line body copy that fills its container; default / muted tone."
        >
          <Paragraph>
            Default paragraph — multi-line body copy built on the Body/Regular typography
            token (16px, line-height 1.5) and the default text color.
          </Paragraph>
          <Paragraph tone="muted">
            Muted paragraph — the same block on the muted text color token, for supporting
            or secondary copy.
          </Paragraph>
        </Section>

        <Section
          title="Logo"
          level="atom"
          description="Brand mark + wordmark; size tracks the Heading typography token."
        >
          <Field label="Sizes">
            <Row>
              <Logo size="small" />
              <Logo size="medium" />
              <Logo size="large" />
            </Row>
          </Field>
          <Field label="Mark only">
            <Logo withWordmark={false} />
          </Field>
        </Section>

        <Section
          title="Button"
          level="atom"
          description="10 types × sizes × outline × icon-only, plus disabled state."
        >
          <Field label="Types (solid)">
            <Row>
              {BUTTON_TYPES.map((v) => (
                <Button key={v} variant={v}>
                  {v}
                </Button>
              ))}
            </Row>
          </Field>
          <Field label="Types (outline)">
            <Row>
              {BUTTON_TYPES.filter((v) => v !== 'link').map((v) => (
                <Button key={v} variant={v} outline>
                  {v}
                </Button>
              ))}
            </Row>
          </Field>
          <Field label="Sizes">
            <Row>
              <Button size="small">Small</Button>
              <Button size="medium">Medium</Button>
              <Button size="large">Large</Button>
            </Row>
          </Field>
          <Field label="Icon only / disabled">
            <Row>
              <Button iconOnly aria-label="Next">
                <Icon name="chevron-right" aria-hidden />
              </Button>
              <Button iconOnly outline aria-label="Close">
                <Icon name="x" aria-hidden />
              </Button>
              <Button disabled>Disabled</Button>
              <Button variant="secondary" disabled>
                Disabled
              </Button>
            </Row>
          </Field>
        </Section>

        {/* -------------------------- Molecules -------------------------- */}

        <Section
          title="Title"
          level="molecule"
          description="Heading with optional subtitle, badge, and icons; levels 1–6."
        >
          <Title level={2} subtitle="An optional supporting subtitle">
            Title with subtitle
          </Title>
          <Title
            level={3}
            leadingIcon={<Icon name="list" aria-hidden />}
            badge={
              <span className="rounded-sm bg-neutral-100 px-2 py-1 text-body text-muted">
                new
              </span>
            }
          >
            Title with icon + badge
          </Title>
          <Row>
            {([1, 2, 3, 4, 5, 6] as const).map((lvl) => (
              <Title key={lvl} level={lvl}>
                H{lvl}
              </Title>
            ))}
          </Row>
        </Section>

        <Section
          title="PageTitle"
          level="molecule"
          description="Large page heading block (eyebrow + H1 + description); left / center."
        >
          <PageTitle eyebrow="Documentation" description="The supporting description sits below the heading in muted text.">
            Getting started
          </PageTitle>
          <PageTitle align="center" eyebrow="Centered" description="Alignment variant set to center.">
            Centered page title
          </PageTitle>
        </Section>

        <Section
          title="Callout"
          level="molecule"
          description="Icon + message on a tinted status surface; five statuses."
        >
          {CALLOUT_STATUSES.map((status) => (
            <Callout key={status} status={status} title={status[0].toUpperCase() + status.slice(1)}>
              This is a {status} callout with the default status icon and emphasis text token.
            </Callout>
          ))}
        </Section>

        <Section
          title="CodeBlock"
          level="molecule"
          description="Neutral or dark code-snippet surface, optional filename."
        >
          <CodeBlock filename="install.sh" code={'npm install @de/system\nimport { Button } from "@de/system";'} />
          <CodeBlock tone="dark" code={'<Button variant="primary">Ship it</Button>'} />
        </Section>

        {/* -------------------------- Organisms -------------------------- */}

        <Section
          title="Header"
          level="organism"
          description="Top documentation bar composing Logo, nav, and a CTA."
        >
          <Header
            navItems={[
              { label: 'Docs', href: '#docs' },
              { label: 'Components', href: '#components' },
              { label: 'Tokens', href: '#tokens' },
            ]}
            cta={<Button size="small">Get started</Button>}
          />
        </Section>
      </div>
    </div>
  );
}

/* ------------------------- Live-control renderer ------------------------ */

function LiveRender({ component, props }: { component: string; props: PropBag }) {
  const render = registry[component];
  return (
    <div className="flex min-h-screen items-center justify-center bg-white p-8 font-base text-text">
      {render ? (
        render(props)
      ) : (
        <div className="flex flex-col items-center gap-2 text-center">
          <p className="m-0 font-base text-h5 font-regular leading-heading text-text">
            Unknown component: <code>{component}</code>
          </p>
          <p className="m-0 font-base text-body font-regular leading-body text-muted">
            Known components: {Object.keys(registry).join(', ')}
          </p>
        </div>
      )}
    </div>
  );
}

/* ------------------------------- Gallery ------------------------------- */

type LiveState = { component: string; props: PropBag } | null;

export function Gallery() {
  const [live, setLive] = React.useState<LiveState>(null);

  React.useEffect(() => {
    function onMessage(event: MessageEvent) {
      const data = event.data;
      if (!data || data.source !== 'vortspec-preview' || data.type !== 'render') return;
      setLive({
        component: String(data.component),
        props: (data.props ?? {}) as PropBag,
      });
    }

    window.addEventListener('message', onMessage);
    // Announce readiness so the parent knows it can start sending render messages.
    window.parent?.postMessage({ source: 'vortspec-preview', type: 'ready' }, '*');

    return () => window.removeEventListener('message', onMessage);
  }, []);

  if (live) {
    return <LiveRender component={live.component} props={live.props} />;
  }
  return <FullGallery />;
}
