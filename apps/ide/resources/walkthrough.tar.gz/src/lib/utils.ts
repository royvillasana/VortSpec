import { clsx, type ClassValue } from 'clsx';
import { extendTailwindMerge } from 'tailwind-merge';

/**
 * tailwind-merge, taught about this project's custom `fontSize` theme keys.
 *
 * The Tailwind theme (tailwind.config.js) adds non-default font sizes:
 *   text-body, text-h1 … text-h6
 * Stock tailwind-merge does not know these are font sizes, so it lumps
 * `text-h2`, `text-body`, etc. into the SAME conflict group as text COLORS
 * (`text-white`, `text-primary`, …). When a component set both — e.g. the
 * Button's `text-white` (variant slot) followed by `text-body` (size slot) —
 * twMerge dropped the color, leaving a black label on a colored fill
 * (a real contrast failure caught in visual verification). Registering the
 * custom sizes in the `font-size` group keeps size and color independent so
 * both survive the merge regardless of authoring order.
 */
const twMerge = extendTailwindMerge({
  extend: {
    classGroups: {
      'font-size': [{ text: ['body', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'] }],
    },
  },
});

/**
 * Merge class names safely. clsx resolves conditional/array class values;
 * twMerge de-duplicates conflicting Tailwind utilities so a consumer-supplied
 * `className` (always passed LAST) wins for layout overrides.
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
