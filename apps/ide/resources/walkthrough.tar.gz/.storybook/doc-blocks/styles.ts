/**
 * Shared presentational style tokens for the SDD-DE Storybook doc blocks.
 *
 * These are the ONLY values the doc blocks hardcode via CSS custom properties —
 * every color/spacing/radius reference below points at the project's own design
 * tokens (src/styles/tokens.css), which are loaded globally in .storybook/preview.
 * Doc blocks are documentation chrome, not shipped UI, but we still route through
 * tokens so the reference pages look like the system they describe.
 */
import type { CSSProperties } from 'react';

export const mono =
  'var(--font-family-mono, ui-monospace, SFMono-Regular, Menlo, monospace)';
export const sans = 'var(--font-family-base, system-ui, sans-serif)';

export const c = {
  border: 'var(--color-neutral-300, #dee2e6)',
  borderStrong: 'var(--color-neutral-muted, #babbbc)',
  surface: 'var(--primitive-neutral-white, #ffffff)',
  surfaceSubtle: 'var(--color-neutral-100, #f8f9fa)',
  text: 'var(--color-text-default, #212529)',
  textMuted: 'var(--color-text-muted, #6c757d)',
  brand: 'var(--theme-primary, #087990)',
  brandTint: 'var(--brand-primary-100, #e6f2f4)',
  brandInk: 'var(--brand-primary-700, #054956)',
  danger: 'var(--color-status-danger, #dc3545)',
  dangerTint: '#fbeaec',
  dangerInk: 'var(--primitive-red-600, #b02a37)',
} as const;

/** Section wrapper — one per doc block, gives every page identical rhythm. */
export const section: CSSProperties = {
  fontFamily: sans,
  color: c.text,
  margin: '28px 0',
  lineHeight: 1.5,
};

export const h2: CSSProperties = {
  fontFamily: sans,
  fontSize: 13,
  fontWeight: 600,
  letterSpacing: '0.06em',
  textTransform: 'uppercase',
  color: c.textMuted,
  margin: '0 0 12px',
};

export const table: CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  fontSize: 14,
  border: `1px solid ${c.border}`,
  borderRadius: 8,
  overflow: 'hidden',
};

export const th: CSSProperties = {
  textAlign: 'left',
  fontWeight: 600,
  fontSize: 12,
  letterSpacing: '0.03em',
  textTransform: 'uppercase',
  color: c.textMuted,
  background: c.surfaceSubtle,
  padding: '8px 12px',
  borderBottom: `1px solid ${c.border}`,
};

export const td: CSSProperties = {
  padding: '10px 12px',
  borderBottom: `1px solid ${c.border}`,
  verticalAlign: 'top',
};

export const code: CSSProperties = {
  fontFamily: mono,
  fontSize: 12.5,
  background: c.surfaceSubtle,
  border: `1px solid ${c.border}`,
  borderRadius: 4,
  padding: '1px 6px',
  color: c.text,
  whiteSpace: 'nowrap',
};

/** Enum-value pill / keyword chip. */
export const pill: CSSProperties = {
  display: 'inline-block',
  fontFamily: mono,
  fontSize: 12,
  lineHeight: 1.6,
  background: c.brandTint,
  color: c.brandInk,
  border: `1px solid ${c.brand}`,
  borderRadius: 999,
  padding: '0 8px',
  margin: '0 6px 6px 0',
};
