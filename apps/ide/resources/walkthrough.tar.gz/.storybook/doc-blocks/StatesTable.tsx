import type { FC } from 'react';
import { section, h2, table, th, td, code } from './styles';

export interface StateRow {
  state: string;
  description: string;
}

export interface StatesTableProps {
  rows: StateRow[];
}

/** 'States & Behaviour' — State | Description. */
export const StatesTable: FC<StatesTableProps> = ({ rows }) => (
  <section style={section}>
    <h2 style={h2}>States &amp; Behaviour</h2>
    <table style={table}>
      <thead>
        <tr>
          <th style={{ ...th, width: 180 }}>State</th>
          <th style={th}>Description</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.state}>
            <td style={{ ...td, whiteSpace: 'nowrap' }}>
              <code style={code}>{r.state}</code>
            </td>
            <td style={{ ...td, whiteSpace: 'normal' }}>{r.description}</td>
          </tr>
        ))}
      </tbody>
    </table>
  </section>
);
