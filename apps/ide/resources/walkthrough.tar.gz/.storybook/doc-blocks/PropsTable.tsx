import type { FC } from 'react';
import { section, h2, table, th, td, code, pill, c } from './styles';

export interface PropRow {
  prop: string;
  /** Free-form type label (e.g. `boolean`, `ReactNode`). Ignored if `values` is set. */
  type?: string;
  /** Enum union — rendered as pills. */
  values?: string[];
  default?: string;
  description: string;
  required?: boolean;
}

export interface PropsTableProps {
  rows: PropRow[];
}

/** Props | Type/Values | Default | Description. Enum unions render as pills. */
export const PropsTable: FC<PropsTableProps> = ({ rows }) => (
  <section style={section}>
    <h2 style={h2}>Props</h2>
    <table style={table}>
      <thead>
        <tr>
          <th style={th}>Prop</th>
          <th style={th}>Type / Values</th>
          <th style={th}>Default</th>
          <th style={th}>Description</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.prop}>
            <td style={{ ...td, whiteSpace: 'nowrap' }}>
              <code style={code}>{r.prop}</code>
              {r.required && (
                <span style={{ color: c.danger, marginLeft: 4 }} title="required">
                  *
                </span>
              )}
            </td>
            <td style={td}>
              {r.values ? (
                <span>
                  {r.values.map((v) => (
                    <span key={v} style={pill}>
                      {v}
                    </span>
                  ))}
                </span>
              ) : (
                <code style={code}>{r.type ?? '—'}</code>
              )}
            </td>
            <td style={td}>
              {r.default ? (
                <code style={code}>{r.default}</code>
              ) : (
                <span style={{ color: c.textMuted }}>—</span>
              )}
            </td>
            <td style={{ ...td, whiteSpace: 'normal' }}>{r.description}</td>
          </tr>
        ))}
      </tbody>
    </table>
  </section>
);
