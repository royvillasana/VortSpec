import type { FC } from 'react';
import { section, h2, mono, c } from './styles';

export interface TokenSwatch {
  /** CSS custom-property name, e.g. `--theme-primary`. */
  name: string;
  /** Resolved value, e.g. `#087990` or `8px`. */
  value: string;
  /** Optional role note, e.g. "primary background". */
  role?: string;
}

export interface TokensProps {
  tokens: TokenSwatch[];
  footnote?: string;
}

const isColor = (v: string) =>
  /^#|^rgb|^hsl|gradient/.test(v.trim().toLowerCase());

/** 'Design Tokens' — swatch grid (color chip + name + value) with a footnote. */
export const Tokens: FC<TokensProps> = ({ tokens, footnote }) => (
  <section style={section}>
    <h2 style={h2}>Design Tokens</h2>
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
        gap: 10,
      }}
    >
      {tokens.map((t) => (
        <div
          key={t.name}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            border: `1px solid ${c.border}`,
            borderRadius: 8,
            padding: '8px 10px',
            background: c.surface,
          }}
        >
          <span
            aria-hidden
            style={{
              flex: '0 0 auto',
              width: 28,
              height: 28,
              borderRadius: 6,
              border: `1px solid ${c.borderStrong}`,
              background: isColor(t.value)
                ? t.value
                : `var(${t.name}, ${c.surfaceSubtle})`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontFamily: mono,
              fontSize: 10,
              color: c.textMuted,
            }}
          >
            {isColor(t.value) ? '' : '{}'}
          </span>
          <span style={{ minWidth: 0, lineHeight: 1.35 }}>
            <code
              style={{
                fontFamily: mono,
                fontSize: 12,
                color: c.text,
                display: 'block',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
              }}
            >
              {t.name}
            </code>
            <span style={{ fontFamily: mono, fontSize: 11.5, color: c.textMuted }}>
              {t.value}
              {t.role ? ` · ${t.role}` : ''}
            </span>
          </span>
        </div>
      ))}
    </div>
    {footnote && (
      <p style={{ margin: '12px 0 0', fontSize: 12.5, color: c.textMuted }}>
        {footnote}
      </p>
    )}
  </section>
);
