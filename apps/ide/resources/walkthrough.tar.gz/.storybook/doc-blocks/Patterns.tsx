import type { FC } from 'react';
import { section, h2, mono, c } from './styles';

export interface Pattern {
  title: string;
  description: string;
  code: string;
}

export interface PatternsProps {
  items: Pattern[];
}

/** 'Common Patterns' — titled, copy-pasteable usage recipes. */
export const Patterns: FC<PatternsProps> = ({ items }) => (
  <section style={section}>
    <h2 style={h2}>Common Patterns</h2>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {items.map((p) => (
        <div key={p.title}>
          <div style={{ fontWeight: 600, fontSize: 14.5, marginBottom: 2 }}>
            {p.title}
          </div>
          <div style={{ color: c.textMuted, fontSize: 13.5, marginBottom: 8 }}>
            {p.description}
          </div>
          <pre
            style={{
              margin: 0,
              fontFamily: mono,
              fontSize: 12.5,
              lineHeight: 1.6,
              background: c.surfaceSubtle,
              border: `1px solid ${c.border}`,
              borderRadius: 8,
              padding: '12px 14px',
              overflowX: 'auto',
              color: c.text,
            }}
          >
            <code>{p.code}</code>
          </pre>
        </div>
      ))}
    </div>
  </section>
);
