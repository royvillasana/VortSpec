import type { FC } from 'react';
import { section, h2, table, th, td, code, c } from './styles';

export interface IdentityProps {
  category: string;
  type: string;
  /** Import statement or path, rendered monospace. */
  importPath: string;
  figmaFile?: string;
  figmaNode?: string;
}

/**
 * Component Identity — the machine-facing "who am I" key/value table.
 * First metadata block on every docs page.
 */
export const Identity: FC<IdentityProps> = ({
  category,
  type,
  importPath,
  figmaFile,
  figmaNode,
}) => {
  const rows: Array<[string, React.ReactNode]> = [
    ['Category', category],
    ['Type', type],
    ['Import', <code style={code}>{importPath}</code>],
  ];
  if (figmaFile) rows.push(['Figma file', figmaFile]);
  if (figmaNode) rows.push(['Figma node', <code style={code}>{figmaNode}</code>]);

  return (
    <section style={section}>
      <h2 style={h2}>Component Identity</h2>
      <table style={table}>
        <tbody>
          {rows.map(([k, v]) => (
            <tr key={k}>
              <th
                style={{
                  ...th,
                  width: 160,
                  textTransform: 'none',
                  letterSpacing: 0,
                  fontSize: 13,
                  color: c.textMuted,
                  borderRight: `1px solid ${c.border}`,
                }}
              >
                {k}
              </th>
              <td style={td}>{v}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
};
