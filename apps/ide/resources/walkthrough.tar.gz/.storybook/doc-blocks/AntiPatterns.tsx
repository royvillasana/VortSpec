import type { FC } from 'react';
import { section, h2, mono, c } from './styles';

export interface AntiPattern {
  title: string;
  why: string;
  /** The correct approach to use instead. */
  instead: string;
}

export interface AntiPatternsProps {
  items: AntiPattern[];
}

/** 'Anti-Patterns' — red-tinted cards, each with a ✗ marker, Why, and Instead. */
export const AntiPatterns: FC<AntiPatternsProps> = ({ items }) => (
  <section style={section}>
    <h2 style={h2}>Anti-Patterns</h2>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {items.map((a) => (
        <div
          key={a.title}
          style={{
            background: c.dangerTint,
            border: `1px solid ${c.danger}`,
            borderLeft: `4px solid ${c.danger}`,
            borderRadius: 8,
            padding: '12px 14px',
          }}
        >
          <div
            style={{
              fontWeight: 600,
              fontSize: 14,
              color: c.dangerInk,
              marginBottom: 4,
            }}
          >
            <span style={{ marginRight: 6 }} aria-hidden>
              ✗
            </span>
            {a.title}
          </div>
          <div style={{ fontSize: 13.5, marginBottom: 6 }}>
            <strong style={{ color: c.dangerInk }}>Why: </strong>
            {a.why}
          </div>
          <div style={{ fontSize: 13.5 }}>
            <strong style={{ color: c.text }}>Instead: </strong>
            <span style={{ fontFamily: a.instead.includes('<') ? mono : 'inherit' }}>
              {a.instead}
            </span>
          </div>
        </div>
      ))}
    </div>
  </section>
);
