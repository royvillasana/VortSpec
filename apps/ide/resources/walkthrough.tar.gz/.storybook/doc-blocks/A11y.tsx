import type { FC } from 'react';
import { section, h2, table, th, td, c } from './styles';

export interface A11yProps {
  role?: string;
  keyboard?: string;
  screenReader?: string;
  wcag?: string;
  notes?: string[];
}

/** Accessibility — ARIA role / Keyboard / Screen reader / WCAG table + notes. */
export const A11y: FC<A11yProps> = ({
  role,
  keyboard,
  screenReader,
  wcag,
  notes,
}) => {
  const rows: Array<[string, string | undefined]> = [
    ['ARIA role', role],
    ['Keyboard', keyboard],
    ['Screen reader', screenReader],
    ['WCAG', wcag],
  ];
  return (
    <section style={section}>
      <h2 style={h2}>Accessibility</h2>
      <table style={table}>
        <tbody>
          {rows
            .filter(([, v]) => v)
            .map(([k, v]) => (
              <tr key={k}>
                <th
                  style={{
                    ...th,
                    width: 160,
                    textTransform: 'none',
                    letterSpacing: 0,
                    fontSize: 13,
                    color: c.textMuted,
                    borderRight: `1px solid ${c.border}`,
                  }}
                >
                  {k}
                </th>
                <td style={{ ...td, whiteSpace: 'normal' }}>{v}</td>
              </tr>
            ))}
        </tbody>
      </table>
      {notes && notes.length > 0 && (
        <ul style={{ margin: '12px 0 0', paddingLeft: 20, fontSize: 13.5 }}>
          {notes.map((n, i) => (
            <li key={i} style={{ marginBottom: 4 }}>
              {n}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
};
