import type { FC } from 'react';
import { section, h2, pill, c } from './styles';

export interface AIHintsProps {
  /** One-sentence "reach for this when…" use-case statement. */
  useCase: string;
  keywords: string[];
  /** Numbered, imperative generation rules for a UI-composing agent. */
  rules: string[];
}

/** 'AI Generation Hints' — the block an AI agent reads to pick + wire this component. */
export const AIHints: FC<AIHintsProps> = ({ useCase, keywords, rules }) => (
  <section style={section}>
    <h2 style={h2}>AI Generation Hints</h2>
    <div
      style={{
        background: c.brandTint,
        border: `1px solid ${c.brand}`,
        borderRadius: 8,
        padding: '14px 16px',
      }}
    >
      <p style={{ margin: '0 0 12px', fontSize: 14, color: c.brandInk }}>
        <strong>Use when: </strong>
        {useCase}
      </p>

      <div style={{ marginBottom: 12 }}>
        <div
          style={{
            fontSize: 12,
            fontWeight: 600,
            letterSpacing: '0.04em',
            textTransform: 'uppercase',
            color: c.textMuted,
            marginBottom: 6,
          }}
        >
          Keywords
        </div>
        <div>
          {keywords.map((k) => (
            <span key={k} style={pill}>
              {k}
            </span>
          ))}
        </div>
      </div>

      <div>
        <div
          style={{
            fontSize: 12,
            fontWeight: 600,
            letterSpacing: '0.04em',
            textTransform: 'uppercase',
            color: c.textMuted,
            marginBottom: 6,
          }}
        >
          Generation Rules
        </div>
        <ol style={{ margin: 0, paddingLeft: 20, fontSize: 13.5 }}>
          {rules.map((r, i) => (
            <li key={i} style={{ marginBottom: 5 }}>
              {r}
            </li>
          ))}
        </ol>
      </div>
    </div>
  </section>
);
