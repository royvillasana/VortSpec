/**
 * SDD-DE Storybook doc blocks — reusable, presentational MDX building blocks.
 *
 * Every component's `<Component>.mdx` composes these so the reference pages share
 * one identical, machine-readable structure:
 *   Identity → Props → Patterns → AntiPatterns → StatesTable → A11y → Tokens → AIHints.
 *
 * All styling routes through the project's own design tokens (loaded in preview).
 */
export { Identity } from './Identity';
export type { IdentityProps } from './Identity';

export { PropsTable } from './PropsTable';
export type { PropsTableProps, PropRow } from './PropsTable';

export { Patterns } from './Patterns';
export type { PatternsProps, Pattern } from './Patterns';

export { AntiPatterns } from './AntiPatterns';
export type { AntiPatternsProps, AntiPattern } from './AntiPatterns';

export { StatesTable } from './StatesTable';
export type { StatesTableProps, StateRow } from './StatesTable';

export { A11y } from './A11y';
export type { A11yProps } from './A11y';

export { Tokens } from './Tokens';
export type { TokensProps, TokenSwatch } from './Tokens';

export { AIHints } from './AIHints';
export type { AIHintsProps } from './AIHints';
