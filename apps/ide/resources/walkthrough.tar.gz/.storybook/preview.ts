import type { Preview } from '@storybook/react';

// Global styles: imports design tokens (src/styles/tokens.css) + Tailwind layers,
// so every story renders with the real design system theme.
import '../src/styles/index.css';

const preview: Preview = {
  parameters: {
    layout: 'centered',
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i,
      },
    },
  },
};

export default preview;
