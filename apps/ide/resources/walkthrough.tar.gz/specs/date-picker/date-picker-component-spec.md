# DatePicker — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

DatePicker is the design system's date-selection form field (molecule). It is a labeled
field that wraps the **native `<input type="date">`**, adding a leading calendar Icon and
the same label / hint / error / ARIA pattern used across the form-item family. It supports
a single date (`date-picker`) and a start–end date range (`date-picker-range`).

**Deliberate decision — wrap the native input, do not build a custom calendar.** We render
the browser's native `<input type="date">` rather than a bespoke calendar popover. The
native control ships an accessible, keyboard-operable picker across platforms and locales
for free, and it keeps the component fully token-pure and robust (no floating layer, no
focus-trap, no date math to own). This trades a small amount of visual customization for
correctness and accessibility.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-white` | `#ffffff` | `background-color` (control) |
| `--color-neutral-100` | `#f8f9fa` | `background-color` (disabled) |
| `--color-neutral-300` | `#dee2e6` | `border-color` (default) |
| `--color-danger` | `#dc3545` | border + focus ring (invalid), error text, required asterisk |
| `--color-primary` | `#0d6efd` | focus ring (default) |
| `--color-text-default` | `#212529` | `color` (label + typed text) |
| `--color-text-muted` | `#6c757d` | `color` (hint, calendar icon, range separator) |
| `--font-family-base` | Roboto | `font-family` |
| `--font-size-body` | `16px` | `font-size` |
| `--font-weight-regular` | `400` | `font-weight` |
| `--radius-default` | `rounded` | `border-radius` |
| `--stroke-width-1` | `1px` | `border-width` |
| `--opacity-disabled` | — | `opacity` (disabled) |
| `--spacing-8 / -32` | `8px / 32px` | icon offset (`left-2`) / input `pl-8` |

All references resolve via the Tailwind theme mapping in `tailwind.config.js` → CSS
variables. No hardcoded hex / px / rem / arbitrary values.

---

### Variants

| Variant | Prop | Description |
|---|---|---|
| **single** | `range={false}` (default) | One `<input type="date">`; spreads native `...props` (value/onChange/min/max). |
| **range** | `range` | Two date inputs (start + end) separated by a muted en-dash `–`; internal state + `onRangeChange(start, end)`. Each input named via `aria-label` ("Start date" / "End date"). |

Both variants share the same control styling (`datePickerVariants`) and the leading
calendar Icon adornment.

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | White bg, neutral-300 border, muted calendar icon | — |
| `focus-visible` | 2px primary ring, offset (danger ring when invalid) | Keyboard focus |
| `invalid` | Danger border + danger focus ring, `aria-invalid`, error text below | `error` set (or `invalid` prop) |
| `disabled` | `opacity-disabled`, `not-allowed` cursor, neutral-100 bg | `disabled` attribute |
| `required` | Danger asterisk appended to label; native `required` on input(s) | `required` prop |

---

### Sizes

| Size | Padding | Font | Radius |
|---|---|---|---|
| `small` | `pl-8 py-1 pr-2` | body 16px | `rounded` |
| `medium` | `pl-8 py-2 pr-2.5` | body 16px | `rounded` |
| `large` | `pl-8 py-2.5 pr-3` | body 16px | `rounded` |

`pl-8` is constant across sizes to reserve room for the leading calendar Icon. Width fills
the container (`w-full`); in range mode each input is `flex-1`.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `size` | `small \| medium \| large` | `medium` | Padding density |
| `invalid` | `boolean` | `!!error` | Force error styling + `aria-invalid` |
| `label` | `React.ReactNode` | — | Field label, associated via `htmlFor` |
| `hint` | `string` | — | Helper text below the control (hidden when `error` set) |
| `error` | `string` | — | Error message below the control; also flips control to invalid |
| `required` | `boolean` | — | Native `required` + visual asterisk |
| `range` | `boolean` | `false` | Render start + end date inputs |
| `onRangeChange` | `(start: string, end: string) => void` | — | Range-mode change callback |
| `min`, `max`, `value`, `onChange`, `disabled`, ... | native | — | `InputHTMLAttributes<HTMLInputElement>` spread (single input; min/max/disabled also apply to range inputs) |
| `className` | `string` | — | Layout overrides on the outer wrapper, merged last via `cn()` |

`forwardRef<HTMLInputElement>` → the single input, or the **first (start)** input in range
mode. `id` falls back to `React.useId()`.

---

### Accessibility

- Control: native `<input type="date">` — retains the built-in picker and full keyboard support.
- Label associated to the (first) input via `htmlFor` / `id`.
- Calendar Icon is decorative (`aria-hidden`).
- Range inputs are individually named via `aria-label` ("Start date" / "End date").
- `aria-invalid` is set automatically when `error` (or `invalid`) is present.
- `aria-describedby` links the control to the hint and/or error text (ids derived from field id).
- Error text uses `role="alert"`; the required asterisk is `aria-hidden` (semantics carried by native `required`).
- Visible focus indicator: `focus-visible:ring-2` (primary, danger when invalid) with offset.

---

### Do Not

- Do not build a custom calendar popover — wrap the native `<input type="date">` (accessibility + token purity).
- Do not hardcode colors, spacing, radius, or type values — reference tokens via Tailwind theme.
- Do not use `style={{}}` or arbitrary `[..]` utilities for design values.
- Do not rely on `invalid` styling alone — pair with visible, associated `error` text.
- Do not remove the focus ring or the label association.

---

### Implementation Tasks

- [x] Create `src/components/modules/date-picker.variants.ts` (CVA `size`, `invalid`, `pl-8` icon room)
- [x] Create `src/components/modules/DatePicker.tsx` (`forwardRef`, `cn()` last on outer wrapper)
- [x] Wrap native `<input type="date">` with token border/bg/text and leading calendar Icon
- [x] Implement `size` (small / medium / large) padding
- [x] Implement `invalid` / `error` — danger border + danger focus ring + `aria-invalid` + error text
- [x] Implement `label` (htmlFor), `hint`, `required` (asterisk + native attribute)
- [x] Implement `range` mode — start + end inputs, en-dash separator, internal state, `onRangeChange`
- [x] `aria-label` per range input; `aria-describedby` wiring for hint/error
- [x] `id` via `React.useId()` fallback
- [x] Focus-visible ring (primary, danger when invalid) and disabled pattern
