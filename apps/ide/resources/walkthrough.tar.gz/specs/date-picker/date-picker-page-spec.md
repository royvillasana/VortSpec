# DatePicker — Page / Usage Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Documents how the DatePicker molecule is composed and placed within forms and screens. It
is a `form-item` control used wherever a single date or a date range must be captured
(filters, booking, scheduling, report ranges, profile fields).

---

### Component Inventory

| Element | Component | Role |
|---|---|---|
| Field wrapper | `DatePicker` (molecule) | Label + control + hint/error layout |
| Leading adornment | `Icon` (`name="calendar"`, `size="small"`, `aria-hidden`) | Visual date affordance |
| Control | native `<input type="date">` | Accessible date entry + picker |
| Range separator | `<span>–</span>` (`text-muted`, `aria-hidden`) | Divides start/end inputs |

DatePicker composes the existing `Icon` atom; it introduces no new tokens.

---

### Usage Example

**Single date**

```tsx
import { DatePicker } from '@/components/modules/DatePicker';

<DatePicker
  label="Due date"
  hint="Pick any weekday."
  min="2026-01-01"
  value={value}
  onChange={(e) => setValue(e.target.value)}
/>
```

**Single date with error + required**

```tsx
<DatePicker
  label="Start date"
  required
  error="Please choose a date."
/>
```

**Date range**

```tsx
<DatePicker
  label="Reporting period"
  range
  size="large"
  onRangeChange={(start, end) => setRange({ start, end })}
/>
```

---

### Responsive

- The field is fluid: the control is `w-full`, so DatePicker fills its column/grid cell.
- In range mode the two inputs are `flex-1` and share the row with the muted separator;
  on narrow containers the inputs shrink evenly rather than wrapping.
- Consumers control column layout via the outer wrapper `className` (merged last), e.g. a
  form grid can constrain width; DatePicker owns no fixed width itself.

---

### Accessibility

- Every DatePicker instance should provide a `label`.
- Pair `invalid`/`error` with visible, associated error text (built in via the `error` prop).
- Range inputs are self-describing via `aria-label`; keep the visible `label` for the group.
- Hint and error text are linked through `aria-describedby`; error text is announced via `role="alert"`.
- The native control guarantees keyboard operability and a platform-accessible picker.

---

### Implementation Tasks

- [x] Compose `DatePicker` from the `Icon` atom + native `<input type="date">`
- [x] Document single, error/required, and range usage examples
- [x] Fluid `w-full` control; range inputs `flex-1`; width owned by consumer wrapper `className`
- [x] Verify label / hint / error / aria wiring in composed forms
- [x] Confirm token purity (no hardcoded values) across all usages
