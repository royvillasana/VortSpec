# Visual-Verify Report — DatePicker

- **Component**: DatePicker (`src/components/modules/DatePicker.tsx`, `date-picker.variants.ts`)
- **Design source**: Figma (file `ojko9pGfsDAvmUf2DA38d2`)
- **Date**: 2026-07-07
- **Live-rendered?**: **No — not executable.** No Storybook story exists for DatePicker.
  Verified from **source of truth** (spec ↔ code ↔ token model). Runtime pixel diff and
  axe scan are *not executable* here — they are **not "failed"**, they were verified from source.

---

## Method

Cross-checked `DatePicker.tsx` + `date-picker.variants.ts` against the Component Spec,
Interaction Spec, the Tailwind→CSS-var token map (`tailwind.config.js`), and `tokens.css`.
Ran the token-audit grep (below). Confirmed `npx tsc --noEmit` → exit 0.

## Checklist results

### Variants & Sizes (source)
| Dimension | Spec | Code | Result |
|---|---|---|---|
| `size` small/medium/large | py-1/pr-2 · py-2/pr-2.5 · py-2.5/pr-3 (+ pl-8) | identical in variants | ✓ |
| default size | medium | `defaultVariants.size='medium'` | ✓ |
| `invalid` true/false | danger border+ring / primary ring | identical | ✓ |
| single vs range | one input / start+end w/ en-dash + `onRangeChange` | implemented | ✓ |
| `pl-8` icon room constant across sizes | yes | base class `pl-8` | ✓ |

### States (source)
default ✓ · focus-visible ring-2 (primary, danger when invalid) w/ offset ✓ · invalid (danger border + `aria-invalid` + error text) ✓ · disabled (`opacity-disabled`, `cursor-not-allowed`, `bg-neutral-100`) ✓ · required (asterisk + native `required`) ✓

### Token audit (zero tolerance)
```
grep -nE '#[0-9a-fA-F]{3,8}|rgb\(|hsl\(|[0-9]+px|\[[0-9]|style=\{\{'  DatePicker.tsx date-picker.variants.ts
→ NO MATCHES
```
Every utility resolves to a CSS var: colors (`bg-white`, `border-neutral-300`, `text-text`,
`text-muted`, `border-danger`, `ring-primary`, `ring-danger`, `bg-neutral-100`), spacing
(`pl-8`=8, `py-1/2/2.5`, `pr-2/2.5/3`, `gap-1/2`, `left-2`), radius (`rounded`=DEFAULT),
border (`border-1`), type (`text-body`, `font-base`, `font-regular`), `opacity-disabled`.
All spacing keys are within the mapped set (0,1,1.5,2,2.5,3,4,5,6,7,8,12.5,18,20) → **no leak.**

### Accessibility (source)
- Native `<input type="date">` — built-in accessible picker + keyboard ✓
- `<label htmlFor>` associated to first input via `id`/`useId` ✓
- Calendar Icon `aria-hidden` + `pointer-events-none` ✓
- Range inputs individually named `aria-label="Start date"/"End date"` ✓
- `aria-invalid` auto-set from `error`/`invalid` ✓
- `aria-describedby` merges incoming + hint + error ids ✓
- Error text `role="alert"` ✓
- Required asterisk **`aria-hidden`**, semantics carried by native `required` — **matches spec §Accessibility** ✓
- Focus ring: `outline-none` replaced by `ring-2` (never suppressed) ✓

### Architecture
`.variants.ts` colocated ✓ · CVA mirrors spec 1:1 ✓ · defaultVariants match ✓ · `forwardRef`→first input ✓ · native `...props` spread onto the control (correct for form-field molecule) ✓ · `className` merged LAST via `cn()` on outer wrapper ✓ · `VariantProps` exported ✓ · no inline `style={{}}` ✓

### Interaction spec
Native picker/keyboard delegated ✓ · single spreads value/onChange/min/max ✓ · range internal start/end + `onRangeChange` on each change ✓ · muted en-dash `aria-hidden` ✓ · `duration-150 ease-out` color transition ✓ · disabled removes from tab order ✓.

### Prior-note check ("wraps a native control — confirm no floating-panel token leaks")
Confirmed: **no floating panel/popover is rendered** by this component (the popover is the
browser-native one). No `shadow-*`, `z-*`, or arbitrary positioning tokens leak. ✓

## Discrepancies
None. (Observation, not a discrepancy: DatePicker's outer wrapper carries `font-base` while
the canonical `Input` molecule and `TimePicker` do not — harmless; the control itself is
`font-base` in all cases.)

## Gate: **PASS** (zero unresolved discrepancies; runtime pixel/axe not executable — verified from source)
