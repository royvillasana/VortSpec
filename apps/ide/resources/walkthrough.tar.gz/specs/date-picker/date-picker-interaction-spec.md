# DatePicker — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Overview

DatePicker delegates the core date-entry interaction to the **native `<input type="date">`**.
The component adds label / hint / error affordances and, in range mode, coordinates a
start + end pair. Because the picker itself is native, the browser owns the calendar popover,
locale formatting, and keyboard model — we deliberately do not re-implement any of it (this
keeps the interaction accessible and token-pure).

---

### Trigger

- **Single**: clicking/tapping the input (or its native calendar indicator) opens the browser's
  native date picker; typing edits the value directly.
- **Range**: the same trigger applies independently to the start input and the end input.
- Keyboard focus (Tab) moves into the input(s); the native picker also opens via the browser's
  own keyboard affordance (platform-dependent).

---

### Flow

**Single date**
1. User focuses the input (Tab or pointer).
2. User picks a date from the native popover, or types one.
3. Native `onChange` fires with the new value; consumer state updates (controlled or native).

**Date range**
1. User focuses the **start** input and selects a date.
2. Internal `start` state updates; `onRangeChange(start, end)` fires.
3. User focuses the **end** input (past the muted `–` separator) and selects a date.
4. Internal `end` state updates; `onRangeChange(start, end)` fires with both values.

---

### Timing

- Border/ring color transitions use `transition-colors duration-150 ease-out` (token-mapped timing).
- No custom open/close animation is owned by the component — the native picker's appearance
  is controlled by the browser/OS.

---

### Edge Cases

| Case | Behavior |
|---|---|
| **Invalid range (end < start)** | The component does not block entry (native inputs are independent). Consumers should validate `start`/`end` from `onRangeChange` and surface an `error` string; passing `error` flips both inputs to the invalid style and renders `role="alert"` text. |
| **`min` / `max` bounds** | Passed through to the native input(s); the browser constrains selectable dates and rejects out-of-range typed values. |
| **Empty value** | Native inputs render their empty placeholder state; value is `''`. `onRangeChange` reports `''` for the unset side. |
| **Disabled** | Native `disabled` removes the input(s) from tab order and applies the disabled visual (neutral-100 bg, `opacity-disabled`). |
| **Unsupported browser** | Browsers without native date support degrade to a text input; the leading icon, label, hint, and error affordances still apply. |

---

### Accessibility & Keyboard

- Native `<input type="date">` retains full built-in keyboard support (arrow keys / typing across
  segments, and the browser's picker-open shortcut).
- Tab / Shift+Tab move between the start and end inputs in range mode.
- Label is associated via `htmlFor`; clicking it focuses the (first) input.
- Each range input is named via `aria-label` ("Start date" / "End date").
- `aria-invalid` is set when `error`/`invalid` is present; `aria-describedby` links hint/error text.
- Error text uses `role="alert"` so assistive tech announces it on appearance.
- Focus is always visible via `focus-visible:ring-2` (primary, danger when invalid).

---

### Implementation Tasks

- [x] Delegate date entry + popover to native `<input type="date">` (no custom calendar)
- [x] Single mode: spread native `value`/`onChange`/`min`/`max` onto the input
- [x] Range mode: internal `start`/`end` state, `onRangeChange` on each change
- [x] Muted en-dash `–` separator between range inputs (`aria-hidden`)
- [x] `aria-label` per range input; label `htmlFor` on the first input
- [x] `error` → `aria-invalid` + danger styling + `role="alert"` text
- [x] Pass `min`/`max` through for bound enforcement; disabled removes from tab order
- [x] Token-mapped color transition (`duration-150 ease-out`); visible focus ring
