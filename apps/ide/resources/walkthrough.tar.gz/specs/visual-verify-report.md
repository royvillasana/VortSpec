# Visual Verify Report — Design System (34 components)

- **Design source:** `figma` (Branch A)
- **Date:** 2026-07-06 · **Full-library re-verify:** 2026-07-07 · **Full 34-component re-run:** 2026-07-07 (see top banner)
- **Scope:** all 34 built components (atoms · molecules · organisms)
- **Verifier:** `/visual-verify`

---

## 🔁 2026-07-07 — FULL 34-COMPONENT RE-RUN (post `text-muted` fix)

`/visual-verify` was re-run across **every built component** (source-of-truth, Branch A). Each
`specs/<component>/visual-verify-report.md` was written/refreshed. The `text-muted` alias fix
(`tailwind.config.js:50` → `colors.muted: var(--color-text-muted)`) is now **confirmed live**, so the
previously systemic token-wiring defect is closed across all affected components (Text, Paragraph,
Slider, Breadcrumb, CodeBlock, Input, InputNumber, Select, FileInput, FormFloating, DatePicker,
TimePicker, PageTitle, Tabs, Upload, …).

### Result: 34 PASS (2 FAILs found → both fixed & re-verified same day)

The re-run found 2 discrepancies; both were **fixed on 2026-07-07** and re-verified. Final state: **34/34
PASS** on all source-of-truth dimensions.

| # | Component | Found | Fix applied (✅ resolved) |
|---|---|---|---|
| — | 32 components | ✅ PASS | Token/variant/state/semantic-ARIA all source-verified clean |
| 1 | **Header** | Real token leak — `header.variants.ts:8` had `border-b border-1` with **no border-color class** → Tailwind Preflight painted the divider its default `gray-200` (#e5e7eb). Grep-invisible (color came from Preflight, not a class). | Added `border-neutral-300` (→ `--color-neutral-300`), matching `navbar.variants.ts:9` / Table / Tabs. Typecheck clean. |
| 2 | **Logo** | Spec↔code drift — (a) `Logo.tsx:28` defaulted `withWordmark = true` vs spec default `false`; (b) linked `<a>` shipped only the UA focus outline, not the spec's `focus-visible:ring-2 ring-primary`. | (a) `withWordmark = false` (matches spec); (b) added `focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2` (+`rounded-sm`) to `logo.variants.ts:9`. Typecheck clean. |

Both fixes bring the **code** to the (correct) **spec** — no spec artifacts changed. Details in the
per-component reports (`specs/header/`, `specs/logo/`), where D1/D2 are now marked ✅ RESOLVED. The Header
divider was the notable catch: a genuine untokenized value invisible to the static-grep token audit
because the offending color originated in Tailwind's Preflight base layer, not in any utility string —
organism-level border/layer scrutiny surfaced it.

### Static leak audit — clean library-wide (grep-visible layer)
Grep across all 34 `.tsx` + `.variants.ts` for `#hex` / `rgb()` / `hsl()` / inline `style={{}}` /
arbitrary `[..px]` / default-palette colors → **0 hits**. Every spacing/sizing utility uses a
mapped key; the expected picker/dropdown-panel offenders don't exist (Select/DatePicker/TimePicker
wrap native controls, so there are no floating panels to leak). `font-mono` (CodeBlock) remains the
one documented intentional exception. All 34 spec dirs have every task checked `- [x]`.

### Non-blocking nits recorded in per-component reports
Select dangling `aria-describedby` idref when both hint+error set; TimePicker required `*` not
`aria-hidden`; several specs carry stale hex/px value labels in prose (code is correct); redundant
`border border-1` on a few atoms (both map to the same token).

---

## ✅ 2026-07-07 full-library re-verify — SYSTEMIC DEFECT `text-muted` FOUND & FIXED

`/visual-verify` was re-run across **all 34 components** (per-component reports now live in each
`specs/<component>/visual-verify-report.md`). It surfaced one broken-token-reference defect that had
spread library-wide; the defect was then **fixed and compile-verified** the same day. Status below is
**RESOLVED** — all 34 components now pass the token dimension.

**Fix applied 2026-07-07.** Added a top-level alias to `tailwind.config.js` →
`colors.muted: 'var(--color-text-muted)'` (kept alongside the existing nested `text: { DEFAULT, muted }`).
This makes the flat utility `text-muted` — and `placeholder:text-muted` — resolve. Compile-verified with
Tailwind 3.4.19: `.text-muted { color: var(--color-text-muted) }` and
`.placeholder:text-muted::placeholder { color: var(--color-text-muted) }` now both emit. **No component
source was changed** — one config line cleared all 17 affected components at once. Each affected
per-component report's D1 is marked **✅ RESOLVED**. The original defect analysis is preserved below for the
audit trail.

---

### Original defect (now resolved) — `text-muted` was a dead class

**The defect.** `tailwind.config.js` defines `colors.text = { DEFAULT, muted }`. Tailwind flattens a
nested `muted` key to the utility **`text-text-muted`** — there is **no** top-level `muted` color, so the
literal utility **`text-muted` matches nothing and compiles to zero CSS** (verified by compiling the real
config with Tailwind 3.4.19). Everywhere `text-muted` is used, `--color-text-muted` (#6c757d) is silently
dropped and the element inherits the ambient foreground. It is **not** a hardcoded-hex/px leak (the
zero-tolerance *hardcode* gate stays green), but it **is** a token-wiring defect that fails the token
dimension.

**Scope (authoritative grep, 2026-07-07).** 19 shipped component files use the dead class; only
`Table.tsx` uses the correct `text-text-muted`:

| Tier | Components failing on `text-muted` |
|---|---|
| ui atoms | Text, Textarea (`placeholder:text-muted`), Paragraph, Slider (marks) |
| molecules | Breadcrumb, CodeBlock, DatePicker, DropdownMenu, FileInput, FormFloating, Input, InputNumber, PageTitle, Select, TimePicker |
| organisms | Tabs, Upload |

(Also present in `Header.stories.tsx` and `src/preview/Gallery.tsx` — not shipped components, but the
gallery renders muted text wrong too.) **17 of 34 components FAIL** on this single root cause.

**Fix (not applied — verify is read-only).** One repo-wide sweep `text-muted` → `text-text-muted`
(and `placeholder:text-muted` → `placeholder:text-text-muted`), **or** add a top-level `text-muted`
color alias in `tailwind.config.js` pointing at `var(--color-text-muted)`. The single sweep clears the
token dimension for all 17 components at once. This belongs in **`/sync-tokens`** or a dedicated fix
commit; re-run `/visual-verify` on the affected components afterward.

> Note: the 2026-07-06 pass covered only the original 11 components and none of them exercised the muted
> path in a way that surfaced this (Callout/Title use `text-text`/status tokens; PageTitle's muted eyebrow
> was mis-passed on 2026-07-06 and is corrected in its per-component report today).

---

## ⚠️ Environment limitation — runtime checks NOT executed

The Figma-flow checklist includes **live-viewport pixel comparison (375 / 768 / 1440px)**
and a **runtime axe audit**. These were **not run**, and their results are **not asserted**,
because this environment has no way to render the components:

- **No app entry point.** The Vite dev server on `:5173` loads `/src/main.tsx`, but that file
  does not exist (`src/` has no `main.tsx` / `App.tsx` / mount harness).
- **No Storybook stories.** Storybook is listening on `:6006`, but there are zero `.stories.tsx`
  files, so nothing renders there either.
- **No browser driver.** Playwright / Puppeteer are not installed, so headless screenshots
  and axe-core cannot be driven.

Everything below is a **source-of-truth verification** (spec ↔ code ↔ token model), which is
fully authoritative for the token, variant, state-wiring, and semantic/ARIA dimensions. The
pixel and runtime-axe dimensions remain **open** until a render harness exists.

**To complete them:** add a mount harness (`src/main.tsx` + a demo/gallery page) **or** generate
Storybook stories (`/storybook`), then install a browser driver and screenshot each component at
the three viewports against the Figma frames.

---

## Token audit — DevTools-equivalent, static (zero tolerance)

Performed by grepping every component + `.variants.ts` file and vetting each utility class
against the token→utility map in `tailwind.config.js`.

| Check | Result |
|---|---|
| Hardcoded hex (`#rrggbb`) in components | ✓ none |
| `rgb()` / `hsl()` literals | ✓ none |
| Inline `style={{}}` for DS values | ✓ none |
| Hardcoded `px` | ✓ only `1px` borders (`callout`, `header`) — allowed exception |
| Every **color** utility → token var | ✓ all map to `var(--…)` via `tailwind.config.js` |
| Every **radius / font-size / line-height / weight / opacity** utility → token var | ✓ |
| Every **spacing / sizing** utility → token var | ✓ **D1, D2 resolved** — see below |

**Root cause of the 2 leaks:** `tailwind.config.js` uses `theme.extend`, which *merges* with
Tailwind's built-in scales. Only the explicitly-mapped keys (`spacing: 0,1,1.5,2,2.5,3,4,5`)
resolve to `var(--spacing-*)`. Any utility using an **unmapped** key silently falls back to
Tailwind's hardcoded default instead of a token.

---

## Resolved discrepancies

### D1 — Icon `large` size is now token-backed  · `src/components/ui/icon.variants.ts:13`
- **Root cause:** the leak existed because the initial token extraction was a *sampled subset* —
  it never captured `spacing/24`. The Figma file **does** define it (`Primitive / Spacing →
  spacing/24 = 24px`, confirmed live via the Desktop Bridge).
- **Fix applied:** added `--spacing-24: 24px` to `src/styles/tokens.css` (sourced from Figma) and
  mapped Tailwind spacing key `6 → var(--spacing-24)` in `tailwind.config.js`. `large: 'h-6 w-6'`
  now resolves to the token — no value invented. **Status: RESOLVED.**

### D2 — Callout icon `mt-0.5` optical nudge removed · `src/components/modules/Callout.tsx:32`
- `mt-0.5` (2px) had no backing token — the smallest Figma spacing token is `spacing/4` (4px), so
  a 2px value is genuinely off the design grid.
- **Fix applied:** removed the magic nudge; the icon aligns via the Callout's flex layout. No
  off-grid value remains. **Status: RESOLVED.**

> Note — separate token-accuracy issue (not a verify blocker): the sampled extraction also wrote
> `--spacing-6: 7px` and `--spacing-12: 13px`, but Figma defines `spacing/6 = 6px` and
> `spacing/12 = 12px` (the 7/13 values are button paddings that were mislabeled). A full
> `/extract-design-system` re-run via the Desktop Bridge would correct these and add the ~85 other
> tokens the sampling missed. Left as-is here to avoid changing the already-verified Button pilot.

---

## Observations (non-blocking)

- **O1 — `font-mono` in CodeBlock** (`code-block.variants.ts:8`). No monospace family token exists
  in the set; this is a **documented intentional exception** (monospace is required for code and
  has no Figma token). Recorded, not a violation.
- **O2 — Interactive links have no tokenized focus ring.** `Logo` (`<a>`) and `Text` (`<a>`) rely
  on the browser's default focus outline; only `Button` defines a custom `focus-visible:ring-2
  ring-primary ring-offset-2`. UA default keeps them keyboard-accessible, but focus styling is
  inconsistent with `Button`. Consider a shared tokenized focus-ring utility.

---

## Passing dimensions (source-verified, all 11)

**Semantic HTML** ✓ — `Button`→`button`, `Logo`/`Text`→`a`, `Paragraph`→`p`, `CodeBlock`→`figure`,
`PageTitle`/`Header`→`header`, `Title`→dynamic `h1–h6` inside a layout wrapper, `Icon`→`svg`
(role/aria-label ↔ aria-hidden switch), `Callout`→`div[role]`, `IconWrapper`→`div`.

**ARIA** ✓ — `aria-disabled` on disabled Button; iconOnly Button warns without `aria-label`;
Icon toggles `role="img"`+`aria-label` vs `aria-hidden`; Callout has `role`; Logo/Header/Text
carry appropriate `aria-label`/`aria-hidden`.

**Variant & state wiring vs spec** ✓ — Button verified 1:1 against `button-component-spec.md`:
10 variants, 3 sizes (padding/radius tokens match the spec table exactly — 8/4, 13/7, 16/8),
outline + iconOnly, and all 5 declared states (default/hover/focus/active/disabled).
No spec declares a `loading`/`aria-busy` state, so its absence is correct (not a gap).

**Architecture** ✓ — every component uses CVA in a separate `.variants.ts`, `cn()` merge,
`forwardRef`, and `className` merged last for layout overrides.

---

## Gate

**Token-purity dimensions: PASSED** — D1 and D2 are resolved token-pure (D1 via the real Figma
`spacing/24` token; D2 by removing an off-grid nudge). No hardcoded or unmapped spacing values remain.

**Runtime dimensions (live-viewport pixel + axe): still not executable** in this environment — no
render harness / browser driver. These remain the only open items before the gate is fully green.
To close them: add a mount harness or run `/storybook`, install a browser driver, then screenshot
each component at 375 / 768 / 1440px against the Figma frames and run axe-core.
