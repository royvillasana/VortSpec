# Logo — Usage / Composition Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./logo-component-spec.md

Atoms have no page of their own; this documents how Logo composes into higher-order components and screens.

---

### Consumed By

| Consumer | Usage |
|---|---|
| `Header` (organism) | Brand mark at the top-left, links home (`href="/"`) |
| `Cover` (organism) | Large brand mark in the hero |
| Screens | Footer / masthead brand mark |

---

### Composition Rules

- Choose `size` from the heading scale to match the surface (large in Cover, small/medium in Header).
- Layout (margin, alignment) is applied via `className`, never color overrides.
- Provide `href="/"` in navigation contexts (Header) so the logo links home; omit it where the logo is purely decorative branding.
- Toggle `withWordmark` per context — mark-only in tight bars, mark + wordmark where space allows.

---

### Accessibility

- The root `aria-label` is the accessible name; the svg mark stays `aria-hidden`.
- In the Header, the linked logo has one clear focus ring and a home destination.
- Do not add a redundant adjacent text link that duplicates the logo's label.

---

### Implementation Tasks

- [x] Verify Logo renders in Header with home link + focus ring
- [x] Verify large size composes correctly in Cover
- [x] Verify wordmark toggle across contexts
