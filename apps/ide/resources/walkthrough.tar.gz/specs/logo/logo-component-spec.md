# Logo — Component Spec

**Version**: 1.0
**Status**: Implemented
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Frame URL**: Cover / Header page
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Brand / product mark: an SVG glyph in the brand color, optionally paired with a wordmark, sized off the heading type scale. Because the mark is `1em`, it tracks the chosen font-size token — used in the Cover and the Header, and links home when given `href`.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--theme-primary` | `#087990` | `color` / `fill` (mark) |
| `--primitive-neutral-white` | `#ffffff` | `fill` (inner path of mark) |
| `--font-family-base` | Roboto | `font-family` (wordmark) |
| `--font-size-h6` | `16px` | `font-size` (small) |
| `--font-size-h5` | `20px` | `font-size` (medium) |
| `--font-size-h3` | `28px` | `font-size` (large) |
| `--line-height-heading` | `1.2` | `line-height` (wordmark) |

The SVG mark is `1em`, so it scales with the active font-size token. All references are via the Tailwind theme mapping in `tailwind.config.js`, which resolves to these CSS variables. No hardcoded values.

---

### Variants

Logo has a single brand appearance; composition is controlled by `withWordmark` rather than color variants.

| Variant | Description |
|---|---|
| mark only | SVG glyph alone (`withWordmark={false}`) |
| mark + wordmark | Glyph followed by the wordmark text (`withWordmark`) |

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | Base brand appearance | — |
| `focus` (link) | Focus ring on the anchor | Keyboard focus, when `href` is set |

Logo has no hover/active color states; when rendered as a link the anchor supplies the focus ring.

---

### Sizes

`size` sets the font-size token; the mark is `1em` and scales with it.

| Size | Font | Token |
|---|---|---|
| `small` | h6 (16px) | `--font-size-h6` |
| `medium` | h5 (20px) | `--font-size-h5` |
| `large` | h3 (28px) | `--font-size-h3` |

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `size` | `small \| medium \| large` | `medium` | Font-size scale; the `1em` mark tracks it |
| `label` | `string` | `"Design Engineering System"` | Accessible name on the root |
| `withWordmark` | `boolean` | `false` | Render the wordmark text next to the mark |
| `wordmark` | `string` | `"DE System"` | Wordmark text |
| `href` | `string` | — | When set, renders `<a href>` (else non-link root) |
| `className` | `string` | — | Layout overrides only, merged last |
| `...props` | `HTMLAttributes` | — | Native root attributes spread |

---

### Content Rules

- Keep the wordmark short (product name); default is "DE System".
- The mark always paints in `--theme-primary` with a white inner path — do not recolor.
- Size is chosen from the heading scale to sit correctly in Cover/Header, not with raw pixels.

---

### Accessibility

- Root carries `aria-label` (defaults to "Design Engineering System").
- The decorative SVG mark is `aria-hidden="true"` — the root label names the logo.
- When `href` is set, the root is an `<a>` with a visible focus ring, never removed.

---

### Do Not

- Do not hardcode colors or font sizes — reference tokens via Tailwind theme.
- Do not recolor the mark or its white inner path.
- Do not render the SVG without the root `aria-label`.
- Do not remove the focus ring on the linked variant.

---

### Implementation Tasks

- [x] Create `src/components/ui/logo.variants.ts` (CVA size)
- [x] Create `src/components/ui/Logo.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Implement `small` / `medium` / `large` sizes via heading font tokens
- [x] Render `1em` SVG mark in `text-primary` with white inner path
- [x] Implement `withWordmark` + `wordmark` text
- [x] Render `<a>` when `href` is present, with focus ring
- [x] Wire root `aria-label` (default) + `aria-hidden` on the svg
- [x] Unit test render, size class, wordmark toggle, link vs non-link
