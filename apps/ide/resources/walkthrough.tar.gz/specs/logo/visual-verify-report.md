# Visual Verify Report — Logo

- **Component**: Logo
- **Source / Branch**: figma / Branch A (codified authoritative Figma design in `specs/logo/`)
- **Date**: 2026-07-07
- **Skill**: /visual-verify
- **Files verified**: `src/components/ui/Logo.tsx`, `src/components/ui/logo.variants.ts`

> **Render limitation**: No browser/screenshot tool is available in this environment.
> Verification is SOURCE-OF-TRUTH: code + token-mapping vs spec plus static analysis.
> No pixel screenshots were captured; no rendered-pixel claims are made. Utility→token
> resolution was confirmed against `tailwind.config.js` and `src/styles/tokens.css`.

---

## Checklist

### Variants
| Check | Result | Notes |
|---|---|---|
| `withWordmark` default matches spec (`false`) | ✓ | `Logo.tsx` default `withWordmark = false` |
| mark-only variant renders glyph alone | ✓ | wordmark `<span>` gated on `withWordmark` |
| mark + wordmark variant renders wordmark text | ✓ | `{withWordmark && <span>{wordmark}</span>}` |
| No color variants (single brand appearance) | ✓ | CVA exposes only `size` |

### Sizes (font-size tokens; mark is 1em)
| Check | Result | Notes |
|---|---|---|
| `small` → h6 (16px) | ✓ | `text-h6` → `--font-size-h6` |
| `medium` → h5 (20px), default | ✓ | `text-h5` → `--font-size-h5`; `defaultVariants.size = 'medium'` |
| `large` → h3 (28px) | ✓ | `text-h3` → `--font-size-h3` |
| Mark is `1em` and tracks font-size | ✓ | svg `h-[1em] w-[1em]` (relative unit, allowed) |

### States
| Check | Result | Notes |
|---|---|---|
| Linked variant has focus ring | ✓ | `focus-visible:ring-2 ring-primary ring-offset-2` + `outline-none` |
| Focus ring at contrast (`ring-primary`) | ✓ | `ring-primary` → `--theme-primary` (#087990) |
| No hover/active color states | ✓ | none defined (matches spec) |
| Non-link variant inert | ✓ | renders `<span>`, no handlers |

### Colors → tokens
| Check | Result | Notes |
|---|---|---|
| Mark paints `--theme-primary` | ✓ | `text-primary` + svg `fill-current` |
| Inner path white | ✓ | `fill-white` → `--primitive-neutral-white` |
| Wordmark inherits primary | ✓ | inherits `text-primary` from root |

### Radius / shadow / font
| Check | Result | Notes |
|---|---|---|
| Radius via token | ✓ | `rounded-sm` → `--radius-4` |
| Font family via token | ✓ | `font-base` → `--font-family-base` |
| Font weight via token | ✓ | `font-regular` → `--font-weight-regular` |
| Line-height via token | ✓ | `leading-heading` → `--line-height-heading` |
| Gap via token | ✓ | `gap-2` → `--spacing-8` |
| No shadow required | ✓ | none in spec |

### Accessibility
| Check | Result | Notes |
|---|---|---|
| Root carries `aria-label` (default) | ✓ | default `"Design Engineering System"` |
| Decorative svg `aria-hidden` | ✓ | `aria-hidden` on `<svg>` |
| Linked root is `<a>` with focus ring | ✓ | focus-visible ring never removed |
| Non-link root exposes accessible name | ✓ (fixed) | added `role="img"` so `aria-label` is exposed on the generic `<span>` |

### Responsive (375 / 768 / 1440)
| Check | Result | Notes |
|---|---|---|
| Fixed size token per `size`; mark tracks font-size | ✓ | no viewport-conditional styling; consumer swaps `size` via props/`className` |
| Wordmark can wrap per consumer `className` | ✓ | base `whitespace-nowrap` overridable via `cn()` (tailwind-merge, className last) |

### Token Audit
`grep -nE '#[0-9a-fA-F]{3,8}|rgb\(|hsl\(|style=\{\{|\[[0-9]+px\]'` on both files → **empty** (✓). Only `[1em]` relative units on the svg, which are permitted (scale with the font-size token).

---

## Discrepancies
| # | Severity | Description | Resolution |
|---|---|---|---|
| 1 | Minor (a11y) | Non-link root was a bare `<span>`; `aria-label` on a generic role may not be exposed by AT, leaving the logo with no accessible name (svg is `aria-hidden`). | Fixed inline: `role={href ? undefined : 'img'}` on the root. |

---

**Result: PASS** (1 minor a11y discrepancy fixed inline; token audit clean; `tsc --noEmit` exits 0)
