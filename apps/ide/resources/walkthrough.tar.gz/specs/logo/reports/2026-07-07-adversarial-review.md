# Adversarial Review — Logo

- **Date**: 2026-07-07
- **Skill**: /adversarial-review
- **Component**: Logo (atom)
- **Files**: `src/components/ui/Logo.tsx`, `src/components/ui/logo.variants.ts`
- **Reference**: `specs/logo/` (component / interaction / page specs) — authoritative codified Figma design
- **Render limitation**: No browser/screenshot tool available; review is source-of-truth (code + token mapping vs spec) plus static analysis.

## Verdict

**PASS** — No Blocker findings. The linked variant carries a focus-visible ring (would be a Blocker if missing), all values resolve to tokens, and the architecture checklist passes. One Minor accessibility finding was resolved inline during review.

## Findings

| # | Severity | Area | Finding | Status |
|---|---|---|---|---|
| 1 | Minor | Accessibility | Non-link root rendered as a bare `<span>` (generic role); `aria-label` on a name-prohibited role may not be surfaced by assistive tech, and the svg is `aria-hidden`, so the mark-only/non-link logo could have no accessible name. | Resolved inline (`role="img"` on non-link root) |
| 2 | Info | Interaction / responsive | Base class includes `whitespace-nowrap`; interaction spec allows wordmark wrapping "per `className`". Verified `cn()` (tailwind-merge) lets a consumer override with `whitespace-normal` since `className` is merged last. | No action |
| 3 | Info | Focus ring | `ring-offset-2` uses Tailwind's built-in ring-offset scale (2px), part of the standard focus-ring utility (not a DS color/space value; `ring-offset` has no token mapping in the theme). Consistent with other atoms. | No action |

### Adversarial probes run
- **Variant coverage**: `size` (small/medium/large) + `withWordmark` toggle — all present; `defaultVariants.size = 'medium'` matches spec default; `withWordmark` default `false` matches spec.
- **State coverage**: focus-visible ring on linked variant present (`focus-visible:ring-2 ring-primary ring-offset-2 outline-none`). Non-link variant inert — confirmed. No spurious hover/active states (spec forbids color-shift states).
- **Token audit**: grep for hex/rgb/hsl/inline-style/`[Npx]` on both files → empty. Only `[1em]` relative svg sizing (permitted). All colors/spacing/radius/font resolve to `var(--token)` via `tailwind.config.js`.
- **Accessibility adversarial**: root `aria-label` (default fallback verified), svg `aria-hidden`, linked root is a real `<a href>` exposing its name; non-link name-exposure gap fixed (finding #1).
- **Responsive (375/768/1440)**: no viewport-locked styling; size is token-driven and consumer-swappable; wordmark wrap overridable.
- **Interaction-spec compliance**: navigation via native `<a>` on click/Enter; focus-visible only; non-link inert; `1em` mark tracking; default `label` fallback — all satisfied.

## Resolved During Review
- **Finding #1** — Added `role={href ? undefined : 'img'}` to the root in `Logo.tsx` so the non-link variant's `aria-label` is reliably exposed as the accessible name, while the linked variant keeps its native `<a>` semantics. Re-ran `npx tsc --noEmit` → exit 0; token-audit grep → still empty.

## Architecture Validation Checklist

| Item | Result | Evidence |
|---|---|---|
| CVA used for variants (separate `.variants.ts`) | ✓ | `logo.variants.ts` uses `cva()` |
| `defaultVariants` match spec | ✓ | `size: 'medium'` = spec default |
| `forwardRef` used | ✓ | `React.forwardRef<HTMLElement, LogoProps>` |
| Spreads native props | ✓ | `{...props}` on root |
| `className` merged last via `cn()` | ✓ | `cn(logoVariants({ size }), className)` |
| `VariantProps` type exported | ✓ | `export type LogoVariants = VariantProps<typeof logoVariants>` |
| No inline `style` for DS values | ✓ | none present |
| `displayName` set | ✓ | `Logo.displayName = 'Logo'` |
| Token-referenced output (no hardcoded values) | ✓ | audit grep empty |
| Type-checks clean | ✓ | `npx tsc --noEmit` exit 0 |
