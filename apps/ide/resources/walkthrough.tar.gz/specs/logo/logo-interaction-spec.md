# Logo — Interaction Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./logo-component-spec.md
**Figma prototype**: Cover / Header page — link State property (normal, focus)

---

### Interaction Overview

Logo is presentational by default. When given `href` it becomes a home link: the user focuses or clicks the anchor and navigates. There are no color-shift hover states — only the anchor focus ring.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Click / tap | Logo (link) | `href` set |
| `Enter` | Anchor (native) | Focus on the logo link |
| Focus | Anchor | Keyboard focus, when `href` set |

---

### Flow

```
Step 1: Logo renders the 1em brand mark (+ optional wordmark) at the size token scale.
Step 2: [Link] Keyboard focus → focus ring on the anchor (focus-visible only).
Step 3: [Link] Click / Enter → navigation to href.
Step 4: [Non-link] No pointer or keyboard event is handled; Logo is inert.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Focus ring (link) | instant | — | `focus-visible:ring-2` |

Logo defines no color transitions; the mark color is static (`--theme-primary`).

---

### Animation Details

None. The mark is a static SVG; only the focus ring appears on keyboard focus.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| No `href` | Renders as a non-interactive labeled mark |
| `withWordmark={false}` | Mark renders alone; root `aria-label` still names it |
| Missing `label` | Falls back to default "Design Engineering System" |
| Very small container | Mark + wordmark keep proportion (mark is `1em`); wordmark may wrap per `className` |

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Fixed size token per `size`; mark tracks font-size. Consumer may swap `size` per breakpoint via `className`/props |

---

### Implementation Tasks

- [x] `focus-visible` ring on the linked variant
- [x] Non-link variant inert to interaction
- [x] Navigation fires on click / Enter when `href` set
- [x] Verify mark scales with font-size token (`1em`)
- [x] Verify default `label` fallback
