# PageTitle — Usage / Composition Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./page-title-component-spec.md

Molecules have no page of their own; this documents how PageTitle composes into higher-order components and screens.

---

### Consumed By

| Consumer | Usage |
|---|---|
| Documentation screens | Top-of-page header block (the `<h1>` region) |
| Feature/landing templates | Primary heading with eyebrow + description |
| `Header` (organism) | Optional in-page section header |

---

### Composition Rules

- Place exactly one `PageTitle` per page, at the top of the `<main>` content.
- Use `align="center"` for hero-style pages, `align="left"` for docs body pages.
- Page width, max-width, and vertical rhythm are applied via `className` on the consumer side.
- Compose the `description` slot with plain text; the component wraps it in a muted `Paragraph`.

---

### Accessibility

- Guarantees a single `h1` per page — do not add another top-level heading.
- Subsequent section headings on the page should use `Title level={2..6}`.

---

### Implementation Tasks

- [x] Verify PageTitle renders as the page's only `<h1>`
- [x] Verify eyebrow + description compose correctly inside a screen header
- [x] Verify left vs center alignment in a page layout
