# PageTitle — Component Spec

**Version**: 1.0
**Status**: Implemented
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Large primary heading block for the top of a documentation page body — an optional eyebrow overline, the page `<h1>`, and an optional supporting description, rendered as a semantic `<header>`.

---

### Composed Atoms

| Atom | Role |
|---|---|
| `Paragraph` | Renders the `description` with `tone="muted"` |
| Overline text | Eyebrow `<span>` styled with the `text-h6` uppercase + muted tokens |
| Heading typography | Page `<h1>` styled with the `text-h1` token |

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--font-family-base` | Roboto | `font-family` (`font-base`) |
| `--font-size-h1` | `40px` | `font-size` (title `<h1>`, `text-h1`) |
| `--font-size-h6` | `16px` | `font-size` (eyebrow, `text-h6`) |
| `--font-weight-regular` | `400` | `font-weight` (`font-regular`) |
| `--line-height-heading` | `1.2` | `line-height` (title, `leading-heading`) |
| `--line-height-body` | `1.5` | `line-height` (eyebrow, `leading-body`) |
| `--color-text-default` | `#212529` | `color` (title, `text-text`) |
| `--color-text-muted` | `#6c757d` | `color` (eyebrow + description, `text-muted`) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js` to these CSS variables. No hardcoded values.

---

### Variants

`PageTitle` has a single visual variant governed by the `align` prop.

| `align` | Description |
|---|---|
| `left` (default) | Left-aligned header block |
| `center` | Center-aligned header block |

---

### States

`PageTitle` is a static presentational molecule — no interactive states.

| State | Visual Change | Trigger |
|---|---|---|
| `default` | Base appearance | — |

---

### Sizes

Fixed type scale: the title always uses `text-h1` and the eyebrow always `text-h6`. No size prop.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `eyebrow` | `ReactNode` | — | Small uppercase overline above the title (`text-h6` muted) |
| `children` | `ReactNode` | — | Title text, rendered as `<h1>` |
| `description` | `ReactNode` | — | Supporting text below the title, via `Paragraph tone="muted"` |
| `align` | `"left" \| "center"` | `"left"` | Horizontal alignment of the block |
| `className` | `string` | — | Layout overrides only, merged last |
| `...props` | `HTMLAttributes<HTMLElement>` | — | Native attributes spread onto `<header>` |

---

### Content Rules

- Eyebrow: 1–3 words, rendered uppercase; describes the page category/section.
- Title: the page name — sentence case, no trailing period.
- Description: one or two sentences of supporting context; keep it scannable.

---

### Accessibility

- Renders a landmark `<header>` wrapping exactly one `<h1>` — the page's top-level heading.
- Only one `PageTitle` (and therefore one `<h1>`) per page.
- Eyebrow and description are siblings of the heading, announced as separate text.

---

### Do Not

- Do not hardcode colors, spacing, or type sizes — reference tokens via Tailwind theme.
- Do not render more than one `PageTitle` per page (would create multiple `h1`s).
- Do not put the eyebrow text inside the `<h1>` — keep it a separate overline.

---

### Implementation Tasks

- [x] Create `src/components/modules/page-title.variants.ts` (CVA: `pageTitleVariants` with `align`)
- [x] Create `src/components/modules/PageTitle.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Render `<header>` landmark wrapping a single `<h1>` (`text-h1`)
- [x] Implement `eyebrow` overline (`text-h6` uppercase muted)
- [x] Compose `Paragraph tone="muted"` for `description`
- [x] Implement `align` left/center
- [x] Verify single `h1` semantics + token-only styling
