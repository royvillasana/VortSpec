# PageTitle — Interaction Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./page-title-component-spec.md
**Figma prototype**: Page headers — static (no prototype states)

---

### Interaction Overview

`PageTitle` is a static presentational molecule. It renders a page header block (eyebrow + `<h1>` + description) and exposes no user interactions of its own.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| — | — | No native interactions; renders statically |

---

### Flow

```
Step 1: Component mounts → <header> renders with alignment from `align`.
Step 2: If eyebrow is provided → uppercase muted overline renders above the title.
Step 3: The <h1> title (children) renders in text-h1.
Step 4: If description is provided → a muted Paragraph renders below the title.
Step 5: No state changes occur after mount; the component is fully declarative.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| — | — | — | No transitions (static molecule) |

---

### Animation Details

None. `PageTitle` renders no animations or transitions.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| No `eyebrow` | Overline span is not rendered |
| No `description` | Paragraph is not rendered |
| `align="center"` | Whole block centers; text alignment follows |
| Long title | Wraps at `leading-heading` (1.2), alignment preserved |

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Block fills its container width; `text-h1` size is fixed. Consumer controls max-width and page padding via `className`. |

---

### Implementation Tasks

- [x] Render `<header>` with alignment classes
- [x] Conditionally render eyebrow and description
- [x] Confirm no transitions/animations are introduced
- [x] Verify layout at 375 / 768 / 1440
