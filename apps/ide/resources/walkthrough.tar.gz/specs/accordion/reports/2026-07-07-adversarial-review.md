# Adversarial Review — Accordion

Date: 2026-07-07

## Verdict: PASS

## Findings

| Severity | Area | Issue | Status |
|---|---|---|---|
| — | Token audit | grep clean; all color/spacing/radius/stroke resolve to `var(--...)` | Pass |
| — | A11y / semantics | Native `<details>`/`<summary>` supplies button role, expanded state, Enter/Space toggle — no manual ARIA needed | Pass |
| — | A11y / disabled | Disabled panel is a non-focusable `<div>` (no `<details>`, no tabindex) so it cannot toggle by mouse or keyboard; `aria-disabled="true"` per spec | Pass |
| — | Focus | Visible inset `ring-primary` focus ring, never removed | Pass |
| — | Spec parity | `allowMultiple` behavior, 2 CVAs, defaults mirror spec 1:1 | Pass |

No Blocker or Major findings.

## Architecture Validation (8 checks)
1. `.variants.ts` colocated — yes (`accordion.variants.ts`)
2. CVA variants mirror spec 1:1 — yes (`accordionSummaryVariants` disabled bool + `accordionBodyVariants`)
3. defaultVariants match spec — yes (`disabled: false`)
4. forwardRef — yes (`HTMLDivElement`)
5. `...props` spread on root — yes (on container `<div>`)
6. `className` merged LAST via `cn()` — yes
7. VariantProps exported — yes (`AccordionSummaryVariants` / `AccordionVariants`)
8. no inline `style={{}}` for DS values — yes

## Token / Variant / State / A11y Checklist
- Tokens: all utilities resolve to `var(--...)`; structural/animation utilities
  (`list-none`, `transition-transform`, `[&::-webkit-details-marker]:hidden`) are not DS values.
- Variants/behavior: `allowMultiple` true/false (exclusive via shared `name`) present.
- States: collapsed / expanded / hover / focus / disabled — all present.
- A11y: native button semantics + expanded state; Enter/Space keyboard toggle;
  disabled row non-focusable + `aria-disabled`; chevron `aria-hidden`; visible focus ring.

## Resolved During Review
None — no defects found; no edits made.

## Notes
No Storybook story exists for Accordion, so runtime pixel-diff and axe were not
executable — verified from source (spec ↔ code ↔ token model). The native
`<details>`/`<summary>` approach means `aria-expanded`/`aria-controls` are exposed
implicitly by the browser; explicit attributes are intentionally omitted. Contrast
assessed from token pairings, not a runtime axe pass.
