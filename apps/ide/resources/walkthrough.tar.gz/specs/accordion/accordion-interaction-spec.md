# Accordion — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./accordion-component-spec.md
**Figma prototype**: Accordion page — expanded/collapsed × states

---

### Interaction Overview

`Accordion` renders a stack of collapsible panels using native
`<details>`/`<summary>`. Toggling is handled entirely by the browser — no React
state — so mouse, keyboard, and assistive tech all work out of the box. The only
scripted concern is the chevron rotation, which is a pure CSS transition driven by
the `group-open:` variant.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Click / tap | `<summary>` | Panel not disabled |
| `Enter` | Focused `<summary>` | Panel not disabled |
| `Space` | Focused `<summary>` | Panel not disabled |

Disabled panels render as a non-interactive row and receive none of these triggers.

---

### Flow

```
Step 1: Component mounts → each panel renders collapsed, unless item.defaultOpen sets it open.
Step 2: User activates a summary (click / Enter / Space) → native <details> toggles its open state.
Step 3: On open → the body region reveals below the summary and the chevron rotates 180° (transition-transform, group-open:rotate-180).
Step 4: On close → body hides, chevron rotates back to 0°.
Step 5: If allowMultiple is false → opening one panel closes the previously open sibling (shared name attribute).
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Chevron rotate | Tailwind default (150ms) | Tailwind default ease | `transition-transform` + `group-open:rotate-180` |
| Panel reveal | Native (instant) | — | Browser default `<details>` disclosure |

---

### Animation Details

- The chevron rotates 180° between collapsed and expanded via `transition-transform`.
  The rotation is bound to the open state through the `group` class on `<details>`
  and the `group-open:rotate-180` utility on the Icon.
- No custom height animation is applied; the panel reveal uses the browser's native
  `<details>` behavior for reliability and accessibility.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| `defaultOpen: true` | Panel renders expanded on mount (native `open` attribute) |
| `disabled: true` | Row is dimmed and non-interactive; cannot toggle by mouse or keyboard |
| `allowMultiple: false` | Exclusive — only one panel open at a time via shared `name` |
| `allowMultiple: true` (default) | Any number of panels open at once |
| Long `content` | Body wraps and grows; padding/gap preserved |
| Empty `items` | Container renders with no rows |

---

### Accessibility & Keyboard

| Key | Action |
|---|---|
| `Tab` | Move focus to the next enabled summary |
| `Shift+Tab` | Move focus to the previous enabled summary |
| `Enter` / `Space` | Toggle the focused panel |

- Native `<summary>` exposes button role and expanded state to assistive tech automatically.
- Focus is always visible via the inset `primary` ring.
- The chevron is `aria-hidden`; disabled rows are marked `aria-disabled="true"` and skipped in the tab order.

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Container fills its width; padding, gap, radius, and dividers fixed by token. Titles and bodies reflow as width changes. |

---

### Implementation Tasks

- [x] Render panels as native `<details>`/`<summary>` (no JS toggle state)
- [x] Wire click / Enter / Space toggling via native behavior
- [x] Rotate chevron 180° on open with `transition-transform` + `group-open:`
- [x] Honor `defaultOpen` via the native `open` attribute
- [x] Support exclusive mode via shared `name` when `allowMultiple` is false
- [x] Make disabled panels non-interactive for mouse and keyboard
- [x] Confirm visible focus ring on the summary
