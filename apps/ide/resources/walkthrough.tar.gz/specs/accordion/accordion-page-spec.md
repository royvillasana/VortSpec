# Accordion — Usage / Composition Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./accordion-component-spec.md

Molecules have no page of their own; this documents how Accordion composes into
higher-order components and screens.

---

### Purpose

Provide progressive disclosure inside content-heavy regions — FAQs, grouped
settings, filter panels, and documentation sections — keeping screens scannable
by collapsing detail until the user asks for it.

---

### Component Inventory

| Component | Role |
|---|---|
| `Accordion` | Container that renders the stack of collapsible panels |
| `Icon` | Rotating `chevron-down` affordance in each summary row |

---

### Consumed By

| Consumer | Usage |
|---|---|
| FAQ / Help screens | Question as `title`, answer as `content` |
| Settings screens | Grouped preference sections |
| Documentation | Collapsible reference sections |

---

### Usage

```tsx
import { Accordion, type AccordionItem } from '@/components';

const faqs: AccordionItem[] = [
  { id: 'shipping', title: 'How long does shipping take?', content: '3–5 business days.', defaultOpen: true },
  { id: 'returns', title: 'What is the return policy?', content: '30-day free returns.' },
  { id: 'legacy', title: 'Deprecated plan', content: 'No longer available.', disabled: true },
];

// Multiple panels open at once (default)
<Accordion items={faqs} className="max-w-2xl" />

// Exclusive — only one panel open at a time
<Accordion items={faqs} allowMultiple={false} />
```

---

### Composition Rules

- Keep `title` short and scannable; put the detail in `content`.
- Layout (margin, `max-width`, placement) is applied via `className`; the
  container owns its internal padding, dividers, and gaps.
- Choose `allowMultiple={false}` when only one panel should be open at a time.
- Reserve `disabled` for panels that are contextually unavailable.

---

### Responsive

| Viewport | Behavior |
|---|---|
| 375 / 768 / 1440 | Container fills width; padding, gap, radius, and dividers fixed by token; titles and bodies reflow. |

---

### Accessibility

- Native `<details>`/`<summary>` supplies button semantics, expanded state, and
  keyboard toggling — do not override with custom handlers.
- Ensure a visible focus ring on every enabled summary.
- The chevron is decorative; the title carries meaning.

---

### Implementation Tasks

- [x] Verify Accordion composes into FAQ/settings prose with correct spacing
- [x] Verify `allowMultiple` toggles between multi-open and exclusive behavior
- [x] Verify `defaultOpen` and `disabled` items render correctly
- [x] Verify keyboard toggling and visible focus ring
