# Visual Verify Report — Accordion

- **Component**: Accordion (`src/components/modules/Accordion.tsx`, `src/components/modules/accordion.variants.ts`)
- **Design source**: Figma (`ojko9pGfsDAvmUf2DA38d2`)
- **Date**: 2026-07-07
- **Rendered live?**: No — no Storybook story exists for Accordion. Verification is
  SOURCE-OF-TRUTH only (spec ↔ code ↔ token model). Runtime pixel/axe checks are
  **not executable — verified from source**, not failed.

## Method
Static verification of the `.tsx` + `.variants.ts` against the Component Spec,
Interaction Spec, and the Tailwind→CSS-var token map, with focus on the interactive
disclosure semantics.

## Checklist Results

### Variants / Behavior (checked)
- `allowMultiple` (default true): panels independent. When false, all `<details>`
  share `name={groupName}` (`React.useId()`) for native exclusive behavior. Matches spec.
- Two CVAs: `accordionSummaryVariants` (disabled true/false) + `accordionBodyVariants`.
  `defaultVariants.disabled = false` — matches spec.

### States (from source)
- collapsed / expanded: native `<details>`; chevron `group-open:rotate-180`. OK
- hover: `hover:bg-neutral-100` on summary. OK
- focus: `focus-visible:ring-2 ring-primary ring-inset`. OK
- disabled: `opacity-disabled pointer-events-none`, rendered as a plain `<div>` (no
  `<details>`), so it cannot toggle by mouse or keyboard. Matches spec exactly. OK

### Sizes (checked)
Single intrinsic size: `px-4 py-3` (16px / 12px), `gap-2` (8px), `rounded` (= `--radius-8`),
`border-1` (= `--stroke-width-1`), `divide-neutral-300`. All token-mapped.

### Token Audit (zero leaks)
grep returns nothing. Every color/spacing/radius/stroke utility resolves to `var(--...)`.
`[&::-webkit-details-marker]:hidden` is a structural pseudo-element selector (not a DS
value); `list-none` / `transition-transform` are structural/animation utilities — all
explicitly allowed by the spec. No hex/rgb/hsl, no arbitrary DS value, no inline style.

### Accessibility — interactive disclosure (from source)
- **Button semantics + expanded state**: provided natively by `<summary>` inside
  `<details>` — the browser exposes the button role and the open/expanded state to AT
  automatically. No explicit `aria-expanded`/`aria-controls` needed (and adding them to a
  native summary is discouraged). Correct approach per spec. OK
- **Keyboard**: native `<summary>` toggles on Enter/Space; Tab/Shift+Tab move between
  enabled summaries. Disabled row is a non-focusable `<div>` (no tabindex) — correctly
  skipped in tab order. OK
- **Chevron**: `aria-hidden`, decorative. OK
- **Disabled**: `aria-disabled="true"` on the non-interactive row (per spec). OK
- **Focus ring**: visible inset primary ring, never removed. OK

### Architecture (8/8)
`.variants.ts` colocated · CVAs mirror spec · defaultVariants match · forwardRef
(`HTMLDivElement`) · `...props` spread on root `<div>` · `className` merged LAST via
`cn()` · `AccordionSummaryVariants`/`AccordionVariants` exported · no inline `style={{}}`.

### Interaction Spec (checked)
Click/Enter/Space toggle (native, non-disabled only); chevron rotate via
`transition-transform` + `group-open:`; `defaultOpen` honored via native `open`;
exclusive mode via shared `name`; disabled non-interactive; empty `items` renders empty
container. All satisfied.

## Discrepancies
None. (The `aria-disabled` on a non-interactive `<div>` is spec-mandated behavior, not a
defect; kept as specified.)

## Gate: PASS (zero unresolved discrepancies)
