# Accordion — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

A stack of collapsible panels for progressively disclosing content — FAQs,
grouped settings, and long-form sections. Each panel shows an always-visible
title row that expands to reveal its body. Built on the native
`<details>`/`<summary>` elements so button semantics, expanded state, and
keyboard toggling come for free with no JavaScript state.

---

### Composed Atoms

| Atom | Role |
|---|---|
| `Icon` | Trailing `chevron-down` glyph that rotates 180° when the panel is open (decorative, `aria-hidden`) |
| Inline text | `title` in the summary row + `content` in the panel body |

---

### Design Tokens Used

| Token | Utility | CSS Property |
|---|---|---|
| `--color-neutral-300` | `border-neutral-300` / `divide-neutral-300` | `border-color` (container + row dividers) |
| `--color-neutral-100` | `hover:bg-neutral-100` | `background-color` (summary hover) |
| `--color-text-default` | `text-text` | `color` (title + body) |
| `--theme-primary` | `ring-primary` | `outline-color` (focus ring) |
| `--stroke-width-1` | `border-1` | `border-width` (container) |
| `--radius-8` | `rounded` | `border-radius` (container) |
| `--spacing-16` | `px-4` | `padding` inline (summary + body) |
| `--spacing-12` | `py-3` | `padding` block (summary + body) |
| `--spacing-8` | `gap-2` | `gap` (title ↔ chevron) |
| `--font-size-body` | `text-body` | `font-size` |
| `--line-height-body` | `leading-body` | `line-height` |
| `--opacity-disabled` | `opacity-disabled` | `opacity` (disabled panel) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js`.
No hardcoded values. `[&::-webkit-details-marker]:hidden`, `list-none`, and
`transition-transform` are structural/animation utilities, not design values.

---

### Variants

Behavior is controlled by `allowMultiple`, mirroring how many panels can be open
at once.

| `allowMultiple` | Behavior |
|---|---|
| `true` (default) | Any number of panels may be open simultaneously |
| `false` | Exclusive accordion — panels share a `name`, so opening one closes the others (native browser behavior) |

---

### States

Each panel is a native `<details>` and exposes standard disclosure states.

| State | Visual Change | Trigger |
|---|---|---|
| `collapsed` | Only the summary row shows; chevron points down | Default (unless `defaultOpen`) |
| `expanded` | Body reveals below the summary; chevron rotates 180° | Click / Enter / Space on summary, or `defaultOpen` |
| `hover` | Summary row background tints to `neutral-100` | Pointer over summary |
| `focus` | 2px inset `primary` ring on the summary | Keyboard focus |
| `disabled` | Row dimmed (`opacity-disabled`); non-interactive, cannot toggle | `item.disabled` |

---

### Sizes

Single intrinsic size. Padding (`px-4 py-3`), radius (`rounded`), gap (`gap-2`),
and dividers are fixed by token; panels grow with content and container width.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `items` | `AccordionItem[]` | — | Panels to render, top to bottom |
| `allowMultiple` | `boolean` | `true` | Allow multiple panels open; `false` = exclusive |
| `className` | `string` | — | Layout overrides only, merged last |
| `...props` | `HTMLAttributes<HTMLDivElement>` | — | Native div attributes spread |

**`AccordionItem`**

| Field | Type | Default | Description |
|---|---|---|---|
| `id` | `string` | — | Stable unique key |
| `title` | `ReactNode` | — | Summary-row header |
| `content` | `ReactNode` | — | Panel body, revealed when expanded |
| `defaultOpen` | `boolean` | `false` | Render expanded on mount |
| `disabled` | `boolean` | `false` | Non-interactive, dimmed, cannot toggle |

---

### Accessibility

- Native `<details>`/`<summary>` provides button semantics, the expanded/collapsed
  state, and Enter/Space keyboard toggling with no ARIA plumbing required.
- Visible focus ring on the summary (`focus-visible:ring-2 ring-primary ring-inset`).
- The chevron is decorative (`aria-hidden`); the title carries the meaning.
- Disabled panels render a non-interactive row marked `aria-disabled="true"` and
  are not focusable/toggleable by mouse or keyboard.

---

### Do Not

- Do not hardcode colors, spacing, radius, or stroke — reference tokens via Tailwind.
- Do not reimplement toggling with JS state — keep native `<details>` semantics.
- Do not remove the focus ring or the visible chevron affordance.
- Do not leave a disabled panel toggleable via the keyboard.

---

### Implementation Tasks

- [x] Create `src/components/modules/accordion.variants.ts` (CVA: `accordionSummaryVariants`, `accordionBodyVariants`)
- [x] Create `src/components/modules/Accordion.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Export `AccordionItem` and `AccordionProps` types
- [x] Render each panel as native `<details className="group">` with `open={defaultOpen}`
- [x] Summary row: title + rotating `chevron-down` Icon, marker hidden, focus ring
- [x] Support `allowMultiple` via shared `name` for exclusive accordion
- [x] Render disabled panels as a non-interactive dimmed row (no toggling)
- [x] Verify token-only styling and `tsc` passes
