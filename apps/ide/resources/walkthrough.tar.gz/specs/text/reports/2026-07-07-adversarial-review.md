# Adversarial Review — Text
Date: 2026-07-07
Skill: /adversarial-review · Component: Text (atom) · Source: figma (Branch A)
Impl: `src/components/ui/Text.tsx` + `src/components/ui/text.variants.ts`

## Verdict: PASS (2 findings resolved inline during review; 0 open Blockers)

Prior review (same date) flagged the missing focus ring as Major/Open; this pass resolves it and a
second unimplemented interaction-spec requirement, both inline in `text.variants.ts`.

## Findings

| # | Severity | Area | Issue | Status |
|---|----------|------|-------|--------|
| F-1 | Major | State coverage / a11y | `link` variant shipped **no token focus-visible ring**. Original classes: `text-primary underline-offset-4 hover:underline active:text-primary-hover cursor-pointer` (grep `focus` in both files = 0 hits). component-spec States + Accessibility declare "Focus ring on the anchor … never removed"; interaction-spec task marked `[x]` but unimplemented. Inconsistent with Logo/Button/Rating (`focus-visible:ring-2 ring-primary ring-offset-2`). Not a Blocker (native outline was never suppressed) but a real spec gap. | **Resolved** |
| F-2 | Minor | Interaction-spec compliance | `link` variant had **no transition**. interaction-spec Timing requires `transition-[color,text-decoration-color]` @150ms ease (task marked `[x]` but unimplemented). Underline/color change was instant vs. the specified 150ms. | **Resolved** |

### Adversarial checks that PASSED (no finding)
- **Variant coverage:** all 4 (primary/muted/link/bullet) present, distinct, token-backed; `bullet` auto-renders leading `dot` Icon.
- **Token audit:** zero `#hex`/`rgb(`/`hsl(`/`style={{`/`[Npx]` in either file; `text-muted` resolves via `colors.muted` alias; `underline-offset-4` is a decoration offset, not a leak.
- **A11y — link semantics:** `<a href>` when `href` set, else `<span>`; visible text is the accessible name.
- **A11y — icon labelling:** bullet dot is `aria-hidden`; leading/trailing icons are caller nodes the spec designates decorative (component cannot enforce — documented, acceptable).
- **Responsive:** single body scale, no breakpoint-dependent classes; matches spec (375/768/1440 unchanged).
- **State coverage:** hover (`hover:underline`), active (`active:text-primary-hover`), and now focus + transition all present; non-link variants inert.

### Observations (non-blocking, unchanged)
- **O-A** — `variant="link"` without `href` renders a non-navigable `<span>` styled as a link (spec anti-pattern the component permits). A DEV warning could harden this.
- **O-B** — `bullet` + manual `leadingIcon` renders a double marker (spec-documented anti-pattern).

## Resolved During Review
Both F-1 and F-2 fixed inline in `text.variants.ts` `link` variant (implements already-declared spec
requirements, so no spec change needed per the SDD Spec Update Rule):
```
link:
  'text-primary underline-offset-4 hover:underline active:text-primary-hover cursor-pointer rounded-sm ' +
  'transition-[color,text-decoration-color] duration-150 ease-out ' +
  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2',
```
`npx tsc --noEmit` → exit 0. No shared config/token/other-component files changed.

## Architecture Validation Checklist
- `.variants.ts` colocated: ✓ (`text.variants.ts`)
- CVA used; variants mirror spec 1:1: ✓ (primary/muted/link/bullet)
- `defaultVariants` match spec default: ✓ (`variant: 'primary'`)
- `forwardRef` used: ✓ (polymorphic `<a>`/`<span>`, ref forwarded)
- Native attrs spread via `...props`: ✓ (on `Comp` root)
- `className` merged LAST via `cn()`: ✓ (`cn(textVariants({ variant }), className)`)
- `VariantProps` exported: ✓ (`TextVariants`)
- No inline `style={{}}` for DS values: ✓

## Notes
Runtime dimensions (live responsive render, on-screen focus-ring visibility, axe, no-layout-shift on
underline) NOT executed — no browser driver. F-1/F-2 are static source findings, now closed.
