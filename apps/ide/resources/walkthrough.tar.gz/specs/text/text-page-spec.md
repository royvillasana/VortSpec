# Text — Usage / Composition Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./text-component-spec.md

Atoms have no page of their own; this documents how Text composes into higher-order components and screens.

---

### Consumed By

| Consumer | Usage |
|---|---|
| `Cover` (organism) | Inline links, contact lines, bulleted lists |
| `Header` (organism) | Nav link labels |
| Molecules | Metadata lines, inline links beside icons |
| Screens | Any single-line label, inline link, or list marker |

---

### Composition Rules

- Text owns the icon ↔ label gap (`--spacing-8`); consumers pass only layout via `className`.
- Use `link` + `href` for navigation; use `primary`/`muted` for static labels.
- Use `bullet` for list items — do not hand-place a dot Icon.
- Pair with Paragraph for multi-line copy; never stack Text nodes to fake paragraphs.

---

### Accessibility

- Link text is descriptive (no "click here"); the visible text is the accessible name.
- Leading/trailing icons stay decorative (`aria-hidden`).
- One clear focus ring per link; never removed.

---

### Implementation Tasks

- [x] Verify Text links render inside Cover/Header with correct spacing
- [x] Verify icon slots align on the body line
- [x] Verify bullet list composition uses the built-in dot
