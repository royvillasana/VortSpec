# Text — Interaction Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./text-component-spec.md
**Figma prototype**: Typography page — link State property (normal, hovered, active)

---

### Interaction Overview

Only the `link` variant is interactive: the user hovers or focuses the anchor and it underlines, then shifts color on press and fires navigation. `primary`, `muted`, and `bullet` are static text.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Hover | Text (link variant) | Variant is `link` |
| Click / tap | Text (link variant) | `href` set |
| `Enter` | Anchor (native) | Focus on the link |
| Focus | Anchor | Keyboard focus, link variant |

---

### Flow

```
Step 1: Pointer enters a link → underline appears (150ms ease color/text-decoration transition).
Step 2: Keyboard focus → focus ring on the anchor (focus-visible only).
Step 3: Pointer down → color shifts to --button-primary-background-hover (active).
Step 4: Release / Enter → navigation to href.
Step 5: Non-link variants (primary/muted/bullet) → no response to any pointer or keyboard event.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Underline on hover (link) | 150ms | ease | `transition-[color,text-decoration-color]` |
| Active color shift (link) | 150ms | ease | same |

Figma `State` property (normal/hovered/active) maps to CSS pseudo-classes (`:hover`, `:active`) — states are browser-driven, not JS.

---

### Animation Details

**Underline (link)**:
- `text-decoration` fades in on hover.
- Duration: 150ms, easing: ease.
- No layout shift — underline occupies the existing line box.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| `link` variant without `href` | Renders as text with link color but is not focusable/navigable — avoid |
| `bullet` + manual `leadingIcon` | Both render; leads to a double marker — avoid |
| Text wraps to two lines | Not supported by design intent — use Paragraph |
| Icon-only (no children) | Icons render with `gap`, but there is no accessible label — provide text |

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Body scale unchanged; single-line text truncates or overflows per consumer `className` |

---

### Implementation Tasks

- [x] Link hover underline transition (150ms ease)
- [x] Link active color shift to `--button-primary-background-hover`
- [x] `focus-visible` ring on the anchor
- [x] Non-link variants inert to interaction
- [x] Verify no layout shift on underline
