# Text — Component Spec

**Version**: 1.0
**Status**: Implemented
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Frame URL**: Typography page
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Single-line body/link text atom with optional leading and trailing icons. It carries the body type token, four content variants (plain, muted, link, bullet), and renders as an anchor when given `href` — the inline text primitive that sits alongside Paragraph (multi-line).

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-text-default` | `#212529` | `color` (primary) |
| `--color-text-muted` | `#6c757d` | `color` (muted / bullet) |
| `--theme-primary` | `#087990` | `color` (link) |
| `--button-primary-background-hover` | `#066173` | `color` (link active) |
| `--font-family-base` | Roboto | `font-family` |
| `--font-size-body` | `16px` | `font-size` |
| `--line-height-body` | `1.5` | `line-height` |
| `--font-weight-regular` | `400` | `font-weight` |
| `--spacing-8` | `8px` | `gap` (icon ↔ label, `gap-2`) |

All references are via the Tailwind theme mapping in `tailwind.config.js`, which resolves to these CSS variables. No hardcoded values.

---

### Variants

Mirrors the Figma `Variant` property 1:1.

| Variant | Description |
|---|---|
| `primary` | Default body color (`text-text`) |
| `muted` | De-emphasized body color (`text-muted`) |
| `link` | Teal (`text-primary`), underline on hover, active color shift to `text-primary-hover`; renders `<a>` with `href` |
| `bullet` | Renders a leading `dot` Icon before the text (list marker) |

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | Base variant appearance | — |
| `hover` (link) | Underline appears | Mouse enter (link only) |
| `active` (link) | Color → `--button-primary-background-hover` | Mouse down (link only) |
| `focus` (link) | Focus ring on the anchor | Keyboard focus (link only) |

`primary`, `muted`, and `bullet` are non-interactive and have no state changes.

---

### Sizes

Text renders at a single body scale — there is no size prop.

| Size | Font | Line height | Token |
|---|---|---|---|
| body | 16px | 1.5 | `--font-size-body` / `--line-height-body` |

Leading/trailing icons use the Icon `small` box to align on the body line.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `variant` | `primary \| muted \| link \| bullet` | `primary` | Color/role of the text |
| `leadingIcon` | `ReactNode` | — | Icon rendered before the label (`gap-2`) |
| `trailingIcon` | `ReactNode` | — | Icon rendered after the label (`gap-2`) |
| `href` | `string` | — | When set, renders `<a href>`; otherwise `<span>` |
| `children` | `ReactNode` | — | The text content (single line) |
| `className` | `string` | — | Layout overrides only, merged last |
| `...props` | `HTMLAttributes` | — | Native span/anchor attributes spread |

---

### Content Rules

- Single line only — use Paragraph for multi-line copy.
- `link` variant should be given an `href`; a link without a destination is an anti-pattern.
- `bullet` variant auto-renders the leading `dot` Icon; do not also pass a `leadingIcon`.
- Icons align on the body line via `gap` = `--spacing-8`.

---

### Accessibility

- Element: `<span>` by default, `<a href>` when `href` is set.
- Anchors are focusable and expose the visible text as their accessible name.
- Leading/trailing icons are decorative (`aria-hidden`) since the text is the label.
- Link focus ring is never removed.

---

### Do Not

- Do not hardcode colors or type values — reference tokens via Tailwind theme.
- Do not use the `link` variant without an `href`.
- Do not wrap multi-line paragraphs in Text — use Paragraph.
- Do not duplicate the bullet dot with a manual `leadingIcon`.

---

### Implementation Tasks

- [x] Create `src/components/ui/text.variants.ts` (CVA variants)
- [x] Create `src/components/ui/Text.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Implement `primary` / `muted` / `link` / `bullet` variants
- [x] Render `<a>` when `href` is present, else `<span>`
- [x] Wire `leadingIcon` / `trailingIcon` with `gap-2`
- [x] Auto-render leading `dot` Icon for `bullet`
- [x] Link hover underline + active color shift + focus ring
- [x] Unit test render, variant class, anchor vs span, icon slots
