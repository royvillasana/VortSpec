# Tag — Usage / Composition Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./tag-component-spec.md

Atoms have no page of their own; this documents how Tag composes into higher-order
components and screens.

---

### Purpose

Document how the Tag atom is consumed to label statuses, categories, and metadata across
molecules, organisms, and screens.

---

### Component Inventory

| Component | Role |
|---|---|
| `Tag` (atom) | The chip itself |
| `Icon` (atom) | Dismiss glyph (`x`), and any `leadingIcon` a consumer supplies |

---

### Usage example

```tsx
import { Tag } from '@/components';
import { Icon } from '@/components';

// Status chip
<Tag variant="success">Active</Tag>

// Metadata chip with a leading icon
<Tag variant="light" size="small" leadingIcon={<Icon name="clock" size="small" aria-hidden />}>
  Updated
</Tag>

// Removable category chip
<Tag variant="primary" removable onRemove={() => removeFilter('react')}>
  React
</Tag>
```

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Intrinsic auto-width, inline flow; wraps with surrounding text/flex container. No size change by breakpoint. |

Tags are laid out by their container (e.g. a `flex flex-wrap gap` group); the atom itself
does not manage multi-tag spacing.

---

### Accessibility

- Use meaningful text as the tag label; do not rely on color alone to convey status.
- Removable tags always expose the dismiss control with `aria-label="Remove"`.
- When grouping many removable tags, ensure each remains individually focusable in tab order.

---

### Implementation Tasks

- [x] Verify Tag renders inline with correct spacing across all variants/sizes
- [x] Verify removable Tag's dismiss button is focusable and fires `onRemove`
- [x] Verify `leadingIcon` aligns with the label at both sizes
