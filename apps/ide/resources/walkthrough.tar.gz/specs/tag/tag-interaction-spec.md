# Tag — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./tag-component-spec.md
**Figma prototype**: Tags page — Type + Size properties, optional dismiss affordance

---

### Interaction Overview

The chip is a static inline label. When `removable`, a trailing dismiss button lets the user
remove the tag; it responds to pointer and keyboard with a brightness shift and a focus ring,
then fires `onRemove`.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Click / tap | Dismiss button | `removable` is true |
| `Enter` / `Space` | Dismiss button (native) | Focus on the dismiss button |
| Hover | Dismiss button | `removable` is true |

---

### Flow

```
Step 1: Pointer enters dismiss button → brightness-95 hover style. Instant, eased by transition.
Step 2: Keyboard focus on dismiss button → 2px primary ring at 2px offset (focus-visible only).
Step 3: Pointer down / Space held → active style (brightness-90).
Step 4: Release / key up over the button → onRemove() fires.
Step 5: Consumer removes the tag from state (component is controlled — it does not self-unmount).
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Brightness on dismiss hover & active | 150ms | ease-out | `transition-[filter]` |

Dismiss states are driven by CSS pseudo-classes (`:hover`, `:active`, `:focus-visible`), not JS.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| `removable` true but no `onRemove` | Button renders; click is a no-op |
| `removable` false | No dismiss button rendered; `onRemove` ignored |
| `leadingIcon` supplied | Rendered before the label with the internal gap |
| Click on chip body (not the button) | No-op — the chip `<span>` is non-interactive |

---

### Accessibility & Keyboard

- Dismiss control is reachable in tab order (native `<button>`).
- `Enter` / `Space` activate it (native button behavior).
- `aria-label="Remove"` names the control for screen readers.
- Focus ring is always visible on keyboard focus (`focus-visible:ring-2`).

---

### Implementation Tasks

- [x] Trailing dismiss `<button>` calls `onRemove` on activation
- [x] Hover/active brightness transition on the dismiss button
- [x] `focus-visible` ring on the dismiss button (not on mouse)
- [x] Decorative `Icon` (`aria-hidden`) inside the labeled dismiss button
