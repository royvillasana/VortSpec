# Adversarial Review — Tag

Date: 2026-07-07

## Verdict: PASS

## Findings

| Severity | Area | Issue | Status |
|---|---|---|---|
| — | Token audit | No hex/rgb/hsl/arbitrary DS value/inline style in either file | Pass |
| Info | Timing | `transition-[filter]` is an arbitrary transition-property, not a DS value leak (documented brightness-hover pattern) | Accepted |
| — | A11y | Dismiss `<button>` has `aria-label="Remove"`; glyph `aria-hidden`; focus ring intact | Pass |
| — | Spec parity | 9 variants + 2 sizes + defaults mirror spec 1:1 | Pass |

No Blocker or Major findings.

## Architecture Validation (8 checks)
1. `.variants.ts` colocated — yes (`tag.variants.ts`)
2. CVA variants mirror spec 1:1 — yes (9 `variant`, 2 `size`)
3. defaultVariants match spec — yes (`base` / `medium`)
4. forwardRef — yes (`HTMLSpanElement`)
5. `...props` spread on root — yes (on `<span>`)
6. `className` merged LAST via `cn()` — yes
7. VariantProps exported — yes (`TagVariants`)
8. no inline `style={{}}` for DS values — yes

## Token / Variant / State / A11y Checklist
- Tokens: all utilities resolve to `var(--...)`; grep clean.
- Variants: base/primary/secondary/success/danger/warning/info/light/dark — all present.
- States: default (static span) + dismiss hover/active/focus — CSS-driven, all present.
- A11y: semantic `<span>` label; real dismiss `<button>` with `aria-label`; decorative
  icon `aria-hidden`; visible focus-visible ring.

## Resolved During Review
None — no defects found; no edits made.

## Notes
No Storybook story exists for Tag, so runtime pixel-diff and axe were not executable.
All checks above are verified from source (spec ↔ code ↔ token model). Contrast is
assessed as plausibly AA from token pairings, not measured by a runtime axe pass.
