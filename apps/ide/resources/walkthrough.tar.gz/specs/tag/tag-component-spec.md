# Tag — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Small inline label/chip used to surface statuses, categories, or metadata. Reuses the
Button color taxonomy so status colors stay consistent across the system, and optionally
carries a leading icon and a dismiss affordance.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--theme-primary` | `#087990` | `background-color` (primary) / focus ring |
| `--theme-secondary` | `#e07b39` | `background-color` (secondary) |
| `--color-status-success` | `#198754` | `background-color` (success) |
| `--color-status-danger` | `#dc3545` | `background-color` (danger) |
| `--color-status-warning` | `#ffc107` | `background-color` (warning) |
| `--color-status-info` | `#0dcaf0` | `background-color` (info) |
| `--color-neutral-100` | `#f8f9fa` | `background-color` (light) |
| `--color-neutral-600` | `#6c757d` | `background-color` (base) |
| `--primitive-neutral-near-black` | `#1a1916` | `background-color` (dark) / label (warning, info) |
| `--primitive-neutral-white` | `#ffffff` | `color` (label on solid fills) |
| `--color-text-default` | `#212529` | `color` (light label) |
| `--spacing-4/6/8/10` | 4/7/8/10px | `padding` / `gap` |
| `--radius-4` | 4px | `border-radius` |
| `--font-family-base` | Roboto | `font-family` |
| `--font-size-body` | `16px` | `font-size` |
| `--font-weight-regular` | `400` | `font-weight` |

All references are via the Tailwind theme mapping in `tailwind.config.js`, which resolves to
these CSS variables. No hardcoded values.

---

### Variants

Mirrors the Button color `Type` property.

| Variant | Description |
|---|---|
| `base` | Neutral gray fill, white label (default) |
| `primary` | Teal fill, white label |
| `secondary` | Orange fill, white label |
| `success` | Green fill, white label |
| `danger` | Red fill, white label |
| `warning` | Amber fill, near-black label |
| `info` | Cyan fill, near-black label |
| `light` | Light gray fill, default-text label |
| `dark` | Near-black fill, white label |

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | Base appearance | — |
| remove `hover` | Dismiss button darkens via `brightness-95` | Mouse enter on dismiss button |
| remove `focus` | 2px ring in `--theme-primary`, offset 2px | Keyboard focus on dismiss button |
| remove `active` | Dismiss button `brightness-90` | Mouse down on dismiss button |

The `<span>` chip itself is non-interactive; only the optional dismiss button reacts to
pointer/keyboard.

---

### Sizes

| Size | Padding V | Padding H | Radius | Font |
|---|---|---|---|---|
| `small` | 4px (`--spacing-4`) | 8px (`--spacing-8`) | 4px (`--radius-4`) | body |
| `medium` | 4px (`--spacing-4`) | 10px (`--spacing-10`) | 4px (`--radius-4`) | body |

Internal gap between leading icon, label, and dismiss button is 4px (`--spacing-4`).

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `variant` | `base \| primary \| secondary \| success \| danger \| warning \| info \| light \| dark` | `base` | Color type |
| `size` | `small \| medium` | `medium` | Chip size |
| `removable` | `boolean` | `false` | Renders a trailing dismiss button |
| `onRemove` | `() => void` | — | Called when the dismiss button is activated |
| `leadingIcon` | `React.ReactNode` | — | Optional decorative icon before the label |
| `className` | `string` | — | Layout overrides only, merged last |
| `...props` | `HTMLAttributes<HTMLSpanElement>` (omit `color`) | — | Native span attributes spread |

---

### Accessibility

- Element: semantic `<span>` (inline, non-interactive label).
- Dismiss control is a real `<button type="button">` with `aria-label="Remove"`.
- Dismiss button keeps a visible `focus-visible` ring (never removed).
- The dismiss glyph is a decorative `Icon` (`aria-hidden`); the accessible name lives on the button.

---

### Do Not

- Do not hardcode colors, spacing, or radius — reference tokens via the Tailwind theme.
- Do not remove the dismiss button's focus ring.
- Do not make the chip `<span>` itself clickable; only the dismiss button is interactive.
- Do not render a dismiss button without `aria-label="Remove"`.

---

### Implementation Tasks

- [x] Create `src/components/ui/tag.variants.ts` (CVA)
- [x] Create `src/components/ui/Tag.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Implement all 9 `variant` color values
- [x] Implement `small` / `medium` sizes
- [x] Implement `removable` trailing dismiss `<button>` calling `onRemove`
- [x] Support optional `leadingIcon`
- [x] Wire focus ring + hover/active brightness on the dismiss button
