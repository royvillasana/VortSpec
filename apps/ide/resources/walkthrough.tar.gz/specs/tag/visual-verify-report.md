# Visual Verify Report — Tag

- **Component**: Tag (`src/components/ui/Tag.tsx`, `src/components/ui/tag.variants.ts`)
- **Design source**: Figma (`ojko9pGfsDAvmUf2DA38d2`)
- **Date**: 2026-07-07
- **Rendered live?**: No — no Storybook story exists for Tag. Verification is
  SOURCE-OF-TRUTH only (spec ↔ code ↔ token model). Runtime pixel/axe checks are
  **not executable — verified from source**, not failed.

## Method
Static verification of the `.tsx` + `.variants.ts` against the Component Spec,
Interaction Spec, and the authoritative Tailwind→CSS-var token map.

## Checklist Results

### Variants (checked)
All 9 color variants present and mirror the spec's Button color taxonomy 1:1:
base, primary, secondary, success, danger, warning, info, light, dark. Label colors
match spec (white on solid fills; `text-near-black` on warning/info; `text-text` on light).
`defaultVariants` = `variant: base`, `size: medium` — matches spec.

### Sizes (checked)
- small -> `px-2 py-1` = 8px H / 4px V (spec: 8px / 4px) OK
- medium -> `px-2.5 py-1` = 10px H / 4px V (spec: 10px / 4px) OK
- gap `gap-1` = `--spacing-4` = 4px internal gap OK
- radius `rounded-sm` = `--radius-4` OK

### States (from source)
Chip `<span>` is non-interactive (spec). Dismiss button declares hover `brightness-95`,
active `brightness-90`, `focus-visible:ring-2 ring-primary ring-offset-2`. Matches the
spec states table exactly. Driven by CSS pseudo-classes, no JS.

### Token Audit (zero leaks)
`grep -nE '#[0-9a-fA-F]{3,8}|rgb\(|hsl\(|[0-9]+px|\[[0-9]|style=\{\{'` on both files
returns nothing. Every color/spacing/radius/font utility resolves to a `var(--...)`
through `tailwind.config.js`. `transition-[filter]` is an arbitrary transition-*property*
(not a DS value) — the documented brightness-hover pattern; ring / ring-offset widths are
the allowed exception. No hex/rgb/hsl, no arbitrary DS value, no inline style.

### Accessibility (from source)
- Chip element is semantic `<span>` (inline label). OK
- Dismiss control is a real `<button type="button">` with `aria-label="Remove"`. OK
- Dismiss glyph `Icon name="x"` is `aria-hidden`; accessible name on the button. OK
- Focus ring never removed. OK
- Contrast: solid token fills with white / near-black label, plausibly AA
  (not runtime-measured; no axe run without a story).

### Architecture (8/8)
`.variants.ts` colocated · CVA mirrors spec · defaultVariants match · forwardRef ·
`...props` spread on root `<span>` · `className` merged LAST via `cn()` ·
`TagVariants` exported · no inline `style={{}}`.

### Interaction Spec (checked)
Every declared trigger handled: click/tap, Enter/Space (native button), hover.
Timing `transition-[filter]` 150ms ease-out present. Edge cases satisfied:
`removable` without `onRemove` -> click no-op; `removable` false -> no button;
`leadingIcon` before label; chip-body click is a no-op.

## Discrepancies
None.

## Gate: PASS (zero unresolved discrepancies)
