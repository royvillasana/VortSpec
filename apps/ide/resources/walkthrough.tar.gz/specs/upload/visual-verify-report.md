# Visual Verify Report — Upload

- **Design source:** `figma` (Branch A) · **Component:** `Upload` (organism) · **Date:** 2026-07-07
- **Spec:** `specs/upload/upload-component-spec.md` + `upload-interaction-spec.md` + `upload-page-spec.md` · **Impl:** `src/components/sections/Upload.tsx` + `upload.variants.ts`
- See `specs/visual-verify-report.md` for shared context and the runtime-check environment limitation.

## Result: PASS (source-of-truth) — 0 open source-level discrepancies

Every spec Implementation Task (component + interaction) is checked. Both `variant`s (`button` /
`dragger`), the dashed drop zone (`border border-1 border-dashed border-neutral-300 rounded
bg-neutral-100 p-6`), the drag-over highlight (`border-primary bg-brand-primary-100`), the removable
file list, the hidden native `<input type="file">` (`sr-only`) driven by `.click()`, and the disabled
pattern all match the spec, and every color/spacing/radius/border utility resolves to a design token.
The `text-muted` classes on the dragger icon/hint and the file-row icons/remove button **now resolve**
via the `muted` color alias (systemic defect fixed 2026-07-07 — see below). The two runtime dimensions
(live-viewport pixel + axe) remain **open** — no render harness in this env.

## ⚠️ Runtime dimensions NOT executed (environment limit)

No browser driver (Playwright/Puppeteer/axe are NOT installed) and the Vite dev server on `:5173` is
DOWN, so the Figma-flow **live-viewport pixel comparison (375/768/1440px)** and the **runtime axe
audit** (which would exercise the drag-and-drop + keyboard drop zone) CANNOT be executed and their
results are NOT asserted. Everything below is a **source-of-truth verification** (spec ↔ code ↔ token
model), authoritative for the token, variant, state-wiring, and semantic/ARIA dimensions.

## Checklist (source-verified)

### Variants ✓
`variant` axis (`button` default / `dragger`) on `uploadVariants` (`upload.variants.ts:14`, both
branches empty wrappers over the shared `flex flex-col gap-3` base). The `dragger` surface is the
separate `draggerZone` CVA (`:30`) with `dragActive` + `disabled` axes, composed at runtime so the
transient drag highlight layers on top. Matches spec Variants table. ✓

### States ✓
| State | Wiring | OK |
|---|---|---|
| `idle` | neutral trigger / dashed zone, empty list | ✓ |
| `drag-over` | `dragActive:true → border-primary bg-brand-primary-100` (`upload.variants.ts:38`) | ✓ |
| `disabled` | `opacity-disabled pointer-events-none cursor-not-allowed` + `aria-disabled` (`:42`, `Upload.tsx:165`) | ✓ |
| `file rows` | one `<li>` per file: icon + name + remove button (`Upload.tsx:184–211`) | ✓ |
| `focus` | `focus-visible:ring-2 ring-primary ring-offset-2` on dragger + remove (`:203`, `:34`) | ✓ |

### Tokens — utility → token
| Utility | → token | OK |
|---|---|---|
| `gap-3` (wrapper) | `--spacing-12` | ✓ |
| `gap-2` (dragger internals, file row) | `--spacing-8` | ✓ |
| `gap-1` (file list) | `--spacing-4` | ✓ |
| `p-6` (drop zone) | `--spacing-24` | ✓ |
| `px-2 py-1` (file row) | `--spacing-8` / `--spacing-4` | ✓ |
| `p-1` (remove button) | `--spacing-4` | ✓ |
| `border border-1 border-neutral-300 border-dashed` | `--stroke-width-1` + `--color-neutral-300` (dashed = style, allowed) | ✓ |
| `rounded` (zone) / `rounded-sm` (row + remove) | `--radius-8` / `--radius-4` | ✓ |
| `bg-neutral-100` (zone + row) | `--color-neutral-100` | ✓ |
| `border-primary bg-brand-primary-100` (drag-over) | `--theme-primary` / `--brand-primary-100` | ✓ |
| `text-text` (prompt + filename) | `--color-text-default` | ✓ |
| `text-muted` (hint, icons, remove) | `--color-text-muted` via `muted` alias | ✓ |
| `hover:text-danger` (remove) | `--color-status-danger` | ✓ |
| `ring-primary` | `--theme-primary` | ✓ |
| `text-body` / `font-regular` / `leading-body` | size / weight / line-height | ✓ |
| `sr-only` / `flex` / `flex-col` / `items-center` / `ml-auto` / `w-full` / `self-start` | structural | ✓ |

### Accessibility ✓
Real native `<input type="file">` kept for semantics, hidden with `sr-only` (not `display:none`),
`tabIndex=-1`, driven by `.click()` (`Upload.tsx:139–148`). `button` variant uses the `Button` atom
(real `<button>`). `dragger` is a keyboard-activatable `role="button" tabIndex={0/-1}` with `aria-label`
(prompt text or fallback), `aria-disabled`, and `Enter`/`Space` handling (`:162–172`). Each file row's
remove control is a real `<button aria-label="Remove file">` with a focus ring; drag-over is visual-only
(click + keyboard always work); decorative icons are `aria-hidden`. Matches spec A11y. ✓

### Token audit (static, zero tolerance)
Grep for `#hex` / `rgb(` / `hsl(` / `style={{` / `[..px]` / default-palette color classes → **0 hits**.
All spacing keys used (`3`, `2`, `1`, `6` → mapped) are in the allow-list. `p-6` → `--spacing-24` (real
Figma token). No unmapped fixed-dimension (`w-<n>`/`h-<n>`) sizing keys; only `w-full` layout primitive.
`border-dashed` is a border *style*, not a value (allowed per spec).

## Resolved (do NOT flag)

- **`text-muted` (dragger hint/icon, file-row icon, remove button) — RESOLVED.** `Upload.tsx:174,178,191,201`
  use `text-muted`, a dead class until the 2026-07-07 fix added `colors.muted: 'var(--color-text-muted)'`
  at `tailwind.config.js:50`. It now emits `.text-muted { color: var(--color-text-muted) }`. Token
  dimension **PASS**. No source change needed in Upload.

## Observations (non-blocking)

- **O-A — stale spec token-table values.** The component-spec "Design Tokens Used" table prints
  `--color-primary #0d6efd` for the drag-over border/ring, but the impl uses `border-primary`/`ring-primary`
  → `--theme-primary` (#087990). The utilities are correct/tokenized; only the spec's hex label is stale
  (a Bootstrap default carried over). Text-only spec drift.
- **O-B — `disabled` double-guarded.** The dragger sets `pointer-events-none` (CVA) *and* the handlers
  early-return on `disabled`; redundant but harmless defense-in-depth.

## Gate
**Token · variant · state · semantic/ARIA dimensions: PASSED** — 0 open source-level discrepancies
(`text-muted` resolved via alias).
**Runtime dimensions (live-viewport pixel + axe): still not executable** in this environment.
