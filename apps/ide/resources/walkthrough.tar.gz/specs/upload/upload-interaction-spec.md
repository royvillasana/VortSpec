# Upload — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Overview

Upload gathers files three ways — clicking a trigger, dragging files onto a drop
zone, or keyboard-activating either surface — and reflects the selection as a
removable list. All file-dialog behaviour comes from the real native
`<input type="file">`; the visible surfaces only trigger it. State is held in
`useState` and mirrored to consumers through `onFilesChange`.

---

### Trigger

- **Click / tap**: Clicking the `button` trigger or anywhere on the `dragger` drop
  zone calls the hidden input's `.click()`, opening the native OS file dialog.
- **Drag and drop** (dragger only): Dragging files over the zone highlights it
  (`border-primary bg-brand-primary-100`); dropping reads `e.dataTransfer.files` and
  adds them. `dragover` / `dragleave` / `drop` all `preventDefault()`.
- **Keyboard**: The `button` trigger is a real `<button>` (native activation). The
  `dragger` is a `role="button"` `tabIndex=0` surface; `Enter` / `Space` open the
  dialog. Both show a visible `focus-visible` ring. Each file row's remove button is
  keyboard focusable and activatable.

---

### Flow

1. Idle — button trigger or empty drop zone; no file rows.
2. User adds files by choosing in the dialog or dropping onto the zone.
3. On the input `change` (or `drop`), the component reads the `FileList`, appends when
   `multiple` (else replaces with the first file), updates state, and calls
   `onFilesChange` with the full list.
4. The file list renders one row per file: file icon + filename + remove button.
5. Clicking a row's remove button splices that file out, updates state, and calls
   `onFilesChange` with the new list.
6. Selecting the same file again still fires `change` because the input value is reset
   after each change.

---

### Timing

- Native dialog open/close is OS-driven (no custom animation).
- Drag-over highlight toggles synchronously on `dragover` (on) / `dragleave` +
  `drop` (off), with a ~150ms `background-color` / `border-color` transition.
- File-list updates commit synchronously via a single React state update.
- Trigger + remove-button hover/focus transitions run ~150ms ease-out.

---

### Edge Cases

| Case | Behaviour |
|---|---|
| Multiple (`multiple`) | New files append to the existing list; list grows. |
| Single (no `multiple`) | Each add replaces the list with the first chosen file. |
| Duplicate file | Not de-duplicated; appends as a separate row (rows keyed by name + index). |
| Remove | Splices the file at that index; `onFilesChange` fires with the remainder. |
| Dialog cancelled / empty drop | `FileList` is empty → no change, list unchanged. |
| Re-select same file | Input value reset after change, so `change` still fires. |
| Disabled | Trigger, drop zone, and remove buttons are non-interactive; drop/keyboard are ignored. |
| Non-accepted type | `accept` filters the native dialog; dropped files are not filtered by `accept` (browser + consumer responsibility). |

---

### Accessibility & Keyboard

- The native input keeps native semantics; it is `sr-only` (not `display:none`).
- `button` variant: real `<button>` — `Tab` reaches it, `Enter`/`Space` activate.
- `dragger` variant: `role="button"` `tabIndex=0` with `aria-label`; `Enter`/`Space`
  open the dialog; `aria-disabled` reflects the disabled state; visible focus ring.
- Drag-over is a visual aid only — activation never requires drag.
- Remove buttons are real `<button aria-label="Remove file">`, focusable and
  activatable, with a visible focus ring.
- Decorative icons are `aria-hidden`.

---

### Implementation Tasks

- [x] Open the native dialog via the hidden input's `.click()` from both surfaces
- [x] `dragger` `role="button"` `tabIndex=0` + `Enter`/`Space` handler; `aria-label`
- [x] `onDragOver`/`onDragLeave`/`onDrop` with `preventDefault()`; read `e.dataTransfer.files`
- [x] Drag-over highlight toggled via `dragActive` state (visual only)
- [x] Add appends when `multiple`, replaces otherwise; `onFilesChange` on every change
- [x] Remove splices by index; `onFilesChange` on remove
- [x] Reset input value after change so re-selecting the same file re-fires
- [x] Ignore drop / keyboard when `disabled`; reflect `aria-disabled`
- [x] Remove buttons keyboard focusable/activatable with visible focus ring
