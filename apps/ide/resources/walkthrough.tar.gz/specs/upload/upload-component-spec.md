# Upload — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Upload is the design system's file-upload control (organism). It composes a real,
visually hidden native `<input type="file">` with one of two visible surfaces — a
Button-styled trigger (`variant="button"`) or a large dashed drop zone
(`variant="dragger"`) — plus a removable list of the selected files. It gives a
branded, accessible upload experience (click, drag-and-drop, and keyboard) while
keeping the browser's native file dialog intact. Selection state is managed
internally and surfaced to consumers via `onFilesChange`.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-neutral-100` | `#f8f9fa` | drop-zone + file-row `background-color` |
| `--color-neutral-300` | — | drop-zone dashed `border-color` |
| `--color-primary` | `#0d6efd` | drag-over border + focus ring |
| `--brand-primary-100` | — | drag-over drop-zone `background-color` |
| `--color-danger` | `#dc3545` | remove-button hover `color` |
| `--color-text-default` | `#212529` | prompt + filename `color` |
| `--color-text-muted` | `#6c757d` | hint, file icon, remove icon `color` |
| `--font-family-base` | Roboto | `font-family` |
| `--font-size-body` | `16px` | `font-size` |
| `--font-weight-regular` | `400` | `font-weight` |
| `--line-height-body` | — | `line-height` |
| `--radius-default` / `--radius-sm` | — | drop-zone + file-row `border-radius` |
| `--opacity-disabled` | — | `opacity` (disabled surfaces) |
| `--spacing-*` | — | wrapper/zone/list `gap` + padding (`gap-3`, `gap-2`, `gap-1`, `p-6`, `px-2`, `py-1`, `p-1`) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js` to
these CSS variables. No hardcoded values. `border-dashed` is a border *style*, not a
value, and is allowed.

---

### Variants

| Property | Values | Description |
|---|---|---|
| `variant` | `button` \| `dragger` | Visible surface: a Button trigger, or a dashed drop zone |

- **button** — a `Button` (`variant="light"`) with `<Icon name="upload" size="small" />`
  and a label (default "Upload") that opens the native file dialog on click.
- **dragger** — a `<div>` drop zone (`border border-1 border-dashed border-neutral-300
  rounded bg-neutral-100 p-6 text-center`) that is clickable, keyboard-activatable
  (`role="button"`, `tabIndex=0`), and accepts drag-and-drop. Contains a large
  `<Icon name="upload" size="large" />`, a prompt line, and a muted hint line.

Both variants share the same hidden native input and the same file-list rendering.

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `idle` | Trigger button / neutral dashed drop zone; empty file list | No interaction |
| `drag-over` | Drop zone highlights: `border-primary` + `bg-brand-primary-100` | File dragged over the dragger |
| `disabled` | `opacity-disabled`, `not-allowed`, non-interactive surface + remove buttons | `disabled` prop |
| `file rows` | One row per selected file: file icon + filename + remove button | One or more files added |
| `focus` | 2px primary ring + offset on the dragger / remove button | Keyboard focus (`focus-visible`) |

---

### Sizes

Upload has no size axis. The `button` variant inherits Button's default `medium`
sizing; the `dragger` variant uses a fixed `p-6` drop zone. File rows use `px-2 py-1`.
Icon sizes are fixed per surface: `small` in the button + file rows, `large` in the
drop zone.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `variant` | `button \| dragger` | `button` | Visible surface |
| `accept` | `string` | — | Native file-type filter, forwarded to the input |
| `multiple` | `boolean` | — | Allow selecting/dropping multiple files (adds append) |
| `disabled` | `boolean` | — | Non-interactive control + remove buttons |
| `buttonLabel` | `string` | `Upload` | Text inside the `button` trigger |
| `promptText` | `React.ReactNode` | "Drag and drop files here, or click to browse" | Primary line in the dragger |
| `hintText` | `React.ReactNode` | "Any file type is accepted" | Muted secondary line in the dragger |
| `onFilesChange` | `(files: File[]) => void` | — | Called with the full list on every add/remove |
| `className` | `string` | — | Layout overrides only, merged last onto the outer wrapper |
| ...rest | native | — | `HTMLAttributes<HTMLDivElement>` (minus `onChange`) spread on the wrapper |

`forwardRef<HTMLDivElement>` targets the outer wrapper. The native input is held by
an internal ref.

---

### Accessibility

- Element: a real native `<input type="file">` retains native semantics; it is
  `sr-only` so it stays out of the visual flow. The visible trigger drives it via a
  programmatic `.click()`.
- **button** variant uses the `Button` atom (a real `<button>`), fully keyboard
  operable.
- **dragger** variant is a keyboard-activatable `role="button"` with `tabIndex=0`,
  an `aria-label`, and `Enter` / `Space` handling that opens the file dialog. It also
  reflects `aria-disabled` when disabled.
- The drag-over highlight is purely visual; activation never depends on drag alone
  (click + keyboard always work).
- Each file row's remove control is a real `<button aria-label="Remove file">` with a
  visible focus ring.
- Visible focus rings on the dragger and remove buttons
  (`focus-visible:ring-2 ring-primary ring-offset-2`).
- Decorative icons are `aria-hidden`.

---

### Do Not

- Do not replace the native `<input type="file">` with a fully fake control — keep the
  real input for semantics; only its dialog is triggered programmatically.
- Do not use `display:none` on surfaces that must stay focusable; the input uses
  `sr-only`.
- Do not rely on the drag-over highlight as the only affordance — click and keyboard
  must always work.
- Do not hardcode colors, spacing, radius, or type values — reference tokens via
  Tailwind theme.
- Do not use `style={{}}` or arbitrary `[..]` design-value utilities.
- Do not omit `aria-label` on the dragger or the remove buttons.
- Do not enumerate the selected files without removal affordance — every row is
  removable.

---

### Implementation Tasks

- [x] Create `src/components/sections/upload.variants.ts` (CVA `variant` axis + `draggerZone` surface with `dragActive` / `disabled`)
- [x] Create `src/components/sections/Upload.tsx` (`forwardRef` to the wrapper, `cn()` last)
- [x] Render a real native `<input type="file">` visually hidden with `sr-only`, held by an internal ref
- [x] `button` variant: `Button variant="light"` + `<Icon name="upload" size="small" />` + `buttonLabel`, opens dialog on click
- [x] `dragger` variant: dashed drop zone, `role="button"` `tabIndex=0` `aria-label`, Enter/Space opens dialog
- [x] Drag handlers: `onDragOver`/`onDragLeave`/`onDrop` (preventDefault; read `e.dataTransfer.files`)
- [x] Drag-over highlight `border-primary bg-brand-primary-100` (visual only)
- [x] Track files with `useState`; add appends (respect `multiple`), remove splices; call `onFilesChange` on any change
- [x] File rows: `<Icon name="file-earmark" />` + filename + `<button aria-label="Remove file">` with `<Icon name="x" />`
- [x] Reset input value after change so re-selecting the same file re-fires
- [x] Disabled pattern across trigger, drop zone, and remove buttons; visible focus rings
