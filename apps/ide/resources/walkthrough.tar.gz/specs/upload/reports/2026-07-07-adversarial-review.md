# Adversarial Review — Upload
Date: 2026-07-07

## Verdict: PASS

Real native file input preserved; dragger is a genuinely keyboard-operable `role="button"`; drag state
and disabled propagation are correct; all token-backed. No Blocker, Major, or Minor findings.

## Findings

| Severity | Area | Issue | Status |
|---|---|---|---|
| — | — | None. | — |

### Border check (highest-value)
`upload.variants.ts:32` dragger zone = `border border-1 border-dashed border-neutral-300 …` — width
(`border`/`border-1` → `--stroke-width-1`) + style (`border-dashed`) + **`border-neutral-300`** (→
`--color-neutral-300`); drag-over adds `border-primary`. No side/width without a color → no Preflight leak. ✓

## Dropzone keyboard operability + drag (red-teamed)
- Real native `<input type="file">`, `sr-only` (not `display:none`), held by internal ref, `tabIndex={-1}` — ✓ (`Upload.tsx:139-148`)
- `variant="button"`: real `<button>` (Button atom) opens dialog via `.click()` — ✓
- `variant="dragger"`: `role="button"`, `tabIndex={disabled ? -1 : 0}`, `aria-label`, `aria-disabled` when disabled — ✓; `onKeyDown` handles **Enter AND Space** with `preventDefault()` → `openDialog()` (`Upload.tsx:126-135`) — ✓
- Drag: `onDragOver`/`onDragLeave`/`onDrop` all `preventDefault()`; drop reads `e.dataTransfer.files`; `dragActive` state drives the visual-only highlight (`draggerZone` CVA `dragActive` axis, not inline style) — ✓
- Disabled: `openDialog`, `handleDrop`, `handleDragOver`, `handleKeyDown` all early-return when disabled; input + Button + remove buttons carry `disabled` — ✓
- File rows: `<Icon file-earmark>` + name + real `<button aria-label="Remove file">` with visible focus ring + disabled handling — ✓; input value reset after change so re-selecting the same file re-fires (`Upload.tsx:95`) — ✓
- Decorative icons `aria-hidden` — ✓

## Architecture Validation
- `.variants.ts` colocated — ✓ (`uploadVariants` variant axis + `draggerZone`)
- CVA mirrors spec 1:1 — ✓ (variant button/dragger; draggerZone dragActive/disabled axes = spec States)
- `defaultVariants` match spec default — ✓ (`variant: 'button'`; draggerZone `dragActive:false`, `disabled:false`)
- `forwardRef` — ✓ (`forwardRef<HTMLDivElement>` → outer wrapper)
- native attrs spread `...props` — ✓ (`Omit<…,'onChange'>`, onto wrapper)
- `className` merged LAST via `cn()` — ✓ (`cn(uploadVariants({ variant }), className)`)
- `VariantProps` exported — ✓ (`UploadVariants`)
- no inline `style={{}}` for DS values — ✓ (drag-over highlight is a CVA variant composed at runtime, not inline)

## Resolved During Review
(none — read-only)

## Notes
Runtime dims (responsive 375/768/1440, axe, screen-reader) NOT executable: no browser driver, Vite `:5173`
down. Layout is intrinsic (`flex flex-col`, `w-full` dragger); no responsive claim to fail from source.
