# Upload — Page / Usage Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Defines how Upload is composed into screens and forms. Upload is an organism used
wherever a flow needs file intake — attachment fields, media/document uploaders,
import steps, avatar pickers. The compact `button` variant fits inline in a form row;
the `dragger` variant anchors a dedicated upload area. It self-manages its file list,
so consumers only react to `onFilesChange`.

---

### Component Inventory

| Element | Component | Role |
|---|---|---|
| Trigger (button variant) | `Button` (`variant="light"`) | Opens the native dialog |
| Upload icon | `Icon` (`name="upload"`, `size="small"` / `large`) | Affordance in trigger + drop zone |
| Drop zone | `<div role="button">` styled via `draggerZone` | Click + drag + keyboard target |
| File control | native `<input type="file">` (`sr-only`) | Real, accessible picker |
| File row icon | `Icon` (`name="file-earmark"`, `size="small"`) | File affordance |
| Remove control | `<button aria-label="Remove file">` + `Icon` (`name="x"`) | Removes a file |

Depends on: `Button` (atom), `Icon` (atom), `cn` util.

---

### Usage example

```tsx
import { Upload } from '@/components/sections/Upload';

// Button trigger (inline)
<Upload
  buttonLabel="Upload résumé"
  accept=".pdf,.docx"
  onFilesChange={(files) => setResume(files[0])}
/>

// Dragger drop zone, multiple files
<Upload
  variant="dragger"
  multiple
  accept="image/*"
  promptText="Drag images here, or click to browse"
  hintText="PNG or JPG, up to 10 files"
  onFilesChange={setImages}
/>
```

---

### Responsive

- The outer wrapper is `flex flex-col gap-3` and takes the width of its container; it
  sets no intrinsic width.
- The `button` trigger is `self-start`, so it hugs its content rather than stretching.
- The `dragger` drop zone is `w-full`, filling the container width; its `text-center`
  content stays centered at any width.
- File rows are `w-full` and wrap naturally; long filenames stay on their row with the
  remove button pinned right (`ml-auto`).
- No fixed breakpoints inside the component; it adapts to its column/section.

---

### Accessibility

- Keyboard reachable and operable via the real input plus a `role="button"` dragger
  (`Enter`/`Space`); the `button` variant is a native `<button>`.
- Visible focus rings on the dragger and every remove button.
- Drag-over highlight is visual only; click + keyboard always work.
- Remove buttons carry `aria-label="Remove file"`; decorative icons are `aria-hidden`.
- When placed in a form, pair Upload with an associated visible label/heading for the
  upload area (Upload itself renders the control, not a field label).

---

### Implementation Tasks

- [x] Expose `variant`, `accept`, `multiple`, `disabled`, `buttonLabel`, `promptText`, `hintText`, `onFilesChange`
- [x] Keep the wrapper width-agnostic (`flex flex-col`); `button` trigger `self-start`, `dragger` `w-full`
- [x] Report the full file list via `onFilesChange` for consumer state
- [x] Compose `Button` + `Icon` (button variant) and the dashed drop zone (dragger variant)
- [x] Render removable file rows with `file-earmark` + `x` icons
- [x] Merge consumer `className` last onto the outer wrapper for layout overrides
