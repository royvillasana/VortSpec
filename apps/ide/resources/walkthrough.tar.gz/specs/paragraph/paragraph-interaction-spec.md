# Paragraph — Interaction Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./paragraph-component-spec.md
**Figma prototype**: Typography page — no interactive states

---

### Interaction Overview

Paragraph is static block copy. It has no pointer or keyboard behavior; it simply lays out multi-line body text at the token type scale.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| — | — | Paragraph exposes no triggers |

---

### Flow

```
Step 1: Paragraph renders its copy as a semantic <p> at body type (16/1.5/400), filling container width.
Step 2: Text reflows to the container width as the viewport changes.
Step 3: No pointer, focus, or keyboard event is handled by Paragraph.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| — | — | — | Paragraph defines no transitions |

---

### Animation Details

None. Paragraph renders static text.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| Empty `children` | Renders an empty `<p>` (no height beyond line-box) |
| Very long unbroken string | Overflows unless the consumer sets wrapping/`break-words` via `className` |
| Inline links needed | Compose `Text` (link variant) inside the copy — Paragraph itself stays inert |
| Muted tone on low-contrast surface | Consumer must verify AA contrast |

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Reflows to container width (`w-full`); measure controlled by consumer `max-width` |

---

### Implementation Tasks

- [x] Confirm no interactive handlers are attached
- [x] Verify `<p>` fills container and reflows across viewports
- [x] Verify body type tokens applied at all widths
- [x] Verify muted tone contrast on target surfaces
