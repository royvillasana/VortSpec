# Adversarial Review — Paragraph

**Date**: 2026-07-07
**Component**: Paragraph (atom)
**Impl**: `src/components/ui/Paragraph.tsx` + `src/components/ui/paragraph.variants.ts`
**Spec**: `specs/paragraph/paragraph-component-spec.md`, `-interaction-spec.md`, `-page-spec.md`
**Reviewer mode**: Red-team / source-of-truth (no browser driver available — no runtime axe or
live-viewport assertions; static + token-model analysis).

## Verdict: PASS — 0 Blockers, 0 Majors, 0 Minors

Paragraph is a minimal, correct atom. Every dimension attacked below held up. No inline fixes were
required in the Paragraph files. `npx tsc --noEmit` passes clean.

---

## Findings

| # | Severity | Dimension | Finding | Status |
|---|---|---|---|---|
| — | — | — | No blocking, major, or minor findings — fully clean against spec | — |

### Attack notes (all survived)

- **Variant coverage** — Spec defines exactly two tones (`default`, `muted`); both present in CVA,
  both resolve to the correct text-color token. No missing/extra variants. ✓
- **State coverage** — Spec declares Paragraph non-interactive (single `default` state, no
  hover/focus/active/disabled). Impl attaches zero handlers and defines no state classes. Matches. ✓
- **Token audit** — grep for hardcoded hex/rgb/hsl/inline-style/arbitrary-px on both files: empty.
  `w-full font-base text-body leading-body font-regular` + tone color — every utility routes through
  Tailwind → `var(--token)`. ✓
- **Accessibility (adversarial)** — Renders semantic `<p>`; participates in reading order; no ARIA
  needed for inert block copy. Default `#212529` and muted `#6c757d` both meet AA on white/`neutral-100`
  surfaces. Spec correctly delegates low-contrast-surface responsibility to the consumer (documented
  edge case). ✓
- **Responsive** — `w-full` only; no fixed width or breakpoint classes, so it reflows to the container
  at 375/768/1440 exactly as the interaction spec requires. Measure (max-width) is intentionally
  consumer-owned. ✓
- **Interaction-spec compliance** — No triggers, timing/transitions, or animation. Edge cases (empty
  children → empty `<p>`; long unbroken string overflows unless consumer sets `break-words`; inline
  links via `Text`) are consistent with the impl. ✓

---

## Resolved During Review

None — no defects found in the Paragraph files. No edits made.

Historical context (already fixed, not this pass): the `muted` tone previously produced a dead
`text-muted` class; that was resolved system-wide via the `colors.muted` alias in `tailwind.config.js`
(shared config, out of scope for edits here) and is verified present.

---

## Architecture Validation Checklist

| Requirement | Result | Evidence |
|---|---|---|
| CVA used for variants (separate `.variants.ts`) | ✓ | `paragraph.variants.ts` exports `paragraphVariants = cva(...)` |
| `defaultVariants` declared | ✓ | `defaultVariants: { tone: 'default' }` |
| `forwardRef` used | ✓ | `React.forwardRef<HTMLParagraphElement, ParagraphProps>` |
| Props spread onto element | ✓ | `{...props}` on `<p>` |
| `className` merged last via `cn()` | ✓ | `cn(paragraphVariants({ tone }), className)` |
| `VariantProps` type exported | ✓ | `export type ParagraphVariants = VariantProps<typeof paragraphVariants>` |
| No inline `style={{}}` for DS values | ✓ | None in component files (Story decorator's `maxWidth` is harness-only, out of scope) |
| `displayName` set | ✓ | `Paragraph.displayName = 'Paragraph'` |
| Semantic element | ✓ | Renders `<p>` |

**Architecture: PASS.**
