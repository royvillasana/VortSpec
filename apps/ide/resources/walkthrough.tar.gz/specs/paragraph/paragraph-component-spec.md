# Paragraph — Component Spec

**Version**: 1.0
**Status**: Implemented
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Frame URL**: Typography page
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Multi-line body copy that fills its container width. Paragraph renders a `<p>` at the body type token with a default or muted tone — the block-level counterpart to Text (single-line), used for descriptions, intros, and running prose.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-text-default` | `#212529` | `color` (default tone) |
| `--color-text-muted` | `#6c757d` | `color` (muted tone) |
| `--font-family-base` | Roboto | `font-family` |
| `--font-size-body` | `16px` | `font-size` |
| `--line-height-body` | `1.5` | `line-height` |
| `--font-weight-regular` | `400` | `font-weight` |

All references are via the Tailwind theme mapping in `tailwind.config.js`, which resolves to these CSS variables. No hardcoded values.

---

### Variants

`tone` sets the text color. Mirrors the Figma `Tone` property 1:1.

| Variant | Description |
|---|---|
| `default` | Default body color (`text-text`) |
| `muted` | De-emphasized body color (`text-muted`) |

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | Base tone appearance | — |

Paragraph is non-interactive and has no hover/focus/active/disabled states.

---

### Sizes

Paragraph renders at a single body scale — there is no size prop.

| Size | Font | Line height | Weight | Token |
|---|---|---|---|---|
| body | 16px | 1.5 | 400 | `--font-size-body` / `--line-height-body` / `--font-weight-regular` |

Block fills the container (`w-full`).

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `tone` | `default \| muted` | `default` | Text color |
| `children` | `ReactNode` | — | Paragraph copy (multi-line) |
| `className` | `string` | — | Layout overrides only, merged last |
| `...props` | `HTMLAttributes<HTMLParagraphElement>` | — | Native `<p>` attributes spread |

---

### Content Rules

- Use for multi-line running copy; use Text for single-line labels and inline links.
- Body Regular 16px / line-height 1.5 — do not alter the type scale inline.
- Fills container width; control measure (max-width) via the consumer's `className`.

---

### Accessibility

- Element: semantic `<p>`.
- Body text meets WCAG AA contrast in both tones against the intended surface.
- Muted tone reserved for secondary/supporting copy, not primary reading content that must meet emphasis.

---

### Do Not

- Do not hardcode colors or type values — reference tokens via Tailwind theme.
- Do not use Paragraph for single-line labels or inline links — use Text.
- Do not nest interactive elements as the paragraph itself (inline links inside are fine via Text).

---

### Implementation Tasks

- [x] Create `src/components/ui/paragraph.variants.ts` (CVA tone)
- [x] Create `src/components/ui/Paragraph.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Render semantic `<p>` with `w-full`
- [x] Apply body type tokens (16px / 1.5 / 400)
- [x] Implement `default` / `muted` tones
- [x] Unit test render, tone class, semantic element
