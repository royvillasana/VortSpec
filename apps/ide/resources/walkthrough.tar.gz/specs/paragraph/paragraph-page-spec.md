# Paragraph — Usage / Composition Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./paragraph-component-spec.md

Atoms have no page of their own; this documents how Paragraph composes into higher-order components and screens.

---

### Consumed By

| Consumer | Usage |
|---|---|
| `Cover` (organism) | Intro / description copy |
| Molecules | Card body text, feature descriptions |
| Screens | Any block of running body copy |

---

### Composition Rules

- Paragraph fills its container; control measure (max-width) and spacing via the consumer's `className`.
- Use `muted` tone for secondary/supporting copy, `default` for primary reading text.
- Compose inline links with `Text` (link variant) inside the copy — Paragraph provides the block, Text provides inline behavior.
- Do not fake paragraphs by stacking `Text` nodes; use Paragraph.

---

### Accessibility

- Semantic `<p>` participates in the document reading order.
- Keep muted copy above AA contrast on its surface.
- Heading structure is owned by heading components, not Paragraph.

---

### Implementation Tasks

- [x] Verify Paragraph renders inside Cover with correct measure/spacing
- [x] Verify inline `Text` links compose cleanly within copy
- [x] Verify tone choice matches content emphasis
