# Tabs — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./tabs-component-spec.md
**Figma prototype**: Tabs page — top/left × states

---

### Interaction Overview

`Tabs` implements the WAI-ARIA Tabs pattern with **automatic activation** —
selection follows focus. Active state is tracked in React (`useState`, seeded from
`defaultTabId`). A roving `tabindex` keeps exactly one tab in the page tab order;
the arrow keys move focus among the remaining tabs and simultaneously activate the
focused tab, swapping the visible panel.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Click / tap | `role="tab"` button | Tab not disabled |
| `ArrowRight` / `ArrowLeft` | Focused tab (`orientation="top"`) | ≥1 enabled tab |
| `ArrowDown` / `ArrowUp` | Focused tab (`orientation="left"`) | ≥1 enabled tab |
| `Home` / `End` | Focused tab | ≥1 enabled tab |

Disabled tabs (native `disabled`) receive none of these triggers and are skipped.

---

### Flow

```
Step 1: Component mounts → active tab = defaultTabId, else the first non-disabled tab. Its panel shows; all others are hidden.
Step 2: User clicks a tab (or arrows onto it) → activate(index) sets active state, focuses the tab, and fires onTabChange(id).
Step 3: The previously active panel gets hidden; the newly active panel (aria-labelledby that tab) is revealed.
Step 4: Roving tabindex updates — the new active tab becomes tabIndex=0, all others tabIndex=-1.
Step 5: Arrow/Home/End navigation wraps within the enabled tabs, skipping any disabled tab in between.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Label color / indicator | Tailwind default (150ms) | Tailwind default ease | `transition-colors` |
| Panel swap | Instant | — | `hidden` attribute toggle |

---

### Animation Details

- The active-tab color shift and accent indicator fade via `transition-colors`;
  no layout animation is applied to the panel swap for reliability.
- Panels are always mounted; only the `hidden` attribute toggles, preserving
  internal state and keeping the swap instant.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| `defaultTabId` set | That tab is active on mount (controlled default / uncontrolled seed) |
| `defaultTabId` omitted | First non-disabled tab is active |
| Single tab | Renders normally; arrow keys wrap to the same tab |
| Disabled tab in the middle | Skipped by arrow navigation; wrap continues to the next enabled tab |
| All tabs after a point disabled | `End` lands on the last *enabled* tab |
| Long `label` | Tab keeps `whitespace-nowrap`; tablist grows/scrolls with container |
| Empty `tabs` | Container renders with an empty tablist and no panels |

---

### Accessibility & Keyboard

| Key | Action |
|---|---|
| `Tab` | Enter/leave the tablist — focus lands on the single active tab (roving tabindex) |
| `ArrowRight` / `ArrowLeft` | (top) Move focus + activate previous/next enabled tab, wrapping |
| `ArrowDown` / `ArrowUp` | (left) Move focus + activate previous/next enabled tab, wrapping |
| `Home` | Move focus + activate the first enabled tab |
| `End` | Move focus + activate the last enabled tab |
| `Tab` (from active tab) | Move focus forward to the associated panel (`tabIndex=0`) |

- `role="tablist"` carries `aria-orientation` (`horizontal` for top, `vertical`
  for left); each tab exposes `aria-selected` and `aria-controls`.
- Selection follows focus (automatic activation) — no separate Enter/Space needed,
  though native button activation still works on click.
- Disabled tabs are marked `aria-disabled` + native `disabled` and are never
  focused by arrow navigation.
- Focus is always visible via the `primary` ring with `ring-offset-2`.

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Container fills its width. `top`: tablist row above the panel. `left`: tablist column beside the panel (panel takes remaining width via `flex-1`). Padding, gap, and the 1px rule stay fixed by token. |

---

### Implementation Tasks

- [x] Track active tab in `useState`, seeded from `defaultTabId` (fallback first enabled)
- [x] Implement `activate(index)` — set state, focus the tab, fire `onTabChange`
- [x] Wire click activation on each enabled tab
- [x] Implement arrow/Home/End keyboard navigation with wrap, skipping disabled tabs
- [x] Map orientation → arrow key axis (Left/Right vs Up/Down) and `aria-orientation`
- [x] Maintain roving `tabindex` (active = 0, others = -1)
- [x] Toggle panels via `hidden`; keep panels focusable (`tabIndex=0`)
- [x] Confirm visible focus ring and disabled-tab skipping
