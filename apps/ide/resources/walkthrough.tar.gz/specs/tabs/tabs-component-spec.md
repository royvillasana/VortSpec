# Tabs — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

An accessible tabbed interface implementing the WAI-ARIA Tabs pattern. A row (or
column) of tabs each control a matching panel; activating a tab swaps the visible
panel. Used to partition related content — settings groups, documentation
sections, or `tabs/top` and `tabs/left` navigation containers — into a single
space-efficient region. Selection follows focus (automatic activation), keyboard
navigation is fully supported, and a single tab stop is maintained via roving
`tabindex`.

---

### Composed Atoms

| Atom | Role |
|---|---|
| `<button role="tab">` | Each tab trigger; carries `aria-selected`, `aria-controls`, roving `tabindex` |
| Inline content | `label` inside each tab, `content` inside each panel |

---

### Design Tokens Used

| Token | Utility | CSS Property |
|---|---|---|
| `--theme-primary` | `text-primary` / `border-primary` / `ring-primary` | `color`, `border-color` (active tab + indicator + focus ring) |
| `--color-text-default` | `text-text` | `color` (panel body + inactive hover) |
| `--color-text-muted` | `text-muted` | `color` (inactive tab label) |
| `--color-neutral-300` | `border-neutral-300` | `border-color` (tablist dividing rule) |
| `--stroke-width-1` | `border-b` / `border-r` | `border-width` (indicator + track rule) |
| `--radius-4` | `rounded-sm` | `border-radius` (focus ring corners) |
| `--spacing-16` | `px-4` / `gap-4` | `padding` inline (tab), `gap` (tablist ↔ panel) |
| `--spacing-8` | `py-2` / `gap-2` | `padding` block (tab + panel), `gap` (label internals) |
| `--font-family-base` | `font-base` | `font-family` |
| `--font-weight-regular` | `font-regular` | `font-weight` |
| `--font-size-body` | `text-body` | `font-size` |
| `--line-height-body` | `leading-body` | `line-height` |
| `--opacity-disabled` | `opacity-disabled` | `opacity` (disabled tab) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js`.
No hardcoded values. `flex`, `flex-col`, `flex-row`, `flex-1`, `gap`, and
`transition-colors` are structural/animation utilities, not design values.

---

### Variants

Controlled by `orientation`, which mirrors the Figma `tabs/top` and `tabs/left`
sets.

| `orientation` | Layout | Indicator | Tablist rule |
|---|---|---|---|
| `top` (default) | Tablist is a horizontal row above the panel | `border-b border-primary` under the active tab | `border-b border-neutral-300` |
| `left` | Tablist is a vertical column beside the panel | `border-r border-primary` beside the active tab | `border-r border-neutral-300` |

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` (inactive) | `text-muted` label, transparent indicator | Not the active tab |
| `active` | `text-primary` label + 1px `primary` accent indicator | Selected tab |
| `hover` | Inactive label tints to `text-text` | Pointer over an enabled inactive tab |
| `focus` | 2px `primary` focus ring (`ring-offset-2`) | Keyboard focus on the tab |
| `disabled` | Dimmed (`opacity-disabled`), non-interactive, skipped by keyboard | `tab.disabled` |

---

### Sizes

Single intrinsic size. Tab padding (`px-4 py-2`), gap (`gap-2` internal,
`gap-4` tablist ↔ panel), and the 1px indicator/rule are fixed by token. Tabs and
panels grow with content and container width.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `tabs` | `TabItem[]` | — | The tabs to render, in order |
| `orientation` | `'top' \| 'left'` | `'top'` | Tablist placement relative to the panel |
| `defaultTabId` | `string` | first non-disabled tab | Initially active tab (uncontrolled) |
| `onTabChange` | `(id: string) => void` | — | Fired when the active tab changes |
| `className` | `string` | — | Layout overrides only, merged last |
| `...props` | `Omit<HTMLAttributes<HTMLDivElement>, 'onChange'>` | — | Native div attributes spread |

**`TabItem`**

| Field | Type | Default | Description |
|---|---|---|---|
| `id` | `string` | — | Stable unique key; seeds tab/panel element ids |
| `label` | `ReactNode` | — | Tab trigger content |
| `content` | `ReactNode` | — | Panel content, shown when active |
| `disabled` | `boolean` | `false` | Non-interactive, dimmed, skipped by keyboard |

---

### Accessibility

- Full WAI-ARIA Tabs pattern: `role="tablist"` (with `aria-orientation`),
  `role="tab"` buttons, and `role="tabpanel"` regions.
- Each tab exposes `aria-selected`, `aria-controls={panelId}`; each panel is
  `aria-labelledby={tabId}` and `hidden` when inactive.
- Roving `tabindex`: only the active tab is in the tab order (`tabIndex=0`); the
  rest are `-1` and reached with the arrow keys.
- Arrow keys move focus (Left/Right for `top`, Up/Down for `left`), Home/End jump
  to the first/last enabled tab; selection follows focus (automatic activation).
- Disabled tabs use the native `disabled` attribute + `aria-disabled` and are
  skipped by keyboard navigation.
- Visible `primary` focus ring on every tab; panels are focusable (`tabIndex=0`)
  so keyboard users can reach panel content directly.

---

### Do Not

- Do not hardcode colors, spacing, radius, or stroke — reference tokens via Tailwind.
- Do not use `border-b-2` / `border-2` (non-token 2px width) for the indicator.
- Do not remove the focus ring or the roving `tabindex` behavior.
- Do not allow arrow navigation to land on a disabled tab.
- Do not render more than one panel visible at a time.

---

### Implementation Tasks

- [x] Create `src/components/sections/tabs.variants.ts` (CVA: `tabsVariants`, `tabListVariants`, `tabVariants`)
- [x] Create `src/components/sections/Tabs.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Export `TabItem` and `TabsProps` types
- [x] Render `role="tablist"` with `aria-orientation` and `role="tab"` buttons
- [x] Wire `aria-selected`, `aria-controls`, roving `tabindex`, and `disabled` handling
- [x] Render `role="tabpanel"` regions with `aria-labelledby`, `hidden`, and `tabIndex=0`
- [x] Support `orientation` (top/left) with token-only 1px active indicator
- [x] Seed uncontrolled state from `defaultTabId` (fallback first non-disabled)
- [x] Verify token-only styling and `tsc` passes
