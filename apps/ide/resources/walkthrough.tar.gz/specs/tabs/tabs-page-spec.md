# Tabs — Usage / Composition Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./tabs-component-spec.md

This documents how the `Tabs` organism composes into higher-order layouts and
screens.

---

### Purpose

Partition related content into a single, space-efficient region where only one
section is visible at a time — settings groups, documentation sections, product
detail panes, or the `tabs/top` / `tabs/left` navigation containers. Keeps screens
scannable while giving the user fast, keyboard-friendly access to each section.

---

### Component Inventory

| Component | Role |
|---|---|
| `Tabs` | Container rendering the tablist and swappable panels |
| `role="tab"` buttons | The tab triggers (built in) |
| `role="tabpanel"` regions | The content panels (built in) |

---

### Consumed By

| Consumer | Usage |
|---|---|
| Settings screens | Group preferences into tabbed sections (`orientation="left"`) |
| Documentation | Code/preview or platform switches (`orientation="top"`) |
| Detail views | Overview / Reviews / Specs panes for a single entity |

---

### Usage

```tsx
import { Tabs, type TabItem } from '@/components';

const items: TabItem[] = [
  { id: 'overview', label: 'Overview', content: <p>Overview content.</p> },
  { id: 'specs', label: 'Specs', content: <p>Specifications.</p> },
  { id: 'reviews', label: 'Reviews', content: <p>Customer reviews.</p>, disabled: true },
];

// Top orientation (default) — horizontal tab row above the panel
<Tabs tabs={items} className="max-w-2xl" />

// Left orientation — vertical tab column beside the panel
<Tabs
  tabs={items}
  orientation="left"
  defaultTabId="specs"
  onTabChange={(id) => console.log('active tab:', id)}
/>
```

---

### Composition Rules

- Keep `label` short and scannable; put the detail in `content`.
- Layout (margin, `max-width`, placement) is applied via `className`; the
  container owns its internal padding, gaps, and the tablist rule.
- Choose `orientation="left"` when there are many tabs or long labels; `top` for a
  few short labels.
- Reserve `disabled` for tabs that are contextually unavailable — do not hide them
  if their existence is meaningful.
- Provide a `defaultTabId` when a tab other than the first should open initially.

---

### Responsive

| Viewport | Behavior |
|---|---|
| 375 / 768 / 1440 | Container fills its width. `top`: tablist stacks above the panel. `left`: tablist column beside a `flex-1` panel. Padding, gap, and the 1px rule stay fixed by token; labels and panel content reflow. |

---

### Accessibility

- Full WAI-ARIA Tabs pattern — `role="tablist"`/`tab`/`tabpanel`, `aria-selected`,
  `aria-controls`/`aria-labelledby`, roving `tabindex`, and arrow/Home/End keys.
- Selection follows focus (automatic activation); disabled tabs are skipped.
- Ensure a visible focus ring on every tab; panels are reachable via `Tab`.

---

### Implementation Tasks

- [x] Verify Tabs composes into settings/detail layouts with correct spacing
- [x] Verify `orientation` toggles between top (row) and left (column) layouts
- [x] Verify `defaultTabId` and `disabled` tabs render and behave correctly
- [x] Verify arrow/Home/End keyboard navigation and visible focus ring
