# Adversarial Review — Tabs
Date: 2026-07-07

## Verdict: PASS

The full WAI-ARIA Tabs pattern — including roving tabindex and arrow/Home/End navigation with
automatic activation and disabled-skipping — is **actually implemented, not assumed**. All token-backed.
No Blocker, Major, or Minor findings.

## Findings

| Severity | Area | Issue | Status |
|---|---|---|---|
| — | — | None. | — |

### Border check (highest-value)
- `tabs.variants.ts:34-35` tablist rule: `border-b border-neutral-300` (top) / `border-r border-neutral-300` (left) — colored ✓
- `tabs.variants.ts:52-57` tab indicator: `border-b`/`border-r` (side/width) always paired with an explicit color — `active → border-primary`, inactive → `border-transparent`. No side/width ever renders without a color class, so no Preflight gray-200 leak. ✓

## WAI-ARIA pattern (red-teamed — is it real?)
- `role="tablist"` with `aria-orientation` (`horizontal` top / `vertical` left) — ✓ (`Tabs.tsx:97-98`)
- `role="tab"` buttons with `aria-selected`, `aria-controls={panelId}`, `id={tabId}` — ✓ (`Tabs.tsx:105-114`)
- `role="tabpanel"` with `aria-labelledby={tabId}`, `hidden={!selected}`, `tabIndex=0` — ✓ (`Tabs.tsx:135-142`)
- **Roving tabindex**: `tabIndex={selected ? 0 : -1}` — ✓ (`Tabs.tsx:115`), exactly one tab stop
- **Arrow-key nav REALLY implemented**: `handleKeyDown` (`Tabs.tsx:63-92`) builds the enabled-index list, maps orientation→axis (Left/Right vs Up/Down), wraps modulo enabled length, handles Home/End, `preventDefault()`s, and calls `activate()` — **automatic activation** (focus + selection move together, `Tabs.tsx:52-61`) — ✓
- **Disabled skipping**: enabled list excludes `tab.disabled`; `activate` guards `if (!tab || tab.disabled) return`; disabled tab gets native `disabled` + `aria-disabled` — ✓
- Only one panel visible at a time (`hidden` on the rest) — ✓; panels focusable with visible ring — ✓

## Architecture Validation
- `.variants.ts` colocated — ✓ (`tabsVariants`, `tabListVariants`, `tabVariants`)
- CVA mirrors spec 1:1 — ✓ (orientation top/left; tab active/disabled/orientation axes = spec States/Variants)
- `defaultVariants` match spec default — ✓ (`orientation: 'top'`, `active: false`, `disabled: false`)
- `forwardRef` — ✓ (`forwardRef<HTMLDivElement>`)
- native attrs spread `...props` — ✓ (`Omit<…,'onChange'>`)
- `className` merged LAST via `cn()` — ✓ (`cn(tabsVariants({ orientation }), className)`)
- `VariantProps` exported — ✓ (`TabsVariants`)
- no inline `style={{}}` for DS values — ✓ (1px indicator via token `border-b`/`border-r`, not `border-2`, per spec Do-Not)
- Inactive tab uses `text-muted` → `--color-text-muted` via the `muted` alias (`tailwind.config.js:50`) — resolves ✓

## Resolved During Review
(none — read-only)

## Notes
Runtime dims (responsive 375/768/1440, axe, screen-reader) NOT executable: no browser driver, Vite `:5173`
down. Source-analyzed responsive: `top` = tablist row above panel; `left` = tablist column + `flex-1` panel.
Invalid `defaultTabId` (no matching tab) degrades gracefully — arrow nav recovers to first enabled tab.
