# Visual Verify Report — Tabs

- **Design source:** `figma` (Branch A) · **Component:** `Tabs` (organism) · **Date:** 2026-07-07
- **Spec:** `specs/tabs/tabs-component-spec.md` + `tabs-interaction-spec.md` + `tabs-page-spec.md` · **Impl:** `src/components/sections/Tabs.tsx` + `tabs.variants.ts`
- See `specs/visual-verify-report.md` for shared context and the runtime-check environment limitation.

## Result: PASS (source-of-truth) — 0 open source-level discrepancies

Every spec Implementation Task (component + interaction) is checked. The `orientation` variants
(`top`/`left`), the token-only 1px active indicator (`border-b`/`border-r` + `border-primary`), the
full WAI-ARIA Tabs wiring (`role="tablist"`/`tab`/`tabpanel`, `aria-selected`, `aria-controls`,
`aria-labelledby`, `aria-orientation`, roving `tabindex`, arrow/Home/End with disabled-skip), and every
color/spacing/radius utility resolve to a design token. The one `text-muted` on the inactive-tab label
**now resolves** via the `muted` color alias (systemic defect fixed 2026-07-07 — see below). The two
runtime dimensions (live-viewport pixel + axe) remain **open** — no render harness in this env.

## ⚠️ Runtime dimensions NOT executed (environment limit)

No browser driver (Playwright/Puppeteer/axe are NOT installed) and the Vite dev server on `:5173` is
DOWN, so the Figma-flow **live-viewport pixel comparison (375/768/1440px)** and the **runtime axe
audit** (which would exercise the roving-tabindex keyboard model) CANNOT be executed and their results
are NOT asserted. Everything below is a **source-of-truth verification** (spec ↔ code ↔ token model),
authoritative for the token, variant, state-wiring, and semantic/ARIA dimensions.

## Checklist (source-verified)

### Variants ✓
`orientation` axis (`top` default / `left`) drives three CVAs (`tabs.variants.ts`): `tabsVariants`
(`flex-col`/`flex-row`), `tabListVariants` (`border-b`/`border-r` + `border-neutral-300` rule), and
`tabVariants` (`border-b`/`border-r` indicator side). Matches the spec `top`/`left` table exactly. ✓

### States ✓
| State (`tabVariants`) | Class → token | OK |
|---|---|---|
| `active` | `text-primary border-primary` → `--theme-primary` | ✓ |
| `default` (inactive) | `text-muted border-transparent` → `--color-text-muted` (via alias) | ✓ |
| `hover` (inactive) | `hover:text-text` → `--color-text-default` | ✓ |
| `focus` | `focus-visible:ring-2 ring-primary ring-offset-2` → `--theme-primary` | ✓ |
| `disabled` | `opacity-disabled pointer-events-none` + native `disabled` → `--opacity-disabled` | ✓ |

### Tokens — utility → token
| Utility | → token | OK |
|---|---|---|
| `px-4` / `py-2` (tab) | `--spacing-16` / `--spacing-8` | ✓ |
| `gap-2` (tab internals) / `gap-4` (container) | `--spacing-8` / `--spacing-16` | ✓ |
| `border-b` / `border-r` (indicator + rule) | `--stroke-width-1` (1px — no `border-2`) | ✓ |
| `border-neutral-300` (tablist rule) | `--color-neutral-300` | ✓ |
| `border-primary` (active indicator) | `--theme-primary` | ✓ |
| `rounded-sm` | `--radius-4` | ✓ |
| `font-base` / `font-regular` / `text-body` / `leading-body` | family / weight / size / line-height | ✓ |
| `text-text` (panel body, `Tabs.tsx:142`) | `--color-text-default` | ✓ |
| `text-muted` (inactive label, `tabs.variants.ts:57`) | `--color-text-muted` via `muted` alias | ✓ |
| `flex` / `flex-col` / `flex-row` / `flex-1` / `whitespace-nowrap` / `transition-colors` | structural | ✓ |

### Accessibility ✓
Full WAI-ARIA Tabs: `role="tablist"` with `aria-orientation` (`horizontal`/`vertical`), `role="tab"`
buttons carrying `aria-selected`, `aria-controls`, `id`, roving `tabIndex` (active 0 / rest -1), native
`disabled` + `aria-disabled`; `role="tabpanel"` regions with `aria-labelledby`, `hidden` when inactive,
and `tabIndex=0`. Ids seeded from `React.useId()` (SSR-safe, unique). Arrow/Home/End navigation skips
disabled tabs and wraps; selection follows focus. Matches spec A11y + keyboard tables. ✓

### Token audit (static, zero tolerance)
Grep for `#hex` / `rgb(` / `hsl(` / `style={{` / `[..px]` / default-palette color classes → **0 hits**.
All spacing keys used (`4`, `2` → mapped) are in the allow-list. Indicator is 1px (`border-b`/`border-r`),
never the forbidden `border-2`. No unmapped fixed-dimension (`w-<n>`/`h-<n>`) sizing keys.

## Resolved (do NOT flag)

- **`text-muted` (inactive tab label) — RESOLVED.** `tabs.variants.ts:57` uses `text-muted`, which was
  a dead class until the 2026-07-07 fix added `colors.muted: 'var(--color-text-muted)'` at
  `tailwind.config.js:50`. It now emits `.text-muted { color: var(--color-text-muted) }`. Token
  dimension **PASS**. No source change needed in Tabs.

## Observations (non-blocking)

- **O-A — automatic activation is intentional.** Selection follows focus (arrow keys activate on move),
  matching the interaction spec ("automatic activation"). This is a deliberate WAI-ARIA choice, not a
  gap versus manual-activation tab patterns.

## Gate
**Token · variant · state · semantic/ARIA dimensions: PASSED** — 0 open source-level discrepancies
(`text-muted` resolved via alias).
**Runtime dimensions (live-viewport pixel + axe): still not executable** in this environment.
