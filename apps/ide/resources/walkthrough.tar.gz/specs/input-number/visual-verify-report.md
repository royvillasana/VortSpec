# Visual Verify Report — InputNumber

- **Component:** `InputNumber` (molecule) · **Design source:** `figma` (`ojko9pGfsDAvmUf2DA38d2`) · **Date:** 2026-07-07
- **Spec:** `specs/input-number/input-number-component-spec.md` + `input-number-interaction-spec.md`
- **Impl:** `src/components/modules/InputNumber.tsx` + `input-number.variants.ts`

## Live-rendered? No — no Storybook story for InputNumber.
Runtime pixel (375/768/1440) and axe are **not executable — verified from source**, NOT "failed".

## Checklist (source-verified)

### Variants — ✓
- `size`: input `px-2 py-1` / `px-2.5 py-2` / `px-3 py-2.5`, steppers `Button size` mirrored — matches spec.
- `invalid`: `border-danger focus-visible:ring-danger` / `ring-primary`, auto-set from `error` (`isInvalid = invalid ?? hasError`) — matches.
- `defaultVariants`: medium / invalid:false — matches.

### States — ✓
default, focus (`ring-2 ring-offset-2`), invalid (danger border/ring + danger description text),
disabled (`opacity-disabled bg-neutral-100 cursor-not-allowed`, both steppers disabled),
at-min / at-max (steppers disabled at bounds via `atMin`/`atMax`). Clamp on step; native-setter dispatch so
React `onChange` fires; controlled + uncontrolled modes both handled.

### Tokens — ✓
`bg-white`/`bg-neutral-100`, `border-neutral-300`/`border-1`, `rounded`, `text-text`/`text-danger`/`text-muted`,
`ring-primary`/`ring-danger`, spacing `gap-1.5`(wrapper)/`gap-1`(group)/`min-w-0`, `px/py` keys `2/2.5/3` + `1/2/2.5`,
`text-body`/`font-base`/`font-regular`/`leading-body`/`opacity-disabled`. All mapped. Stepper sizing inherits
already-token-verified `buttonVariants`. `duration-150 ease-out` = timing, allowed.

### Token audit — ✓
Zero matches across `InputNumber.tsx` + `input-number.variants.ts`.

### Accessibility (source) — ✓
Native `<input type="number">` (arrow-key stepping); `<label htmlFor>` ↔ `id` (`useId` fallback);
**stepper buttons carry `aria-label` "Decrease" / "Increase"** and `tabIndex={-1}` (per spec — keyboard users
step via the native input, not by tabbing 3 controls); `aria-invalid` auto; single description `<p id>` linked
via `aria-describedby` with `error` precedence over `hint` — the referenced node is always rendered when
`description` exists → **no dangling idref**; required `*` `aria-hidden`; visible focus ring.

### Architecture — ✓
`.variants.ts` colocated; CVA mirrors spec; `forwardRef` (merged-ref to expose the input); `...props` spread on
`<input>`; `className` merged LAST on wrapper via `cn()`; `VariantProps` exported; no inline `style={{}}`.

### Interaction spec — ✓
Step/clamp/bounds, native onChange + onValueChange, disabled steppers, focus ring — all satisfied.

## Discrepancies
None. No fixes applied.

## Gate: **PASS** — zero unresolved source-level discrepancies. Runtime pixel/axe not executable (no story).
