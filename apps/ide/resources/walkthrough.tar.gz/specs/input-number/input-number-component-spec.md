# InputNumber — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

InputNumber is a numeric stepper form field. It composes a decrement `Button`, a
native `<input type="number">`, and an increment `Button` into one inline group,
with an optional label and hint/error text. It captures a bounded numeric value:
users type directly, use the native arrow keys, or click the `−` / `+` steppers.
It shares the label / hint / error / ARIA pattern of the Input molecule and is
distinct from a free-text Input in that its value is always numeric and bounded by
`min` / `max` / `step`.

---

### Composed Atoms

| Atom | Role |
|---|---|
| `Button` (`variant="light"`, `iconOnly`) | Decrement (`−`) and increment (`+`) steppers, sized to match |
| `Icon` (`dash`, `plus`) | Glyphs inside the stepper buttons (decorative) |
| Native `<input type="number">` | The numeric value control at the center of the group |

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-white` | `#ffffff` | `background-color` (input, default) |
| `--color-neutral-100` | `#f8f9fa` | `background-color` (input disabled) + stepper surface |
| `--color-neutral-300` | `#dee2e6` | `border-color` (input, default) |
| `--color-danger` | `#dc3545` | `border-color` + focus ring (invalid); error text; required `*` |
| `--color-primary` | `#0d6efd` | focus ring (default) |
| `--color-text-default` | `#212529` | `color` (label + typed value, `text-text`) |
| `--color-text-muted` | `#6c757d` | `color` (hint text, `text-muted`) |
| `--font-family-base` | Roboto | `font-family` (`font-base`) |
| `--font-size-body` | `16px` | `font-size` (`text-body`) |
| `--font-weight-regular` | `400` | `font-weight` (`font-regular`) |
| `--radius-default` | `rounded` | `border-radius` (input) |
| `--stroke-width-1` | `1px` | `border-width` (`border-1`) |
| `--spacing-4` | `4px` | `gap` (steppers ↔ input, `gap-1`) |
| `--spacing-6` | `6px` | `gap` (label ↔ group ↔ hint, `gap-1.5`) |
| `--opacity-disabled` | — | `opacity` (disabled) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js`
to these CSS variables. No hardcoded values.

---

### Variants

| Property | Values | Description |
|---|---|---|
| `size` | `small` \| `medium` \| `large` | Padding density of the input and the matching stepper buttons |
| `invalid` | `true` \| `false` | Error styling: danger border + danger focus ring, `aria-invalid` (auto-set when `error` is present) |

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | White bg, neutral-300 border | — |
| `focus-visible` | 2px primary ring, offset (danger ring when invalid) | Keyboard focus in the input |
| `invalid` | Danger border + danger focus ring, danger hint text | `invalid` prop or `error` string set |
| `disabled` | `opacity-disabled`, `not-allowed` cursor, neutral-100 input bg, steppers disabled | `disabled` attribute |
| `at-min` | Decrement stepper disabled | current value ≤ `min` |
| `at-max` | Increment stepper disabled | current value ≥ `max` |

---

### Sizes

| Size | Input padding | Stepper button | Font | Radius |
|---|---|---|---|---|
| `small` | `px-2 py-1` | Button `size="small"` (`p-1`) | body 16px | `rounded` |
| `medium` | `px-2.5 py-2` | Button `size="medium"` (`p-1.5`) | body 16px | `rounded` |
| `large` | `px-3 py-2.5` | Button `size="large"` (`p-2`) | body 16px | `rounded` |

The group is `inline-flex items-stretch gap-1`; the input fills the available width
(`w-full min-w-0`) and the steppers hug their glyphs.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `size` | `small \| medium \| large` | `medium` | Padding density (input + steppers) |
| `invalid` | `boolean` | `false` (or `true` when `error` set) | Error styling + `aria-invalid` |
| `label` | `ReactNode` | — | Field label, associated to the input via `htmlFor` |
| `hint` | `string` | — | Helper text below the control (hidden when `error` present) |
| `error` | `string` | — | Error text below the control; sets `aria-invalid` + danger styling |
| `required` | `boolean` | — | Marks the field required; renders a danger `*` after the label |
| `value` | `string \| number` | — | Controlled value |
| `defaultValue` | `string \| number` | — | Uncontrolled initial value |
| `min` / `max` | `number \| string` | — | Bounds; clamp on step and disable the relevant stepper |
| `step` | `number \| string` | `1` | Increment/decrement amount |
| `disabled` | `boolean` | — | Disables the input and both steppers |
| `onChange` | `ChangeEventHandler<HTMLInputElement>` | — | Native change handler (typing, arrow keys, and stepper clicks) |
| `onValueChange` | `(value: number) => void` | — | Convenience callback with the parsed numeric value |
| `id` | `string` | React `useId` fallback | Ties label + hint/error to the input |
| `className` | `string` | — | Layout overrides only, merged last onto the outer wrapper |
| `...props` | `InputHTMLAttributes<HTMLInputElement>` | — | Native input attributes spread (`size`, `onChange` re-typed) |

`forwardRef<HTMLInputElement>` targets the native input.

---

### Accessibility

- Element: semantic native `<input type="number">` — keeps native number semantics and arrow-key stepping.
- Label is associated via `htmlFor` / `id`; `id` falls back to `React.useId()`.
- Stepper buttons carry explicit `aria-label`s (`"Decrease"` / `"Increase"`) and are `tabIndex={-1}` so keyboard users step via the input's native arrow keys rather than tabbing through three controls.
- `aria-invalid` is set automatically when `error` (or `invalid`) is present.
- `aria-describedby` links the input to the hint/error paragraph (`error` takes precedence over `hint`).
- Visible focus indicator: `focus-visible:ring-2` (primary, or danger when invalid) with offset.
- Error/validity is never conveyed by color alone — it is paired with associated `error` text.
- Disabled uses the native `disabled` attribute on the input and both steppers (removed from tab order).

---

### Do Not

- Do not hardcode colors, spacing, radius, or type values — reference tokens via the Tailwind theme.
- Do not use `style={{}}` or arbitrary `[..]` utilities.
- Do not use InputNumber for non-numeric input — use the Input molecule for free text.
- Do not rely on `invalid` alone to convey errors — always pair with a visible, associated `error` string.
- Do not remove the focus ring or the stepper `aria-label`s.
- Do not make the steppers tab stops (keep native arrow-key stepping the primary keyboard path).

---

### Implementation Tasks

- [x] Create `src/components/modules/input-number.variants.ts` (CVA `size`, `invalid`)
- [x] Create `src/components/modules/InputNumber.tsx` (`forwardRef` to input, spreads props, `cn()` last on wrapper)
- [x] Compose two `Button` steppers (`variant="light"`, `iconOnly`, matching `size`) with `dash` / `plus` `Icon`s
- [x] Render styled native `<input type="number">` with `w-full`, token border/bg/text, `text-center`
- [x] Implement `size` (small / medium / large) for input padding + stepper size
- [x] Implement `invalid` — danger border + danger focus ring + `aria-invalid` (auto from `error`)
- [x] Support controlled (`value`) and uncontrolled (`defaultValue`) modes
- [x] Clamp to `min` / `max` and honor `step` on stepper click; disable steppers at bounds
- [x] Fire native `onChange` (via native value setter + input event) and convenience `onValueChange`
- [x] Wire `label` (`htmlFor`), `required` `*`, and hint/error text with `aria-describedby`
- [x] `id` via `React.useId` fallback; focus-visible ring + disabled pattern
- [x] Verify token-only styling and `tsc --noEmit` passes
