# Adversarial Review — InputNumber

Date: 2026-07-07

## Verdict: PASS

Stepper wiring, clamping, controlled/uncontrolled modes, and the single-`description` ARIA path all hold up.
`aria-describedby` points at `descId` only when `description` (= `error ?? hint`) is truthy, and the single
`<p id={descId}>` renders under the exact same condition — the idref always resolves. No dangling idref in any
prop combination (hint+error collapses to error, by design).

## Findings

| Severity | Area | Issue | Status |
|---|---|---|---|
| Info | A11y | Stepper buttons `aria-label` "Decrease"/"Increase", `tabIndex={-1}` — matches spec's deliberate non-tab-stop requirement (native arrow keys are the keyboard path). | Not a defect |
| Minor | Cleanup | `input-number.variants.ts` base lists both `border` and `border-1` (both → `--stroke-width-1`). Redundant, harmless. | Open (cosmetic) |

## Architecture Validation (8 checks)
1. ✓ `.variants.ts` colocated. 2. ✓ CVA mirrors spec (`size`/`invalid`). 3. ✓ `defaultVariants` match spec.
4. ✓ `forwardRef<HTMLInputElement>` via merged ref. 5. ✓ `...props` spread on `<input>`. 6. ✓ `className` merged LAST via `cn()`.
7. ✓ `VariantProps` exported (`InputNumberVariants`). 8. ✓ No inline `style={{}}`.

## Token/Variant/State/A11y checklist
- Token audit: ✓ zero hex/rgb/hsl/px/arbitrary/inline-style.
- Variants: ✓ size + invalid (auto from error). States: ✓ default/focus/invalid/disabled/at-min/at-max.
- A11y: ✓ icon-only steppers labelled, aria-invalid auto, non-dangling describedby, aria-hidden asterisk, visible focus ring.

## Resolved During Review
None — component was already correct.

## Notes
Runtime pixel diff and axe **not executed** (no story). Clamp/bounds/native-setter dispatch verified by source
reading, not runtime. Verified from source (spec ↔ code ↔ token model). `npx tsc --noEmit` exits 0.
