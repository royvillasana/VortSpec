# InputNumber — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./input-number-component-spec.md
**Figma prototype**: form-item input-number — stepper group (Size property; interactive focus/hover/disabled states)

---

### Interaction Overview

InputNumber captures a bounded numeric value through three cooperating paths: the
user can type into the native input, use the native ArrowUp / ArrowDown keys, or
click the `−` / `+` steppers. Every path funnels through the input's native
`onChange`, so consumers get one consistent change signal plus the numeric
convenience callback `onValueChange`. The value is clamped to `min` / `max` when
stepped, and the relevant stepper disables at each bound.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Click `−` | Decrement `Button` | Not disabled and value > `min` |
| Click `+` | Increment `Button` | Not disabled and value < `max` |
| Type digits | Native input | Field focused, not disabled |
| ArrowUp / ArrowDown | Native input | Field focused (native number stepping by `step`) |
| Focus | Native input | Keyboard/pointer focus → focus ring |

---

### Flow

```
Step 1: Component mounts → value initializes from `value` (controlled) or `defaultValue` (uncontrolled); steppers evaluate min/max to set their disabled state.
Step 2: User clicks + / − → handleStep reads the input's current value, adds/subtracts `step`, clamps to [min, max], and writes it back via the native value setter.
Step 3: Writing the value dispatches a native input event → React onChange fires → onChange(event) and onValueChange(parsedNumber) are called; numericValue updates so bound-based stepper disabling re-evaluates.
Step 4: User types or presses ArrowUp/ArrowDown → native onChange fires → same onChange + onValueChange path; typing is left free-form (clamping happens on step).
Step 5: When `error` (or `invalid`) is set → the input shows the danger border/ring, hint text renders in danger, and aria-invalid + aria-describedby link the message.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Border / ring / bg color | 150ms | ease-out | `transition-colors duration-150 ease-out` (input) |
| Stepper bg / filter | 150ms | ease-out | inherited from `Button` (`transition-[background-color,border-color,color,filter]`) |

---

### Animation Details

No bespoke animations. Only the token-driven color transitions on focus/hover/disabled
inherited from the input and the composed `Button` atoms.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| Value at `min`, click `−` | Decrement stepper is disabled; clamp keeps the value at `min` |
| Value at `max`, click `+` | Increment stepper is disabled; clamp keeps the value at `max` |
| Empty / non-numeric input, click a stepper | Base falls back to `min` (or `0`), then steps and clamps |
| `step` other than 1 | Steppers and native arrow keys move by `step` |
| Typing a non-numeric string | Native number input rejects it; no `onValueChange` fires (NaN guarded) |
| `disabled` | Input and both steppers are inert; no change events |
| Controlled without state update | Value reverts on next render (standard controlled behavior) |
| Long / wide value | Input fills the group width (`w-full min-w-0`); steppers keep their size |

---

### Accessibility & Keyboard

| Key / action | Result |
|---|---|
| `Tab` | Moves focus to the native input (steppers are `tabIndex={-1}`, skipped) |
| `ArrowUp` / `ArrowDown` | Native number stepping by `step`, respecting `min` / `max` |
| Type digits / `-` / `.` | Direct numeric entry |
| Click `−` / `+` | Steps the value; buttons announce via `aria-label` (`Decrease` / `Increase`) |
| Focus | Visible `focus-visible` ring (primary, danger when invalid) |

- `aria-invalid` set automatically from `error` / `invalid`; `aria-describedby` points to the hint/error text.
- Errors are always paired with visible, associated text — never color alone.

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | The group fills its container width; the input flexes (`w-full`), steppers keep their intrinsic size. Label, group, and hint stack vertically with fixed `gap-1.5`. |

---

### Implementation Tasks

- [x] Wire `−` / `+` stepper clicks to a clamped step by `step`, honoring `min` / `max`
- [x] Route stepper changes through the native value setter so `onChange` fires natively
- [x] Fire `onValueChange` with the parsed number on every change path
- [x] Support native typing and ArrowUp / ArrowDown stepping (native number semantics)
- [x] Disable the decrement stepper at `min` and the increment stepper at `max`
- [x] Keep steppers out of the tab order (`tabIndex={-1}`) with descriptive `aria-label`s
- [x] Apply danger border/ring + danger hint text and `aria-invalid` when `error`/`invalid`
- [x] Confirm only token-driven color transitions are introduced
