# InputNumber — Usage / Composition Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./input-number-component-spec.md

Molecules have no page of their own; this documents how InputNumber composes into
higher-order components, forms, and screens.

---

### Purpose

Provide a bounded numeric entry control for forms — quantities, counts, prices,
durations, and settings — where increment/decrement affordances and hard limits
(`min` / `max` / `step`) improve accuracy over free-text entry.

---

### Component Inventory

| Element | Component | Notes |
|---|---|---|
| Decrement / increment steppers | `Button` (`variant="light"`, `iconOnly`) | Sized to match `size`; `tabIndex={-1}` |
| Stepper glyphs | `Icon` (`dash`, `plus`) | Decorative |
| Value control | Native `<input type="number">` | Styled via `inputNumberVariants` |
| Label | Native `<label htmlFor>` | Optional; danger `*` when `required` |
| Hint / error | Native `<p>` linked by `aria-describedby` | `error` wins over `hint` |

---

### Consumed By

| Consumer | Usage |
|---|---|
| `Form` (organism) | Quantity, price, and count fields with validation |
| Cart / checkout screens | Item quantity steppers |
| Settings / filter panels | Bounded numeric preferences (page size, range limits) |

---

### Usage Example

```tsx
import { InputNumber } from '@/components/modules/InputNumber';

// Uncontrolled, bounded quantity
<InputNumber
  label="Quantity"
  defaultValue={1}
  min={1}
  max={10}
  step={1}
  hint="Up to 10 per order"
/>

// Controlled with error state
const [qty, setQty] = React.useState(0);
<InputNumber
  label="Seats"
  required
  value={qty}
  min={1}
  onValueChange={setQty}
  error={qty < 1 ? 'Select at least one seat' : undefined}
/>
```

---

### Composition Rules

- Layout (margin, width, grid placement) is applied via `className` on the outer wrapper; the component owns its internal group spacing.
- Prefer `onValueChange` for numeric state; use `onChange` when you need the raw event.
- Always set `min` / `max` when the value is bounded so the steppers disable correctly.
- Pair `error` with the `invalid`/`aria-invalid` styling it triggers — never signal errors by color alone.
- Provide a `label` (or an external label via `id` + `htmlFor`) for every field.

---

### Responsive

| Viewport | Behavior |
|---|---|
| 375 | Group fills container width; input flexes, steppers keep size |
| 768 | Same; typically placed in single-column form rows |
| 1440 | May sit in multi-column form grids via wrapper `className` |

---

### Accessibility

- Every field has an associated label (`htmlFor` / `id`, `id` falls back to `useId`).
- Steppers expose `aria-label`s and stay out of the tab order; keyboard users step via native arrow keys.
- `aria-invalid` + `aria-describedby` connect the control to its error/hint text.
- Visible focus ring is preserved on the input.

---

### Implementation Tasks

- [x] Verify InputNumber composes `Button` + `Icon` + native number input into one inline group
- [x] Verify label / hint / error render and associate correctly (`htmlFor`, `aria-describedby`)
- [x] Verify controlled and uncontrolled usage examples behave as documented
- [x] Verify steppers clamp to `min` / `max` and disable at bounds
- [x] Verify layout overrides apply via wrapper `className` without breaking internal spacing
