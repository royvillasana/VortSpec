# Visual Verify Report — Title

- **Design source:** `figma` (Branch A) · **Component:** `Title` (molecule) · **Date:** 2026-07-07
- **Spec:** `specs/title/title-component-spec.md` + `title-interaction-spec.md` ·
  **Impl:** `src/components/modules/Title.tsx` + `title.variants.ts` · **Composes:** `Icon` atom (slots)
- See `specs/visual-verify-report.md` for shared context and the runtime-check environment limitation.

## Result: PASS (source-of-truth) — 0 open source-level discrepancies

All spec tasks are checked. Static presentational molecule; every token, the `level` (1–6) →
`hN`/`text-hN` mapping, the `fillContainer` variant, the slot composition, and heading semantics are
verified against the specs and the token map. The two runtime dimensions (live-viewport pixel
comparison + axe) remain open — no render harness in this env (see below).

---

## ⚠️ Runtime dimensions NOT executed (environment limit)

This environment has NO browser driver (Playwright/Puppeteer NOT installed) and no render harness
for this component, so the Figma-flow **live-viewport pixel comparison (375 / 768 / 1440px)** and
**runtime axe audit** CANNOT be executed and are NOT asserted. Everything below is a
**source-of-truth verification** (spec ↔ code ↔ token model), authoritative for
token/variant/state-wiring/ARIA dimensions. To close runtime dims: install a browser driver +
Storybook/harness, screenshot each viewport vs the Figma frame, and run axe-core.

---

## Checklist (source-verified)

### Variants ✓
`level` drives both the semantic tag and the size token (1:1), plus a `fillContainer` width axis.

| `level` | Tag (`h${level}`) | Size class → token | OK |
|---|---|---|---|
| 1 | `<h1>` | `text-h1` → `--font-size-h1` (40px) | ✓ |
| 2 (default) | `<h2>` | `text-h2` → `--font-size-h2` (32px) | ✓ |
| 3 | `<h3>` | `text-h3` → `--font-size-h3` (28px) | ✓ |
| 4 | `<h4>` | `text-h4` → `--font-size-h4` (24px) | ✓ |
| 5 | `<h5>` | `text-h5` → `--font-size-h5` (20px) | ✓ |
| 6 | `<h6>` | `text-h6` → `--font-size-h6` (16px) | ✓ |
| fillContainer true | — | `w-full` (structural) | ✓ |

`titleHeadingVariants` default `level: '2'`; component default `level = 2` — consistent ✓.

### States ✓
Static molecule — only `default`. Interaction spec confirms no interactions, no transitions.
Nothing in the code adds hover/focus/transition. Correct (not a gap). Any interactivity comes from
consumer-supplied `badge`/icon slot nodes, not from Title itself ✓.

### Slots ✓
`leadingIcon`, heading (`children`), `badge`, `trailingIcon` rendered in a `flex items-center gap-2`
row; `subtitle` rendered as a sibling `<span>` below. All four slots present and correctly ordered
per the interaction-spec flow ✓.

### Tokens ✓
| Slot | Utility | → token | OK |
|---|---|---|---|
| heading row | `gap-2` | `--spacing-8` | ✓ |
| wrapper | `gap-1` | `--spacing-4` | ✓ |
| heading | `font-base` / `font-regular` | base family / regular weight | ✓ |
| heading | `leading-heading` | `--line-height-heading` | ✓ |
| heading | `text-text` | `--color-text-default` | ✓ |
| heading | `text-h1`…`text-h6` | `--font-size-h1`…`h6` | ✓ |
| subtitle | `text-body` / `leading-body` | body size / body leading | ✓ |
| subtitle | `text-secondary` | `--theme-secondary` (#e07b39) | ✓ |

`m-0` on the heading resets UA margin (structural) ✓. `w-full` (fillContainer) is structural ✓.

### Accessibility ✓
- Renders a real `<hN>` element (`h${level}`) so heading hierarchy is preserved for AT ✓.
- Subtitle is a sibling `<span>`, not inside the heading — announced separately (per "Do Not") ✓.
- Icon slots are visual; consumer supplies `aria-label` when meaningful (documented in spec) ✓.

### Token audit ✓
Zero hardcoded hex / `px`; zero inline `style={{}}`; zero arbitrary `[..]`. Every utility resolves to
a `var(--…)` via `tailwind.config.js`.

---

## Observations (non-blocking)

- **O-A — `level` string-cast.** `titleHeadingVariants({ level: String(level) as '1' })` casts the
  numeric `level` to the CVA string key with an `as '1'` assertion. Functionally correct across all
  six levels (the CVA map has keys `'1'`–`'6'`); the `as '1'` is a loose type assertion only —
  cosmetic. No runtime impact.

## Gate

**Token · variant · state · semantic/ARIA dimensions: PASSED** — 0 open source-level discrepancies.
**Runtime dimensions (live-viewport pixel + axe): still not executable** in this environment.
