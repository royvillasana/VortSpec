# Title — Component Spec

**Version**: 1.0
**Status**: Implemented
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Section-level heading molecule that pairs a semantic heading (`h1`–`h6`) with an optional subtitle, inline badge, and leading/trailing icons — used to label content regions inside cards, panels, and screen sections.

---

### Composed Atoms

| Atom | Role |
|---|---|
| `Icon` | Rendered via `leadingIcon` / `trailingIcon` slots (inherits color) |
| Heading typography | `hN` styled with the `text-hN` type token via `titleHeadingVariants` |
| Inline text | Subtitle span using the body + secondary theme tokens |

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--font-family-base` | Roboto | `font-family` (`font-base`) |
| `--font-size-h1` | `40px` | `font-size` (`text-h1`, level 1) |
| `--font-size-h2` | `32px` | `font-size` (`text-h2`, level 2) |
| `--font-size-h3` | `28px` | `font-size` (`text-h3`, level 3) |
| `--font-size-h4` | `24px` | `font-size` (`text-h4`, level 4) |
| `--font-size-h5` | `20px` | `font-size` (`text-h5`, level 5) |
| `--font-size-h6` | `16px` | `font-size` (`text-h6`, level 6) |
| `--font-size-body` | `16px` | `font-size` (subtitle, `text-body`) |
| `--font-weight-regular` | `400` | `font-weight` (`font-regular`) |
| `--line-height-heading` | `1.2` | `line-height` (`leading-heading`) |
| `--line-height-body` | `1.5` | `line-height` (`leading-body`, subtitle) |
| `--theme-secondary` | `#e07b39` | `color` (subtitle, `text-secondary`) |
| `--color-text-default` | `#212529` | `color` (heading, `text`) |
| `--spacing-8` | `8px` | `gap` (`gap-2` between heading row items) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js` to these CSS variables. No hardcoded values.

---

### Variants

`Title` has no color variants — its appearance is driven by the `level` prop (1–6), which maps 1:1 to a semantic tag and a matching type-size token.

| `level` | Tag | Size token |
|---|---|---|
| `1` | `<h1>` | `text-h1` (40px) |
| `2` (default) | `<h2>` | `text-h2` (32px) |
| `3` | `<h3>` | `text-h3` (28px) |
| `4` | `<h4>` | `text-h4` (24px) |
| `5` | `<h5>` | `text-h5` (20px) |
| `6` | `<h6>` | `text-h6` (16px) |

`fillContainer` (boolean) applies `w-full` so the wrapper spans its parent.

---

### States

`Title` is a static presentational molecule — it has no interactive states.

| State | Visual Change | Trigger |
|---|---|---|
| `default` | Base appearance | — |

---

### Sizes

Size is expressed through `level` (see Variants). There is no separate size prop.

| `level` | Font | Line height |
|---|---|---|
| `1`–`6` | `text-h1`…`text-h6` | `leading-heading` (1.2) |

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `level` | `1 \| 2 \| 3 \| 4 \| 5 \| 6` | `2` | Semantic tag + type-size token |
| `subtitle` | `ReactNode` | — | Rendered below the heading in `text-secondary` |
| `badge` | `ReactNode` | — | Inline node after the heading text |
| `leadingIcon` | `ReactNode` | — | Icon before the heading (`Icon` atom) |
| `trailingIcon` | `ReactNode` | — | Icon after the badge (`Icon` atom) |
| `fillContainer` | `boolean` | `false` | Wrapper spans full width (`w-full`) |
| `className` | `string` | — | Layout overrides only, merged last |
| `...props` | `HTMLAttributes<HTMLDivElement>` | — | Native div attributes spread (`title` omitted) |

---

### Content Rules

- Heading text: concise section label, sentence case, no trailing period.
- Subtitle: one supporting line; keep to a single sentence.
- Badge: short status/count token, placed after the heading.
- Icons: decorative by default — provide an accessible label if meaningful.

---

### Accessibility

- Renders a real `<hN>` element so heading hierarchy is preserved for assistive tech.
- Choose `level` to match document outline order — do not pick a level purely for size.
- Icon slots are visual; if an icon conveys meaning, the consumer supplies an `aria-label`.
- Subtitle is a sibling `<span>`, not part of the heading text, so it is announced separately.

---

### Do Not

- Do not hardcode colors, spacing, or type sizes — reference tokens via Tailwind theme.
- Do not skip heading levels to achieve a visual size (use CSS, keep semantics correct).
- Do not place block-level content inside the badge or icon slots.

---

### Implementation Tasks

- [x] Create `src/components/modules/title.variants.ts` (CVA: `titleVariants`, `titleHeadingVariants`)
- [x] Create `src/components/modules/Title.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Map `level` 1–6 → `hN` tag + `text-hN` token
- [x] Implement `subtitle`, `badge`, `leadingIcon`, `trailingIcon` slots
- [x] Implement `fillContainer` (`w-full`)
- [x] Compose `Icon` atom in icon slots
- [x] Verify heading semantics + token-only styling
