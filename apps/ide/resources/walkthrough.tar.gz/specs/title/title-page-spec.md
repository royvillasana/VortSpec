# Title — Usage / Composition Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./title-component-spec.md

Molecules have no page of their own; this documents how Title composes into higher-order components and screens.

---

### Consumed By

| Consumer | Usage |
|---|---|
| `Card` (molecule) | Section header inside the card body |
| `Header` (organism) | Section/region labels |
| Screens | Titling content regions, panels, and list sections |

---

### Composition Rules

- Pick `level` to fit the document outline, not to hit a target size — size follows the token.
- Layout (margin, width, alignment) is applied via `className`; the wrapper owns the `gap-2` heading row.
- Icon slots take the `Icon` atom; badge takes a `Badge` atom or inline node.
- Use `fillContainer` when the title must align to a full-width column edge.

---

### Accessibility

- Preserve a single `h1` per screen; use `Title level={2..6}` for nested sections.
- Ensure icon/badge content that conveys meaning carries an accessible name.

---

### Implementation Tasks

- [x] Verify Title renders inside Card with correct heading level
- [x] Verify icon + badge slots align with heading at all levels
- [x] Verify `fillContainer` aligns title to column width
