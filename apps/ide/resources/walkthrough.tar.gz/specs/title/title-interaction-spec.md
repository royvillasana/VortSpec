# Title — Interaction Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./title-component-spec.md
**Figma prototype**: Titles page — static (no prototype states)

---

### Interaction Overview

`Title` is a static presentational molecule. It renders a heading with optional subtitle, badge, and icons, and exposes no user interaction of its own — any interactivity comes from nodes passed into the badge/icon slots.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| — | — | No native interactions; renders statically |

---

### Flow

```
Step 1: Component mounts → wrapper <div> renders the heading row (leadingIcon, hN, badge, trailingIcon).
Step 2: If subtitle is provided → a secondary-colored <span> renders below the heading row.
Step 3: If fillContainer is true → wrapper takes w-full; otherwise it hugs content.
Step 4: No state changes occur after mount; the component is fully declarative.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| — | — | — | No transitions (static molecule) |

---

### Animation Details

None. `Title` renders no animations or transitions.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| No `subtitle` | Subtitle span is not rendered |
| No `badge` / icons | Slots are simply empty; heading row still centers via `gap-2` |
| Interactive node in badge slot | Its own interactivity applies; `Title` adds nothing |
| Long heading text | Wraps naturally at `leading-heading` (1.2) |

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Intrinsic width by default; spans full width only when `fillContainer` is set or `className="w-full"` is passed. Type sizes are fixed per `level`. |

---

### Implementation Tasks

- [x] Render heading row with icon/badge slots (`gap-2`)
- [x] Conditionally render subtitle span
- [x] Apply `fillContainer` width behavior
- [x] Confirm no transitions/animations are introduced
