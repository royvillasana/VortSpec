# Visual Verify Report — Button

**Component**: Button
**Design source**: Figma (Branch A — figma authoritative)
**Date**: 2026-07-07
**Verifier**: /visual-verify
**Method note**: No browser-automation/screenshot tool exists in this environment. Verification is **source-of-truth**: implementation code (`Button.tsx`, `button.variants.ts`) and the Tailwind→token mapping (`tailwind.config.js` → `src/styles/tokens.css`) evaluated against the spec files (which codify the Figma design). No pixel screenshots were produced or claimed.

---

## Files verified

- `specs/button/button-component-spec.md`, `button-interaction-spec.md`, `button-page-spec.md`
- `src/components/ui/Button.tsx`
- `src/components/ui/button.variants.ts`
- `tailwind.config.js`, `src/styles/tokens.css`, `src/lib/utils.ts`

---

## Per-viewport results (375 / 768 / 1440)

Button is intrinsic auto-width at all breakpoints (interaction spec: "Intrinsic auto-width; full-width only when consumer passes `className='w-full'`"). No viewport-conditional styles exist in the component, so behavior is identical across 375/768/1440 and correct per spec.

| Check | 375 | 768 | 1440 |
|---|---|---|---|
| Auto-width, no forced full-width | ✓ | ✓ | ✓ |
| Padding/gap stable across viewports | ✓ | ✓ | ✓ |
| No overflow / no responsive regressions | ✓ | ✓ | ✓ |

## Variants (Figma "Type" — 10 values)

| Variant | Present | Fill/label → token | Result |
|---|---|---|---|
| base | ✓ | `bg-neutral-600` / `text-white` | ✓ |
| primary (default) | ✓ | `bg-primary` / `text-white` | ✓ |
| secondary | ✓ | `bg-secondary` / `text-white` | ✓ |
| success | ✓ | `bg-success` / `text-white` | ✓ |
| danger | ✓ | `bg-danger` / `text-white` | ✓ |
| warning | ✓ | `bg-warning` / `text-near-black` | ✓ |
| info | ✓ | `bg-info` / `text-near-black` | ✓ |
| light | ✓ | `bg-neutral-100` / `text-near-black` | ✓ |
| dark | ✓ | `bg-near-black` / `text-white` | ✓ |
| link | ✓ | `bg-transparent` / `text-primary` underline-on-hover | ✓ |
| `outline` (boolean, inverts solids; no-op for link) | ✓ | 9 compound variants | ✓ |

## Sizes

| Size | V pad | H pad | Radius | Token classes | Result |
|---|---|---|---|---|---|
| small | `py-1`=spacing-4 (4px) | `px-2`=spacing-8 (8px) | `rounded-sm`=radius-4 | ✓ | ✓ |
| medium | `py-1.5`=spacing-6 (6px) | `px-3`=spacing-12 (12px) | `rounded`=radius-8 | ✓ | ✓ |
| large | `py-2`=spacing-8 (8px) | `px-4`=spacing-16 (16px) | `rounded`=radius-8 | ✓ | ✓ |
| iconOnly | symmetric `p-1`/`p-1.5`/`p-2` + `aspect-square` | | | ✓ | ✓ |

## States

| State | Spec | Implementation | Result |
|---|---|---|---|
| default | base appearance | base variant classes | ✓ |
| hover | primary→hover token; others brightness-95; outline fills | `hover:bg-primary-hover`; `hover:brightness-95`; compound `hover:bg-*` | ✓ |
| focus | 2px ring `--theme-primary` offset 2px | `focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2` | ✓ |
| active | primary→hover token; others brightness-90 | `active:bg-primary-hover`; `active:brightness-90` | ✓ |
| disabled | opacity 0.65, pointer-events none, aria-disabled | `disabled:opacity-disabled disabled:pointer-events-none`; `aria-disabled` | ✓ |
| loading / error | n/a (no such prop in spec) | — | n/a |

## Token resolution audit

| Category | Utilities → token | Result |
|---|---|---|
| Colors | `bg-*`, `text-*`, `border-*` → `var(--theme-*)`/`var(--color-*)`/`var(--primitive-*)` | ✓ |
| Spacing | `px-*`/`py-*`/`p-*`/`gap-2` → `var(--spacing-*)` | ✓ |
| Radius | `rounded-sm`/`rounded` → `var(--radius-4)`/`var(--radius-8)` | ✓ |
| Border width | `border`/`border-1` → `var(--stroke-width-1)` | ✓ |
| Font | `font-base`/`font-regular`/`text-body` → `var(--font-family-base)`/`var(--font-weight-regular)`/`var(--font-size-body)` | ✓ |
| Opacity | `opacity-disabled` → `var(--opacity-disabled)` | ✓ |
| Shadow | none used (button has no shadow in spec) | n/a |

## Accessibility

| Check | Result |
|---|---|
| Semantic native `<button>` | ✓ |
| Default `type="button"` | ✓ |
| `aria-disabled` mirrors `disabled` | ✓ |
| Visible focus ring, never removed (`focus-visible:ring-2`) | ✓ |
| icon-only requires `aria-label` (DEV warning) | ✓ |
| Native props spread; label via children/aria | ✓ |

## Token audit (grep)

`grep -nE '#[0-9a-fA-F]{3,8}|rgb\(|hsl\(|style=\{\{|\[[0-9]+px\]' Button.tsx button.variants.ts` → **empty** (exit 1). ✓
Sanctioned exceptions checked: no `font-mono`, no raw hex, no inline style. `rounded-full` not used. `border-transparent`/`border` are keyword/token, not hardcoded values. The `transition-[background-color,border-color,color,filter]` arbitrary value is a property list (no px/hex) — allowed.

---

## Discrepancies

| # | Found | Authoritative | Fix applied | Status |
|---|---|---|---|---|
| 1 | Spec annotated medium padding as 7px/13px (`--spacing-6`/`--spacing-12`); tokens.css was corrected to 6px/12px on 2026-07-06. Code references the tokens (`py-1.5`/`px-3`), so it renders 6px/12px correctly. | tokens.css (dated correction) | Updated stale px annotations in `button-component-spec.md` (Design Tokens table + Sizes table). No code change needed — code is token-referenced. | RESOLVED |
| 2 | Outline `base` compound variant omitted `hover:brightness-100`, so it dimmed 5% on hover (`hover:brightness-95` from base leaked through) while the other 8 outline solids neutralize it. | Internal consistency / code | Added `hover:brightness-100` to the `base`+`outline` compound variant in `button.variants.ts`. | RESOLVED |
| 3 | `dark` variant uses `hover:brightness-125 active:brightness-150` (lightens) instead of the spec's generic "others darken via brightness-95/90". | Code (intentional) | No change — darkening near-black (#1a1916) is imperceptible; brightening gives visible feedback. Documented deviation, accepted. | ACCEPTED |

---

**Result: PASS**
