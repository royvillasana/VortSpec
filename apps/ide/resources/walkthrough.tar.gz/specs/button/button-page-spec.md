# Button — Usage / Composition Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./button-component-spec.md

Atoms have no page of their own; this documents how Button composes into higher-order components and screens.

---

### Consumed By

| Consumer | Usage |
|---|---|
| `Header` (organism) | Primary CTA in the top bar |
| `Callout` (molecule) | Optional action affordance |
| Screens | Any action / navigation trigger |

---

### Composition Rules

- Buttons receive layout (margin, width, grid placement) via `className`, never variant overrides.
- Icon content is a `Icon` atom placed in `children`; gap is owned by the button (`gap` = `--spacing-8`).
- Never wrap a button in an anchor or nest interactive elements.

---

### Accessibility

- One primary (`variant="primary"`) action per view group.
- Icon-only buttons always carry `aria-label`.

---

### Implementation Tasks

- [x] Verify Button renders inside Header with correct spacing
- [x] Verify Icon child aligns with label at all sizes
