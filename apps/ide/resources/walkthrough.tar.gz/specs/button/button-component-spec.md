# Button — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Frame URL**: Buttons page (node 4:192632)
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Interactive control that triggers an action or navigation. The richest atom in the system — it exercises the full status-color, spacing, radius, stroke, and opacity token set and anchors every other component.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--theme-primary` | `#087990` | `background-color` / `color` / `border-color` |
| `--button-primary-background-hover` | `#066173` | `background-color` (primary hover/active) |
| `--theme-secondary` | `#e07b39` | `background-color` (secondary) |
| `--color-status-success` | `#198754` | `background-color` (success) |
| `--color-status-danger` | `#dc3545` | `background-color` (danger) |
| `--color-status-warning` | `#ffc107` | `background-color` (warning) |
| `--color-status-info` | `#0dcaf0` | `background-color` (info) |
| `--color-status-warning-emphasis` | `#7a6100` | `color` (outline warning label) |
| `--color-status-info-emphasis` | `#0a6c8a` | `color` (outline info label) |
| `--color-neutral-100` | `#f8f9fa` | `background-color` (light) |
| `--color-neutral-600` | `#6c757d` | `background-color` (base) |
| `--primitive-neutral-near-black` | `#1a1916` | `background-color` (dark) / dark label |
| `--primitive-neutral-white` | `#ffffff` | `color` (label on solid) |
| `--color-text-default` | `#212529` | `color` (base/light outline label) |
| `--spacing-4/6/8/10/12/16` | 4/6/8/10/12/16px | `padding` / `gap` |
| `--radius-4` / `--radius-8` | 4px / 8px | `border-radius` |
| `--stroke-width-1` | `1px` | `border-width` |
| `--opacity-disabled` | `0.65` | `opacity` (disabled) |
| `--font-family-base` | Roboto | `font-family` |
| `--font-size-body` | `16px` | `font-size` |
| `--font-weight-regular` | `400` | `font-weight` |

All references are via the Tailwind theme mapping in `tailwind.config.js`, which resolves to these CSS variables. No hardcoded values.

---

### Variants

Mirrors the Figma `Type` property 1:1.

| Variant | Description |
|---|---|
| `base` | Neutral gray fill, white label |
| `primary` | Teal fill, white label (default) |
| `secondary` | Orange fill, white label |
| `success` | Green fill, white label |
| `danger` | Red fill, white label |
| `warning` | Amber fill, near-black label |
| `info` | Cyan fill, near-black label |
| `light` | Light gray fill, near-black label |
| `dark` | Near-black fill, white label |
| `link` | No fill/border, teal underline-on-hover label |

`outline` (boolean) inverts any solid variant: transparent fill, colored border + label, fills on hover. Not applicable to `link`.

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | Base appearance | — |
| `hover` | Primary → `--button-primary-background-hover`; others darken via `brightness-95`; outline fills | Mouse enter |
| `focus` | 2px ring in `--theme-primary`, offset 2px | Keyboard focus |
| `active` | Primary → hover token; others `brightness-90` | Mouse down |
| `disabled` | `--opacity-disabled` (0.65), `pointer-events: none` | `disabled` prop |

---

### Sizes

| Size | Padding V | Padding H | Radius | Font |
|---|---|---|---|---|
| `small` | 4px (`--spacing-4`) | 8px (`--spacing-8`) | 4px (`--radius-4`) | body |
| `medium` | 6px (`--spacing-6`) | 12px (`--spacing-12`) | 8px (`--radius-8`) | body |
| `large` | 8px (`--spacing-8`) | 16px (`--spacing-16`) | 8px (`--radius-8`) | body |

`iconOnly` makes padding symmetric and the box square (`aspect-square`).

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `variant` | `base \| primary \| secondary \| success \| danger \| warning \| info \| light \| dark \| link` | `primary` | Type/color |
| `size` | `small \| medium \| large` | `medium` | Control size |
| `outline` | `boolean` | `false` | Outlined instead of filled |
| `iconOnly` | `boolean` | `false` | Square icon-only button (requires `aria-label`) |
| `disabled` | `boolean` | `false` | Disables interaction |
| `className` | `string` | — | Layout overrides only, merged last |
| `...props` | `ButtonHTMLAttributes` | — | Native button attributes spread |

---

### Accessibility

- Element: native `<button>` (defaults to `type="button"`).
- `aria-disabled="true"` mirrors the `disabled` attribute.
- `iconOnly` buttons must receive an `aria-label` (dev warning if missing).
- Focus ring never removed — `focus-visible:ring-2`.

---

### Do Not

- Do not hardcode colors, spacing, or radius — reference tokens via Tailwind theme.
- Do not remove the focus ring.
- Do not render an `iconOnly` button without an accessible name.

---

### Implementation Tasks

- [x] Create `src/components/ui/button.variants.ts` (CVA)
- [x] Create `src/components/ui/Button.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Implement all 10 `variant` values
- [x] Implement `outline` compound variants
- [x] Implement `small` / `medium` / `large` sizes + `iconOnly`
- [x] Wire `disabled` + `aria-disabled`, focus ring
- [x] Unit test render, variant class, disabled, click handler
