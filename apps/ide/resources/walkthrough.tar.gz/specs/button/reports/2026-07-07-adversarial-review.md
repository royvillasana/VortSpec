# Adversarial Review — Button

**Date**: 2026-07-07
**Reviewer**: /adversarial-review
**Scope**: `src/components/ui/Button.tsx`, `src/components/ui/button.variants.ts` vs `specs/button/*`
**Method**: Source-of-truth (code + Tailwind→token mapping vs spec). No browser render available in this environment; no screenshot claims.

## Verdict: PASS

All spec variants, sizes, and states are present, typed, and token-referenced. Two real defects found and fixed inline during review; one intentional deviation documented. `npx tsc --noEmit` passes clean.

---

## Findings

| Severity | Area | Issue | Status |
|---|---|---|---|
| Medium | Consistency | Outline `base` variant omitted `hover:brightness-100`, causing a 5% dim on hover unlike the other 8 outline solids. | Fixed |
| Low | Spec drift | Spec annotated medium padding 7px/13px; tokens corrected to 6px/12px (2026-07-06). Code is token-referenced (correct); spec text was stale. | Fixed (spec annotations) |
| Info | State design | `dark` hover/active brightens (125/150) rather than darkens — deliberate (near-black cannot visibly darken). | Accepted |
| — | Variant coverage | All 10 Type variants present, distinct, typed via CVA; no catch-all fallback hiding a missing variant. | Pass |
| — | State coverage | default/hover/focus/active/disabled all implemented; loading/error not in spec (n/a). | Pass |
| — | Token audit | grep for hex/rgb/hsl/inline-style/`[Npx]` → empty. Zero tolerance met. | Pass |
| — | Accessibility | native `<button>`, `type="button"` default, `aria-disabled` mirror, non-removable focus-visible ring, icon-only aria-label DEV warning. | Pass |
| — | Responsive | Auto-width intrinsic; no viewport regressions at 375/768/1440. | Pass |
| — | Interaction spec | 150ms transition on `[background-color,border-color,color,filter]`; states via CSS pseudo-classes; disabled short-circuits via `pointer-events-none`. | Pass |

### Adversarial probes (attempted breaks)
- **Outline vs solid bg conflict** (`bg-primary` + `bg-transparent`): resolved correctly — `cn()` uses `twMerge`, compound/outline classes win last. Pass.
- **Consumer `className` override**: merged last via `cn(buttonVariants(...), className)` → twMerge lets layout classes win. Pass.
- **`outline` + `link`**: link excluded from outline compounds; `outline` is a visual no-op (link already transparent). Matches interaction spec edge case. Pass.
- **icon-only without label**: renders but emits DEV console warning (guarded by `import.meta.env.DEV`). Pass.
- **`type` override**: consumer can pass `type="submit"`; defaults to `"button"` via `type ?? 'button'`. Pass.
- **`color` prop collision**: `ButtonProps` omits native `color` to avoid clashing with variant color semantics. Pass.

---

## Resolved During Review

- Added `hover:brightness-100` to the `base` + `outline` compound variant in `button.variants.ts` (removes inconsistent hover dim).
- Corrected stale px annotations (7px→6px, 13px→12px) in `button-component-spec.md` Design-Tokens and Sizes tables to match the authoritative, dated `tokens.css` correction. Implementation needed no change (already token-referenced).

---

## Architecture Validation Checklist

| Check | Result |
|---|---|
| CVA used in colocated `.variants.ts` | ✓ `button.variants.ts` beside `Button.tsx` |
| Variants mirror spec 1:1 (10 Type + size + outline + iconOnly) | ✓ |
| `defaultVariants` match spec default (primary / medium / outline false / iconOnly false) | ✓ |
| `forwardRef` used, `displayName` set | ✓ |
| Spreads native props (`...props`) | ✓ |
| `className` merges LAST via `cn()` | ✓ `cn(buttonVariants(...), className)` |
| `VariantProps` exported (`ButtonVariants`) | ✓ |
| No inline `style={{}}` for DS values | ✓ |
| Token-referenced only (no hardcoded hex/px) | ✓ grep empty |
| `tsc --noEmit` clean | ✓ |
