# Button — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./button-component-spec.md
**Figma prototype**: Buttons page (node 4:192632) — State property (normal, hovered, active, disabled)

---

### Interaction Overview

The user points, focuses, or presses the button; the surface responds with a color/brightness shift and a focus ring, and fires the click handler unless disabled.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Click / tap | Button | Not disabled |
| `Enter` / `Space` | Button (native) | Focus on the button |
| Hover | Button | Not disabled |

---

### Flow

```
Step 1: Pointer enters → hover style applies (primary → hover token; others brightness-95). Instant, eased by transition.
Step 2: Keyboard focus → 2px primary ring at 2px offset (focus-visible only, no ring on mouse press).
Step 3: Pointer down → active style (primary → hover token; others brightness-90).
Step 4: Release over button → onClick fires.
Step 5: disabled=true → opacity 0.65, pointer-events none, aria-disabled=true; no hover/active/click.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Color / brightness on hover & active | 150ms | ease | `transition-[background-color,border-color,color,filter]` |
| Underline (link) on hover | 150ms | ease | same |

Figma component `State` property (normal/hovered/active/disabled) maps to CSS pseudo-classes (`:hover`, `:active`, `:disabled`) — states are driven by the browser, not JS.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| Click while disabled | No-op (`pointer-events: none`) |
| `iconOnly` without `aria-label` | Dev console warning; still renders |
| Rapid double-click | Both clicks fire (no built-in debounce — caller's concern) |
| `outline` + `link` | `outline` ignored for `link` |

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Intrinsic auto-width; full-width only when consumer passes `className="w-full"` |

---

### Implementation Tasks

- [x] Hover/active color + brightness transitions
- [x] `focus-visible` ring (not on mouse)
- [x] Disabled short-circuits interaction
- [x] `iconOnly` accessible-name dev warning
