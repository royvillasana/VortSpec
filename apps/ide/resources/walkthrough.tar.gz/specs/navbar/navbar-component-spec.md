# Navbar — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Frame URL**: Sections / Navbar
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Organism that renders a responsive top navigation bar spanning the full page width. It composes the system `Logo` (brand), a set of `NavItem` links, an optional trailing CTA, and a mobile toggler into a single `<header><nav aria-label="Primary">` landmark. From the `md` breakpoint up the links render inline; below it they collapse behind a toggler that reveals a stacked panel.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--primitive-neutral-white` | `#ffffff` | `background-color` (bar surface, `bg-white`) |
| `--primitive-neutral-300` | neutral 300 | `border-color` (bottom border, `border-neutral-300`) |
| `--stroke-width-1` | `1px` | `border-width` (`border-1`) |
| `--spacing-16` | `16px` | `padding-inline` (`px-4`) + `gap` (`gap-4`) |
| `--spacing-8` | `8px` | `padding-block` (`py-2`) + toggler padding (`p-2`) |
| `--spacing-4` | `4px` | stacked panel row gap (`gap-1`) |
| `--theme-primary` | `#087990` | focus ring (`ring-primary`), active/hover link color (via `NavItem`) |
| `--primitive-neutral-100` | neutral 100 | toggler hover surface (`hover:bg-neutral-100`) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js`. Link color, hover, active surface, and typography are owned by the `NavItem` molecule; CTA color is owned by the injected `Button`. Structural utilities (`flex`, `hidden`, `md:flex`, `md:hidden`, `flex-col`, `z-10`, `w-full`, `items-center`, `justify-between`) carry no design values. No hardcoded hex/px.

---

### Variants

The Navbar has a single structural variant driven by the `sticky` boolean (mirrors the Figma `Sticky` property). Responsive collapse is intrinsic, not a variant flag.

| Variant | Description |
|---|---|
| `default` | Bar flows in normal document order; inline links from `md` up |
| `responsive` | Below `md`, links + cta hide and the toggler reveals a stacked panel |
| `sticky` | Bar pins to the top of the viewport (`sticky top-0 z-10`) |

Content composition (brand / items / cta) is supplied by the consumer via props.

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | Base bar; toggler collapsed (`Icon name="list"`) | — |
| `menu open` (mobile) | Toggler shows `Icon name="x"`; stacked panel visible below | Toggler click |
| `nav-link hover` | Hover surface + primary color on the link | Mouse enter (owned by `NavItem`) |
| `nav-link active` | Primary text color + `aria-current="page"` | `active` item (owned by `NavItem`) |
| `toggler focus` | Focus ring on the toggler | Keyboard focus |
| `scrolled` (sticky only) | Bar remains fixed at `top-0` above content (`z-10`) | Page scroll |

---

### Sizes

The Navbar has no size prop; it is full-bleed (`w-full`) and its height is intrinsic to its padding and content.

| Dimension | Value | Token |
|---|---|---|
| Padding V | 8px | `--spacing-8` (`py-2`) |
| Padding H | 16px | `--spacing-16` (`px-4`) |
| Item gap | 16px | `--spacing-16` (`gap-4`) |
| Stacked panel row gap | 4px | `--spacing-4` (`gap-1`) |
| Toggler padding | 8px | `--spacing-8` (`p-2`) |
| Bottom border | 1px | `--stroke-width-1` |

The composed `Logo` is rendered at `size="small"` by default.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `brand` | `ReactNode` | `<Logo size="small" href="/" />` | Brand mark in the leading group |
| `items` | `NavbarNavItem[]` | `[]` | Nav links: `{ label: string; href: string; active?: boolean }` |
| `cta` | `ReactNode` | — | Trailing call-to-action (e.g. a `Button`) |
| `sticky` | `boolean` | `false` | Pins the bar to the top (`sticky top-0 z-10`) |
| `className` | `string` | — | Layout overrides only, merged last via `cn()` |
| `...props` | `HTMLAttributes<HTMLElement>` | — | Native attributes spread onto `<header>` |

Exported type: `NavbarNavItem = { label: string; href: string; active?: boolean }`.

---

### Composed Components

| Component | Slot | Spec |
|---|---|---|
| `Logo` | Leading brand group (default when `brand` omitted) | `specs/logo/logo-component-spec.md` |
| `NavItem` | One per `items` entry (`orientation="horizontal"` inline, `"vertical"` in panel) | `specs/nav-item/nav-item-component-spec.md` |
| `Icon` | Toggler glyph (`list` closed / `x` open) | `specs/icon/icon-component-spec.md` |
| `Button` | Typical `cta` payload (trailing) | `specs/button/button-component-spec.md` |

---

### Content Rules

- Nav labels: 1–2 words, sentence case, no trailing punctuation.
- Provide a real `href` per nav item — links, not buttons.
- Mark at most one item `active` (the current page).
- Keep the trailing group to a single primary CTA.

---

### Accessibility

- Root element is a semantic `<header>` landmark containing a single `<nav aria-label="Primary">`.
- Nav links are real anchors (via `NavItem`) — keyboard focusable in source order.
- The active item sets `aria-current="page"` (via `NavItem` `active`).
- The toggler is a `<button>` with `aria-label="Toggle navigation"`, `aria-expanded` reflecting open state, and `aria-controls` pointing at the panel `id`.
- Visible focus ring on the toggler (`focus-visible:ring-2 ring-primary ring-offset-2`); links inherit focus rings from `NavItem`.
- Bar surface (`white`) and link color (`primary`) meet WCAG AA contrast.

---

### Do Not

- Do not hardcode colors, spacing, or the border width — reference tokens via the Tailwind theme.
- Do not render nav items as `<button>` or `<div>` — they must be `NavItem` anchors.
- Do not omit `aria-expanded` / `aria-controls` / `aria-label` on the toggler.
- Do not add a second `<nav>` without a distinct `aria-label`.
- Do not use `style={{}}` or arbitrary `[..]` design values.

---

### Implementation Tasks

- [x] Create `src/components/sections/navbar.variants.ts` (CVA, `sticky` boolean, mirrors `header.variants.ts`)
- [x] Create `src/components/sections/Navbar.tsx` (`forwardRef<HTMLElement>`, spreads props, `cn()` last)
- [x] Render semantic `<header>` with a single `<nav aria-label="Primary">`
- [x] Default `brand` to `<Logo size="small" href="/" />`
- [x] Map `items` to `NavItem` (`orientation="horizontal"` inline, `"vertical"` in panel), keyed by `href`, forwarding `active`
- [x] Hide inline links + cta below `md` (`hidden md:flex`); render toggler `md:hidden`
- [x] Toggler swaps `Icon name="list"` ↔ `"x"`, toggles `useState`, wires `aria-expanded` + `aria-controls` + `aria-label`
- [x] Render stacked collapsible panel (`flex flex-col`) with panel `id` when open
- [x] Wire `sticky` → `sticky top-0 z-10`
- [x] Verify all surface/spacing/border values reference tokens (no hardcoded hex/px)
