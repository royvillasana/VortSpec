# Navbar — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./navbar-component-spec.md
**Figma prototype**: Sections / Navbar — Sticky property (static, sticky) + responsive collapse

---

### Interaction Overview

The user navigates from the top bar. On wide viewports the links and CTA sit inline; hovering or focusing a link reveals its state and tabbing moves through the bar in source order. On narrow viewports the links collapse behind a toggler: pressing it expands a stacked panel below the bar and swaps the toggler glyph. When `sticky`, the bar stays pinned to the top as the page scrolls.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Click / tap | Toggler `<button>` | Viewport below `md` |
| Hover | Nav link (`NavItem`) | — |
| Keyboard focus | Brand, nav links, CTA, toggler | `Tab` / `Shift+Tab` |
| Click / tap | Brand, nav link, CTA | — |
| Resize | Viewport crosses `md` | Collapsed layout ↔ inline layout |
| Scroll | Page | `sticky` = `true` |

---

### Flow

```
Step 1: [≥ md] Links + CTA render inline; toggler is hidden (md:hidden).
Step 2: [< md] Links + CTA are hidden; toggler shows Icon "list".
Step 3: Toggler press → open state flips to true → Icon swaps to "x",
        aria-expanded becomes "true", and the stacked panel (id=aria-controls)
        renders below the bar with links in a vertical column.
Step 4: Toggler press again → open flips to false → panel unmounts,
        Icon returns to "list", aria-expanded becomes "false".
Step 5: Nav link click / Enter → navigates to its href (owned by NavItem).
Step 6: [sticky=true] Page scrolls → bar remains fixed at top-0, above content via z-10.
        [sticky=false] Bar scrolls away with the document.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Nav link hover / active | 150ms | ease | owned by `NavItem` |
| Toggler icon swap | instant | — | conditional `Icon name` |
| Panel open / close | instant (mount/unmount) | — | conditional render on `open` |
| CTA color / brightness | 150ms | ease | owned by `Button` |
| Sticky pin | instant | — | `position: sticky` (no transition) |

The open/close state is driven by React `useState`; the pin is driven by CSS positioning, not JS.

---

### Animation Details

The Navbar adds no bespoke animation of its own. Link hover/active motion is inherited from `NavItem`; the CTA runs the injected `Button`'s own transitions. The mobile panel mounts and unmounts on toggle without an explicit transition.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| `items` empty | `<nav aria-label="Primary">` renders with only brand + (inline) cta / toggler; panel is empty |
| No `cta` | Trailing group omits the CTA; toggler and links still render |
| Custom `brand` passed | Replaces the default `Logo`; brand still leads |
| Active link | The `active` item gets primary color + `aria-current="page"` (via `NavItem`) |
| Keyboard on toggler | `Tab` focuses it (visible ring); `Enter`/`Space` toggles the panel |
| Resize while open | Crossing to `md` hides the panel (`md:hidden`) even if `open` is true; inline links show |
| Esc while open | Optional: consumers may close the menu on `Escape` (not required by the organism) |

---

### Accessibility & Keyboard

- `<nav aria-label="Primary">` distinguishes this region from any other nav.
- Toggler is a `<button aria-label="Toggle navigation">` with `aria-expanded` reflecting `open` and `aria-controls` referencing the panel `id`.
- The panel element carries the `id` targeted by `aria-controls` only while open.
- Nav links are focusable anchors in source order; the active link exposes `aria-current="page"`.
- Focus order: brand → inline links → CTA → toggler (toggler last, hidden ≥ md); in the open panel, focus flows into the stacked links.
- Visible focus ring on the toggler; links inherit focus rings from `NavItem`.

---

### Implementation Tasks

- [x] Toggler toggles `open` via `useState` and swaps `Icon` `list` ↔ `x`
- [x] `aria-expanded` reflects `open`; `aria-controls` references the panel `id`
- [x] Inline links + cta hidden below `md`; toggler hidden from `md` up
- [x] Stacked panel renders only when `open`, with vertical `NavItem`s
- [x] Active link forwards to `NavItem` `active` → `aria-current="page"`
- [x] `sticky` prop pins the bar (`sticky top-0 z-10`)
- [x] Empty `items` / missing `cta` handled gracefully
