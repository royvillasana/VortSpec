# Navbar — Placement / Composition Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./navbar-component-spec.md

Organisms have no page of their own; this documents how the Navbar anchors templates and screens, how its navigation collapses responsively, and the landmark structure it contributes.

---

### Purpose

Define where the Navbar sits in a page's landmark structure, which templates and screens it anchors, and how its navigation behaves across breakpoints — inline links on wide viewports, a toggler-driven stacked panel on narrow ones.

---

### Component Inventory

Components the Navbar composes.

| Component | Spec file | Status |
|---|---|---|
| `Logo` | `specs/logo/logo-component-spec.md` | Implemented |
| `NavItem` | `specs/nav-item/nav-item-component-spec.md` | Implemented |
| `Icon` | `specs/icon/icon-component-spec.md` | Implemented |
| `Button` | `specs/button/button-component-spec.md` | Implemented |

---

### Anchors These Templates / Screens

| Template / Screen | Usage |
|---|---|
| Marketing / landing | Logo left, inline nav links + primary CTA right; hamburger on mobile |
| Dashboard shell | Top bar with logo, nav, and account/CTA; typically `sticky` |
| Documentation layout | Logo + section nav links, collapsing to a menu on mobile |

---

### Usage Example

```tsx
import { Navbar } from '@/components/sections/Navbar';
import { Button } from '@/components/ui/Button';

<Navbar
  sticky
  items={[
    { label: 'Home', href: '/', active: true },
    { label: 'Docs', href: '/docs' },
    { label: 'Pricing', href: '/pricing' },
  ]}
  cta={<Button variant="primary">Sign in</Button>}
/>
```

Layout: `<header>` (`w-full`, `bg-white`, `border-b border-1 border-neutral-300`, `px-4 py-2`) wrapping `<nav aria-label="Primary" class="flex w-full items-center justify-between gap-4">`. Inline group is `hidden md:flex`; toggler is `md:hidden`; the open panel is `flex flex-col`.

---

### Layout Structure

The Navbar is the first landmark in the page, above `<main>`.

```
<Page>
  <Navbar sticky>                         ← full-width bar, top-0 z-10
    <nav aria-label="Primary">            ← flex w-full items-center justify-between gap-4
      {brand / Logo}                      ← leads
      <div class="hidden md:flex">        ← inline links + cta (≥ md)
        {items → NavItem horizontal}
        {cta}
      </div>
      <button class="md:hidden">          ← toggler (< md), aria-expanded/controls
        <Icon list | x />
      </button>
    </nav>
    {open && (
      <div id={panelId} class="flex flex-col md:hidden">  ← stacked panel (< md)
        {items → NavItem vertical}
        {cta}
      </div>
    )}
  </Navbar>
  <main id="main-content"> … </main>
  <Footer />
</Page>
```

---

### Responsive Breakpoints

| Breakpoint | Layout change |
|---|---|
| 375px (mobile) | Inline links + cta hidden; toggler visible. Tapping it opens the stacked panel below the bar (`flex flex-col`). |
| 768px (tablet, `md`) | Inline nav: brand left, links + CTA right; toggler hidden. Panel never shows (`md:hidden`). |
| 1440px (wide) | Full-bleed bar (`w-full`); intrinsic height; content aligned via `justify-between`. |

The `md` breakpoint is the single collapse boundary — below it the toggler owns navigation, at/above it the inline links do.

---

### Accessibility

- Navbar is the page's `<header>` banner landmark, placed before `<main>`.
- Contains a single `<nav aria-label="Primary">`; any secondary nav elsewhere must use a distinct label.
- Toggler exposes `aria-label="Toggle navigation"`, `aria-expanded`, and `aria-controls` → panel `id`.
- Nav links are real anchors, focusable in source order; the active link sets `aria-current="page"`.
- Provide a skip link (`Skip to content`) targeting `<main id="main-content">`.
- Bar surface (`white`) vs. link color (`primary`) meets WCAG AA contrast.

---

### Implementation Tasks

**Composition**
- [x] Place `Navbar` as the first landmark, above `<main>`
- [x] Render brand (`Logo` default) leading the single `<nav aria-label="Primary">`
- [x] Map `items` to `NavItem` anchors (horizontal inline, vertical in panel), forwarding `active`
- [x] Render trailing `cta` (typically `Button`) in both inline group and panel

**Behavior**
- [x] Hide inline links + cta below `md`; show toggler below `md`
- [x] Toggle stacked panel via `useState`; swap `Icon` `list` ↔ `x`
- [x] Apply `sticky top-0 z-10` when `sticky` is set
- [x] Keep the bar full-width (`w-full`) with `justify-between` alignment

**Accessibility**
- [x] Toggler wires `aria-expanded` + `aria-controls` + `aria-label`
- [x] Confirm single `<nav aria-label="Primary">` landmark
- [x] Active link forwards to `aria-current="page"` via `NavItem`
- [x] Pair with a skip link to `<main id="main-content">`

**QA**
- [x] Visual QA at 375px / 768px / 1440px against the Figma Navbar frame
- [x] All surface/spacing/border values verified as token references (no hardcoded values)
