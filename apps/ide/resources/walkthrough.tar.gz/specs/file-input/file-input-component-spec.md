# FileInput — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

FileInput is the design system's file-chooser form field (molecule). It composes a
real native `<input type="file">` (visually hidden) with a styled `<label>` trigger
built from the Button `light` styles, a selected-filename display, and the standard
label / hint / error field pattern. It gives a branded, accessible file picker while
keeping the browser's native file dialog and keyboard behaviour intact.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-neutral-100` | `#f8f9fa` | trigger `background-color` (Button `light`) |
| `--color-near-black` | — | trigger `color` (Button `light`) |
| `--color-primary` | `#0d6efd` | focus ring on the trigger label |
| `--color-danger` | `#dc3545` | required marker + error text + `aria-invalid` |
| `--color-text-default` | `#212529` | field label `color` |
| `--color-text-muted` | `#6c757d` | filename + hint `color` |
| `--font-family-base` | Roboto | `font-family` |
| `--font-size-body` | `16px` | `font-size` |
| `--font-weight-regular` | `400` | `font-weight` |
| `--radius-sm` / `--radius-default` | — | trigger `border-radius` (via Button size) |
| `--opacity-disabled` | — | `opacity` (disabled trigger) |
| `--spacing-*` | — | wrapper `gap`, trigger padding (via Button size) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js` to
these CSS variables. No hardcoded values.

---

### Variants

| Property | Values | Description |
|---|---|---|
| `size` | `small` \| `medium` \| `large` | Trigger padding/radius (mirrored to `buttonVariants`) + wrapper gap |

The trigger uses the Button `light` variant. The `size` axis is mirrored 1:1 to
`buttonVariants({ size })` so the trigger matches Button sizing exactly.

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `empty` | Trigger + upload icon + `buttonLabel`, no filename shown | No file selected |
| `selected` | Filename (single) or "N files selected" (multiple) beside the trigger | User picks file(s) |
| `focus` | 2px primary ring + offset on the trigger label | Keyboard focus on the input (`peer-focus-visible`) |
| `disabled` | `opacity-disabled`, `not-allowed`, non-interactive trigger | `disabled` attribute |
| `error` | Danger error text under the field, `aria-invalid` on input | `error` prop set |

---

### Sizes

| Size | Trigger padding / radius | Wrapper gap | Font |
|---|---|---|---|
| `small` | `px-2 py-1` `rounded-sm` (Button small) | `gap-1` | body 16px |
| `medium` | `px-3 py-1.5` `rounded` (Button medium) | `gap-1.5` | body 16px |
| `large` | `px-4 py-2` `rounded` (Button large) | `gap-2` | body 16px |

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `size` | `small \| medium \| large` | `medium` | Trigger + wrapper sizing |
| `label` | `React.ReactNode` | — | Field label, associated via `htmlFor` |
| `hint` | `string` | — | Helper text below the control (hidden when `error` set) |
| `error` | `string` | — | Error message; danger text + `aria-invalid` |
| `required` | `boolean` | — | Native `required` + visual `*` marker |
| `buttonLabel` | `string` | `Choose file` | Text inside the trigger button |
| `accept` | `string` | — | Native file-type filter (spread) |
| `multiple` | `boolean` | — | Allow selecting multiple files |
| `id` | `string` | `React.useId()` | Input id; label/hint/error ids derive from it |
| `onChange` | `(e) => void` | — | Called after internal filename tracking |
| `className` | `string` | — | Layout overrides only, merged last onto the outer wrapper |
| ...rest | native | — | `InputHTMLAttributes<HTMLInputElement>` (minus `size`/`type`) spread on the input |

`forwardRef<HTMLInputElement>` targets the native file input.

---

### Accessibility

- Element: real native `<input type="file">` — retains native semantics + keyboard operation.
- The input is visually hidden with `sr-only` (not `display:none`), so it stays focusable and in the tab order.
- The visible trigger is a `<label htmlFor={id}>` programmatically associated with the input, giving a full click target and native activation.
- Keyboard focus on the input surfaces a visible ring on the trigger via `peer-focus-visible:ring-2` (primary) with offset.
- `error` sets `aria-invalid` and links the message via `aria-describedby`; `hint` is likewise linked via `aria-describedby`.
- `required` sets the native attribute and shows a decorative `*` (`aria-hidden`).
- Disabled state uses the native `disabled` attribute (input removed from tab order) and a non-interactive trigger.

---

### Do Not

- Do not replace the native `<input type="file">` with a fake button that opens the dialog via JS click only — keep the real input for semantics + keyboard.
- Do not use `display:none` on the input (breaks focus/tab order) — use `sr-only`.
- Do not hardcode colors, spacing, radius, or type values — reference tokens via Tailwind theme.
- Do not use `style={{}}` or arbitrary `[..]` utilities.
- Do not rely on `error` styling alone — always pair with the associated, visible error text.
- Do not remove the focus ring from the trigger.

---

### Implementation Tasks

- [x] Create `src/components/modules/file-input.variants.ts` (CVA `size`, mirrored to `buttonVariants` size)
- [x] Create `src/components/modules/FileInput.tsx` (`forwardRef` to the file input, `cn()` last on wrapper)
- [x] Render a real native `<input type="file">` visually hidden with `peer sr-only`
- [x] Style the `<label htmlFor>` trigger with `buttonVariants({ variant: 'light', size })` + `cursor-pointer`
- [x] Put `<Icon name="upload" size="small" aria-hidden />` + `buttonLabel` inside the trigger
- [x] Track selected filename(s) via `React.useState` from `onChange`; also call the consumer `onChange`
- [x] Show single filename or "N files selected" for multiple, in `text-muted text-body`
- [x] Implement label / hint / error pattern with `aria-describedby` + `aria-invalid`
- [x] Visible focus via `peer-focus-visible:ring-*` on the trigger; disabled pattern
- [x] `id` via `React.useId()` fallback; derive hint/error ids
