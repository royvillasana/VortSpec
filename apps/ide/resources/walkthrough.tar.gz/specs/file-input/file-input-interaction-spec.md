# FileInput — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Overview

FileInput opens the browser's native file dialog from a branded trigger, then
reflects the chosen file(s) inline. All activation and keyboard behaviour comes from
the real native `<input type="file">`; the styled `<label>` is only the visible
surface.

---

### Trigger

- **Click / tap**: Clicking the styled `<label>` (or its icon/text) activates the
  associated input via `htmlFor` and opens the native OS file dialog.
- **Keyboard**: `Tab` moves focus to the hidden-but-focusable input. A visible ring
  appears on the trigger label (`peer-focus-visible`). `Enter` / `Space` opens the
  native file dialog. Focus, ring, and dialog are all native — no JS handlers needed
  to open the picker.

---

### Flow

1. Empty state — trigger shows the upload icon + `buttonLabel` ("Choose file"); no filename.
2. User activates the trigger (click or keyboard) → native file dialog opens.
3. User selects file(s) and confirms → the input fires `change`.
4. The component reads `event.target.files`, stores the name(s) in state, and calls the consumer `onChange`.
5. Selected state — the filename (single) or "N files selected" (multiple) renders beside the trigger in muted text.
6. Re-activating the trigger and choosing again replaces the displayed selection.

---

### Timing

- Native dialog open/close is OS-driven (no custom animation).
- Filename display updates synchronously on the `change` event (single React state commit).
- Trigger hover/focus transitions inherit Button's `transition` (~150ms ease-out).

---

### Edge Cases

| Case | Behaviour |
|---|---|
| No file chosen / dialog cancelled | `files` is empty → no filename shown, selection stays as it was (browser default: unchanged). |
| Multiple files (`multiple`) | Display collapses to "N files selected"; individual names are not enumerated to avoid overflow. |
| Selecting then re-opening and cancelling | Native input keeps the prior selection; displayed text is unchanged. |
| Clearing programmatically | If a consumer resets the input value, the next `change` with empty `files` clears the displayed text. |
| Disabled | Trigger is non-interactive (`pointer-events-none`, `opacity-disabled`); input is removed from tab order. |
| Error present | Error text shows and `aria-invalid` is set; selection flow is otherwise unchanged. |

---

### Accessibility & Keyboard

- Input keeps native semantics; it is `sr-only` (focusable), never `display:none`.
- `Tab` reaches the input; the trigger shows a visible `peer-focus-visible` ring (primary, offset).
- `Enter` / `Space` on the focused input opens the dialog (native).
- Label is programmatically associated (`htmlFor`) — screen readers announce the field label with the file input.
- `error` → `aria-invalid` + `aria-describedby` link to the message; `hint` is linked via `aria-describedby` too.
- Required marker `*` is decorative (`aria-hidden`); the native `required` attribute conveys the constraint.

---

### Implementation Tasks

- [x] Associate the `<label>` trigger to the input via `htmlFor` for click + keyboard activation
- [x] Keep the input `sr-only` (focusable) so `Tab` / `Enter` / `Space` open the native dialog
- [x] Surface a visible focus ring on the trigger via `peer-focus-visible`
- [x] On `change`, read `event.target.files`, update filename state, and call consumer `onChange`
- [x] Render single filename vs. "N files selected" for multiple
- [x] Handle empty `files` (cancelled/cleared) by showing no filename
- [x] Wire `aria-invalid` + `aria-describedby` for error and hint
