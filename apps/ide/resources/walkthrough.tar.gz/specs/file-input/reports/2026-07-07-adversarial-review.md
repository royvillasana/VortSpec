# Adversarial Review — FileInput

Date: 2026-07-07

## Verdict: PASS

Real native `<input type="file">` kept focusable via `peer sr-only`, styled `<label>` trigger from
`buttonVariants`, filename tracking, and the `peer-focus-visible` ring on the trigger are all correct. The one
**Major** a11y defect — a dangling `aria-describedby` idref when both `error` and `hint` are set (identical root
cause to Select) — was **found and FIXED inline during this review**.

## Findings

| Severity | Area | Issue | Status |
|---|---|---|---|
| Major | A11y (dangling idref) | `describedBy` was built from `[hasError ? errorId : null, hint ? hintId : null]`, including `hintId` whenever `hint` was truthy. But the message region renders `hasError ? <error> : (hint && <hint>)`: with both props set, only the error `<span>` renders, so `aria-describedby` referenced a `…-hint` id with no rendered node → dangling idref, a real screen-reader defect. | **RESOLVED (fixed inline)** |

**Failure scenario (pre-fix):** `<FileInput hint="Max 5MB" error="File too large" />` → input got
`aria-describedby` including `…-hint`, but the hint `<span>` was not rendered (error branch wins).

**Fix applied:** `[hasError ? errorId : null, !hasError && hint ? hintId : null]` — `hintId` is now referenced
only when it will render. Error-only, hint-only, and hint+error combinations all resolve correctly.

## Architecture Validation (8 checks)
1. ✓ `.variants.ts` colocated. 2. ✓ CVA mirrors spec (`size`, mirrored to `buttonVariants`). 3. ✓ `defaultVariants` match spec.
4. ✓ `forwardRef<HTMLInputElement>` → file input. 5. ✓ `...props` spread on `<input>`. 6. ✓ `className` merged LAST via `cn()`.
7. ✓ `VariantProps` exported (`FileInputVariants`). 8. ✓ No inline `style={{}}`.

## Token/Variant/State/A11y checklist
- Token audit: ✓ zero hex/rgb/hsl/px/arbitrary/inline-style (grep hit `fileNames[0]` is an array index).
- Variants: ✓ size mirrored to Button. States: ✓ empty/selected/focus/disabled/error.
- A11y: ✓ real focusable input via `sr-only`, label trigger association, peer focus ring, aria-invalid,
  decorative icon aria-hidden, aria-hidden asterisk, and (post-fix) **non-dangling aria-describedby**.

## Resolved During Review
- Fixed dangling `aria-describedby` hint idref in `FileInput.tsx` (see Findings). `npx tsc --noEmit` exits 0.

## Notes
Runtime pixel diff and axe **not executed** (no story). The native file dialog and focus-ring surfacing are
runtime behaviours not pixel-confirmed here. The dangling-idref is a structural defect, fully assertable and
fixable from source (spec ↔ code ↔ token model).
