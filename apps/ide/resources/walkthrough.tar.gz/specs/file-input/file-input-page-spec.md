# FileInput — Page / Usage Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Defines how FileInput is composed into forms. FileInput is a `form-item` molecule
(horizontal / vertical) used wherever a form needs a file upload field — avatar
upload, document attachment, import flows, etc. It carries its own label / hint /
error, so it drops directly into a form column.

---

### Component Inventory

| Element | Component | Role |
|---|---|---|
| Field label | `<label htmlFor>` | Associates text with the input |
| Trigger | `<label>` styled via `buttonVariants({ variant: 'light', size })` | Opens the native dialog |
| Icon | `Icon` (`name="upload"`, `size="small"`) | Trigger affordance |
| File control | native `<input type="file">` (`sr-only`) | Real, accessible picker |
| Filename display | `<span class="text-muted text-body">` | Shows selection |
| Hint / error | `<span>` (`text-muted` / `text-danger`) | Helper + validation text |

Depends on: `Icon` (atom), `buttonVariants` (Button styles), `cn` util.

---

### Usage example

```tsx
import { FileInput } from '@/components/modules/FileInput';

// Basic
<FileInput label="Resume" hint="PDF or DOCX, up to 5MB" accept=".pdf,.docx" />

// Required + error
<FileInput
  label="Profile photo"
  required
  accept="image/*"
  error="A file is required"
/>

// Multiple, large trigger
<FileInput
  label="Attachments"
  multiple
  size="large"
  buttonLabel="Add files"
/>
```

---

### Responsive

- The outer wrapper is `flex flex-col` and takes the width of its form column; it does not set an intrinsic width.
- The trigger row is `flex flex-wrap items-center gap-2` — long filenames wrap to a new line under the trigger on narrow columns rather than overflowing.
- In a two-column form (horizontal `form-item`), place `label` and control per the form's grid; FileInput's internal stack still applies.
- No fixed breakpoints inside the component; it adapts to its container.

---

### Accessibility

- One labelled field per FileInput; label is programmatically tied to the input (`htmlFor`).
- Error and hint text are linked via `aria-describedby`; `error` also sets `aria-invalid`.
- Keyboard reachable and operable via the native input; visible focus ring on the trigger.
- Required conveyed via native `required` (visual `*` is decorative).
- When grouping several FileInputs, keep each within its own labelled field; do not share ids.

---

### Implementation Tasks

- [x] Provide `label`, `hint`, `error`, `required` as first-class field props
- [x] Keep the wrapper width-agnostic (`flex flex-col`) so it fits any form column
- [x] Allow the trigger row to wrap (`flex-wrap`) for long filenames
- [x] Derive unique `label` / `hint` / `error` ids from the input `id` (via `React.useId()` fallback)
- [x] Support `accept` / `multiple` passthrough for real-world upload fields
- [x] Merge consumer `className` last onto the outer wrapper for layout overrides
