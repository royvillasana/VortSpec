# Visual Verify Report — FileInput

- **Component:** `FileInput` (molecule) · **Design source:** `figma` (`ojko9pGfsDAvmUf2DA38d2`) · **Date:** 2026-07-07
- **Spec:** `specs/file-input/file-input-component-spec.md` + `file-input-interaction-spec.md`
- **Impl:** `src/components/modules/FileInput.tsx` + `file-input.variants.ts`

## Live-rendered? No — no Storybook story for FileInput.
Runtime pixel (375/768/1440) and axe are **not executable — verified from source**, NOT "failed".

## Checklist (source-verified)

### Variants — ✓
- `size`: wrapper `gap-1` / `gap-1.5` / `gap-2`; trigger via `buttonVariants({ variant:'light', size })` (mirrored 1:1 to Button) — matches spec.

### States — ✓
empty (icon + `buttonLabel`, no filename), selected (single name or "N files selected"), focus
(`peer-focus-visible:ring-2 ring-primary ring-offset-2` on the trigger label), disabled
(`opacity-disabled pointer-events-none cursor-not-allowed` on trigger + native `disabled` on input),
error (danger text + `aria-invalid`).

### Tokens — ✓
Trigger bg/text/radius/padding via already-token-verified `buttonVariants` light; `ring-primary`/`ring-offset-2`,
`text-text`/`text-danger` (asterisk/error), `text-muted` (filename/hint), `gap-1/1.5/2`, `gap-2` row,
`text-body`/`font-base`/`font-regular`/`leading-body`/`opacity-disabled`. All mapped.

### Token audit — ✓
Zero matches (the only grep hit `fileNames[0]` is an array index, not a Tailwind arbitrary value).

### Accessibility (source) — ✓
Real native `<input type="file">` hidden with `peer sr-only` (not `display:none` — stays focusable/in tab order);
`<label htmlFor>` trigger programmatically associated; keyboard focus on the input surfaces a ring on the trigger
via `peer-focus-visible:*`; `aria-invalid` from `error`; required `*` `aria-hidden`; upload Icon decorative `aria-hidden`.

## Discrepancies (with authoritative side + fix)

| # | Discrepancy | Authoritative | Fix applied |
|---|---|---|---|
| D1 | **Dangling `aria-describedby` idref**: `describedBy` included `hintId` whenever `hint` was truthy, but the message region renders `hasError ? <error> : (hint && <hint>)`. With both `error` and `hint` set, only the error `<span>` renders, so `aria-describedby` referenced a `…-hint` id with no node. | Spec §Accessibility: hint "hidden when `error` is present" + linked via `aria-describedby` ⇒ idref must resolve. | **Fixed in `FileInput.tsx`**: `hintId` included only when `!hasError && hint`, so it's referenced only when its node renders. `npx tsc --noEmit` exits 0. |

## Gate: **PASS** — D1 resolved inline; zero unresolved discrepancies. Runtime pixel/axe not executable (no story).
