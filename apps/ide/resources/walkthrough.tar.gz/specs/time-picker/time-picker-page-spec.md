# TimePicker — Usage / Composition Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./time-picker-component-spec.md

Molecules have no page of their own; this documents how TimePicker composes into higher-order components and screens.

---

### Purpose

Provide a token-pure, accessible time-entry field for forms and scheduling flows, built on the native `<input type="time">`.

---

### Component Inventory

| Component | Role |
|---|---|
| `Icon` (`clock`) | Leading decorative adornment |
| Native `<input type="time">` | The time control |
| `label` / `hint` / `error` text | Field metadata (same pattern as Input) |

---

### Usage Example

```tsx
import { TimePicker } from '@/components/modules/TimePicker';

// Minutes only (default granularity)
<TimePicker
  label="Start time"
  hint="24-hour format"
  value={value}
  onChange={(e) => setValue(e.target.value)}
  step={60}
/>

// With seconds + validation error
<TimePicker
  label="Alarm"
  required
  step={1}
  min="06:00:00"
  max="09:00:00"
  error="Choose a time between 6 and 9 AM."
/>
```

---

### Consumed By

| Consumer | Usage |
|---|---|
| `Form` (organism) | Time fields within scheduling / booking forms |
| Settings screens | Quiet-hours, reminder, and availability times |
| Filters | Time-range constraints (paired min/max fields) |

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Field fills its container width (`w-full`); padding, radius, and gaps are fixed by token. Stack fields vertically on narrow screens. |

---

### Accessibility

- Always provide a `label`; it is associated to the input automatically.
- Pair `error` text with the danger styling — color is never the only cue.
- Prefer native `min`/`max`/`step` over custom validation so the browser enforces valid times.

---

### Implementation Tasks

- [x] Verify TimePicker renders inside a form with correct label/hint/error spacing
- [x] Verify `size` variants map to the correct field padding
- [x] Verify `step`, `min`, `max` pass through to the native input
- [x] Verify error state announces via `aria-describedby` + `aria-invalid`
