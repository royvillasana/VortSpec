# Visual-Verify Report — TimePicker

- **Component**: TimePicker (`src/components/modules/TimePicker.tsx`, `time-picker.variants.ts`)
- **Design source**: Figma (file `ojko9pGfsDAvmUf2DA38d2`)
- **Date**: 2026-07-07
- **Live-rendered?**: **No — not executable.** No Storybook story exists for TimePicker.
  Verified from **source of truth** (spec ↔ code ↔ token model). Runtime pixel diff and axe
  scan are *not executable* here — **not "failed"**, verified from source.

---

## Method
Cross-checked `TimePicker.tsx` + `time-picker.variants.ts` vs Component + Interaction specs,
the Tailwind→CSS-var map, and `tokens.css`. Ran token-audit grep. `npx tsc --noEmit` → exit 0.

## Checklist results

### Variants & Sizes (source)
| Dimension | Spec | Code | Result |
|---|---|---|---|
| `size` small/medium/large | pr-2/py-1 · pr-2.5/py-2 · pr-3/py-2.5 (+pl-8) | identical | ✓ |
| default size | medium | `defaultVariants.size='medium'` | ✓ |
| `invalid` true/false | danger border+ring / primary ring | identical | ✓ |

### States (source)
default ✓ · focus-visible ring-2 (primary / danger) + offset ✓ · invalid (danger border + `aria-invalid` + error text) ✓ · disabled (`opacity-disabled`, `not-allowed`, `bg-neutral-100`) ✓

### Token audit (zero tolerance)
```
grep -nE '#[0-9a-fA-F]{3,8}|rgb\(|hsl\(|[0-9]+px|\[[0-9]|style=\{\{'  TimePicker.tsx time-picker.variants.ts
→ NO MATCHES
```
All utilities CSS-var backed: `bg-white`, `border-neutral-300`, `text-text`, `text-muted`,
`border-danger`, `ring-primary`/`ring-danger`, `bg-neutral-100`; spacing `pl-8`/`py-*`/`pr-*`/
`gap-1`/`left-2`; `rounded`, `border-1`, `text-body`, `leading-body`, `font-base`, `font-regular`,
`opacity-disabled`. All spacing keys within the mapped set → **no leak.**

### Accessibility (source)
- Native `<input type="time">` — spinbutton semantics + keyboard for free ✓
- `<label htmlFor>` via `id`/`useId` ✓
- Clock Icon `aria-hidden` + `pointer-events-none` ✓
- `aria-invalid` derived from `error`/`invalid` ✓
- `aria-describedby` → hint or error id ✓
- **Required asterisk is NOT `aria-hidden`** — announced to AT, matching the prior review note and
  the canonical `Input` molecule pattern; native `required` also set ✓ (**prior-note check passed**)
- Focus ring replaces `outline-none` (never suppressed) ✓

### Architecture
`.variants.ts` colocated ✓ · CVA mirrors spec (`size`,`invalid`) ✓ · defaults match ✓ · `forwardRef`→input ✓ · native `...props` spread onto control ✓ · `className` LAST via `cn()` on wrapper ✓ · `VariantProps` exported ✓ · no inline `style` ✓

### Interaction spec
Native picker/keyboard delegated ✓ · `step`/`min`/`max` via `...props` ✓ · disabled + empty handled ✓ · `error` → aria-invalid + describedby ✓ · `duration-150 ease-out` transition ✓.

## Discrepancies
None. (Observation: wrapper is `flex flex-col gap-1` without `font-base` — this **matches the
canonical `Input` molecule** convention; the input control itself is `font-base`. Not a defect.)

## Gate: **PASS** (zero unresolved discrepancies; runtime pixel/axe not executable — verified from source)
