# TimePicker — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./time-picker-component-spec.md
**Figma prototype**: Time field — native `<input type="time">` (native picker + keyboard entry)

---

### Interaction Overview

`TimePicker` delegates all interaction to the native `<input type="time">`. Users type a time or open the browser's native time picker; the component adds only the field chrome (label, clock icon, hint/error) around it. No custom popup or keyboard handling is re-implemented.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Click / focus | native input | Opens the browser time picker and/or focuses the field |
| Keyboard entry | native input | Type hours/minutes; arrow keys adjust the focused segment |
| Native picker commit | native input | Fires `change` with the selected `HH:MM` (or `HH:MM:SS`) value |

---

### Flow

```
Step 1: Component mounts → label associates to the input (htmlFor/id); clock Icon overlays the field.
Step 2: User focuses the field → 2px focus ring (primary, or danger when invalid).
Step 3: User types or opens the native picker → the browser handles segment editing and validation.
Step 4: On selection/edit → native `change` fires; consumer updates `value` via onChange.
Step 5: If `error` is set → aria-invalid + danger border applied and the error text is announced via aria-describedby.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Border / ring color | 150ms | ease-out | `transition-colors duration-150 ease-out` |

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| `step={60}` | Minute granularity (default); seconds hidden |
| `step={1}` | Seconds segment shown; `HH:MM:SS` values |
| `min` / `max` | Native constrains valid times; out-of-range entry flagged by the browser |
| Empty value | Field shows placeholder segments; value is `""` |
| `disabled` | `opacity-disabled`, neutral-100 surface, not-allowed cursor; no interaction |
| `error` present | Danger border + ring; hint hidden, error shown and announced |

---

### Accessibility & Keyboard

| Key | Action |
|---|---|
| `Tab` | Move focus into / out of the field |
| `Left` / `Right` | Move between hour / minute / (second / AM-PM) segments |
| `Up` / `Down` | Increment / decrement the focused segment |
| `0`–`9` | Type the focused segment directly |

- Native spinbutton semantics and announcements are preserved (no ARIA re-implementation needed).
- Label is programmatically associated; hint/error are exposed via `aria-describedby`; `aria-invalid` reflects error state.

---

### Implementation Tasks

- [x] Delegate all picker/keyboard interaction to the native `<input type="time">`
- [x] Apply focus-visible ring (primary / danger) with a 150ms color transition
- [x] Support native `step`, `min`, `max` via `...props` spread
- [x] Handle disabled and empty-value states
- [x] Announce error via `aria-describedby` + `aria-invalid`
