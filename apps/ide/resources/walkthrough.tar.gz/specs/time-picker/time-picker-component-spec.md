# TimePicker — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

A labeled time-selection field that wraps the **native `<input type="time">`** with a leading clock icon adornment. Using the native control is a deliberate decision: it inherits the browser's built-in accessibility, keyboard behaviour, and locale-aware time entry (and stays fully token-pure) instead of re-implementing a custom time widget. It follows the same label / hint / error / `aria` pattern as the Input molecule.

---

### Composed Atoms

| Atom | Role |
|---|---|
| `Icon` (`clock`) | Decorative leading adornment inside the field (`aria-hidden`, `text-muted`) |
| Native `<input type="time">` | The accessible, token-styled time control |
| Inline text | Optional `label`, `hint`, and `error` messages |

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-white` | `#ffffff` | `background-color` (field, `bg-white`) |
| `--color-neutral-300` | `#dee2e6` | `border-color` (default, `border-neutral-300`) |
| `--color-neutral-100` | `#f8f9fa` | `background-color` (disabled, `disabled:bg-neutral-100`) |
| `--color-status-danger` | `#dc3545` | `border-color` / ring / text (invalid, `border-danger` / `text-danger`) |
| `--color-text-default` | `#212529` | `color` (input + label text, `text-text`) |
| `--color-text-muted` | — | `color` (clock icon + hint, `text-muted`) |
| `--theme-primary` | — | focus ring (`ring-primary`) |
| `--stroke-width-1` | `1px` | `border-width` (`border-1`) |
| `--radius-8` | `8px` | `border-radius` (`rounded`) |
| `--spacing-8` | `8px` | left padding for icon room (`pl-8`) |
| `--spacing-8` | `8px` | icon offset (`left-2`) |
| `--spacing-4` | `4px` | field ↔ label/message gap (`gap-1`) |
| `--opacity-disabled` | — | disabled opacity (`opacity-disabled`) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js` to these CSS variables. No hardcoded values.

---

### Variants

| Property | Values | Effect |
|---|---|---|
| `size` | `small` \| `medium` (default) \| `large` | Vertical padding of the field (`py`/`pr`) |
| `invalid` | `true` \| `false` (default) | Danger border + focus ring; auto-derived from `error` when unset |

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | Neutral-300 border, white surface | — |
| `focus-visible` | 2px primary ring (danger ring when invalid) | Keyboard focus |
| `invalid` | Danger border + ring, error text below | `error` present or `invalid` |
| `disabled` | `opacity-disabled`, neutral-100 surface, `not-allowed` cursor | `disabled` |

---

### Sizes

| `size` | Padding |
|---|---|
| `small` | `pr-2 py-1` (+ `pl-8` for icon) |
| `medium` | `pr-2.5 py-2` (+ `pl-8`) |
| `large` | `pr-3 py-2.5` (+ `pl-8`) |

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `size` | `"small" \| "medium" \| "large"` | `"medium"` | Field padding scale |
| `invalid` | `boolean` | derived from `error` | Force danger styling |
| `label` | `ReactNode` | — | Field label, associated via `htmlFor` |
| `hint` | `string` | — | Helper text (hidden when `error` is set) |
| `error` | `string` | — | Error message; sets `aria-invalid` + danger styling |
| `required` | `boolean` | — | Marks the field required (renders `*` on label) |
| `id` | `string` | `React.useId()` | Input id (fallback generated) |
| `className` | `string` | — | Layout overrides on the outer wrapper, merged last |
| `...props` | `InputHTMLAttributes<HTMLInputElement>` | — | Native input attrs spread (`value`, `onChange`, `min`, `max`, `step`, …); `size` omitted |

---

### Accessibility

- The native `<input type="time">` retains built-in behaviour, keyboard support, and spinbutton semantics — no custom widget re-implements it.
- `label` is associated to the input via `htmlFor`/`id` (id falls back to `React.useId()`).
- The clock `Icon` is decorative (`aria-hidden`) — it is never the sole signal.
- `hint` and `error` are linked to the input through `aria-describedby`; `error` also sets `aria-invalid`.
- `required` renders a visible `*` and sets the native `required` attribute.

---

### Do Not

- Do not build a custom dropdown/spinner time widget — use the native control.
- Do not hardcode colors, spacing, radius, or stroke — reference tokens via Tailwind theme.
- Do not remove the label association or convey error state by color alone.
- Do not use inline `style={{}}` for design-system values.

---

### Implementation Tasks

- [x] Create `src/components/modules/time-picker.variants.ts` (CVA: `timePickerVariants` with `size` + `invalid`)
- [x] Create `src/components/modules/TimePicker.tsx` (`forwardRef`, spreads props, `cn()` last on outer wrapper)
- [x] Wrap native `<input type="time">` in a `relative` container with a leading `clock` Icon (`pl-8`)
- [x] Implement `small` / `medium` / `large` sizes
- [x] Wire `label` (`htmlFor` + `useId` fallback), `hint`, `error`, `required`
- [x] Derive `aria-invalid` + danger styling from `error`; link messages via `aria-describedby`
- [x] Spread native attrs (`value`/`onChange`/`min`/`max`/`step`) via `...props`
- [x] Verify token-only styling and `tsc` passes
