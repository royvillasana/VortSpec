# Slider — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Slider is the design system's single-value range selection control. It renders a
styled native `<input type="range">`, so it inherits the built-in slider role and full
keyboard operability (arrow keys, Home/End) with no custom JavaScript. The track and
handle are tinted with the token-backed `accent-primary` utility. An optional row of
tick-mark labels can be rendered beneath the track to communicate the scale.

Use Slider for continuous or stepped numeric input where the approximate value matters
more than an exact typed number (volume, brightness, price range, zoom, opacity).

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--theme-primary` | `#0d6efd` | `accent-color` (track + handle, via `accent-primary`) |
| `--color-primary` | `#0d6efd` | focus ring color (`ring-primary`) |
| `--color-text-muted` | `#6c757d` | `color` (mark labels) |
| `--font-size-body` | `16px` | `font-size` (mark labels) |
| `--line-height-body` | — | `line-height` (mark labels) |
| `--radius-default` | `rounded` | `border-radius` (focus-ring shape) |
| `--spacing-1` | `4px` | gap between track and marks row (`gap-1`) |
| `--opacity-disabled` | — | `opacity` (disabled) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js`.
`accent-primary` maps to `accent-color: var(--theme-primary)` and is the sanctioned,
token-backed way to color a native range input. No hardcoded values.

---

### Variants

| Property | Values | Description |
|---|---|---|
| `size` | `small` \| `medium` \| `large` | Height of the control row (`h-4` / `h-5` / `h-6`) |
| `marks` | `{ value: number; label?: string }[]` | Optional tick-mark labels rendered beneath the track |

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | `accent-primary` track and handle | — |
| `focus-visible` | 2px primary ring, offset, `rounded` | Keyboard focus |
| `disabled` | `opacity-disabled`, `not-allowed` cursor | `disabled` attribute |

---

### Sizes

| Size | Control row height | Notes |
|---|---|---|
| `small` | `h-4` (16px) | Compact rows, dense toolbars |
| `medium` | `h-5` (20px) | Default |
| `large` | `h-6` (24px) | Prominent, touch-friendly targets |

Width fills the container (`w-full`). The native handle/track dimensions are drawn by
the platform and tinted via `accent-color`.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `size` | `small \| medium \| large` | `medium` | Height of the control row |
| `marks` | `{ value: number; label?: string }[]` | — | Evenly-distributed tick labels beneath the track |
| `min`, `max`, `step`, `value`, `defaultValue`, `onChange`, `disabled`, ... | native | — | `InputHTMLAttributes<HTMLInputElement>` spread onto the input |
| `aria-label`, `aria-labelledby`, `aria-describedby` | native ARIA | — | Passthrough for labelling |
| `className` | `string` | — | Layout overrides only; merged last via `cn()` onto the wrapper (or the input when there are no marks) |

---

### Accessibility

- Element: semantic native `<input type="range">` — keeps the implicit `slider` role,
  value semantics, and platform keyboard behavior.
- Labelling is the consumer's responsibility: pass `aria-label`, `aria-labelledby`
  (referencing a visible label), or associate a `<label htmlFor>`.
- `aria-describedby` passthrough links the control to helper/scale text.
- Visible focus indicator: `focus-visible:ring-2` (primary) with offset and `rounded`.
- Disabled state uses the native `disabled` attribute (removed from tab order).
- Mark labels are decorative scale hints; the authoritative value is exposed by the
  native input to assistive technology.

---

### Do Not

- Do not hardcode colors, spacing, radius, or type values — reference tokens via Tailwind theme.
- Do not use `style={{}}` or arbitrary `[..]` utilities (including percentage-positioned marks).
- Do not replace the native input with a custom `div`/pointer implementation — it forfeits
  free keyboard and screen-reader support.
- Do not ship a Slider without an accessible name (`aria-label` / `aria-labelledby` / `<label>`).
- Do not remove the focus ring.

---

### Implementation Tasks

- [x] Create `src/components/ui/slider.variants.ts` (CVA `size`)
- [x] Create `src/components/ui/Slider.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Render styled native `<input type="range">` with `w-full accent-primary cursor-pointer`
- [x] Implement `size` (small / medium / large) control-row height
- [x] Add focus-visible ring (primary, offset, `rounded`) and disabled pattern
- [x] Implement optional `marks` — `flex justify-between` label row (`text-body text-muted`)
- [x] Place `className` on the wrapper when marks are present, else on the input
- [x] Support `aria-label` / `aria-labelledby` / native attribute passthrough via spread
