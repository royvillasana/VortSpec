# Slider — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens

---

### Overview

Slider lets a user pick a numeric value within a bounded range by dragging the handle or
using the keyboard. Because it is a native `<input type="range">`, all value math,
clamping, and stepping are handled by the platform; the component only styles the control
and surfaces changes through the native `onChange`/`onInput` events.

---

### Trigger

- **Pointer**: press and drag the handle, or click/tap anywhere on the track to jump the
  value toward that point.
- **Keyboard**: focus the control (Tab), then use arrow / Home / End / Page keys.

---

### Flow

1. The control renders at the current `value` (or `defaultValue`), handle positioned by
   the browser according to `min`/`max`.
2. On drag, the browser moves the handle, snaps to `step`, and fires `onChange` with the
   updated `event.target.value` on each increment.
3. On keyboard input, the browser adjusts the value by one `step` (arrows) or jumps to a
   bound (Home/End) and fires `onChange`.
4. The consumer reads `event.target.value` (a string) and updates state; for a controlled
   slider the new `value` prop redraws the handle position.
5. When `marks` are provided, the label row beneath the track stays static, communicating
   the scale while the handle moves.

---

### Timing

- Value updates are immediate — no debounce or delay is introduced by the component.
- The focus ring and any track/handle tint transitions follow the browser's native
  rendering; no custom animation is added.

---

### Edge Cases

- **Below min / above max**: the native input clamps the value to `[min, max]`; out-of-range
  drags or programmatic values are corrected by the platform.
- **Non-aligned step**: the browser snaps to the nearest valid `step` boundary.
- **Missing min/max**: defaults to the HTML range default (`min=0`, `max=100`, `step=1`).
- **Disabled**: the `disabled` attribute blocks pointer and keyboard interaction and removes
  the control from the tab order.
- **Empty `marks` array**: treated as no marks — the bare input is rendered and `className`
  falls on the input.

---

### Accessibility & Keyboard

| Key | Action |
|---|---|
| `Tab` / `Shift+Tab` | Move focus to / from the slider |
| `ArrowRight` / `ArrowUp` | Increase value by one `step` |
| `ArrowLeft` / `ArrowDown` | Decrease value by one `step` |
| `Home` | Jump to `min` |
| `End` | Jump to `max` |
| `PageUp` / `PageDown` | Larger increment/decrement (browser-defined) |

- Implicit `slider` role and current value are exposed to assistive technology by the native
  input.
- An accessible name must be provided by the consumer via `aria-label`, `aria-labelledby`,
  or an associated `<label>`.
- A visible `focus-visible` ring (primary, offset) marks keyboard focus.

---

### Implementation Tasks

- [x] Render native `<input type="range">` so keyboard + role come for free
- [x] Spread native `min`/`max`/`step`/`value`/`onChange` so platform handles value math
- [x] Rely on native clamping/stepping for edge cases (no custom bounds logic)
- [x] Preserve visible `focus-visible` ring for keyboard operation
- [x] Passthrough `aria-label` / `aria-labelledby` / `aria-describedby` for naming
- [x] Treat empty `marks` array as "no marks"
