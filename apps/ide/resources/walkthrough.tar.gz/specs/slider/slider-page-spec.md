# Slider — Page/Usage Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens

---

### Purpose

Documents how the Slider atom is composed into forms and settings surfaces. Slider is a
form control, not a standalone page; this spec shows how it sits within a labelled field
group and how the optional `marks` scale is used.

---

### Component Inventory

| Component | Role |
|---|---|
| `Slider` | The range control itself (this atom) |
| `Text` / `<label>` | Accessible name associated with the slider |
| `Paragraph` / helper text | Optional description or live value readout |

---

### Usage Example

```tsx
import { Slider } from '@/components/ui/Slider';

// Simple, labelled slider
<label htmlFor="volume" className="text-body text-text">Volume</label>
<Slider id="volume" min={0} max={100} step={1} defaultValue={40} aria-labelledby="volume" />

// Slider with tick marks (scale communicated beneath the track)
<label id="quality-label" className="text-body text-text">Quality</label>
<Slider
  aria-labelledby="quality-label"
  min={0}
  max={3}
  step={1}
  defaultValue={1}
  size="large"
  marks={[
    { value: 0, label: 'Low' },
    { value: 1, label: 'Medium' },
    { value: 2, label: 'High' },
    { value: 3, label: 'Max' },
  ]}
  className="mt-2"
/>

// Disabled
<Slider aria-label="Locked" defaultValue={50} disabled />
```

---

### Responsive

- The input is `w-full`, so it fills whatever column or field the layout provides.
- The `marks` row is `flex justify-between`, distributing labels evenly across the full
  track width at any container size — no fixed positions or arbitrary values.
- `size` scales the control-row height (16 / 20 / 24px) for denser or more touch-friendly
  layouts; choose `large` for primary, touch-first surfaces.

---

### Accessibility

- Always give the slider an accessible name: `aria-label`, `aria-labelledby` (pointing at a
  visible label), or an associated `<label htmlFor>`.
- Provide a visible value readout when the exact number matters (e.g., a live `<output>`),
  associated via `aria-describedby`.
- Do not rely on the `marks` labels alone to name the control — they are scale hints, not
  the accessible name.
- The focus ring must remain visible for keyboard users.

---

### Implementation Tasks

- [x] Slider fills its container (`w-full`) within field groups
- [x] Demonstrate labelled usage via `aria-labelledby` / `<label htmlFor>`
- [x] Demonstrate `marks` usage with an evenly-distributed `flex justify-between` row
- [x] Demonstrate `size` and `disabled` usage
- [x] Document accessible-naming requirement and visible focus ring
