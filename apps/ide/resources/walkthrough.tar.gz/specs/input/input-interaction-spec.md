# Input — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./input-component-spec.md
**Figma prototype**: form-item / input — states: default, focus, filled, error, disabled

---

### Interaction Overview

`Input` is an interactive form control. The user focuses the field, types a value, and (on
validation) may see an error message. All state is native — the component adds accessible
wiring (label association, `aria-invalid`, `aria-describedby`) and a token-driven focus ring.

---

### Trigger

| Trigger | Element | Result |
|---|---|---|
| Click / tap label | `<label>` | Moves focus to the associated `<input>` (native `htmlFor`) |
| Click / tap / Tab | `<input>` | Focuses the control; focus ring appears |
| Type | `<input>` | Updates the value; placeholder (`text-muted`) is replaced by value (`text-text`) |
| `error` prop set | wrapper | Border + focus ring turn danger; error line renders and is announced |

---

### Flow

```
Step 1: Component mounts → id resolves (provided or React.useId()); label wires to control via htmlFor.
Step 2: User focuses (Tab or click) → focus-visible ring (ring-primary, or ring-danger when invalid) appears; outline suppressed.
Step 3: User types → value renders in text-text; hint (if present) stays beneath in text-muted.
Step 4: Validation sets `error` → border-danger + aria-invalid; error line (text-danger) renders with an id referenced by aria-describedby.
Step 5: User corrects input and `error` clears → danger styling and error line are removed; focus ring returns to primary.
Step 6: When `disabled` → control is non-interactive (opacity-disabled, bg-neutral-100, cursor-not-allowed) and skipped in the tab order.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Border / background color | default | default | `transition-colors` |
| Focus ring | instant | — | Applied on `:focus-visible` |

---

### Animation Details

Only a `transition-colors` on the control softens border/background changes (e.g. entering the
error state). The focus ring and disabled styling apply immediately.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| No `id` supplied | `React.useId()` generates one; label + describedby ids derive from it |
| `hint` and `error` both set | Both lines render; `aria-describedby` references both ids (hint first) |
| `error` set, no `hint` | Only the error line renders; `aria-describedby` references the error id |
| `required` | Asterisk (`text-danger`, `aria-hidden`) shows; native `required` carries semantics |
| `orientation="horizontal"` | Label sits beside the control (`items-center gap-3`); message line stays beneath |
| `disabled` | Non-focusable, non-editable; excluded from tab order |
| Long value | Native single-line scroll; layout unchanged |

---

### Accessibility & Keyboard

| Key | Action |
|---|---|
| `Tab` / `Shift+Tab` | Move focus into / out of the control |
| Character keys | Enter text |
| `Esc` | Native behavior (may clear in `type="search"`) |

- Focus is always visible via `focus-visible:ring-2`.
- `aria-invalid` + `aria-describedby` expose validation state and messages to screen readers.
- Label click focuses the control (native `htmlFor` association).

---

### Implementation Tasks

- [x] Resolve `id` (provided or `React.useId()`) and associate label via `htmlFor`
- [x] Apply `focus-visible` ring (primary, danger when invalid) and suppress outline
- [x] Derive invalid state + `aria-invalid` from `error`
- [x] Wire `aria-describedby` to hint and/or error ids only when rendered
- [x] Apply `transition-colors` for border/background state changes
- [x] Ensure disabled control is non-interactive and out of the tab order
