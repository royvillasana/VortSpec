# Visual Verify Report — Input

- **Component:** `Input` (molecule) · **Design source:** `figma` (`ojko9pGfsDAvmUf2DA38d2`) · **Date:** 2026-07-07
- **Spec:** `specs/input/input-component-spec.md` + `input-interaction-spec.md`
- **Impl:** `src/components/modules/Input.tsx` + `input.variants.ts`

## Live-rendered? No — no Storybook story for Input.
Runtime pixel comparison (375/768/1440) and runtime axe are **not executable — verified from source**
(spec ↔ code ↔ token model), NOT "failed". Static token/variant/state/ARIA dimensions are authoritative below.

## Checklist (source-verified)

### Variants — ✓
- `size`: small `px-2 py-1` / medium `px-2.5 py-2` / large `px-3 py-2.5` — matches spec 1:1.
- `orientation`: vertical `flex-col gap-1` / horizontal `items-center gap-3` (`fieldVariants`) — matches.
- `invalid` derived from `error` (not a public variant) — matches spec.
- `defaultVariants`: medium / vertical / invalid:false — matches spec defaults.

### States — ✓
default (`border-neutral-300 bg-white`), focus (`focus-visible:ring-2 ring-offset-2`, outline suppressed),
error (`border-danger` + `ring-danger` + `aria-invalid` + danger line), disabled
(`opacity-disabled bg-neutral-100 cursor-not-allowed`), filled/placeholder (`text-text` / `text-muted`).

### Tokens — ✓
Every utility resolves to a mapped token: `bg-white`, `border-neutral-300`, `border-1`→stroke,
`rounded`→radius-8, `text-text`/`text-muted`/`text-danger`, `ring-primary`/`ring-danger`,
spacing keys `1/2/2.5/3` all mapped, `ring-offset-2`→spacing-8, `text-body`/`font-base`/`font-regular`/`leading-body`/`opacity-disabled`.

### Token audit (grep hex/rgb/hsl/px/arbitrary/inline-style) — ✓
Zero matches across `Input.tsx` + `input.variants.ts`.

### Accessibility (source) — ✓
Real `<label htmlFor>` ↔ `<input id>` (`useId` fallback); `aria-invalid` on error; `aria-describedby` built
from **only rendered** ids (hint & error render independently — no dangling idref); required `*` `aria-hidden`;
visible focus ring never removed; error conveyed by text not color alone.

### Architecture — ✓
`.variants.ts` colocated; CVA mirrors spec; `forwardRef`; `...props` spread on `<input>`; `className` merged
LAST on wrapper via `cn()`; `VariantProps` exported (`InputVariants`); no inline `style={{}}`.

### Interaction spec — ✓
Focus/blur ring, error-focus danger ring, disabled non-interactive, controlled/uncontrolled via native attrs,
`className` layout-only — all satisfied.

## Discrepancies
None. No fixes applied.

## Gate: **PASS** — zero unresolved source-level discrepancies. Runtime pixel/axe not executable (no story).
