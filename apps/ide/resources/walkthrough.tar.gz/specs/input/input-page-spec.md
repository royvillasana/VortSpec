# Input — Usage / Composition Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./input-component-spec.md

Molecules have no page of their own; this documents how Input composes into higher-order
components and screens.

---

### Purpose

Provide the standard labeled text field used across forms — a self-contained, accessible unit
(label + control + help/error) that consumers place into layouts and validation flows.

---

### Component Inventory

| Element | Source |
|---|---|
| `<label>` | Native, associated via `htmlFor`/`id` |
| `<input>` | Native, styled by `inputVariants` |
| Help / error line | Inline `hint` / `error` text |

### Consumed By

| Consumer | Usage |
|---|---|
| `Form` (organism) | Primary text fields with per-field validation |
| Auth screens (Login / Sign-up) | Email, username, password fields |
| Settings / profile screens | Editable single-line values |

---

### Usage Example

```tsx
import { Input } from '@/components';

// Vertical (default) with hint
<Input label="Email" type="email" placeholder="you@example.com" hint="We'll never share it." />

// Required + error
<Input label="Username" required error="That username is taken." />

// Horizontal, small
<Input label="Port" orientation="horizontal" size="small" defaultValue="8080" />

// Layout override on the outer wrapper
<Input label="Search" type="search" className="max-w-sm" />
```

---

### Composition Rules

- Choose `size` to match surrounding form density; keep it consistent within a form.
- Layout (margin, max-width, grid placement) is applied via `className` on the outer wrapper; the control owns its internal padding and gaps.
- Provide `error` text (not just the danger border) whenever validation fails.
- Use `orientation="horizontal"` for compact inline fields (settings rows); default `vertical` for stacked forms.

---

### Responsive

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Control fills its container width (`w-full`); padding, radius, and gaps are fixed by token. Wrap the field in a constrained container (`max-w-*`) for readable line lengths. |

---

### Accessibility

- Every Input must have a `label` (or an equivalent `aria-label` via `...props`) — never an unlabeled control.
- Error and hint text are wired via `aria-describedby`; error additionally sets `aria-invalid`.
- Maintain a visible focus ring; do not override it away in consumer `className`.

---

### Implementation Tasks

- [x] Verify Input composes into forms with correct spacing via outer `className`
- [x] Verify label click focuses the control (htmlFor association)
- [x] Verify error state exposes `aria-invalid` + `aria-describedby`
- [x] Verify vertical and horizontal orientations render correctly
