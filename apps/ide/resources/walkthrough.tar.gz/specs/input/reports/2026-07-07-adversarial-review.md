# Adversarial Review — Input

Date: 2026-07-07

## Verdict: PASS

## Findings

| Severity | Area | Issue | Status |
|---|---|---|---|
| Info | A11y | `hint` and `error` render independently; when both are passed `aria-describedby` references both ids and both nodes exist → no dangling idref (matches spec: "both ids wired only when their element renders"). | Not a defect |
| Minor | Cleanup | `input.variants.ts` base lists both `border` and `border-1`; both resolve to `--stroke-width-1` (redundant, harmless). | Open (cosmetic) |

## Architecture Validation (8 checks)
1. ✓ `.variants.ts` colocated. 2. ✓ CVA mirrors spec 1:1 (`size`/`invalid`/`orientation`).
3. ✓ `defaultVariants` match spec. 4. ✓ `forwardRef<HTMLInputElement>`. 5. ✓ `...props` spread on control.
6. ✓ `className` merged LAST via `cn()`. 7. ✓ `VariantProps` exported (`InputVariants`). 8. ✓ No inline `style={{}}`.

## Token/Variant/State/A11y checklist
- Token audit: ✓ zero hex/rgb/hsl/px/arbitrary/inline-style.
- Variants: ✓ size + orientation; invalid derived from `error`.
- States: ✓ default/focus/error/disabled/filled.
- A11y: ✓ label association, aria-invalid, non-dangling aria-describedby, aria-hidden asterisk, visible focus ring.

## Resolved During Review
None — component was already correct.

## Notes
Runtime pixel diff and axe were **not executed** (no Storybook story). All results verified from source
(spec ↔ code ↔ token model). `npx tsc --noEmit` exits 0.
