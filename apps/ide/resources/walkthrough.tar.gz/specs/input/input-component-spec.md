# Input — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

A labeled single-line text field. Composes a `<label>`, the native `<input>` control, and a
help/error line into one accessible unit — associating the label to the control, exposing
validation state (`aria-invalid`), and announcing hint/error text via `aria-describedby`. Used
for form fields wherever a user enters short free text (name, email, search terms, etc.).

---

### Composed Atoms / Elements

| Element | Role |
|---|---|
| `<label>` | Visible label, associated to the control via `htmlFor`/`id`; shows a `text-danger` asterisk when `required` |
| `<input>` | Native single-line text control (styled by `size` + invalid state) |
| Help / error line | Muted `hint` (`text-muted`) or `error` (`text-danger`) message beneath the control, wired via `aria-describedby` |

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-white` | `#ffffff` | `background-color` (control, `bg-white`) |
| `--color-neutral-300` | `#dee2e6` | `border-color` (default, `border-neutral-300`) |
| `--color-status-danger` | `#dc3545` | `border-color` / `color` (invalid, asterisk, error text) |
| `--theme-primary` | — | `box-shadow` (focus ring, `ring-primary`) |
| `--color-text-default` | `#212529` | `color` (label + input value, `text-text`) |
| `--color-text-muted` | — | `color` (placeholder + hint, `text-muted`) |
| `--color-neutral-100` | `#f8f9fa` | `background-color` (disabled, `bg-neutral-100`) |
| `--stroke-width-1` | `1px` | `border-width` (`border-1`) |
| `--radius-8` | `8px` | `border-radius` (`rounded`) |
| `--spacing-2` … `--spacing-3` | 8–13px | `padding` (size ramp: `px-2 py-1` → `px-3 py-2.5`) |
| `--spacing-2` (ring offset) | 8px | `box-shadow` offset (`ring-offset-2`) |
| `--spacing-1` | 4px | `gap` (label ↔ control ↔ message, `gap-1`) |
| `--spacing-3` | 13px | `gap` (horizontal label ↔ control, `gap-3`) |
| `--opacity-disabled` | — | `opacity` (`disabled:opacity-disabled`) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js`. No hardcoded values.

---

### Variants

| Prop | Values | Effect |
|---|---|---|
| `size` | `small` \| `medium` (default) \| `large` | Control padding (`px-2 py-1` / `px-2.5 py-2` / `px-3 py-2.5`); all use `text-body` |
| `orientation` | `vertical` (default) \| `horizontal` | Label placement — stacked above (`flex-col gap-1`) vs. beside the control (`items-center gap-3`) |

The invalid state is not a public variant — it is derived from the `error` prop.

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | Neutral-300 border, white surface | — |
| `focus` | `ring-2 ring-primary ring-offset-2`, no outline | `:focus-visible` |
| `filled` | Value in `text-text`; placeholder in `text-muted` | User input |
| `error` | `border-danger`, `ring-danger` on focus, `aria-invalid`, danger error line | `error` prop set |
| `disabled` | `opacity-disabled`, `bg-neutral-100`, `cursor-not-allowed` | `disabled` prop |

---

### Sizes

| `size` | Padding |
|---|---|
| `small` | `px-2 py-1` |
| `medium` | `px-2.5 py-2` |
| `large` | `px-3 py-2.5` |

Typography is `text-body` at every size; the control fills its container width (`w-full`).

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `label` | `ReactNode` | — | Visible label, associated via `htmlFor`/`id` |
| `hint` | `string` | — | Muted help line beneath the control |
| `error` | `string` | — | Error message; sets danger state + `aria-invalid`, announced via `aria-describedby` |
| `size` | `"small" \| "medium" \| "large"` | `"medium"` | Control padding |
| `orientation` | `"vertical" \| "horizontal"` | `"vertical"` | Label placement |
| `id` | `string` | auto (`React.useId()`) | Control id; generated when omitted |
| `required` | `boolean` | — | Marks the field required; renders a `text-danger` asterisk |
| `disabled` | `boolean` | — | Disables the control |
| `className` | `string` | — | Layout overrides only, merged last on the **outer wrapper** |
| `ref` | `Ref<HTMLInputElement>` | — | Forwarded to the native `<input>` |
| `...props` | `InputHTMLAttributes<HTMLInputElement>` | — | Native input attributes spread (`size` omitted — reused as a variant) |

---

### Accessibility

- Label is associated to the control via `htmlFor`/`id`; `id` auto-generates with `React.useId()` when not supplied.
- `error` sets `aria-invalid` and the error text is referenced by `aria-describedby`; `hint` text is also referenced by `aria-describedby`. Both ids are wired only when their element renders.
- Visible focus indicator via `focus-visible:ring-2` (danger ring when invalid) — never `outline: none` without a replacement.
- The `required` asterisk is `aria-hidden`; the native `required` attribute carries the semantic to assistive tech.
- Error is conveyed by text, not color alone.

---

### Do Not

- Do not hardcode colors, spacing, radius, or stroke — reference tokens via the Tailwind theme.
- Do not remove the focus ring without an accessible replacement.
- Do not rely on the danger border color alone to signal an error — always provide `error` text.
- Do not pass `className` to style the control internals — it targets layout on the outer wrapper only.

---

### Implementation Tasks

- [x] Create `src/components/modules/input.variants.ts` (`inputVariants` size+invalid; `fieldVariants` orientation)
- [x] Create `src/components/modules/Input.tsx` (`forwardRef`, spreads props, `cn()` last on outer wrapper)
- [x] Implement `size` ramp (small/medium/large) and derived invalid state from `error`
- [x] Auto-generate `id` with `React.useId()` and associate `<label htmlFor>`
- [x] Wire `aria-invalid` + `aria-describedby` for hint and error
- [x] Render `required` asterisk (`text-danger`, `aria-hidden`)
- [x] Implement `orientation` (vertical/horizontal) wrapper layout
- [x] Verify token-only styling and visible focus ring
