# Visual-Verify Report — Table

- **Component**: Table (organism) — `src/components/sections/Table.tsx`, `src/components/sections/table.variants.ts`
- **Design source**: Figma (`ojko9pGfsDAvmUf2DA38d2` — Sections / Table)
- **Date**: 2026-07-07
- **Rendered live?** No — Table has **no Storybook story**. Runtime pixel/DOM/axe checks are **not executable**; verification is **source-of-truth** (spec ↔ code ↔ token model).

---

## Method
Read component + interaction spec, `tokens.css`, `tailwind.config.js`; audited every utility against the token map; validated semantic table structure and ARIA from source; verified sort/selection logic against the interaction spec.

## Checklist

### Visual (source-derived)
- ✓ Structure: real `<table class="w-full border-collapse text-body">` with `<thead>`/`<tbody>`, `<caption>` when provided.
- ✓ Header cells `<th scope="col">` carry `bg-neutral-100 font-regular` via `tableCellVariants({ head: true })`.
- ✓ Per-column `align` (left/center/right) applied to both header and body cells; `defaultVariants.align = left` matches spec.
- ✓ Body rows `hover:bg-neutral-100`; dividers `border-b border-neutral-300`.
- ✓ Sort affordance: `chevron-expand` (none) / `chevron-up` (asc) / `chevron-down` (desc) — matches spec state table.
- ✓ Empty state: single centered `No data` cell, `text-text-muted`, `colSpan` = all columns.
- ✓ Selectable: leading `<th>`/`<td>` checkbox column; select-all reflects `indeterminate` (verified Checkbox atom exposes DOM `indeterminate`).

### Token audit (zero tolerance) — PASS
- grep → no hex/rgb/hsl/px/arbitrary/inline-style in code.
- Spacing: `px-3`(12), `py-2`(8), `gap-1`(4) — all mapped.
- Colors: `bg-neutral-100`, `border-neutral-300`, `text-text`, `text-text-muted`, `ring-primary` — resolve to CSS vars.
- Radius: `rounded-sm` (`--radius-4`). Type: `text-body`, `font-base`, `leading-body`, `font-regular` — all tokens.
- **Divider leak check**: cell base `border-b border-neutral-300` — **token color present** (border width via `borderWidth.DEFAULT` = `--stroke-width-1`). No Preflight-gray leak.

### Accessibility (from source)
- ✓ Semantic `<table>`; `<th scope="col">` on every header.
- ✓ Sortable headers: `aria-sort` = none/ascending/descending; label wrapped in a keyboard-operable `<button type="button">` with visible focus ring (`sortButtonClasses`).
- ✓ Selection via accessible `Checkbox` atom; per-control `aria-label` ("Select all rows" / "Select row"); indeterminate select-all.
- ✓ Optional `<caption>` names the table.
- ✓ Sort `Icon` marked `aria-hidden`.

### Architecture (8 checks) — PASS (with documented exception)
- ✓ `.variants.ts` colocated · ✓ CVA mirrors spec (align + head) · ✓ defaultVariants match · **Exception**: intentionally **not** `forwardRef` — generic `function Table<T>` per spec (generics don't compose with forwardRef); `displayName` set. · ✓ `...props` spread on `<table>` · ✓ `className` merged LAST via `cn('w-full border-collapse text-body', className)` · ✓ `TableCellVariants` exported · ✓ no inline `style`.

### Interaction spec — PASS
Sort asc→desc→asc toggle per column, `onSortChange` fired; number vs `localeCompare`; selection Set keyed by `rowKey` survives re-order; select-all checked/unchecked/indeterminate; empty-data span; row hover.

## Discrepancies
1. **Null-sort order drift (FIXED)** — Interaction spec edge case says null/undefined values sort "last-ascending"; code returned `-1` for null `a`, sorting nulls **first**. Authoritative side = spec. Fix applied in `compareValues`: null `a` → `1`, null `b` → `-1`, so nulls sort last ascending (and first descending via the caller's `-res`). `tsc` exits 0.

## Gate
**PASS** — the one discrepancy found was resolved inline. Runtime pixel/axe not executable (no story); verified from source.
