# Table — Placement / Composition Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./table-component-spec.md

Organisms have no page of their own; this documents how Table composes into
data-dense screens, the components it hosts, and how it behaves responsively.

---

### Purpose

Define how the Table is composed inside list/detail and dashboard screens, which
cell components it hosts through column `render` slots, and how it stays usable
across breakpoints (horizontal scroll on narrow viewports).

---

### Component Inventory

| Component | Spec file | Status |
|---|---|---|
| `Checkbox` | `specs/checkbox/checkbox-component-spec.md` | Implemented |
| `Icon` | `specs/icon/icon-component-spec.md` | Implemented |
| `Text` (`link`) | `specs/text/text-component-spec.md` | Implemented (optional cell content) |
| `Tag` | `specs/tag/tag-component-spec.md` | Implemented (optional cell content) |
| `Button` | `specs/button/button-component-spec.md` | Implemented (optional actions cell) |

The Table itself renders only `<table>` structure, `Checkbox`, and `Icon`; any
richer cell content (links, tags, badges, actions) is injected by the consumer
through each column's `render`.

---

### Usage Example

```tsx
import { Table, type TableColumn } from '@/components/sections/Table';
import { Tag } from '@/components/ui/Tag';

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  status: 'active' | 'invited';
}

const columns: TableColumn<User>[] = [
  { key: 'name', header: 'Name', sortable: true, accessor: (u) => u.name },
  { key: 'email', header: 'Email', sortable: true, accessor: (u) => u.email },
  { key: 'role', header: 'Role', align: 'center', accessor: (u) => u.role },
  {
    key: 'status',
    header: 'Status',
    align: 'right',
    render: (u) => (
      <Tag variant={u.status === 'active' ? 'success' : 'info'}>{u.status}</Tag>
    ),
  },
];

export function UsersTable({ users }: { users: User[] }) {
  return (
    <Table
      columns={columns}
      data={users}
      rowKey={(u) => u.id}
      selectable
      caption="Team members"
      onSortChange={(key, dir) => console.log('sort', key, dir)}
      onSelectionChange={(keys) => console.log('selected', keys)}
    />
  );
}
```

---

### Anchors These Templates / Screens

| Template / Screen | Usage |
|---|---|
| Dashboard / list view | Primary data grid with sort + bulk selection |
| Settings — members | Selectable roster with role/status cells |
| Reports | Sortable read-only table (no selection) |

---

### Responsive Breakpoints

The `<table>` is full-width (`w-full`). Because a data table has an intrinsic
minimum column width, the **consuming screen wraps the Table in a horizontally
scrollable container** at narrow viewports rather than the organism reflowing
its own columns.

| Breakpoint | Layout change |
|---|---|
| 375px (mobile) | Wrap in `overflow-x-auto`; table scrolls horizontally; header row stays aligned to columns |
| 768px (tablet) | Table typically fits; `w-full` distributes remaining width |
| 1024px+ (desktop) | Full inline table; extra width absorbed by cell content |

```tsx
<div className="overflow-x-auto">
  <Table … />
</div>
```

Column collapsing / priority hiding is the screen's responsibility, not the
organism's.

---

### Spacing System

| Region | Value | Token |
|---|---|---|
| Cell padding H | 12px | `--spacing-12` (`px-3`) |
| Cell padding V | 8px | `--spacing-8` (`py-2`) |
| Row divider | 1px | `--stroke-width-1` (`border-b`) |

---

### Landmark & Accessibility Structure

- The Table is a real `<table>` region; pair it with a `caption` (or an external
  heading + `aria-labelledby`) so its purpose is announced.
- Sortable headers expose `aria-sort`; selection uses accessible `Checkbox`
  atoms with `aria-label`.
- When wrapped for horizontal scroll, give the scroll container `tabindex={0}`
  and an accessible name so keyboard users can scroll it.
- Cell text meets WCAG AA on the `white` / `neutral-100` surfaces.

---

### Implementation Tasks

**Composition**
- [x] Expose a typed `TableColumn<T>[]` + `data: T[]` + `rowKey` API
- [x] Host rich cell content (links, tags, actions) via column `render`
- [x] Support `selectable` selection and per-column `sortable`

**Behavior**
- [x] Keep the table full-width (`w-full border-collapse`)
- [x] Document the `overflow-x-auto` wrapper for narrow viewports

**Accessibility**
- [x] Real `<table>` / `<thead>` / `<tbody>` / `<th scope="col">` / `<caption>`
- [x] `aria-sort` on sortable headers; `aria-label` on selection checkboxes
- [x] Verify AA contrast on cell surfaces

**QA**
- [x] Visual QA at 375px (scroll) / 768px / 1440px against the Figma Table frame
- [x] All surface/spacing/border values verified as token references
