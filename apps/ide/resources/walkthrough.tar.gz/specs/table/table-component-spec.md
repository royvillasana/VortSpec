# Table — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Frame URL**: Sections / Table
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Organism that renders a semantic, generic data table. It maps a typed column
model (`TableColumn<T>[]`) over a row array (`T[]`) into a real `<table>` with
`<thead>` / `<tbody>`, `<th scope="col">` headers, and token-driven surfaces.
It supports per-column alignment, client-side sorting on sortable columns, and
optional row selection with an indeterminate select-all checkbox. It composes
the `Checkbox` atom (selection) and the `Icon` atom (sort affordance), and is
generic enough to host the full table-cell/table-column vocabulary (text, link,
tags, badge, actions, etc.) through each column's `render` slot.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-neutral-100` | neutral-100 | `background-color` (header cells `bg-neutral-100`, row hover `hover:bg-neutral-100`) |
| `--color-neutral-300` | neutral-300 | `border-color` (cell dividers `border-neutral-300`) |
| `--color-text-default` | text | `color` (cell text `text-text`) |
| `--color-text-muted` | text-muted | `color` (caption + empty state `text-text-muted`) |
| `--theme-primary` | primary | `box-shadow` (sort button focus ring `ring-primary`) |
| `--stroke-width-1` | 1px | `border-width` (bottom borders via `border-b`) |
| `--spacing-12` | 12px | `padding-inline` (cells `px-3`) |
| `--spacing-8` | 8px | `padding-block` (cells `py-2`) |
| `--radius-4` | 4px | `border-radius` (sort button `rounded-sm`) |
| `--font-family-base` | base | `font-family` (`font-base`) |
| `--font-size-body` | body | `font-size` (`text-body`) |
| `--line-height-body` | body | `line-height` (`leading-body`) |
| `--font-weight-regular` | regular | `font-weight` (header cells `font-regular`) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js`
to these CSS variables. Selection checkbox colors/sizing are owned by the
`Checkbox` atom; sort glyphs by the `Icon` atom. No hardcoded hex/px values.

---

### Variants

Composition-driven variants (no CVA `variant` prop on the table itself — the
table's structure is data-driven).

| Variant | Trigger | Description |
|---|---|---|
| `plain` (default) | `selectable={false}`, no `sortable` columns | Read-only table |
| `selectable` | `selectable` | Leading checkbox column + select-all header checkbox |
| `sortable` | any column `sortable` | Header renders a sort toggle button + sort `Icon` |

Cell alignment (`left` / `center` / `right`) is a per-column variant of
`tableCellVariants`.

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default row` | Base cell surface, `text-text` on `white` | — |
| `row hover` | `hover:bg-neutral-100` | Pointer over the `<tr>` |
| `row selected` | Row checkbox checked; membership in the selected set | Checkbox toggle |
| `sort none` | Header shows `chevron-expand`; `aria-sort="none"` | Sortable, not active |
| `sort asc` | Header shows `chevron-up`; `aria-sort="ascending"` | First / toggled activation |
| `sort desc` | Header shows `chevron-down`; `aria-sort="descending"` | Toggle from asc |
| `select-all indeterminate` | Header checkbox shows dash | Some (not all) rows selected |
| `empty` | Single centered `No data` cell (`text-text-muted`) spanning all columns | `data` empty |

---

### Sizes

The Table has no size prop; it is full-bleed (`w-full`) and its height is
intrinsic to row count and cell padding.

| Dimension | Value | Token |
|---|---|---|
| Cell padding H | 12px | `--spacing-12` (`px-3`) |
| Cell padding V | 8px | `--spacing-8` (`py-2`) |
| Divider border | 1px | `--stroke-width-1` (`border-b`) |
| Text size | body | `--font-size-body` (`text-body`) |

---

### Props / API

```ts
type TableColumn<T> = {
  key: string;
  header: React.ReactNode;
  align?: 'left' | 'center' | 'right';
  sortable?: boolean;
  render?: (row: T, rowIndex: number) => React.ReactNode;
  accessor?: (row: T) => React.ReactNode;
};
```

| Prop | Type | Default | Description |
|---|---|---|---|
| `columns` | `TableColumn<T>[]` | — | Column definitions in render order |
| `data` | `T[]` | — | Row data |
| `rowKey` | `(row: T, i: number) => React.Key` | — | Stable per-row key (React key + selection identity) |
| `selectable` | `boolean` | `false` | Adds a leading checkbox column + select-all header |
| `caption` | `ReactNode` | — | Rendered in `<caption>` |
| `onSortChange` | `(key: string, dir: 'asc'\|'desc') => void` | — | Fired after a header sort toggle |
| `onSelectionChange` | `(keys: React.Key[]) => void` | — | Fired after the selected set changes |
| `className` | `string` | — | Layout overrides only, merged last via `cn()` on `<table>` |
| `...props` | `HTMLAttributes<HTMLTableElement>` (minus `children`) | — | Native attributes spread onto `<table>` |

**No `forwardRef`.** `Table` is a generic function component (`function Table<T>`)
because generics do not compose cleanly with `React.forwardRef`, and a data table
rarely needs a forwarded `<table>` ref. `Table.displayName = 'Table'` is set for
devtools.

---

### Composed Atoms

| Atom | Slot | Spec |
|---|---|---|
| `Checkbox` | Leading selection column + select-all header (when `selectable`) | `specs/checkbox/checkbox-component-spec.md` |
| `Icon` | Trailing sort affordance on sortable headers | `specs/icon/icon-component-spec.md` |

---

### Accessibility

- Root is a real semantic `<table>`; header row uses `<th scope="col">`.
- Sortable headers carry `aria-sort` (`none` / `ascending` / `descending`) and
  wrap their label in a keyboard-operable `<button>` with a visible focus ring
  (`focus-visible:ring-2 ring-primary ring-offset-2`).
- Selection uses the accessible `Checkbox` atom; the select-all header checkbox
  reflects `indeterminate` when only some rows are selected. Each row checkbox
  has an `aria-label` ("Select row" / "Select all rows").
- An optional visible `<caption>` names the table for assistive tech.
- Cell text (`text-text`) on the `white` / `neutral-100` surfaces meets WCAG AA.

---

### Do Not

- Do not hardcode colors, spacing, radius, or border widths — reference tokens
  via the Tailwind theme.
- Do not render the table as stacked `<div>`s — it must be a real `<table>` with
  `<thead>` / `<tbody>` / `<th scope>`.
- Do not wrap `Table` in `forwardRef` — it is intentionally a generic function
  component.
- Do not omit `aria-sort` from sortable headers or `aria-label` from selection
  checkboxes.
- Do not use `style={{}}` or arbitrary `[...]` values for design-system tokens.

---

### Implementation Tasks

- [x] Create `src/components/sections/table.variants.ts` (`tableCellVariants` align + head, sort button focus classes)
- [x] Create `src/components/sections/Table.tsx` as a generic function component (no `forwardRef`)
- [x] Render real `<table className="w-full border-collapse text-body">` with `<thead>` / `<tbody>`
- [x] Header cells `<th scope="col">` with `bg-neutral-100 font-regular` and per-column `align`
- [x] Body cells `<td>` with `border-b border-neutral-300 text-text`, rows `hover:bg-neutral-100`
- [x] Client-side sort via `accessor` (falls back to `row[key]`) with number/string compare; toggle asc/desc; emit `onSortChange`; set `aria-sort`
- [x] Sort `Icon`: `chevron-expand` (none) / `chevron-up` (asc) / `chevron-down` (desc)
- [x] Optional selection: leading `Checkbox` column + indeterminate select-all; manage `Set` state; emit `onSelectionChange`
- [x] Optional `<caption>` and empty-state row spanning all columns
- [x] Accept `className` merged LAST on `<table>`; export `Table`, `TableProps`, `TableColumn`
- [x] Verify all surface/spacing/border values reference tokens (no hardcoded hex/px)
- [x] `tsc --noEmit` passes
