# Adversarial Review — Table

Date: 2026-07-07

## Verdict: PASS

## Findings

| Severity | Area | Issue | Status |
|---|---|---|---|
| Minor | Behavior/Spec | `compareValues` sorted `null`/`undefined` **first** in ascending order; interaction-spec edge case requires "last-ascending". | **Resolved** — fixed inline (nulls now sort last ascending). |
| Info | Runtime | No Storybook story → runtime axe / pixel diff not executable. | Documented (source-verified) |

No Blocker or Major findings after the inline fix.

## Architecture Validation (8 checks)
1. `.variants.ts` colocated — ✓ (`table.variants.ts`)
2. CVA variants mirror spec 1:1 — ✓ (`tableCellVariants`: `align` + `head`)
3. defaultVariants match spec default — ✓ (`align: left`, `head: false`)
4. `forwardRef` — ✓ **Documented intentional exception**: generic `function Table<T>` (generics ⊥ forwardRef); `Table.displayName = 'Table'` set. Spec explicitly mandates this.
5. `...props` spread on root — ✓ on `<table>` (`Omit<…, 'children'>`)
6. `className` merged LAST via `cn()` — ✓ `cn('w-full border-collapse text-body', className)`
7. `VariantProps` exported — ✓ `TableCellVariants`
8. No inline `style={{}}` for DS values — ✓

## Token / Variant / State / A11y checklist
- Token audit: PASS — no hex/rgb/hsl/px/arbitrary/inline-style; spacing (`px-3`, `py-2`, `gap-1`) mapped; colors + radius + type all resolve to CSS vars.
- Divider audit: PASS — cell `border-b border-neutral-300` (token color present); width via `borderWidth.DEFAULT`; no untokenized divider.
- Variants: plain / selectable / sortable composition-driven; per-column align — all correct.
- States: default, row-hover, selected, sort none/asc/desc, indeterminate, empty — all present.
- A11y: `<table>` + `<th scope="col">`; `aria-sort`; sort `<button>` focus ring; Checkbox `aria-label`; indeterminate select-all; optional `<caption>`.

## Resolved During Review
- Fixed `compareValues` null ordering to match the interaction spec ("last-ascending"). `npx tsc --noEmit` → exit 0.

## Notes
Verified from source (no Table story). Runtime axe and pixel-diff **not executable** — reported as source-verified, never "passed at runtime." Sort direction for nulls in descending is the natural inverse via the caller's `-res`; the spec only pins the ascending case.
