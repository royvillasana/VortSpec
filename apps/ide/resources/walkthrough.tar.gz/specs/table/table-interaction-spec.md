# Table — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./table-component-spec.md
**Figma prototype**: Sections / Table — Sort + Selection behaviors

---

### Interaction Overview

Two interactive affordances layer over a static grid: sortable column headers
that toggle the row order and reflect direction through an icon + `aria-sort`,
and an optional per-row selection model driven by checkboxes with an
indeterminate select-all in the header. Everything is keyboard operable and
client-side; consumers observe changes through `onSortChange` and
`onSelectionChange`.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Click / `Enter` / `Space` | Sortable header `<button>` | Column `sortable` |
| Click / `Space` | Row `Checkbox` | `selectable` |
| Click / `Space` | Select-all header `Checkbox` | `selectable` |
| Hover | Body `<tr>` | — |

---

### Flow

```
Step 1: Pointer over a row → row surface tints (hover:bg-neutral-100).
Step 2: Activate a sortable header → dir resolves:
        - new column        → asc
        - same column, asc  → desc
        - same column, desc → asc
        Rows re-sort by accessor (or row[key]); header Icon updates
        (chevron-up / chevron-down); aria-sort updates; onSortChange(key, dir) fires.
Step 3: Toggle a row checkbox → its key is added/removed from the selected set;
        onSelectionChange([...keys]) fires.
Step 4: Toggle the select-all header checkbox:
        - if all visible rows selected → clears them
        - otherwise                    → selects all visible rows
        Header checkbox becomes checked / unchecked / indeterminate accordingly;
        onSelectionChange fires.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Row hover tint | instant | — | `hover:bg-neutral-100` |
| Sort re-order | instant | — | React state (no animated reflow) |
| Sort button focus ring | instant | — | `focus-visible:ring-2 ring-primary` |
| Checkbox check/indeterminate | owned by `Checkbox` | — | `peer-*` transitions in the atom |

Sorting is synchronous client-side (`Array.prototype.sort` over a copy);
numbers compare numerically, everything else via `localeCompare`.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| `data` empty | Single centered `No data` cell (`text-text-muted`) spanning every column |
| All rows selected | Select-all header checkbox is checked (not indeterminate) |
| Some rows selected | Select-all header checkbox is `indeterminate` (dash glyph) |
| No rows selected | Select-all header checkbox is unchecked |
| `sortable` column with custom `render` but no `accessor` | Sort still uses `row[key]` value |
| Mixed `align` columns | Each column's header and body cells align independently (`left`/`center`/`right`) |
| Re-sort after selection | Selection keyed by `rowKey`, so it survives re-ordering |
| `null` / `undefined` cell values | Sorted last-ascending (null-safe compare) |

---

### Accessibility & Keyboard

| Key | Action |
|---|---|
| `Tab` / `Shift+Tab` | Move between sort buttons and checkboxes in DOM order |
| `Enter` / `Space` | Activate a focused sort header button |
| `Space` | Toggle a focused checkbox |

- Sortable headers expose `aria-sort` and are native `<button>`s inside
  `<th scope="col">` — announced with role, label, and sort state.
- Selection checkboxes are the accessible `Checkbox` atom with per-control
  `aria-label`; the select-all reflects `indeterminate`.
- Visible focus rings on every interactive control (no `outline: none` without a
  replacement ring).

---

### Implementation Tasks

- [x] Sortable header renders a keyboard-operable `<button>` with focus ring
- [x] Sort toggles asc → desc → asc per column; updates Icon + `aria-sort`; emits `onSortChange`
- [x] Client-side sort via `accessor` / `row[key]` with number + string compare (null-safe)
- [x] Row checkboxes toggle membership; emit `onSelectionChange`
- [x] Select-all computes checked / indeterminate from visible row keys
- [x] Empty-data state renders a single spanning cell
- [x] Row hover tint via `hover:bg-neutral-100`
