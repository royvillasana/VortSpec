# NavItem — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

A single navigation link used across every navigation surface in the system:
horizontal top bars, vertical rails, and inline (tree) menus at multiple depths.
It renders a semantic `<a>` when a destination (`href`) is supplied, otherwise a
`<button type="button">` for in-page navigation triggers (e.g. expanding a
submenu). It supports a leading icon, a trailing submenu affordance, and active
and disabled states.

---

### Composed Atoms

| Atom | Role |
|---|---|
| `Icon` | Optional consumer-supplied leading `icon`; trailing submenu chevron (`chevron-down` horizontal / `chevron-right` inline/vertical) when `hasChildren` |
| Inline text | The link label (`children`), wrapped in a `<span>` |

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--theme-primary` | — | `color` (active / hover text) |
| `--color-text-default` | `#212529` | `color` (default text, `text-text`) |
| `--color-neutral-100` | `#f8f9fa` | `background-color` (hover surface) |
| `--brand-primary-100` | — | `background-color` (active surface, vertical/inline) |
| `--radius-8` | `8px` | `border-radius` (`rounded`) |
| `--spacing-12` | `13px` | horizontal padding (`px-3`) |
| `--spacing-8` | `8px` | vertical padding (`py-2`), gap (`gap-2`) |
| `--spacing-16` | `16px` | level-2 indent (`pl-4`) |
| `--spacing-24` | `24px` | level-3 indent (`pl-6`) |
| `--font-size-body` | — | `font-size` (`text-body`) |
| `--line-height-body` | — | `line-height` (`leading-body`) |
| `--opacity-disabled` | — | `opacity` (disabled) |

All references resolve through the Tailwind theme mapping in
`tailwind.config.js`. No hardcoded values, no arbitrary utilities.

---

### Variants

Two CVA axes — `orientation` × `level` — plus `active` and `disabled` state
axes. Deeper levels add left indent for inline/vertical layouts only.

| `orientation` (default `horizontal`) | Submenu chevron | Level indent |
|---|---|---|
| `horizontal` | `chevron-down` | none (level ignored) |
| `vertical` | `chevron-right` | level 2 → `pl-4`, level 3 → `pl-6` |
| `inline` | `chevron-right` | level 2 → `pl-4`, level 3 → `pl-6` |

| `level` (default `1`) | Effect |
|---|---|
| `1` | No indent |
| `2` | `pl-4` (inline/vertical) |
| `3` | `pl-6` (inline/vertical) |

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | `text-text` | Base |
| `hover` | `bg-neutral-100 text-primary` | Pointer over (non-active, non-disabled) |
| `active` | `text-primary`; vertical/inline add `bg-brand-primary-100`; `aria-current="page"` | `active` prop |
| `focus` | 2px primary focus ring with offset | Keyboard focus (`focus-visible`) |
| `disabled` | `opacity-disabled`, `pointer-events-none`, `aria-disabled` | `disabled` prop |

---

### Sizes

Single intrinsic size. Padding (`px-3 py-2`), radius (`rounded`), gap (`gap-2`),
and body typography (`text-body` / `leading-body`) are fixed by token. Level
indent is the only depth-driven dimension.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `orientation` | `"horizontal" \| "vertical" \| "inline"` | `"horizontal"` | Navigation surface; drives chevron direction and indent behavior |
| `level` | `1 \| 2 \| 3` | `1` | Nesting depth; adds left indent for inline/vertical |
| `active` | `boolean` | `false` | Current item — active styling + `aria-current="page"` |
| `disabled` | `boolean` | `false` | Dim + block interaction + `aria-disabled` |
| `icon` | `ReactNode` | — | Optional leading icon |
| `hasChildren` | `boolean` | `false` | Render trailing submenu chevron |
| `href` | `string` | — | When set, renders `<a>`; otherwise `<button type="button">` |
| `children` | `ReactNode` | — | Link label |
| `className` | `string` | — | Layout overrides only, merged last |
| `...props` | `AnchorHTMLAttributes<HTMLAnchorElement>` | — | Native attributes spread (`children` omitted) |

---

### Accessibility

- Active item sets `aria-current="page"`.
- Disabled item sets `aria-disabled` and removes pointer events; when rendered
  as a `<button>` it also receives the native `disabled` attribute.
- Renders semantic `<a>` (with `href`) or `<button type="button">` (without).
- Visible focus ring via `focus-visible:ring-2 ring-primary ring-offset-2`.
- The submenu chevron is decorative (`aria-hidden`); meaning comes from the label.

---

### Do Not

- Do not hardcode colors, spacing, radius, or typography — reference tokens via
  the Tailwind theme.
- Do not render an `<a>` without an `href` (use the button form instead).
- Do not rely on color alone to convey the active state — `aria-current` carries it.
- Do not apply level indent on horizontal orientation.

---

### Implementation Tasks

- [x] Create `src/components/modules/nav-item.variants.ts` (CVA: `orientation`, `level`, `active`, `disabled` + compoundVariants for indent/active surface)
- [x] Create `src/components/modules/NavItem.tsx` (`forwardRef`, `cn()` last, named export)
- [x] Render `<a>` when `href` present, else `<button type="button">`
- [x] Implement default / hover / active / focus / disabled states with tokens
- [x] Add leading `icon` slot and `hasChildren` trailing chevron (direction per orientation)
- [x] Wire `aria-current`, `aria-disabled`, and native button `disabled`
- [x] Verify token-only styling and `tsc` type-check
