# NavItem — Page / Usage Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens

---

### Purpose

Show how `NavItem` composes into real navigation surfaces: a horizontal top-bar
menu and an inline (tree) side menu with nested levels. NavItem is a molecule —
it is the repeated unit inside `<nav>` landmarks and menu lists.

---

### Component Inventory

| Component | Role |
|---|---|
| `NavItem` | The repeated navigation link unit |
| `Icon` | Leading icons and trailing submenu chevrons (composed inside NavItem) |
| `<nav>` landmark | Semantic container the consumer supplies |

---

### Usage Example

Horizontal bar:

```tsx
<nav aria-label="Primary" className="flex items-center gap-1">
  <NavItem href="/" active>Home</NavItem>
  <NavItem href="/docs" hasChildren>Docs</NavItem>
  <NavItem href="/pricing">Pricing</NavItem>
  <NavItem href="/settings" disabled>Settings</NavItem>
</nav>
```

Inline tree (nested levels):

```tsx
<nav aria-label="Documentation" className="flex flex-col gap-1">
  <NavItem orientation="inline" href="/docs" hasChildren active>
    Getting Started
  </NavItem>
  <NavItem orientation="inline" level={2} href="/docs/install">Install</NavItem>
  <NavItem orientation="inline" level={2} href="/docs/config" hasChildren>
    Configuration
  </NavItem>
  <NavItem orientation="inline" level={3} href="/docs/config/tokens">
    Tokens
  </NavItem>
</nav>
```

---

### Responsive

- Horizontal bars collapse to a vertical/inline menu on narrow viewports (the
  consumer swaps `orientation`); NavItem itself is layout-agnostic and grows to
  its container.
- Indent (`level`) is preserved across breakpoints so hierarchy stays legible.

---

### Accessibility

- Each navigation region is wrapped in a `<nav>` landmark with an `aria-label`.
- The active item carries `aria-current="page"`.
- Disabled items expose `aria-disabled` and are removed from pointer interaction.
- Keyboard traversal follows natural DOM order with a visible focus ring.

---

### Implementation Tasks

- [x] Compose NavItem inside `<nav>` landmarks (horizontal + inline examples)
- [x] Demonstrate `active`, `disabled`, `hasChildren`, and nested `level` usage
- [x] Confirm orientation-driven chevron direction and indent in context
- [x] Verify token-only styling end to end
