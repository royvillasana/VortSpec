# NavItem — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens

---

### Overview

NavItem is an interactive navigation element. It behaves as a link (navigating
to `href`) or, when no `href` is given, as a button that a parent menu wires to
an action such as expanding/collapsing a submenu. Hover, focus, active, and
disabled states give continuous feedback.

---

### Trigger

- **Pointer**: click/tap activates the link or button.
- **Keyboard**: `Enter` (and `Space` for the button form) activates the focused item.
- **Hover**: pointer entering a non-active, non-disabled item.
- **Focus**: keyboard focus reveals the focus ring.

---

### Flow

1. User moves pointer over an enabled, non-active item → `bg-neutral-100` surface
   and `text-primary` label appear (hover).
2. User clicks:
   - With `href` → the `<a>` navigates.
   - Without `href` → the `<button>` fires its handler (e.g. toggles the submenu
     that `hasChildren` advertises).
3. The current item is passed `active` → it renders `text-primary` (and a
   `bg-brand-primary-100` surface for vertical/inline) and exposes
   `aria-current="page"`.
4. Keyboard users tabbing through the nav see a 2px primary focus ring on the
   focused item.

---

### Timing

- State changes are immediate (hover/focus/active) — no scripted animation.
- No debounce or delay; feedback tracks input directly.

---

### Edge Cases

- **No `href`** → renders `<button type="button">` instead of `<a>`; no navigation,
  handler-driven only.
- **`hasChildren`** → shows a trailing chevron affordance (`chevron-down` for
  horizontal, `chevron-right` for inline/vertical) signalling an expandable submenu;
  the parent owns the expanded/collapsed logic.
- **`disabled`** → `pointer-events-none` blocks hover/click; `aria-disabled` is set;
  the button form also gets native `disabled`. No hover surface appears.
- **`active` + `disabled`** → disabled styling wins interaction-wise; `aria-current`
  still communicates the current location.
- **Long label** → text wraps/grows with the item; indent (level) is preserved.

---

### Accessibility & Keyboard

| Key | Action |
|---|---|
| `Tab` / `Shift+Tab` | Move focus between items |
| `Enter` | Activate link or button |
| `Space` | Activate the button form |

- Focus is always visible (`focus-visible` ring), never suppressed.
- `aria-current="page"` marks the active item for assistive tech.
- `aria-disabled` communicates the disabled state; pointer events are removed.
- Decorative chevron is `aria-hidden`.

---

### Implementation Tasks

- [x] Render `<a>`/`<button>` by `href` presence
- [x] Hover feedback for enabled, non-active items
- [x] `focus-visible` ring on keyboard focus
- [x] `active` → `aria-current="page"` + active styling
- [x] `disabled` → `aria-disabled` + `pointer-events-none` (+ native button `disabled`)
- [x] `hasChildren` → orientation-correct decorative chevron
