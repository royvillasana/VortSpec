# Visual Verify Report — NavItem

- **Design source:** `figma` (Branch A) · **Component:** `NavItem` (molecule) · **Date:** 2026-07-07
- **Spec:** `specs/nav-item/nav-item-component-spec.md` + `nav-item-interaction-spec.md` ·
  **Impl:** `src/components/modules/NavItem.tsx` + `nav-item.variants.ts` · **Composes:** `Icon` atom
- See `specs/visual-verify-report.md` for shared context and the runtime-check environment limitation.

## Result: PASS (source-of-truth) — 0 open source-level discrepancies

All spec + interaction tasks are checked. Every token, variant, state, and ARIA dimension is
verified against the specs and the `tailwind.config.js` → `tokens.css` token map. No hardcoded
values, no inline `style`, no arbitrary utilities. The two runtime dimensions (live-viewport pixel
comparison + axe) remain open — no render harness in this env (see below).

---

## ⚠️ Runtime dimensions NOT executed (environment limit)

This environment has NO browser driver (Playwright/Puppeteer NOT installed) and no render harness
for this component, so the Figma-flow **live-viewport pixel comparison (375 / 768 / 1440px)** and
**runtime axe audit** CANNOT be executed and are NOT asserted. Everything below is a
**source-of-truth verification** (spec ↔ code ↔ token model), authoritative for
token/variant/state-wiring/ARIA dimensions. To close runtime dims: install a browser driver +
Storybook/harness, screenshot each viewport vs the Figma frame, and run axe-core.

---

## Checklist (source-verified)

### Variants ✓
Two CVA axes (`orientation` × `level`) + `active`/`disabled` state axes — matches spec.

| Axis | Value | Class → token | OK |
|---|---|---|---|
| orientation | horizontal | (base only; chevron `chevron-down`) | ✓ |
| orientation | vertical | chevron `chevron-right`; active surface `bg-brand-primary-100` | ✓ |
| orientation | inline | chevron `chevron-right`; active surface `bg-brand-primary-100` | ✓ |
| level | 1 | no indent | ✓ |
| level | 2 (vertical/inline) | `pl-4` → `--spacing-16` | ✓ |
| level | 3 (vertical/inline) | `pl-6` → `--spacing-24` | ✓ |

Chevron direction resolved at runtime (`inline`/`vertical` → `chevron-right`, else `chevron-down`)
matches the spec table. `defaultVariants` = horizontal / 1 / active false / disabled false ✓.
CompoundVariants correctly restrict indent + active surface to vertical/inline only (horizontal
ignores level, per "Do Not") ✓.

### States ✓
| State | Class → token | OK |
|---|---|---|
| default | `text-text` → `--color-text-default` | ✓ |
| hover (non-active) | `hover:bg-neutral-100` + `hover:text-primary` | ✓ |
| active | `text-primary`; vertical/inline `bg-brand-primary-100`; `aria-current="page"` | ✓ |
| focus | `focus-visible:ring-2 ring-primary ring-offset-2` | ✓ |
| disabled | `opacity-disabled` + `pointer-events-none` + `aria-disabled` (+ native `disabled` on button form) | ✓ |

Interaction spec's `active + disabled` edge case honored: disabled class wins interaction while
`aria-current` still renders ✓.

### Tokens ✓
| Utility | → token | OK |
|---|---|---|
| `gap-2` | `--spacing-8` | ✓ |
| `px-3` | `--spacing-12` | ✓ |
| `py-2` | `--spacing-8` | ✓ |
| `pl-4` / `pl-6` | `--spacing-16` / `--spacing-24` | ✓ |
| `rounded` | `--radius-8` | ✓ |
| `text-body` / `leading-body` | `--font-size-body` / `--line-height-body` | ✓ |
| `font-base` / `font-regular` | `--font-family-base` / `--font-weight-regular` | ✓ |
| `text-text` / `text-primary` / `bg-neutral-100` / `bg-brand-primary-100` | text-default / theme-primary / neutral-100 / brand-primary-100 | ✓ |
| `ring-primary` | `--theme-primary` | ✓ |
| `opacity-disabled` | `--opacity-disabled` | ✓ |

### Accessibility ✓
- Renders semantic `<a>` when `href` present, else `<button type="button">` (isLink switch) ✓.
- `aria-current="page"` on active; `aria-disabled` on disabled; native `disabled` only on button form ✓.
- Visible focus ring never suppressed ✓. Trailing chevron `aria-hidden` (decorative), meaning carried
  by label span ✓.

### Token audit ✓
Zero hardcoded hex / `rgb()` / `px`; zero inline `style={{}}`; zero arbitrary `[..]`. Every
color/spacing/radius/type utility resolves to a `var(--…)` via `tailwind.config.js`. `ring-2` /
`ring-offset-2` are focus-indicator geometry (analogous to the allowed outline-width), not DS
spacing/color tokens — acceptable.

---

## Observations (non-blocking)

- **O-A — forwardRef typed to `HTMLAnchorElement` only.** The component can render a `<button>`, but
  the ref type is `HTMLAnchorElement` and is cast via `ref as React.Ref<never>`. Functional and
  matches the spec's stated API (props extend `AnchorHTMLAttributes`), but a consumer forwarding a
  ref to the button form gets a loose type. Cosmetic type-precision note only.

## Gate

**Token · variant · state · semantic/ARIA dimensions: PASSED** — 0 open source-level discrepancies.
**Runtime dimensions (live-viewport pixel + axe): still not executable** in this environment.
