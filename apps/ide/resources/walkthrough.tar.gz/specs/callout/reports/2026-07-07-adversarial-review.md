# Adversarial Review — Callout

**Component**: Callout (molecule)
**Date**: 2026-07-07
**Design source**: Figma / Branch A (`specs/callout/`)
**Files**: `src/components/modules/Callout.tsx`, `src/components/modules/callout.variants.ts`
**Skill**: /adversarial-review

> Render limitation: no browser/screenshot tool available. Review is source-of-truth
> (code + token mapping vs. spec) plus static analysis (token-audit grep, `tsc --noEmit`).
> No pixel/screenshot claims are made.

---

## Verdict

**PASS** — No Blocker or High findings. The implementation mirrors all three Callout
specs, is fully token-referenced, and passes the Architecture Validation Checklist and
type check. One Low finding is a token-system limitation that is spec-conformant; two
nits carry no action.

---

## Findings

| Severity | Area | Issue | Status |
|---|---|---|---|
| Low | A11y / contrast | `success` (`#198754`) and `danger` (`#dc3545`) title/icon color sits ~3.9–4.0:1 on `neutral-100` — marginally under WCAG AA 4.5:1 for normal text. Spec maps these statuses to the raw status color and no `*-emphasis` token exists for success/danger. Icon is decorative (`aria-hidden`) and the message body (`text-text`, high contrast) carries meaning, so status is never conveyed by low-contrast text alone. | Accepted — spec-conformant; shared/token concern (see below) |
| Info | A11y / role | Default `role="note"` is not a live region; urgent messages depend on the consumer opting into `role="alert"`. This is the documented spec behavior (note default, alert for urgent). | By design (matches spec) |
| Nit | Styling | Base class uses both `border` and `border-1`; both resolve to `--stroke-width-1` (1px). `border` also guarantees `border-style: solid` alongside preflight. Redundant width utility but harmless and token-pure. | No action |

### Variant / state coverage
- All 5 `status` values implemented (info/warning/success/danger/secondary), mirror Figma `Status` 1:1, `defaultVariants.status = 'info'`. ✓
- No interactive states expected or present (static molecule). ✓
- Edge cases from interaction spec covered in code: `icon={null}` hides icon (`icon !== null` guard); custom `icon` node overrides default (`icon ?? <Icon…>`); no `title` renders message only; `role="alert"` passthrough; long message wraps (`items-start`, `flex-col`). ✓

### Token audit
```
grep -nE '#[0-9a-fA-F]{3,8}|rgb\(|hsl\(|style=\{\{|\[[0-9]+px\]' Callout.tsx callout.variants.ts
→ (no matches)  ✓
```
No hex, rgb/hsl, inline `style`, or `[Npx]` arbitrary values. No Tailwind `/opacity` modifiers on `var()` colors (would produce invalid `rgb(var()/…)`). ✓

### A11y adversarial
- Icon decorative via Icon atom (no `label` ⇒ `aria-hidden`); explicit `aria-hidden` also passed. ✓
- Meaning carried by text + icon shape, not color alone. ✓
- Message body dark-on-light contrast strong. ✓
- `role` overridable; `title` attribute intentionally omitted from spread (`Omit<…, 'title'>`) so a text title prop can't leak into a native tooltip. ✓

### Responsive
- No fixed dimensions; box fills container at 375/768/1440; padding/gap/radius token-fixed; text reflows. No viewport branches. ✓ (structural)

### Interaction-spec compliance
- No transitions/animations introduced. ✓
- Status resolves to `info` default; border + emphasis color applied on `neutral-100`. ✓

---

## Resolved During Review

None. No implementation defects were found; no inline changes were required.
`tsc --noEmit` → exit 0 (baseline, unchanged).

### Shared / out-of-scope concerns (not fixed here)
- No `--color-status-success-emphasis` / `--color-status-danger-emphasis` tokens exist.
  A darker emphasis token for these two statuses would raise the success/danger
  title/icon text contrast to ≥4.5:1. Adding tokens requires editing
  `src/styles/tokens.css` + `tailwind.config.js` (shared files, out of scope for this
  component review). Recommend the design system add these two emphasis tokens, then
  switch Callout's success/danger variants to `text-success-emphasis` / `text-danger-emphasis`.

---

## Architecture Validation Checklist

| Check | Result |
|---|---|
| CVA variants live in separate `.variants.ts` (`callout.variants.ts`) | ✓ |
| Variants mirror the spec 1:1 (5 statuses, no extras/omissions) | ✓ |
| `defaultVariants` declared (`status: 'info'`) | ✓ |
| `forwardRef` used, ref forwarded to root `<div>` | ✓ |
| Native props spread (`{...props}`) onto root | ✓ |
| `className` merged last via `cn()` (`cn(calloutVariants({…}), className)`) | ✓ |
| `VariantProps` type exported (`CalloutVariants`, plus `CalloutStatus`) | ✓ |
| No inline `style={{}}` for design-system values | ✓ |
| `displayName` set | ✓ |
| All color/spacing/radius/font values resolve to `var(--token)` via Tailwind | ✓ |
