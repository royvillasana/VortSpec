# Callout — Usage / Composition Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./callout-component-spec.md

Molecules have no page of their own; this documents how Callout composes into higher-order components and screens.

---

### Consumed By

| Consumer | Usage |
|---|---|
| Documentation screens | Notes, tips, warnings, and error callouts inline in prose |
| `Form` (organism) | Validation summary or contextual guidance |
| Screens | Status messaging within content regions |

---

### Composition Rules

- Choose `status` by meaning (info/warning/success/danger/secondary), not by color preference.
- Layout (margin, max-width, block placement) is applied via `className`; the box owns its internal padding and gaps.
- Message content goes in `children`; keep the optional `title` short.
- Use `role="alert"` only for messages that must interrupt; otherwise keep the `note` default.

---

### Accessibility

- Always pair the status color with descriptive text — color is never the only cue.
- Reserve `role="alert"` for urgent, time-sensitive content to avoid announcement noise.

---

### Implementation Tasks

- [x] Verify Callout renders inside documentation prose with correct spacing
- [x] Verify each status maps to the correct border + emphasis color
- [x] Verify `role="alert"` announces urgent messages
