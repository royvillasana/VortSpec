# Visual Verify Report — Callout

- **Design source:** `figma` (Branch A) · **Component:** `Callout` (molecule) · **Date:** 2026-07-07 (re-verified; originally 2026-07-06)
- **Spec:** `specs/callout/callout-component-spec.md` · **Impl:** `src/components/modules/Callout.tsx` +
  `callout.variants.ts` · **Composes:** `Icon` atom
- See `specs/visual-verify-report.md` for shared context and the runtime-check environment limitation.

## Result: PASS (source-of-truth) — 0 open source-level discrepancies

All spec tasks are checked. Every token, variant, state, and ARIA dimension verified against the
Component + Interaction spec and the `tailwind.config.js` → `tokens.css` token map. The two runtime
dimensions (live-viewport pixel comparison + axe) remain **open** — no render harness in this env
(see below).

---

## ⚠️ Runtime dimensions NOT executed (environment limit)

The Figma-flow checklist's **live 375 / 768 / 1440px pixel comparison** and **runtime axe audit**
were **not run** — this environment cannot render the component: no mount harness
(`src/main.tsx` / `App.tsx` / `index.html` all absent), zero `.stories.tsx`, and no browser driver
(Playwright/Puppeteer not installed). Identical limitation to the system-wide report.
**To close:** add a mount harness or run `/storybook`, install a browser driver, then screenshot
Callout at the three viewports against the Figma frame and run axe-core.

Everything below is a **source-of-truth** verification (spec ↔ code ↔ token model) — fully
authoritative for token, variant, state-wiring, and semantic/ARIA dimensions.

---

## Checklist (source-verified)

### Variants — all 5 statuses present & correct ✓
Mirror the Figma `Status` property; surface is always `neutral-100`, border + emphasis text vary.
`DEFAULT_ICON` map matches the spec table exactly.

| `status` | Border class → token | Text class → token | Default icon |
|---|---|---|---|
| `info` (default) | `border-info` → `--color-status-info` | `text-info-emphasis` → `--color-status-info-emphasis` | `info` ✓ |
| `warning` | `border-warning` → `--color-status-warning` | `text-warning-emphasis` → `--color-status-warning-emphasis` | `exclamation-triangle` ✓ |
| `success` | `border-success` → `--color-status-success` | `text-success` → `--color-status-success` | `check-circle` ✓ |
| `danger` | `border-danger` → `--color-status-danger` | `text-danger` → `--color-status-danger` | `x-circle` ✓ |
| `secondary` | `border-secondary` → `--theme-secondary` | `text-secondary-emphasis` → `--color-status-secondary-emphasis` | `info` ✓ |

`defaultVariants.status = 'info'` and runtime `status ?? 'info'` both resolve the default ✓.

### States ✓
Static presentational molecule — only `default`. Interaction spec confirms no interactive states,
no transitions/animations. Nothing in the code adds hover/focus/transition. Correct (not a gap).

### Tokens — surface / spacing / type / radius / border ✓
| Utility | → token | OK |
|---|---|---|
| `bg-neutral-100` | `--color-neutral-100` (#f8f9fa) | ✓ |
| `p-3` | `--spacing-12` | ✓ |
| `gap-2` (icon↔text) | `--spacing-8` | ✓ |
| `gap-1` (title↔message) | `--spacing-4` | ✓ |
| `rounded` | `--radius-8` | ✓ |
| `border` / `border-1` | `--stroke-width-1` (1px — allowed exception) | ✓ |
| `font-base` | `--font-family-base` | ✓ |
| `text-body` | `--font-size-body` / `--line-height-body` | ✓ |
| `leading-body` | `--line-height-body` | ✓ |
| `font-regular` (title) | `--font-weight-regular` | ✓ |
| `text-text` (message body) | `--color-text-default` | ✓ |
| Icon `size="medium"` → `h-5 w-5` | `--spacing-20` | ✓ |

Every referenced CSS variable exists in `src/styles/tokens.css`. **D2 (the `mt-0.5` off-grid nudge)
stays resolved** — no `mt-0.5` in current source; icon aligns via `items-start` flex.

### Accessibility ✓
- Semantic `<div role={role}>`; `role` defaults to `"note"`, `"alert"` supported via prop (per spec).
- Default icon is decorative: `<Icon … aria-hidden />` and the atom also sets `aria-hidden` when
  unlabelled → `aria-hidden="true"`. Meaning is carried by text, not color ✓.
- `icon={null}` hides the glyph; custom `icon` node overrides the default — both honored in JSX ✓.

### Token audit (DevTools-equivalent, static — zero tolerance) ✓
- Zero hardcoded hex / `rgb()` / `hsl()`; zero inline `style={{}}`.
- Only hardcoded `px` is the `1px` border (allowed). Every color/spacing/radius utility resolves to
  a `var(--…)` via `tailwind.config.js`.

---

## Observations (non-blocking)

- **O-A — redundant border width.** The base class lists both `border` and `border-1`; both map to
  `--stroke-width-1`. Harmless (same token), pure cleanup — drop one.
- **O-B — title not visually differentiated.** The `title` span uses `font-regular` (400), the same
  weight and `text-body` size as the message body, so it separates from the body only by the line
  break. The current token set exposes no heavier weight (`--font-weight-regular` is the only weight
  token) and no distinct heading size for inline labels, so this is consistent with available
  tokens — a **documented token-coverage gap**, not a hardcode violation (cf. root report O1
  `font-mono`). When `/extract-design-system` is re-run to full coverage, add a medium/bold weight
  (or a small-heading size) token and apply it to the title.

---

## Gate

**Token · variant · state · semantic/ARIA dimensions: PASSED** — 0 open source-level discrepancies.
**Runtime dimensions (live-viewport pixel + axe): still not executable** in this environment (no
render harness / browser driver) — the only items left before the gate is fully green.
