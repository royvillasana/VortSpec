# Callout — Component Spec

**Version**: 1.0
**Status**: Implemented
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Alert/callout box that surfaces a contextual message — a status icon plus optional title and message on a tinted neutral surface with a status-colored border — used for notes, tips, warnings, and errors in documentation and forms.

---

### Composed Atoms

| Atom | Role |
|---|---|
| `Icon` | Default status icon (or a consumer override); inherits the status text color |
| Inline text | Optional `title` span + message body (`children`) |

Default icon per status: `info → info`, `warning → exclamation-triangle`, `success → check-circle`, `danger → x-circle`, `secondary → info`.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-neutral-100` | `#f8f9fa` | `background-color` (surface, all statuses) |
| `--color-status-info` | `#0dcaf0` | `border-color` / `color` (info) |
| `--color-status-warning` | `#ffc107` | `border-color` (warning) |
| `--color-status-warning-emphasis` | `#7a6100` | `color` (warning text/icon) |
| `--color-status-success` | `#198754` | `border-color` / `color` (success) |
| `--color-status-danger` | `#dc3545` | `border-color` / `color` (danger) |
| `--theme-secondary` | `#e07b39` | `border-color` (secondary) |
| `--color-status-secondary-emphasis` | — | `color` (secondary text/icon) |
| `--color-status-info-emphasis` | `#0a6c8a` | `color` (info text/icon) |
| `--color-text-default` | `#212529` | `color` (message body, `text-text`) |
| `--stroke-width-1` | `1px` | `border-width` (`border-1`) |
| `--radius-8` | `8px` | `border-radius` (`rounded`) |
| `--spacing-12` | `13px` | `padding` (`p-3`) |
| `--spacing-8` | `8px` | `gap` (icon ↔ text, `gap-2`) |
| `--spacing-4` | `4px` | `gap` (title ↔ message, `gap-1`) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js` to these CSS variables. No hardcoded values.

---

### Variants

Mirrors the Figma `Status` property. Each status sets the border color and the text/icon emphasis color; the surface is always `neutral-100`.

| `status` | Border | Text / icon | Default icon |
|---|---|---|---|
| `info` (default) | info | info-emphasis | `info` |
| `warning` | warning | warning-emphasis | `exclamation-triangle` |
| `success` | success | success | `check-circle` |
| `danger` | danger | danger | `x-circle` |
| `secondary` | secondary | secondary-emphasis | `info` |

---

### States

`Callout` is a static presentational molecule — no interactive states.

| State | Visual Change | Trigger |
|---|---|---|
| `default` | Base appearance | — |

---

### Sizes

Single intrinsic size. Padding (`p-3`), radius (`rounded`), and gaps are fixed by token; the box grows with its content and container width.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `status` | `"info" \| "warning" \| "success" \| "danger" \| "secondary"` | `"info"` | Status color set (border + text/icon) |
| `title` | `ReactNode` | — | Optional heading above the message |
| `icon` | `ReactNode` | default per status | Override the status icon; pass `null` to hide it |
| `children` | `ReactNode` | — | The callout message body |
| `role` | `string` | `"note"` | ARIA role (`"note"`, or `"alert"` for urgent) |
| `className` | `string` | — | Layout overrides only, merged last |
| `...props` | `HTMLAttributes<HTMLDivElement>` | — | Native div attributes spread (`title` omitted) |

---

### Content Rules

- Title: short label (1–4 words), sentence case.
- Message: one or two sentences; keep the callout scannable.
- Icon: keep the default status icon unless a more specific glyph is warranted.

---

### Accessibility

- `role` defaults to `"note"`; use `role="alert"` for time-sensitive/urgent messages.
- The status icon is paired with a text message — color is never the sole signal of meaning.
- The default icon is decorative (`aria-hidden`); meaning is carried by the text.
- Message body uses `text-text` for a readable contrast against the `neutral-100` surface.

---

### Do Not

- Do not hardcode colors, spacing, radius, or stroke — reference tokens via Tailwind theme.
- Do not rely on the border/text color alone to convey status — always include text.
- Do not hide the icon and the title simultaneously with no message (empty callout).

---

### Implementation Tasks

- [x] Create `src/components/modules/callout.variants.ts` (CVA: `calloutVariants` with `status`)
- [x] Create `src/components/modules/Callout.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Implement all 5 `status` values (border + emphasis color)
- [x] Map default icon per status; support `icon` override and `null` to hide
- [x] Compose `Icon` atom with inherited color
- [x] Wire `role` (default `note`), optional `title`, message body
- [x] Verify token-only styling and non-color status signal
