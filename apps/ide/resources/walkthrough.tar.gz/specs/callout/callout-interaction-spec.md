# Callout — Interaction Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./callout-component-spec.md
**Figma prototype**: Callouts page — static (Status property only, no interactive states)

---

### Interaction Overview

`Callout` is a static presentational molecule. It renders an icon + message on a tinted status surface and exposes no user interaction — it communicates via ARIA `role` (`note` by default, `alert` when urgent).

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| — | — | No native interactions; renders statically |

---

### Flow

```
Step 1: Component mounts → status resolves (defaults to "info") and sets border + emphasis color on the neutral-100 surface.
Step 2: Unless icon is null → the status icon renders (default per status, or the override), color inherited.
Step 3: If title is provided → a heading span renders above the message (gap-1).
Step 4: The message body (children) renders in text-text.
Step 5: Assistive tech exposes the box via role (note/alert); no state changes after mount.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| — | — | — | No transitions (static molecule) |

---

### Animation Details

None. `Callout` renders no animations or transitions.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| `icon={null}` | Icon is hidden; text still fills the row |
| Custom `icon` node | Override replaces the default status glyph |
| No `title` | Only the message body renders |
| `role="alert"` | Screen readers announce the message immediately on insert |
| Long message | Wraps within the box; padding/gap preserved |

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Box fills its container width; padding (`p-3`), gap (`gap-2`), and radius are fixed by token. Text reflows as width changes. |

---

### Implementation Tasks

- [x] Resolve status default (`info`) and apply border + emphasis color
- [x] Render default icon per status; honor `icon` override and `null`
- [x] Conditionally render title above message (`gap-1`)
- [x] Apply `role` (default `note`) for assistive tech
- [x] Confirm no transitions/animations are introduced
