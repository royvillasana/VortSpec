# Visual Verify Report — Rating

**Component**: Rating
**Source of truth**: Figma (Branch A) — codified in `specs/rating/*`
**Date**: 2026-07-07
**Skill**: /visual-verify

> **Render limitation**: No browser/screenshot tool is available in this environment.
> This is a **source-of-truth verification** — the implementation code and its Tailwind→token
> mapping are checked against the authoritative spec, plus static analysis. No pixel screenshots
> were captured and no visual/pixel claims are made.
>
> **No Storybook story**: `Rating.stories.tsx` does not exist. The live app is served at
> `http://localhost:6006/` but the component has no dedicated story, so no interactive/manual
> visual pass was possible. Recommend adding a story before sign-off.

---

## Checklist

### Variants
| Item | Result | Notes |
|---|---|---|
| `default` (star-fill filled / star empty) | ✓ | `renderStar` returns `<Icon name="star-fill" text-warning>` when filled, `<Icon name="star" text-neutral-300>` when empty |
| `custom-icon` (`icon` / `emptyIcon`) | ✓ | Custom nodes override glyphs; preview/commit logic unchanged |
| `readOnly` (non-interactive `role="img"`) | ✓ | Renders `<span role="img">` with descriptive `aria-label` |

### Sizes (Icon size + row gap → tokens)
| Size | Gap | Icon | Result |
|---|---|---|---|
| small | `gap-1` → `--spacing-4` (4px) | small → `h-4 w-4` (16px) | ✓ |
| medium | `gap-1.5` → `--spacing-6` (6px) | medium → `h-5 w-5` (20px) | ✓ |
| large | `gap-2` → `--spacing-8` (8px) | large → `h-6 w-6` (24px) | ✓ |

### States
| State | Result | Notes |
|---|---|---|
| empty | ✓ | index > displayValue → `star` / `text-neutral-300` |
| filled | ✓ | index ≤ displayValue → `star-fill` / `text-warning` |
| hover (preview up to pointer) | ✓ | `onMouseEnter`/`onMouseLeave` set/clear `hoverValue`; `displayValue = hoverValue ?? currentValue` |
| focus (2px ring, 2px offset) | ✓ | `focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2` |
| readonly (conveys value to SR) | ✓ | `aria-label="Rated N out of M"` on `role="img"` span |
| half | N/A | Not defined in spec (states = empty/filled/hover/focus) |
| disabled | N/A | Not a spec prop/state for Rating |

### Colors → tokens
| Element | Class | Token | Result |
|---|---|---|---|
| Filled star | `text-warning` | `--color-status-warning` (#ffc107) | ✓ |
| Empty star | `text-neutral-300` | `--color-neutral-300` (#dee2e6) | ✓ |
| Focus ring | `ring-primary` | `--theme-primary` (#087990) | ✓ |

### Sizing / spacing → tokens
| Element | Class | Token | Result |
|---|---|---|---|
| Row gap (s/m/l) | `gap-1` / `gap-1.5` / `gap-2` | `--spacing-4/6/8` | ✓ |
| Focus-ring radius | `rounded-sm` | `--radius-4` (4px) | ✓ |
| Icon box | `h-4/5/6 w-4/5/6` | `--spacing-16/20/24` | ✓ |

### Accessibility
| Item | Result | Notes |
|---|---|---|
| Interactive uses radiogroup + radio semantics | ✓ | `role="radiogroup"` with `<button role="radio" aria-checked>` per star |
| Radiogroup has accessible name (`aria-label`) | ✓ (fixed) | Added default `aria-label="Rating"` (consumer-overridable via spread props) |
| Per-star `aria-label` (e.g. "3 stars") | ✓ | Singular/plural handled (`1 star` vs `N stars`) |
| Star glyphs decorative (`aria-hidden`) | ✓ | Icons pass `aria-hidden`; name lives on the button |
| readOnly conveys value to SR | ✓ | `role="img"` + `aria-label="Rated N out of M"` |
| Focus ring never removed | ✓ | `focus-visible:ring-2`, outline replaced by ring |
| readOnly not focusable/clickable | ✓ | Renders spans, no buttons/handlers |

### Responsive (375 / 768 / 1440)
| Viewport | Result | Notes |
|---|---|---|
| 375 | ✓ | Intrinsic `inline-flex` auto-width row; no breakpoint change (per page spec) |
| 768 | ✓ | Same — size is consumer-driven, not breakpoint-driven |
| 1440 | ✓ | Same |

### Token audit (static)
`grep -nE '#[0-9a-fA-F]{3,8}|rgb\(|hsl\(|style=\{\{|\[[0-9]+px\]'` on `Rating.tsx` + `rating.variants.ts`
→ **no matches**. No hardcoded hex/rgb/hsl, no inline `style={{}}`, no arbitrary `[Npx]` values.
(`transition-[filter]` is an arbitrary CSS *property*, not a DS value — allowed. SVG glyph
path coords live in `Icon`, not in Rating — allowed.)

---

## Discrepancies

| # | Severity | Discrepancy | Resolution |
|---|---|---|---|
| 1 | Minor (a11y) | Interactive `radiogroup` had no accessible name (task a11y checklist requires an `aria-label` on the radio-group) | Fixed inline: added default `aria-label="Rating"`, overridable via spread props |

---

## Result: PASS

All variants, sizes, states, color/spacing/radius token mappings, and accessibility
requirements conform to the spec. The single minor a11y gap (unnamed radiogroup) was fixed
inline. `npx tsc --noEmit` passes. **Note**: no Storybook story exists — add `Rating.stories.tsx`
for interactive visual/manual QA before final sign-off.
