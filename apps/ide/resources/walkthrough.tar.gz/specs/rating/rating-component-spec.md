# Rating — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Star rating control for capturing or displaying a discrete score out of `max` (default 5).
Interactive by default — a `radiogroup` of real `<button>` stars with hover preview and
keyboard support — or a static, non-interactive display when `readOnly`. Supports a
custom-icon variant so consumers can swap the star glyph while keeping all behavior.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-status-warning` | `#ffc107` | `color` (filled star, `text-warning`) |
| `--color-neutral-300` | `#dee2e6` | `color` (empty star, `text-neutral-300`) |
| `--theme-primary` | `#087990` | focus ring (`ring-primary`) |
| `--spacing-4` | 4px | row gap (small, `gap-1`) |
| `--spacing-6` | 6px | row gap (medium, `gap-1.5`) |
| `--spacing-8` | 8px | row gap (large, `gap-2`) |
| `--radius-4` | 4px | star button focus-ring radius (`rounded-sm`) |

All references resolve to CSS variables via the Tailwind theme mapping in
`tailwind.config.js`. No hardcoded hex/px values.

---

### Variants

| Variant | Description |
|---|---|
| `default` | Star glyphs: `star-fill` (amber) filled, `star` (neutral-300) empty |
| `custom-icon` | Consumer supplies `icon` (filled) and/or `emptyIcon` (empty) React nodes |
| `readOnly` | Non-interactive display rendered as `role="img"` |

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `empty` | Star shows `star` glyph in `text-neutral-300` | Index above current/hover value |
| `filled` | Star shows `star-fill` glyph in `text-warning` | Index ≤ current/hover value |
| `hover` | Stars up to the hovered index preview as filled | Pointer enters / focus on a star button |
| `focus` | 2px `ring-primary` at 2px offset on the focused star | Keyboard focus (`focus-visible`) |

Hover preview is driven by local `useState` (`hoverValue`); fill color and focus ring are
token-backed CSS.

---

### Sizes

| Size | Icon size | Row gap |
|---|---|---|
| `small` | small (16px) | 4px (`gap-1`) |
| `medium` | medium (20px) | 6px (`gap-1.5`) |
| `large` | large (24px) | 8px (`gap-2`) |

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `value` | `number` | — | Controlled rating value (1..max) |
| `defaultValue` | `number` | `0` | Initial value for uncontrolled usage |
| `max` | `number` | `5` | Number of stars rendered |
| `onChange` | `(value: number) => void` | — | Fired with the selected value on activation |
| `readOnly` | `boolean` | `false` | Renders a non-interactive `role="img"` display |
| `size` | `small \| medium \| large` | `medium` | Star size and row gap |
| `icon` | `React.ReactNode` | — | Custom filled-star glyph (custom-icon variant) |
| `emptyIcon` | `React.ReactNode` | — | Custom empty-star glyph |
| `className` | `string` | — | Layout overrides only, merged last |
| `...props` | `HTMLAttributes<HTMLDivElement>` (omit `onChange`, `defaultValue`) | — | Native attributes spread |

Controlled when `value` is provided; otherwise uncontrolled via internal state seeded by
`defaultValue`.

---

### Accessibility

- Interactive: container is `role="radiogroup"`; each star is a real
  `<button type="button" role="radio">` with `aria-checked` and an `aria-label` like `"3 stars"`.
- Stars are natively focusable (Tab) and activate with Enter/Space.
- `readOnly`: rendered as `<span role="img" aria-label="Rated N out of M">` with decorative,
  non-interactive glyphs.
- Star glyphs are decorative `Icon`s (`aria-hidden`); the accessible name lives on the button.
- Focus ring is always visible on keyboard focus (`focus-visible:ring-2`), never removed.

---

### Do Not

- Do not hardcode colors, spacing, or radius — reference tokens via the Tailwind theme.
- Do not remove the star buttons' focus ring.
- Do not make `readOnly` stars focusable or clickable.
- Do not omit the per-star `aria-label` or the container `role`.
- Do not use inline `style={{}}` or arbitrary `[..]` Tailwind values.

---

### Implementation Tasks

- [x] Create `src/components/ui/rating.variants.ts` (CVA — container + star sizing)
- [x] Create `src/components/ui/Rating.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Render `max` stars with `star-fill` (`text-warning`) / `star` (`text-neutral-300`)
- [x] Implement `small` / `medium` / `large` sizes (Icon size + row gap)
- [x] Interactive `radiogroup` of `<button role="radio">` with `aria-label` + `aria-checked`
- [x] Support controlled (`value`) and uncontrolled (`defaultValue`) modes
- [x] Local `hoverValue` preview highlight up to the hovered/focused star
- [x] `readOnly` `role="img"` display with descriptive `aria-label`
- [x] Custom-icon variant via `icon` / `emptyIcon`
- [x] Token-backed focus ring on each star button
