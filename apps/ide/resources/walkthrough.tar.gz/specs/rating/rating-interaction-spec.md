# Rating — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./rating-component-spec.md
**Figma prototype**: Rating page — Size property, default + custom-icon variants, readOnly state

---

### Interaction Overview

Interactive Rating lets the user preview a score by hovering (or focusing) stars and commit
it by clicking (or pressing Enter/Space). Stars up to the pointer/focus position fill in
`text-warning`; on activation the value is set and `onChange` fires. In `readOnly` mode the
control is a static display and does not respond to input.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Hover | Star button | Not `readOnly` |
| Focus (Tab) | Star button | Not `readOnly` |
| Click / tap | Star button | Not `readOnly` |
| `Enter` / `Space` | Star button (native) | Focus on a star |

---

### Flow

```
Step 1: Pointer enters star N → hoverValue = N; stars 1..N preview as filled (text-warning). Instant, eased by transition.
Step 2: Keyboard focus lands on star N → hoverValue = N (same preview) + 2px primary ring at 2px offset (focus-visible).
Step 3: Click star N or press Enter/Space → select(N): uncontrolled state updates (or onChange only, if controlled).
Step 4: onChange(N) fires so the consumer can persist the value.
Step 5: Pointer leaves / blur → hoverValue clears; display falls back to the committed value.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Star brightness on hover/active | 150ms | ease-out | `transition-[filter]` |

Fill color swaps immediately with `hoverValue`; the brightness cue and focus ring are driven
by CSS pseudo-classes (`:hover`, `:active`, `:focus-visible`).

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| Controlled (`value` set) | Internal state is bypassed; only `onChange` fires — the parent must re-render with the new `value` |
| Uncontrolled (`defaultValue`) | Internal state updates on select; `onChange` still fires |
| Clearing the rating | Consumer sets `value`/state back to `0`; all stars render empty |
| `readOnly` | No buttons rendered; hover/click/keyboard do nothing |
| `onChange` omitted (uncontrolled) | Selection still updates the internal display |
| Custom `icon` / `emptyIcon` | Preview + commit logic unchanged; only the rendered glyph differs |

---

### Accessibility & Keyboard

- Each star is reachable in tab order (native `<button role="radio">`).
- `Enter` / `Space` activate the focused star (native button behavior).
- `aria-checked` reflects the committed value; `aria-label` (e.g. `"3 stars"`) names each option.
- The container `role="radiogroup"` groups the options.
- Focus ring is always visible on keyboard focus (`focus-visible:ring-2 ring-primary`).
- `readOnly` exposes a single `role="img"` with `aria-label="Rated N out of M"`.

---

### Implementation Tasks

- [x] `hoverValue` state previews fill up to the hovered/focused star
- [x] Click / Enter / Space commits via `select()` → `onChange`
- [x] Controlled vs uncontrolled selection paths
- [x] Hover/focus preview clears on mouse-leave / blur
- [x] `focus-visible` ring on each star button (not on mouse)
- [x] `readOnly` renders a non-interactive `role="img"` display
