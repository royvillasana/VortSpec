# Adversarial Review — Rating

**Date**: 2026-07-07
**Reviewer**: Adversarial review (autonomous)
**Files**: `src/components/ui/Rating.tsx`, `src/components/ui/rating.variants.ts`
**Method**: Source-of-truth (code + token mapping vs `specs/rating/*`) + static analysis.
No browser/screenshot tool available — no visual/pixel claims. No Storybook story exists.

---

## Verdict: PASS (no Blockers)

The implementation faithfully matches all three specs. One minor accessibility gap (unnamed
radiogroup) was resolved inline during review. Remaining findings are advisory/non-blocking:
one is a spec-level ARIA-pattern note, one is a shared/global concern outside these files.

---

## Findings

| # | Severity | Area | Finding | Status |
|---|---|---|---|---|
| 1 | Minor | Accessibility | Interactive `role="radiogroup"` had no accessible name; screen readers announce an unnamed group. | **Resolved** — default `aria-label="Rating"` added (overridable via spread props) |
| 2 | Advisory | Accessibility / ARIA pattern | `role="radio"` children rely on native `<button>` Tab-to-each + Enter/Space instead of the WAI-ARIA APG radio pattern (roving `tabindex` + arrow-key navigation, single tab stop). Keyboard-operable and matches the codified spec ("reachable in tab order (native button)"), so **not changed** — flagged as a spec-level design decision to revisit if strict APG conformance is desired. | Not changed (matches spec) |
| 3 | Advisory (shared) | Token/theming | `focus-visible:ring-offset-2` renders the ring offset gap with Tailwind's built-in default `--tw-ring-offset-color` (#fff), not a design token. Consistent with the rest of the DS (global Tailwind default, not a value in these files) — reported as a shared concern, not fixed here. | Report only (shared) |

No Blocker or Major findings.

---

## Adversarial Probes (all cleared)

- **Variant coverage**: `default`, `custom-icon`, `readOnly` all present and correct. ✓
- **State coverage**: empty / filled / hover / focus / readOnly covered. `half` and `disabled` are
  not in the spec (correctly absent). ✓
- **Token audit**: grep for hex/rgb/hsl/inline-style/`[Npx]` → no matches. All color/spacing/radius
  values resolve to tokens via `tailwind.config.js`. ✓
- **Keyboard operability**: each star is a native `<button>` in tab order; Enter/Space commit via
  `select()`; focus preview via `onFocus`/`onBlur`. ✓
- **SR-exposed value**: interactive → per-star `aria-label` + `aria-checked`; readOnly →
  `role="img"` `aria-label="Rated N out of M"`. ✓
- **Icon-only stars labelled**: glyphs are decorative (`aria-hidden`); accessible name on the button. ✓
- **Controlled vs uncontrolled**: `isControlled = value !== undefined`; internal state bypassed when
  controlled, `onChange` always fires. `readOnly` uses `currentValue`. ✓
- **Edge cases**: value=0 → all empty, all `aria-checked=false`; hover clears on leave/blur;
  `onChange` omitted still updates uncontrolled state. ✓
- **Prop leakage**: `value`, `defaultValue`, `max`, `readOnly`, `icon`, `emptyIcon`, `size`, `onChange`
  all destructured — not spread onto the DOM node. ✓
- **Responsive**: intrinsic inline-flex row, no breakpoint dependency (matches page spec). ✓
- **Interaction-spec compliance**: `transition-[filter] duration-150 ease-out` + `hover:brightness-95`
  / `active:brightness-90` matches the timing table exactly. ✓

---

## Resolved During Review

1. **Unnamed radiogroup (Finding #1)** — added `aria-label="Rating"` to the interactive container,
   placed before `{...props}` so consumers can override it. `npx tsc --noEmit` passes after the change.

---

## Architecture Validation Checklist

| Requirement | Result | Evidence |
|---|---|---|
| CVA for variants (separate `.variants.ts`) | ✓ | `ratingVariants` + `ratingStarVariants` in `rating.variants.ts` |
| `defaultVariants` declared | ✓ | Both CVA configs default `size: 'medium'` |
| `forwardRef` | ✓ | `React.forwardRef<HTMLDivElement, RatingProps>`; ref forwarded to div (and span in readOnly) |
| Spreads native props | ✓ | `{...props}` on the container/span |
| `className` merged last via `cn()` | ✓ | `cn(ratingVariants({ size }), className)` |
| `VariantProps` type exported | ✓ | `export type RatingVariants` in variants; `RatingProps` exported from `Rating.tsx` |
| No inline `style={{}}` for DS values | ✓ | None present (token audit clean) |
| `displayName` set | ✓ | `Rating.displayName = 'Rating'` |
| Barrel export | ✓ | `export { Rating, type RatingProps }` in `src/components/index.ts` |

---

## Follow-ups (non-blocking)

- Add `Rating.stories.tsx` (Storybook story missing) to enable interactive/manual visual QA.
- Consider (spec + DS-wide) whether to adopt strict WAI-ARIA APG radio-group keyboard semantics
  (roving tabindex + arrow keys) — currently spec-sanctioned as native-button Tab navigation.
- DS-wide: consider a tokenized `ring-offset-color` default so focus offsets resolve to a token.
