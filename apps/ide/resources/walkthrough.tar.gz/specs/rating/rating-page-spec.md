# Rating — Usage / Composition Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./rating-component-spec.md

Atoms have no page of their own; this documents how Rating composes into higher-order
components and screens.

---

### Purpose

Document how the Rating atom is consumed to capture user scores (forms, reviews, feedback)
and to display aggregate or fixed ratings (product cards, review lists) in `readOnly` mode.

---

### Component Inventory

| Component | Role |
|---|---|
| `Rating` (atom) | The star row itself |
| `Icon` (atom) | Star glyphs (`star`, `star-fill`) and any custom `icon` / `emptyIcon` |

---

### Usage example

```tsx
import { Rating } from '@/components';
import { Icon } from '@/components';

// Interactive, uncontrolled
<Rating defaultValue={3} onChange={(v) => save(v)} />

// Interactive, controlled
<Rating value={score} onChange={setScore} size="large" />

// Read-only display (e.g. average rating on a product card)
<Rating value={4} readOnly aria-label="Rated 4 out of 5" />

// Custom-icon variant
<Rating
  defaultValue={2}
  icon={<Icon name="star-fill" className="text-primary" aria-hidden />}
  emptyIcon={<Icon name="star" className="text-neutral-300" aria-hidden />}
/>
```

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Intrinsic auto-width, inline-flex row. No size change by breakpoint; consumer picks `size`. |

The atom lays out its own stars with a token-backed gap; surrounding layout is the
container's responsibility.

---

### Accessibility

- Interactive ratings expose a `radiogroup` of labeled `radio` buttons; each is keyboard reachable.
- `readOnly` ratings expose a single `role="img"` with a descriptive `aria-label`.
- Do not rely on color alone — the `aria-label` conveys the numeric value.
- Keep the focus ring visible for keyboard users.

---

### Implementation Tasks

- [x] Verify interactive Rating captures and commits values across all sizes
- [x] Verify hover/focus preview highlights stars up to the pointer position
- [x] Verify `readOnly` Rating renders a non-interactive `role="img"` with correct label
- [x] Verify custom `icon` / `emptyIcon` render while behavior is preserved
