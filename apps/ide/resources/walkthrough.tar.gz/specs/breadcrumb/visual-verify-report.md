# Visual Verify Report — Breadcrumb

- **Component**: Breadcrumb (`src/components/modules/Breadcrumb.tsx`, `src/components/modules/breadcrumb.variants.ts`)
- **Design source**: Figma (`ojko9pGfsDAvmUf2DA38d2`)
- **Date**: 2026-07-07
- **Rendered live?**: No — no Storybook story exists for Breadcrumb. Verification is
  SOURCE-OF-TRUTH only (spec ↔ code ↔ token model). Runtime pixel/axe checks are
  **not executable — verified from source**, not failed.

## Method
Static verification of the `.tsx` + `.variants.ts` against the Component Spec,
Interaction Spec, and the Tailwind→CSS-var token map, focused on nav landmark,
`aria-current`, and separator semantics.

## Checklist Results

### Structure / Variants (checked)
- Root `<nav aria-label="Breadcrumb">` -> `<ol>` -> `<li>` crumbs. Matches spec.
- `breadcrumbVariants` CVA styles the `<ol>` track; single `size: md` value; default `md`.
- Crumb rendering: last -> `<span aria-current="page">`; has `href` -> `<a>`;
  otherwise -> plain `<span>`. Mirrors spec 1:1.

### States (from source)
- link default: `text-muted`. OK
- link hover: `hover:text-primary` + `hover:underline underline-offset-4`. OK
- link focus: `focus-visible:ring-2 ring-primary ring-offset-2 rounded-sm`. OK
- plain crumb: `text-muted`, non-interactive `<span>`. OK
- current: `text-text`, `aria-current="page"`, not a link. OK

### Sizes (checked)
Single size `md`: `text-body` / `leading-body`, `gap-2` (8px), `rounded-sm` (=`--radius-4`)
focus radius. All token-mapped.

### Token Audit (zero leaks)
grep returns nothing. `text-muted` resolves via the `muted` alias -> `--color-text-muted`.
`underline-offset-4` is a text-underline-offset utility (not a spacing/color DS value).
Every color/spacing/radius/font utility resolves to `var(--...)`. No hex/rgb/hsl, no
arbitrary DS value, no inline style.

### Accessibility (from source)
- **Nav landmark**: `<nav aria-label="Breadcrumb">` present. OK
- **aria-current on last crumb**: `<span aria-current="page">` — only on the last item. OK
- **Separator aria-hidden**: separator wrapped in `<span aria-hidden>`, rendered only
  between crumbs (`!isLast`), never inside an anchor. OK
- **Links keyboard-focusable** with visible `focus-visible` ring. OK
- Current page not in tab order (it is a span, not a link). OK
- Color not the sole signal — `aria-current` conveys current page. OK

### Architecture (8/8)
`.variants.ts` colocated · CVA mirrors spec · defaultVariants match (`size: md`) ·
forwardRef (`HTMLElement`) · `...props` spread on root `<nav>` · `className` merged LAST
via `cn()` · `BreadcrumbVariants` exported · no inline `style={{}}`.

### Interaction Spec (checked)
Hover/focus on linked crumbs; Enter activates (native anchor); no animations (instant).
Edge cases: single item -> one current crumb, no separator (verified: `lastIndex=0`,
`!isLast` is false); items without `href` -> plain span; custom separator stays decorative;
long trail wraps via `flex-wrap`; empty `items` -> `<nav><ol></ol></nav>`. All satisfied.

## Discrepancies
- **Minor (non-blocking)**: `breadcrumbVariants` declares a `size` variant, but the
  component never accepts/forwards a `size` prop (it always calls `breadcrumbVariants()`
  with the default `md`). Since there is only one `size` value, this is cosmetic dead
  configuration, not a visual or token defect. Spec describes size as "single intrinsic
  size (md)", so behavior is correct; left as-is (no functional impact, no code change
  needed to satisfy the spec).

## Gate: PASS (zero unresolved code discrepancies)
