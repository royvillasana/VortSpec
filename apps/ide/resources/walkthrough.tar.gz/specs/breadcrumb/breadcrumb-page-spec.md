# Breadcrumb — Page Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Placement and composition guidance for `Breadcrumb` on a page. The breadcrumb sits near the
top of a content region — typically above the page title — giving users orientation within the
site hierarchy and a one-click path back to any ancestor.

---

### Component Inventory

| Component | Role |
|---|---|
| `Breadcrumb` | The trail: labelled `<nav>` + `<ol>` of crumbs |
| `Icon` (via Breadcrumb) | Default `chevron-right` separator (decorative) |

---

### Usage Example

```tsx
import { Breadcrumb } from '@/components';

<Breadcrumb
  items={[
    { label: 'Home', href: '/' },
    { label: 'Components', href: '/components' },
    { label: 'Breadcrumb' }, // current page — no href
  ]}
/>

// Custom separator:
<Breadcrumb
  separator="/"
  items={[
    { label: 'Docs', href: '/docs' },
    { label: 'Guides', href: '/docs/guides' },
    { label: 'Routing' },
  ]}
/>
```

Place the breadcrumb in the page header region, before the `<h1>` / `PageTitle`, within the
main content column. It is a `<nav>` landmark, so it can live directly under `<main>` or a
header wrapper.

---

### Responsive

- The `<ol>` uses `flex-wrap`, so a long trail wraps to multiple lines within its container
  rather than overflowing horizontally.
- On narrow viewports, if a trail is very deep, the product may truncate middle crumbs
  (e.g. `Home / … / Current`) by passing a shortened `items` array or a custom ellipsis crumb;
  the component renders whatever `items` it is given and does not truncate automatically.
- Typography stays `text-body` across breakpoints; spacing is token-fixed (`gap-2`).

---

### Accessibility

- The trail is a `<nav aria-label="Breadcrumb">` landmark discoverable by assistive tech.
- Crumbs are an ordered list (`<ol>` / `<li>`) conveying sequence.
- The current page is marked with `aria-current="page"` and is not a link.
- Separators are `aria-hidden` and excluded from the accessible name of any crumb.
- Only one breadcrumb landmark per page region to avoid ambiguity.

---

### Implementation Tasks

- [x] Position `Breadcrumb` above the page title in the content column
- [x] Provide `items` with the final entry as the current page (no `href`)
- [x] Confirm the `<nav aria-label="Breadcrumb">` landmark renders once per region
- [x] Verify wrapping behavior for long trails (`flex-wrap`)
- [x] Verify token-only styling with no inline `style` or arbitrary utilities
