# Breadcrumb — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Breadcrumb trail that shows the user's location within the site hierarchy and lets them
navigate back to any ancestor page. Composed of a labelled `<nav>` wrapping an ordered list
of crumbs (`breadcrumb-item`) separated by decorative markers (`breadcrumb-separator`).
Intermediate crumbs are links; the final crumb is the current, non-interactive page.

---

### Composed Atoms

| Atom | Role |
|---|---|
| `Icon` | Default separator glyph (`chevron-right`), decorative (`aria-hidden`) |
| Inline link / text | Each crumb: `<a>` (has `href`), plain `<span>` (no `href`), or current-page `<span>` |

The separator is fully overridable via the `separator` prop (e.g. a `/` string).

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-text-default` | `#212529` | `color` (current crumb, `text-text`) |
| `--color-text-muted` | — | `color` (link idle + separators, `text-muted`) |
| `--theme-primary` | — | `color` on link hover (`hover:text-primary`) + focus ring |
| `--spacing-8` | `8px` | `gap` between crumbs and around separators (`gap-2`) |
| `--radius-4` | `4px` | focus-ring radius (`rounded-sm`) |
| `--font-family-base` | — | `font-family` (`font-base`) |
| `--font-size-body` | `16px` | `font-size` (`text-body`) |
| `--line-height-body` | `1.5` | `line-height` (`leading-body`) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js` to these CSS
variables. No hardcoded hex, px, rem, or arbitrary `[..]` values, and no inline `style`.

---

### Variants

Structural only — no color/style variants. A minimal CVA (`breadcrumbVariants`) styles the `<ol>`
track (inline, wrapping row + body typography) and exposes an optional `size` (default `md`).

---

### States

Interactive states apply to linked (intermediate) crumbs only.

| State | Visual Change | Trigger |
|---|---|---|
| link `default` | `text-muted` | Intermediate crumb with `href` |
| link `hover` | `text-primary` + underline (`underline-offset-4`) | Pointer hover |
| link `focus` | 2px `primary` focus ring, offset 2, `rounded-sm` | Keyboard focus (`focus-visible`) |
| plain crumb | `text-muted`, non-interactive | Intermediate crumb without `href` |
| `current` | `text-text`, `aria-current="page"`, not a link | Last crumb |

---

### Sizes

Single intrinsic size (`size="md"`). Typography is `text-body` / `leading-body`; the trail grows
with its content and wraps within its container. Gaps are fixed by token (`gap-2`).

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `items` | `BreadcrumbItem[]` | — | Ordered trail; last item is the current page |
| `separator` | `ReactNode` | `<Icon name="chevron-right" />` | Decorative separator between crumbs |
| `className` | `string` | — | Layout overrides only, merged last (on `<nav>`) |
| `...props` | `HTMLAttributes<HTMLElement>` | — | Native nav attributes spread onto `<nav>` |

`BreadcrumbItem` = `{ label: ReactNode; href?: string }` (exported).

---

### Accessibility

- Root is `<nav aria-label="Breadcrumb">` containing an `<ol>` of `<li>` crumbs.
- The current (last) crumb carries `aria-current="page"` and is not a link.
- Separators are decorative (`aria-hidden`) and are never placed inside an anchor.
- Links are keyboard-focusable with a visible `focus-visible` ring (`ring-primary`, offset 2).
- Color is not the sole signal: the current page is conveyed by `aria-current`, not color alone.

---

### Do Not

- Do not link the last crumb — it is the current page.
- Do not place the separator inside an anchor or expose it to assistive tech.
- Do not hardcode colors, spacing, radius, or typography — reference tokens via Tailwind theme.
- Do not use inline `style` or arbitrary `[..]` utilities for design-system values.

---

### Implementation Tasks

- [x] Create `src/components/modules/breadcrumb.variants.ts` (CVA `breadcrumbVariants`, optional `size`)
- [x] Create `src/components/modules/Breadcrumb.tsx` (`forwardRef<HTMLElement>`, spreads props, `cn()` last)
- [x] Render `<nav aria-label="Breadcrumb"> > <ol> > <li>` structure
- [x] Render intermediate crumbs as `<a>` (with `href`) or plain `<span>` (no `href`)
- [x] Render last crumb as `<span aria-current="page" class="text-text">` (no link)
- [x] Render decorative separator between crumbs; default chevron `Icon`, overridable via `separator`
- [x] Wire link hover/focus tokens (`hover:text-primary`, focus ring, `rounded-sm`)
- [x] Export `BreadcrumbItem` type
- [x] Verify token-only styling and `tsc` passes
