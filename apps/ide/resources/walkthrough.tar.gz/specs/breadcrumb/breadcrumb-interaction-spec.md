# Breadcrumb — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Overview

Breadcrumb is a lightweight navigation molecule. The only interactivity lives on the
intermediate crumbs, which are anchors. Hovering or focusing a linked crumb reveals an
affordance; activating it navigates to that ancestor. The current-page crumb and any
crumb without an `href` are inert.

---

### Trigger

- **Pointer**: hovering a linked crumb; clicking it navigates.
- **Keyboard**: `Tab` moves focus across linked crumbs in reading order; `Enter` activates.

---

### Flow

1. User scans the trail from left (root) to right (current page).
2. Linked crumbs render in `text-muted`.
3. On hover, the focused link changes to `text-primary` and shows an underline
   (`underline-offset-4`).
4. On keyboard focus, the link shows a 2px `primary` focus ring (offset 2, `rounded-sm`).
5. Activating a link (click / `Enter`) navigates to `href`.
6. The last crumb (current page) never receives link styling or focus — it is a static span.

---

### Timing

- No animations or transitions. Hover/focus styling is applied instantly via utility classes.
- No delays, debouncing, or async state.

---

### Edge Cases

| Case | Behavior |
|---|---|
| Single item | Renders one `<li>` as the current page (`aria-current="page"`, `text-text`); no separator. |
| Items without `href` | Intermediate crumbs without `href` render as plain `text-muted` spans (not focusable). |
| Custom separator | `separator` prop (e.g. `"/"`) replaces the chevron; still decorative (`aria-hidden`), never inside a link. |
| Long trail | The `<ol>` wraps (`flex-wrap`) within its container; crumbs stay left-aligned. |
| Empty `items` | Renders `<nav><ol></ol></nav>` with no crumbs (no error). |

---

### Accessibility & Keyboard

| Key | Action |
|---|---|
| `Tab` | Move focus to the next linked crumb |
| `Shift+Tab` | Move focus to the previous linked crumb |
| `Enter` | Activate the focused crumb link |

- Focus order follows DOM order (root → current).
- The current crumb is not in the tab order (it is not a link).
- Separators are `aria-hidden` and skipped by assistive tech.
- The `<nav aria-label="Breadcrumb">` landmark lets screen-reader users jump to the trail.

---

### Implementation Tasks

- [x] Linked crumbs are anchors with token-based hover (`hover:text-primary` + underline)
- [x] Linked crumbs show a visible `focus-visible` ring (`ring-primary`, offset 2, `rounded-sm`)
- [x] Last crumb is inert with `aria-current="page"`
- [x] Intermediate crumbs without `href` render as non-interactive spans
- [x] Separator overridable and always decorative (`aria-hidden`), outside anchors
- [x] Single-item trail renders only the current page with no separator
