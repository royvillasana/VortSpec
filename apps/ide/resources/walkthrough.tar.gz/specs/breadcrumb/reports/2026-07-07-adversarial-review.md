# Adversarial Review — Breadcrumb

Date: 2026-07-07

## Verdict: PASS-WITH-GAPS

## Findings

| Severity | Area | Issue | Status |
|---|---|---|---|
| — | Token audit | grep clean; `text-muted` resolves via `muted` alias -> `--color-text-muted` | Pass |
| — | A11y / landmark | `<nav aria-label="Breadcrumb">` landmark present | Pass |
| — | A11y / current | `aria-current="page"` only on last crumb; last crumb is not a link | Pass |
| — | A11y / separator | Separator wrapped in `<span aria-hidden>`, only between crumbs, never inside an anchor | Pass |
| Minor | CVA / spec parity | `breadcrumbVariants` exposes a `size` variant that the component never wires to a prop (always default `md`). Single-value, so cosmetic dead config — no visual/token impact. Spec calls for a single intrinsic `md` size, so behavior is correct. | Open (non-blocking) |

No Blocker or Major findings.

## Architecture Validation (8 checks)
1. `.variants.ts` colocated — yes (`breadcrumb.variants.ts`)
2. CVA variants mirror spec 1:1 — yes (single `size: md`, structural-only, per spec)
3. defaultVariants match spec — yes (`size: md`)
4. forwardRef — yes (`HTMLElement`, on `<nav>`)
5. `...props` spread on root — yes (on `<nav>`)
6. `className` merged LAST via `cn()` — yes (on `<nav>`)
7. VariantProps exported — yes (`BreadcrumbVariants`)
8. no inline `style={{}}` for DS values — yes

## Token / Variant / State / A11y Checklist
- Tokens: all utilities resolve to `var(--...)`; `underline-offset-4` is a non-DS text utility.
- Variants: structural only (single `md`) — matches spec.
- States: link default/hover/focus, plain crumb, current — all present.
- A11y: nav landmark; `aria-current="page"` on last; decorative `aria-hidden` separators
  outside anchors; keyboard-focusable links with visible ring; current not in tab order.

## Resolved During Review
None — no defects found; no edits made. One Minor (unwired single-value `size` variant)
left open as non-blocking; wiring it would add no functional value given the single size.

## Notes
No Storybook story exists for Breadcrumb, so runtime pixel-diff and axe were not
executable — verified from source (spec ↔ code ↔ token model). Contrast assessed from
token pairings, not a runtime axe pass.
