# IconWrapper — Component Spec

**Version**: 1.0
**Status**: Implemented
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Frame URL**: Icons / Cover page
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Fixed square container that frames a single Icon on a toned background — the contact/social affordance used on the Cover and similar surfaces. It supplies the box size (from padding tokens), the rounded corner, and the tone (background + inherited icon color) so the wrapped Icon inherits the right `currentColor`.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--spacing-8` | `8px` | `padding` (small `p-2`) |
| `--spacing-10` | `10px` | `padding` (medium `p-2.5`) |
| `--spacing-12` | `12px` | `padding` (large `p-3`) |
| `--color-neutral-100` | `#f8f9fa` | `background-color` (default tone) |
| `--color-text-default` | `#212529` | `color` (default tone icon) |
| `--theme-primary` | `#087990` | `background-color` (primary tone) |
| `--theme-secondary` | `#e07b39` | `background-color` (secondary tone) |
| `--primitive-neutral-near-black` | `#1a1916` | `background-color` (dark tone) |
| `--primitive-neutral-white` | `#ffffff` | `color` (icon on primary/secondary/dark) |
| `--radius-8` | `8px` | `border-radius` |

All references are via the Tailwind theme mapping in `tailwind.config.js`, which resolves to these CSS variables. No hardcoded values.

---

### Variants

`tone` sets the background fill and the inherited icon color (via `currentColor`). Mirrors the Figma `Tone` property 1:1.

| Variant | Description |
|---|---|
| `default` | Light neutral fill (`bg-neutral-100`), default text-colored icon |
| `primary` | Teal fill (`bg-primary`), white icon |
| `secondary` | Orange fill (`bg-secondary`), white icon |
| `dark` | Near-black fill, white icon |

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | Base tone appearance | — |

IconWrapper is a presentational container with no interactive states. If it is placed inside an interactive parent (e.g. an anchor), the parent owns hover/focus.

---

### Sizes

`size` sets the padding token around the inner Icon; combined with `aspect-square` this fixes the box size.

| Size | Padding | Token |
|---|---|---|
| `small` | 8px (`p-2`) | `--spacing-8` |
| `medium` | 10px (`p-2.5`) | `--spacing-10` |
| `large` | 12px (`p-3`) | `--spacing-12` |

The box is always square (`aspect-square`) and rounded (`--radius-8`).

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `size` | `small \| medium \| large` | `medium` | Padding-derived square box size |
| `tone` | `default \| primary \| secondary \| dark` | `default` | Background fill + inherited icon color |
| `children` | `ReactNode` | — | The Icon to frame |
| `className` | `string` | — | Layout overrides only, merged last |
| `...props` | `HTMLAttributes<HTMLDivElement>` | — | Native div attributes spread |

---

### Content Rules

- `children` must be a single `Icon`. Do not place text or multiple icons inside.
- Let the Icon inherit `currentColor` from the wrapper's tone — do not color the Icon directly.
- Choose `size` to match the surrounding affordance grid, not the icon's intrinsic size.

---

### Accessibility

- Element: `<div>` (non-semantic container).
- The wrapper is decorative; the accessible name comes from the inner Icon's `label` (or the interactive parent).
- Tone background/icon pairs meet WCAG AA contrast for meaningful icons.

---

### Do Not

- Do not hardcode colors, padding, or radius — reference tokens via Tailwind theme.
- Do not put a colored icon inside — rely on tone's `currentColor`.
- Do not use IconWrapper as a button; wrap it in a real interactive element instead.

---

### Implementation Tasks

- [x] Create `src/components/ui/icon-wrapper.variants.ts` (CVA size + tone)
- [x] Create `src/components/ui/IconWrapper.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Implement `small` / `medium` / `large` padding sizes + `aspect-square`
- [x] Implement `default` / `primary` / `secondary` / `dark` tones
- [x] Apply `--radius-8` rounding
- [x] Verify inner Icon inherits tone `currentColor`
- [x] Unit test render, size class, tone class
