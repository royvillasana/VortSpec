# IconWrapper — Interaction Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./icon-wrapper-component-spec.md
**Figma prototype**: Icons / Cover page — no interactive states

---

### Interaction Overview

IconWrapper is a static presentational container. It has no interactive behavior of its own; any hover/focus/press response comes from an interactive parent that wraps it.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| — | — | IconWrapper exposes no triggers; the parent owns interaction |

---

### Flow

```
Step 1: IconWrapper renders its toned square and paints the inner Icon at the tone's currentColor.
Step 2: No pointer, focus, or keyboard event is handled by IconWrapper.
Step 3: If wrapped in an interactive parent, that parent's states drive any color/elevation change.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| — | — | — | IconWrapper defines no transitions |

---

### Animation Details

None. IconWrapper renders a static box.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| No `children` | Renders an empty toned square |
| Multiple children | All render, but the box is sized for a single Icon — avoid |
| Placed inside an anchor/button | Parent owns hover/focus; wrapper stays visually static |
| Colored icon passed in | Overrides tone's `currentColor` — not recommended |

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Fixed square box (padding token + `aspect-square`); does not reflow |

---

### Implementation Tasks

- [x] Confirm no interactive handlers are attached
- [x] Verify inner Icon inherits tone `currentColor`
- [x] Verify box stays square across viewports
- [x] Verify parent (if interactive) owns state changes
