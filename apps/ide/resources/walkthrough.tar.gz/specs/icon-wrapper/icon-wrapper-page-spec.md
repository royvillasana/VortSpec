# IconWrapper — Usage / Composition Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./icon-wrapper-component-spec.md

Atoms have no page of their own; this documents how IconWrapper composes into higher-order components and screens.

---

### Consumed By

| Consumer | Usage |
|---|---|
| `Cover` (organism) | Contact / social affordances (email, links, social icons) |
| Molecules | Feature bullets, list-item leading marks |
| Screens | Toned icon badges beside labels |

---

### Composition Rules

- Wrap exactly one `Icon` atom; the wrapper owns the box size (`size`) and color (`tone`).
- Layout (margin, grid placement, gap to an adjacent label) is applied via `className`, never tone overrides.
- To make the affordance interactive, wrap IconWrapper in an anchor/button — do not add handlers to the wrapper itself.
- Keep tone consistent within an affordance group (e.g. all `dark` in a social row).

---

### Accessibility

- The inner Icon supplies the accessible name via `label`; the wrapper is decorative.
- When interactive, the wrapping anchor/button provides the accessible name and focus ring.

---

### Implementation Tasks

- [x] Verify IconWrapper renders inside Cover with correct spacing
- [x] Verify tone + size pair matches the affordance group
- [x] Verify accessible name is provided by the Icon or interactive parent
