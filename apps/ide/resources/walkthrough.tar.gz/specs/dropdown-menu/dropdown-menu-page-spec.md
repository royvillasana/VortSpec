# DropdownMenu — Usage / Composition Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./dropdown-menu-component-spec.md

Molecules have no page of their own; this documents how DropdownMenu composes into higher-order
components and screens.

---

### Purpose

Provide a reusable menu surface that a trigger control opens, listing actions, links, and grouped
choices. It is the panel half of a dropdown pattern — the trigger and open/close logic live in the
parent.

---

### Component Inventory

| Component | Role |
|---|---|
| `DropdownMenu` | The menu surface (this molecule) |
| `Button` (atom) | Typical trigger controlling the parent's `open` state |
| `Icon` (atom) | Optional leading glyph passed into an item's `icon` slot |

---

### Consumed By

| Consumer | Usage |
|---|---|
| `Header` (organism) | Account / overflow menu opened from a nav control |
| Toolbars & action bars | Overflow ("···") action menus |
| Screens | Contextual action/settings menus anchored to a trigger |

---

### Usage Example

```tsx
import * as React from 'react';
import { Button } from '@/components/ui/Button';
import { Icon } from '@/components/ui/Icon';
import { DropdownMenu, type DropdownMenuEntry } from '@/components/modules/DropdownMenu';

function AccountMenu() {
  const [open, setOpen] = React.useState(false);

  const items: DropdownMenuEntry[] = [
    { type: 'group-label', label: 'Signed in as Roy' },
    { type: 'item', label: 'Profile', icon: <Icon name="info" aria-hidden />, href: '/profile' },
    { type: 'item', label: 'Settings', active: true, onSelect: () => setOpen(false) },
    { type: 'separator' },
    { type: 'item', label: 'Billing', disabled: true },
    { type: 'item', label: 'Sign out', onSelect: () => setOpen(false) },
  ];

  return (
    <div className="relative inline-block">
      <Button aria-haspopup="menu" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
        Account
      </Button>
      {open && (
        <DropdownMenu items={items} className="absolute right-0 mt-1" />
      )}
    </div>
  );
}
```

The parent owns `open`, positioning (`absolute` + anchor), and closing on select / outside click.

---

### Composition Rules

- The trigger (parent) owns open/close, positioning, and focus restoration; the menu is stateless.
- Choose `item` vs `separator` vs `group-label` by meaning; do not fake dividers with empty items.
- Pass layout (position, width, margins) via `className`; the panel owns its padding and gaps.
- Use `href` for navigation items and `onSelect` for action items; both may coexist.

---

### Responsive

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Panel keeps `min-w-20` and grows to content; the parent decides anchor/position and may switch to a full-width sheet on small screens. Rows reflow labels as width changes. |

---

### Accessibility

- Parent trigger should expose `aria-haspopup="menu"` and `aria-expanded`.
- The surface is `role="menu"` with `role="menuitem"` children and `role="separator"` dividers.
- Disabled items use `aria-disabled`; active items use `aria-current`.
- Parent moves focus into the menu on open and restores it to the trigger on close.

---

### Implementation Tasks

- [x] Verify DropdownMenu renders inside a positioned parent controlled by a trigger `Button`
- [x] Verify items, separators, and group labels render with correct roles
- [x] Verify disabled and active items expose `aria-disabled` / `aria-current`
- [x] Verify layout overrides apply via `className` (position/width) without breaking padding
