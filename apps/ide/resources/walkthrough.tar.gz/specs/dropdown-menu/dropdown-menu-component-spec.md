# DropdownMenu — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Presentational menu surface that lists actionable items, separators, and group labels inside a
floating panel (`role="menu"`). It renders the panel and its rows only — opening, closing, and
focus management are the parent's concern (e.g. a trigger `Button` toggling an `open` flag). Used
for overflow menus, action menus, and account/settings menus.

---

### Composed Atoms

| Atom | Role |
|---|---|
| Leading `icon` slot | Optional consumer-supplied node before an item's label (e.g. an `Icon`) |
| Item row | `<a>` (when `href`) or `<button>` — `role="menuitem"` |
| Separator | `<hr role="separator">` between groups |
| Group label | Non-interactive `<div>` heading a set of items |

This molecule is composed of `dropdown-menu-item` and `dropdown-menu-item-group` per the design inventory.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--primitive-neutral-white` | `#ffffff` | `background-color` (panel surface, `bg-white`) |
| `--color-neutral-300` | `#dee2e6` | `border-color` (panel + separator, `border-neutral-300`) |
| `--color-neutral-100` | `#f8f9fa` | `background-color` (item hover, `hover:bg-neutral-100`) |
| `--brand-primary-100` | — | `background-color` (active item, `bg-brand-primary-100`) |
| `--theme-primary` | — | `color` (active item text + focus ring, `text-primary` / `ring-primary`) |
| `--color-text-default` | `#212529` | `color` (item label, `text-text`) |
| `--color-text-muted` | — | `color` (group label, `text-muted`) |
| `--stroke-width-1` | `1px` | `border-width` (`border-1`) |
| `--radius-8` | `8px` | `border-radius` (panel, `rounded`) |
| `--radius-4` | `4px` | `border-radius` (item rows, `rounded-sm`) |
| `--shadow-default` | — | `box-shadow` (panel elevation, `shadow-md`) |
| `--spacing-80` | `80px` | `min-width` (panel, `min-w-20`) |
| `--spacing-4` | `4px` | `padding` (panel, `p-1`) / separator margin (`my-1`) / group-label `py-1` |
| `--spacing-8` | `8px` | `gap` (icon ↔ label, `gap-2`) / item `py-2` |
| `--spacing-12` | `13px` | item + group-label horizontal padding (`px-3`) |
| `--opacity-disabled` | — | `opacity` (disabled item, `opacity-disabled`) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js` to these CSS variables. No hardcoded values.

---

### Variants

The menu renders a heterogeneous list; each entry is a discriminated union member keyed by `type`.

| `type` | Element | Interactive | Notes |
|---|---|---|---|
| `item` | `<a>` / `<button>` `role="menuitem"` | Yes | Optional `icon`, `href`, `disabled`, `active`, `onSelect` |
| `separator` | `<hr role="separator">` | No | Visual divider between groups |
| `group-label` | `<div>` | No | Muted, non-interactive section heading |

Item-level CVA axes (`dropdownMenuItemVariants`):

| Axis | Values | Effect |
|---|---|---|
| `active` | `true` / `false` (default) | `true` → `bg-brand-primary-100 text-primary`; `false` → `text-text` + `hover:bg-neutral-100` |
| `disabled` | `true` / `false` (default) | `true` → `opacity-disabled pointer-events-none` |

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | `text-text` on white surface | Item at rest |
| `hover` | `bg-neutral-100` | Pointer over a non-active, non-disabled item |
| `active` | `bg-brand-primary-100 text-primary` | Item marked `active` (current selection) |
| `focus` | 2px `ring-primary` ring, offset 2 | Keyboard focus (`focus-visible`) |
| `disabled` | `opacity-disabled`, `pointer-events-none`, `aria-disabled` | Item marked `disabled` |

---

### Sizes

Single intrinsic size. The panel has a fixed `min-w-20` (80px) and grows to its content/container
width. Padding, radius, and gaps are token-fixed; the panel height grows with the item count.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `items` | `DropdownMenuEntry[]` | — | Ordered entries (items, separators, group labels) to render |
| `className` | `string` | — | Layout overrides only, merged last |
| `...props` | `HTMLAttributes<HTMLDivElement>` | — | Native div attributes spread onto the panel |

`DropdownMenuEntry` (discriminated union):

| Member | Shape |
|---|---|
| item | `{ type: 'item'; label: ReactNode; icon?: ReactNode; href?: string; disabled?: boolean; active?: boolean; onSelect?: () => void }` |
| separator | `{ type: 'separator' }` |
| group-label | `{ type: 'group-label'; label: ReactNode }` |

Exported types: `DropdownMenuProps`, `DropdownMenuEntry`, `DropdownMenuItemEntry`,
`DropdownMenuSeparatorEntry`, `DropdownMenuGroupLabelEntry`, `DropdownMenuVariants`.

---

### Accessibility

- Panel is `role="menu"`; interactive rows are `role="menuitem"`; dividers are `role="separator"`.
- Disabled items expose `aria-disabled` and drop pointer/click handling (and `href`).
- Active items expose `aria-current`.
- Every row has a visible `focus-visible` ring — focus is never suppressed without a replacement.
- The parent owns open/close and focus management (moving focus into the menu on open, restoring
  it on close). Full roving-tabindex arrow navigation is out of scope; Tab + Enter operates rows.

---

### Do Not

- Do not hardcode colors, spacing, radius, or shadow — reference tokens via Tailwind theme.
- Do not manage open/close state inside this component — it is a stateless surface.
- Do not give a `group-label` or `separator` an interactive role or handler.
- Do not rely on `active` color alone to convey selection — pair it with `aria-current`.

---

### Implementation Tasks

- [x] Create `src/components/modules/dropdown-menu.variants.ts` (CVA: `dropdownMenuItemVariants` with `active` + `disabled`)
- [x] Create `src/components/modules/DropdownMenu.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Render panel as `role="menu"` with token-backed surface, border, shadow, `min-w-20`
- [x] Render `item` rows as `<a role="menuitem">` (href) or `<button role="menuitem" type="button">`
- [x] Render `separator` as `<hr role="separator">` and `group-label` as muted non-interactive div
- [x] Wire `active`, `disabled` (`aria-disabled`, no href/handler), leading `icon` slot
- [x] Apply visible focus ring and verify token-only styling
