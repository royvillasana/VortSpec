# DropdownMenu — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./dropdown-menu-component-spec.md
**Figma prototype**: Dropdown menu — surface + item states (default / hover / active / focus / disabled)

---

### Interaction Overview

`DropdownMenu` is a presentational surface. It exposes per-row interaction (click / keyboard
activation) but holds no open/close state itself — a parent (typically a trigger `Button`) mounts
and unmounts the surface and manages focus. Rows communicate via `role="menuitem"`, `aria-current`
(active), and `aria-disabled` (disabled).

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Parent opens the menu | External trigger (e.g. `Button`) | Parent toggles its own `open` flag and renders `<DropdownMenu>` |
| Activate item (pointer) | `<a>` / `<button>` `role="menuitem"` | Not disabled → fires `onSelect` (or navigates for `href`) |
| Activate item (keyboard) | Focused row | Enter / Space activates the focused `menuitem` |

---

### Flow

```
Step 1: Parent sets open = true and renders <DropdownMenu items=… /> (positioning owned by parent).
Step 2: Menu paints the role="menu" surface; each entry maps to an item, separator, or group-label.
Step 3: User moves focus into a row (Tab) → focus-visible ring appears.
Step 4: User activates the row (click / Enter) → non-disabled item fires onSelect (href navigates).
Step 5: Parent typically closes the menu in response to onSelect and restores focus to the trigger.
Step 6: Disabled rows ignore activation (pointer-events-none + no handler/href).
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Item hover background | instant | — | `hover:bg-neutral-100` (no explicit transition) |
| Focus ring | instant | — | `focus-visible:ring-2` |

Open/close enter-exit animation, if any, is owned by the parent, not this component.

---

### Animation Details

The surface itself renders no mount animation. Hover and focus are immediate token-driven style
changes. Any open/close transition is applied by the parent wrapper.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| `disabled` item | `aria-disabled`, dimmed (`opacity-disabled`), `pointer-events-none`; `href`/`onSelect` dropped |
| `active` item | `bg-brand-primary-100 text-primary` + `aria-current`; still activatable unless disabled |
| `separator` entry | Renders `<hr role="separator">`; non-focusable, non-interactive |
| `group-label` entry | Muted heading; non-focusable, non-interactive |
| Empty `items` array | Renders an empty panel surface (no rows) |
| Item with `href` | Renders `<a>`; click both navigates and fires `onSelect` when not disabled |
| Item without `href` | Renders `<button type="button">`; native `disabled` also set when disabled |

---

### Accessibility & Keyboard

| Key / Role | Behavior |
|---|---|
| `role="menu"` | Applied to the panel container |
| `role="menuitem"` | Applied to each interactive row |
| `role="separator"` | Applied to dividers |
| `Tab` / `Shift+Tab` | Moves focus between rows (native focus order) |
| `Enter` / `Space` | Activates the focused row |
| `aria-disabled` | Set on disabled rows |
| `aria-current` | Set on active rows |

Full roving-tabindex arrow-key navigation (Up/Down cycling a single tab stop) is out of scope for
this presentational surface; Tab + Enter is the supported model. The parent is responsible for
moving focus into the menu on open and restoring it to the trigger on close.

---

### Implementation Tasks

- [x] Fire `onSelect` on pointer/keyboard activation for non-disabled items
- [x] Render `<a>` for `href` items and `<button type="button">` otherwise
- [x] Drop `href`/`onClick` and set `aria-disabled` for disabled items
- [x] Set `aria-current` for active items; apply active surface color
- [x] Render separators (`role="separator"`) and group labels as non-interactive
- [x] Apply visible `focus-visible` ring to every row
- [x] Confirm no open/close state is held internally (parent-owned)
