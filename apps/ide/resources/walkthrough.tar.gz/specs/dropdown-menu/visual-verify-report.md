# Visual Verify Report — DropdownMenu

- **Design source:** `figma` (Branch A) · **Component:** `DropdownMenu` (molecule) · **Date:** 2026-07-07
- **Spec:** `specs/dropdown-menu/dropdown-menu-component-spec.md` + `dropdown-menu-interaction-spec.md` ·
  **Impl:** `src/components/modules/DropdownMenu.tsx` + `dropdown-menu.variants.ts`
- See `specs/visual-verify-report.md` for shared context and the runtime-check environment limitation.

## Result: PASS (source-of-truth) — 0 open source-level discrepancies

Every spec task is checked. The three entry types (item / separator / group-label), the item CVA axes
(`active`, `disabled`), all five item states, and the full menu/menuitem/separator ARIA model verify
against the spec + token map. **The former `text-muted` leak is now RESOLVED:** the `group-label` row
used `text-muted`, a **dead class** that emitted no CSS, but a top-level
`colors.muted: 'var(--color-text-muted)'` alias was added to `tailwind.config.js` on 2026-07-07
(compile-verified), so the group label now gets the intended `--color-text-muted` (#6c757d) applied
correctly. No component code changed.

---

## ⚠️ Runtime dimensions NOT executed (environment limit)

This environment has NO browser driver (Playwright/Puppeteer NOT installed) and no render harness for
these components, so the Figma-flow **live-viewport pixel comparison (375/768/1440px)** and **runtime
axe audit** CANNOT be executed and are NOT asserted. Everything here is a **source-of-truth
verification** (spec ↔ code ↔ token model), authoritative for token/variant/state-wiring/ARIA
dimensions. To close runtime dims: install a browser driver + Storybook/harness, screenshot each
viewport vs the Figma frame, run axe-core.

---

## Checklist (source-verified)

### Variants ✓
| `type` | Element | Interactive | OK |
|---|---|---|---|
| `item` | `<a role="menuitem">` (href) / `<button type="button" role="menuitem">` | yes | ✓ |
| `separator` | `<hr role="separator">` | no | ✓ |
| `group-label` | non-interactive `<div>` (muted — see D1) | no | ✓ (color defect D1) |

Item CVA axes (`dropdownMenuItemVariants`): `active` true → `bg-brand-primary-100 text-primary`,
false → `text-text hover:bg-neutral-100` ✓ · `disabled` true → `opacity-disabled pointer-events-none` ✓.
Leading `icon` slot rendered before label ✓.

### States ✓
| State | Wiring | OK |
|---|---|---|
| default | `text-text` on `bg-white` panel | ✓ |
| hover | `hover:bg-neutral-100` (non-active items) | ✓ |
| active | `bg-brand-primary-100 text-primary` + `aria-current="true"` | ✓ |
| focus | `focus-visible:ring-2 ring-primary ring-offset-2` on every row | ✓ |
| disabled | `opacity-disabled pointer-events-none` + `aria-disabled`; href/onSelect dropped; `<button>` also native `disabled` | ✓ |
| open / closed | correctly **out of scope** — panel is stateless, parent owns mount/unmount | ✓ |

### Tokens ✓
| Utility | → token | OK |
|---|---|---|
| `bg-white` | `--primitive-neutral-white` | ✓ |
| `border` / `border-1` | `--stroke-width-1` (1px, allowed) | ✓ |
| `border-neutral-300` (panel + separator) | `--color-neutral-300` | ✓ |
| `bg-neutral-100` (hover) | `--color-neutral-100` | ✓ |
| `bg-brand-primary-100` (active) | `--brand-primary-100` | ✓ |
| `text-primary` / `ring-primary` | `--theme-primary` | ✓ |
| `text-text` | `--color-text-default` | ✓ |
| `rounded` (panel) / `rounded-sm` (rows) | `--radius-8` / `--radius-4` | ✓ |
| `shadow-md` | `--shadow-default` | ✓ |
| `min-w-20` | `--spacing-80` (80px) | ✓ |
| `p-1` `my-1` `py-1` | `--spacing-4` (4px) | ✓ |
| `gap-2` `py-2` | `--spacing-8` (8px) | ✓ |
| `px-3` | `--spacing-12` (12px) | ✓ |
| `text-body` / `leading-body` / `font-base` | body size / line-height / family tokens | ✓ |
| `opacity-disabled` | `--opacity-disabled` | ✓ |
| `text-muted` (group-label) | → --color-text-muted (resolves via colors.muted alias, added 2026-07-07) | ✓ |

`ring-2` / `ring-offset-2` are fixed 2px focus-indicator widths (Tailwind defaults, not spacing) —
allowed like outline-width.

### Accessibility ✓
- Panel `role="menu"`; interactive rows `role="menuitem"`; dividers `role="separator"` ✓.
- Disabled items expose `aria-disabled` and drop `href`/`onClick` (`<a href={undefined}>` is not
  focusable; `<button disabled>` leaves the tab order) ✓.
- Active items expose `aria-current="true"` ✓ (selection not conveyed by color alone).
- Every row has a visible `focus-visible` ring ✓.
- **Trigger `aria-haspopup`/`aria-expanded` and focus-into/restore are correctly out of scope** — the
  spec assigns open/close + focus management to the parent trigger; this is a stateless surface. Not a
  gap. Roving-tabindex arrow nav is explicitly out of scope (Tab + Enter/Space model) ✓.

### Architecture ✓
CVA in `dropdown-menu.variants.ts` ✓ · `cn()` used, consumer `className` merged **last**, native
div props spread onto the panel ✓ · `forwardRef<HTMLDivElement>` ✓ · discriminated-union entry types
exported ✓ · no inline `style={{}}` for DS values ✓.

### Token audit ✓
Zero hardcoded hex / `rgb()` / `hsl()` / arbitrary `[..]`; zero inline `style={{}}`; only literal px is
the `1px` border (allowed). **No hardcode leak.** The former D1 dead-class note is now resolved:
`text-muted` resolves to `--color-text-muted` after the `colors.muted` alias fix (2026-07-07) — no
hardcodes; gate clean.

---

## Discrepancies

**✅ RESOLVED 2026-07-07 — D1 — `text-muted` is a dead class (muted token not applied).** Fixed by
adding `colors.muted: 'var(--color-text-muted)'` to `tailwind.config.js` (compile-verified); no
component code changed. At `DropdownMenu.tsx:71` the
`group-label` `<div>` uses `text-muted`. Compiling the project's actual `tailwind.config.js` confirms
Tailwind emits `.text-text-muted` and `.text-neutral-muted` but **not `.text-muted`** (no top-level
`muted` color exists; `text.muted` → `text-text-muted`). The group label therefore renders in the
inherited foreground rather than the intended `--color-text-muted` (#6c757d). This is a codebase-wide
convention (18+ files use `text-muted`; only `Table.tsx` uses the correct `text-text-muted`) — fix
DS-wide by adding a top-level `muted`/`text-muted` alias in `tailwind.config.js` or replacing
`text-muted` → `text-text-muted`. Verify-only: not edited here.

## Observations (non-blocking)
- **O-A — separator `<hr>` default border side.** `<hr className="my-1 border-neutral-300">` relies on
  the browser/Tailwind-base `<hr>` rendering; the intended 1px divider color token is applied. No
  action needed.

## Gate
**Variant · state · ARIA · architecture dimensions: PASSED.** **Token dimension: PASSED — 0 open
discrepancies (D1 resolved 2026-07-07)** — the `text-muted` dead-class was fixed DS-wide via the
`colors.muted` alias in `tailwind.config.js` (compile-verified). **Runtime dimensions (live-viewport
pixel + axe): not executable** in this environment.
