# Icon — Interaction Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./icon-component-spec.md
**Figma prototype**: Icons page — no interactive states

---

### Interaction Overview

Icon is a static, non-interactive glyph. It has no pointer or keyboard behavior of its own; its only "response" is passive — its color tracks the `currentColor` of whatever context renders it.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| — | — | Icon exposes no triggers; interaction belongs to its container |

---

### Flow

```
Step 1: Icon mounts and paints its glyph at the inherited currentColor.
Step 2: If the surrounding context changes color (e.g. a link hover, a disabled button), the glyph re-inherits the new currentColor. No transition is owned by Icon.
Step 3: No pointer, focus, or keyboard event is handled by Icon.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Color inheritance | inherited | inherited | Governed by the parent's `transition` (Icon adds none) |

Icon defines no animations. Any color transition seen on an icon is produced by its parent (e.g. Button's 150ms color transition).

---

### Animation Details

None. Icon renders a static SVG.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| Both `name` and `children` provided | `children` renders the custom shape; `name` is ignored |
| Unknown `name` | Renders nothing inside the SVG (empty glyph) — pass `children` instead |
| No `label` | Icon is `aria-hidden` and skipped by assistive tech |
| Placed in a color-transitioning parent | Glyph color animates with the parent, not independently |

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Fixed token box size (16/20/24px); does not reflow |

---

### Implementation Tasks

- [x] Confirm no interactive handlers are attached
- [x] Verify color inherits `currentColor` in all contexts
- [x] Verify decorative icons are `aria-hidden`
- [x] Verify glyph animates only with parent color transitions
