# Visual Verify Report — Icon

- **Component**: Icon (`src/components/ui/Icon.tsx`, `src/components/ui/icon.variants.ts`)
- **Design source / Branch**: figma / Branch A (source-of-truth)
- **Date**: 2026-07-07
- **Skill**: /visual-verify
- **Spec**: `specs/icon/icon-component-spec.md`, `icon-interaction-spec.md`, `icon-page-spec.md`

> **Render limitation**: No browser-automation or screenshot tool is available in this
> environment (no Playwright/Puppeteer, no per-component render harness). Verification is
> performed against the **source of truth** — the implementation code and the Tailwind →
> `var(--token)` mapping (`tailwind.config.js`, `src/styles/tokens.css`) compared to the
> codified Figma spec — plus static analysis. No pixel screenshots were captured; SVG path
> `d` coordinates are treated as glyph geometry, not layout, and are out of token-audit scope.
> Live-viewport pixel comparison (375/768/1440) and runtime axe remain not-executable here.

---

## Checklist

| Area | Item | Result |
|---|---|---|
| Variants | Spec `name` set (info, exclamation-triangle, check-circle, x-circle, x, list, chevron-right, link, dot) all present in registry | ✓ |
| Variants | Icon has no color/style variants (color driven by `currentColor`) — matches spec | ✓ |
| Sizes | `small` → `h-4 w-4` → `--spacing-16` (16px) | ✓ |
| Sizes | `medium` → `h-5 w-5` → `--spacing-20` (20px), default variant | ✓ |
| Sizes | `large` → `h-6 w-6` → `--spacing-24` (24px) | ✓ |
| Canvas | `viewBox="0 0 16 16"` on `<svg>` | ✓ |
| States | Non-interactive; single `default` state painting at `currentColor` | ✓ |
| Color → token | Fill via `fill-current` (CVA base) = `currentColor`; no hardcoded color | ✓ |
| Sizing → token | All box sizing via token-backed spacing utilities; no raw px | ✓ |
| Radius / shadow | None applicable to Icon | ✓ (n/a) |
| A11y — decorative | No `label` → `aria-hidden="true"`, `role` omitted, removed from a11y tree | ✓ |
| A11y — meaningful | `label` present → `role="img"` + `aria-label={label}` | ✓ |
| Responsive | Fixed token box at 375 / 768 / 1440; does not reflow | ✓ |
| Token audit | grep `#hex / rgb( / hsl( / style={{ / [Npx]` on Icon.tsx + icon.variants.ts → **empty** | ✓ |
| Architecture | CVA size variants, `forwardRef`, `{...props}` spread, `cn()` last, `VariantProps` exported | ✓ |

### Sizes — token resolution
| `size` | Class → Tailwind key → token | Result |
|---|---|---|
| `small` | `h-4 w-4` → `4` → `--spacing-16` (16px) | ✓ |
| `medium` (default) | `h-5 w-5` → `5` → `--spacing-20` (20px) | ✓ |
| `large` | `h-6 w-6` → `6` → `--spacing-24` (24px) | ✓ |

`defaultVariants.size = 'medium'` ✓. All glyphs draw on a `viewBox="0 0 16 16"` canvas.

### Responsive verification (375 / 768 / 1440)
Icon renders a fixed token-sized box (16 / 20 / 24px) chosen by the `size` prop and does
not depend on viewport width. Behavior is identical across all three breakpoints, matching
the interaction spec's "does not reflow" rule. ✓ (source-of-truth; live pixel compare not run.)

### Token audit (static, zero tolerance)
grep `#hex / rgb( / hsl( / style={{ / [Npx]` on `Icon.tsx` + `icon.variants.ts` → **0 hits**.
`viewBox` / `xmlns` / `d=` are SVG attributes and path geometry, not CSS DS values. The
`style={{}}` matches from a repo-wide grep live only in `Icon.stories.tsx` (non-shipped demo
layout), outside the token gate. `npx tsc --noEmit` exits 0.

---

## Discrepancies

| # | Severity | Item | Detail | Status |
|---|---|---|---|---|
| — | — | — | No source-level discrepancies found | — |

**Note (informational, not a discrepancy):** the runtime glyph registry contains a
superset of the 9 spec-documented glyphs (adds `check`, `dash`, `plus`, `chevron-down/up/left`,
`chevron-expand`, `caret-down-fill`, `star`, `star-fill`, `calendar`, `clock`, `upload`,
`file-earmark`, `three-dots-vertical`, `search`). These extras are actively consumed by
Checkbox (`check`/`dash`), Accordion (`chevron-down`), InputNumber (`dash`/`plus`), and Select
(`caret-down-fill`), so the superset is intentional and required. The spec frames the 9 as the
canonical registered set; no code change is warranted.

---

## Result: PASS
