# Icon — Usage / Composition Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./icon-component-spec.md

Atoms have no page of their own; this documents how Icon composes into higher-order components and screens.

---

### Consumed By

| Consumer | Usage |
|---|---|
| `IconWrapper` (atom) | The single Icon inside the padded square affordance |
| `Text` (atom) | `leadingIcon` / `trailingIcon` slots and the `bullet` dot |
| `Button` (atom) | Icon content in `children`, including `iconOnly` |
| Molecules / organisms | Status indicators, chevrons, close controls |

---

### Composition Rules

- Icon inherits color from its parent via `currentColor` — parents set color, Icon never does.
- Size is chosen with the `size` prop to match the parent's type/box scale, not with raw classes.
- Decorative icons next to a text label omit `label`; standalone icons carry `label`.
- Never wrap an Icon in an interactive element unless the parent supplies the accessible name.

---

### Accessibility

- Meaningful icons expose `role="img"` + `aria-label`; decorative icons are `aria-hidden`.
- When paired with visible text, the text is the accessible name and the Icon stays decorative.

---

### Implementation Tasks

- [x] Verify Icon inherits color inside Button, Text, and IconWrapper
- [x] Verify size prop aligns Icon with each parent's scale
- [x] Verify decorative vs labeled a11y in composition
