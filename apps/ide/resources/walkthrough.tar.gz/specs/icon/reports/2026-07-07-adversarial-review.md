# Adversarial Review — Icon

- **Date**: 2026-07-07
- **Component**: Icon (`src/components/ui/Icon.tsx`, `src/components/ui/icon.variants.ts`)
- **Story**: `src/components/ui/Icon.stories.tsx`
- **Spec**: `specs/icon/icon-component-spec.md`, `icon-interaction-spec.md`, `icon-page-spec.md`
- **Method**: source-of-truth (code + Tailwind token mapping vs spec) + static analysis.
  No screenshot/browser tooling available; SVG `d` coords are glyph geometry, out of token-audit scope.

## Verdict: PASS

No Blocker or High findings. The Icon atom is token-pure, correctly sized via spacing
tokens, colored via `currentColor`, and accessible (decorative `aria-hidden` vs meaningful
`role="img"` + `aria-label`). `npx tsc --noEmit` exits 0. No inline fixes were required.

## Findings

| Severity | Area | Issue | Status |
|---|---|---|---|
| Info | Variant coverage | Runtime `iconGlyphs` registry (25 glyphs) is a superset of the 9 spec-documented names. Extras (`check`, `dash`, `plus`, `chevron-down/up/left`, `caret-down-fill`, etc.) are consumed by Checkbox / Accordion / InputNumber / Select, so removal would break consumers. `IconName = keyof typeof iconGlyphs` is intentionally broader than the spec Props table. | Accepted — no change |
| Info | Glyph fidelity | The `link` glyph uses a single `<path>`; Bootstrap's canonical `link` icon is two chained paths, so this renders a simplified link mark. Pure glyph geometry (not layout/token); cannot verify pixel fidelity without a render harness. | Noted — no change |
| Info | A11y (prop override) | `{...props}` is spread after `role` / `aria-hidden` / `aria-label`, so a consumer can override the computed a11y attributes. Intentional escape-hatch flexibility, not a defect. | Accepted — no change |
| Pass | Token audit | grep `#hex / rgb( / hsl( / style={{ / [Npx]` on Icon.tsx + icon.variants.ts → 0 hits. Story-file inline `style={{}}` are layout scaffolding in `.stories.tsx`, outside the component. | — |
| Pass | State coverage | Icon is non-interactive by spec — no hover/focus/active/disabled owned; color inherits from context via `fill-current`. Matches interaction spec. | — |
| Pass | Interaction-spec compliance | No handlers attached; `children` wins over `name`; unknown/absent glyph → empty SVG box; decorative → `aria-hidden`. All documented edge cases match. | — |
| Pass | Responsive | Fixed token box (16/20/24px) at 375/768/1440; no reflow. | — |

## Resolved During Review

None — no discrepancies required inline fixes. Icon's own files were left unchanged.

### Shared-config / cross-component concerns
None. Sizing utilities (`h-4/5/6`, `w-4/5/6`) resolve through the shared
`tailwind.config.js` spacing map (`4→--spacing-16`, `5→--spacing-20`, `6→--spacing-24`)
to `src/styles/tokens.css`; all present and correct. No shared defects surfaced.

## Architecture Validation Checklist

| Check | Result |
|---|---|
| CVA used for variants (size) in separate `.variants.ts` | ✓ `icon.variants.ts` |
| `defaultVariants` match spec default (`medium`) | ✓ |
| `forwardRef` with `displayName` | ✓ `forwardRef<SVGSVGElement>`, `Icon.displayName = 'Icon'` |
| Spreads native props (`{...props}`) | ✓ `SVGAttributes<SVGSVGElement>` spread on `<svg>` |
| `className` merged last via `cn()` | ✓ `cn(iconVariants({ size }), className)` |
| `VariantProps` exported | ✓ `IconVariants` (VariantProps) exported and extended by `IconProps` |
| No inline `style={{}}` for DS values | ✓ none in component |
| Color via `currentColor` / token classes | ✓ `fill-current` base |
| Sizing via tokens (no raw px) | ✓ token-backed spacing utilities |
| `npx tsc --noEmit` | ✓ exit 0 |
