# Icon — Component Spec

**Version**: 1.0
**Status**: Implemented
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Frame URL**: Icons page
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Single-glyph SVG atom that renders a registered (or custom) vector mark at a token-sized box. Color is inherited from context via `currentColor`, so the same Icon adapts to any surface — it fronts the full Bootstrap icon set and is the visual primitive inside Button, Text, IconWrapper, and beyond.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--spacing-16` | `16px` | `height` / `width` (small `h-4`) |
| `--spacing-20` | `20px` | `height` / `width` (medium `h-5`) |
| `--spacing-24` | `24px` | `height` / `width` (large `h-6`) |
| `currentColor` | inherited | `fill` (color follows context) |

All sizing is applied through the Tailwind theme mapping in `tailwind.config.js`, which resolves to these CSS variables. Color is never hardcoded — the glyph always paints with `currentColor`. No hardcoded values.

---

### Variants

Icon has no color/style variants of its own — appearance is driven entirely by the inherited `currentColor` and the selected glyph. The `name` prop selects one registered glyph.

| Registered `name` | Glyph |
|---|---|
| `info` | Info circle |
| `exclamation-triangle` | Warning triangle |
| `check-circle` | Success check in circle |
| `x-circle` | Error x in circle |
| `x` | Close / dismiss |
| `list` | List / menu |
| `chevron-right` | Forward chevron |
| `link` | Link / anchor |
| `dot` | Filled dot (bullet) |

For any unregistered glyph, pass raw `<path>`/shape markup as `children`.

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | Paints at `currentColor` | — |

Icon is non-interactive. It has no hover/focus/active/disabled states of its own; its color simply follows the context it is placed in (e.g. a hovered link or disabled button).

---

### Sizes

| Size | Box | Token |
|---|---|---|
| `small` | 16px (`h-4 w-4`) | `--spacing-16` |
| `medium` | 20px (`h-5 w-5`) | `--spacing-20` |
| `large` | 24px (`h-6 w-6`) | `--spacing-24` |

All glyphs draw on a `viewBox="0 0 16 16"` canvas and scale to the box.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `size` | `small \| medium \| large` | `medium` | Box size |
| `name` | `info \| exclamation-triangle \| check-circle \| x-circle \| x \| list \| chevron-right \| link \| dot` | — | Registered glyph to render |
| `label` | `string` | — | Accessible name; when omitted the icon is decorative (`aria-hidden`) |
| `children` | `ReactNode` | — | Custom path/shape for an unregistered glyph |
| `className` | `string` | — | Layout overrides only, merged last |
| `...props` | `SVGProps` | — | Native SVG attributes spread |

---

### Content Rules

- Provide exactly one of `name` or `children`.
- Give `label` only when the icon conveys standalone meaning; omit it when an adjacent text label already names the action.
- Never bake color into the SVG — let `currentColor` inherit.

---

### Accessibility

- Element: `<svg viewBox="0 0 16 16" fill="currentColor">`.
- Labeled: `role="img"` + `aria-label={label}`.
- Decorative (no `label`): `aria-hidden="true"` and removed from the accessibility tree.
- Color contrast is the responsibility of the surrounding context, not the Icon.

---

### Do Not

- Do not hardcode `fill` colors — always inherit `currentColor`.
- Do not set pixel sizes directly — use the `size` prop (token-backed).
- Do not render a meaningful icon without a `label`.

---

### Implementation Tasks

- [x] Create `src/components/ui/icon.variants.ts` (CVA size variants)
- [x] Create `src/components/ui/Icon.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Build the registered glyph map (info, exclamation-triangle, check-circle, x-circle, x, list, chevron-right, link, dot)
- [x] Support `children` for unregistered glyphs
- [x] Implement `small` / `medium` / `large` sizes via spacing tokens
- [x] Wire `label` → `role="img"` + `aria-label`; else `aria-hidden`
- [x] Unit test render, size class, labeled vs decorative a11y
