# Radio — Page / Usage Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens

---

### Purpose

Documents how the Radio atom is composed into radio groups within forms and settings
screens. A Radio is never used alone — it belongs to a group of two or more options
sharing a `name`, from which the user selects exactly one.

---

### Component Inventory

| Component | Role |
|---|---|
| `Radio` (atom) | Single selectable option with optional label |
| `fieldset` / `legend` (native) | Groups related radios and names the choice |

---

### Usage

A radio group: every option shares the same `name`, so the browser enforces single
selection. Wrap the group in a `<fieldset>` with a `<legend>` for an accessible group name.

```tsx
import { Radio } from '@/components/ui/Radio';

function PlanPicker() {
  return (
    <fieldset>
      <legend>Choose a plan</legend>
      <Radio name="plan" value="free" label="Free" defaultChecked />
      <Radio name="plan" value="pro" label="Pro" />
      <Radio name="plan" value="team" label="Team" />
      <Radio name="plan" value="enterprise" label="Enterprise" disabled />
    </fieldset>
  );
}
```

Notes:
- **Same `name`** across all options is what links them into one mutually-exclusive group.
- Give each option a unique `value` — that is what `onChange` / form submission reports.
- Use `defaultChecked` (uncontrolled) or `checked` + `onChange` (controlled), not both.
- Sizes should be consistent within a single group (`size="small"` etc. on all options).

---

### Responsive

- The control size is fixed per `size` prop and does not scale with viewport.
- Groups stack vertically by default; a parent flex/grid layout may arrange options in
  columns on wider viewports. Layout is the consumer's responsibility via `className`.
- Label text wraps within its column; the circle stays top-/center-aligned via the
  `inline-flex items-center` label.

---

### Accessibility

- Wrap each group in `<fieldset>` + `<legend>` so AT announces the group's purpose.
- Each Radio's `<label>` wraps its input, providing an accessible name per option.
- Keyboard: Tab reaches the group; arrow keys move selection (native).
- Focus ring is always visible on the focused option.

---

### Implementation Tasks

- [x] Radio composes into a `<fieldset>`/`<legend>` group
- [x] Shared `name` enforces single selection across options
- [x] Per-option `value` + optional `label`
- [x] Consistent `size` across a group
- [x] Group is keyboard-navigable with visible focus
