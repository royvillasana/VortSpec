# Adversarial Review — Radio

**Date**: 2026-07-07
**Reviewer**: /adversarial-review (autonomous)
**Files**: `src/components/ui/Radio.tsx`, `src/components/ui/radio.variants.ts`
**Source of truth**: `specs/radio/` (component / interaction / page specs), codified Figma design.
**Method**: static source-of-truth analysis + token-mapping audit. No browser render available
(no screenshot claims). No Storybook story exists for Radio.

---

## Verdict

**PASS — no Blocker or Major findings.** Implementation is fully spec-compliant, token-pure,
and consistent with the sibling Checkbox atom. No inline fixes were required.

---

## Findings

| # | Severity | Area | Finding | Status |
|---|---|---|---|---|
| 1 | Info | Focus ring width | `ring-2` / `ring-offset-2` are Tailwind literal 2px (ring *color* is tokenized). Spec explicitly mandates "2px ring, 2px offset"; identical to Checkbox. | Accepted (spec-compliant, DS-consistent) |
| 2 | Info | Redundant utility | `border border-1` both resolve to `--stroke-width-1`; `leading-body` is redundant with `text-body`'s bundled line-height. | Accepted (harmless, matches Checkbox convention; both tokenized) |
| 3 | Info | Disabled label | `peer-disabled:opacity-disabled` dims only the circle, not the label text. | Accepted (identical to Checkbox — DS-wide convention, not a Radio defect) |

No Blocker, Major, or Minor defects were found.

### Adversarial probes run (all passed)
- **Variant coverage**: only `size` (small/medium/large) exists per spec; no missing/extra variants. `defaultVariants.size = medium` present on both cva blocks.
- **State coverage**: unchecked / checked / focus-visible / disabled all handled via `peer-*` on the sibling box; transition matches interaction spec (`transition-colors duration-150 ease-out`).
- **Token audit**: grep for hex/rgb/hsl/inline-style/`[Npx]` → empty. Every color/spacing/radius/stroke/opacity/font utility resolves through `tailwind.config.js` to a `--token`.
- **Accessibility adversarial**: real native `<input type="radio">` retained (not a `role="radio"` div); `name`/`value` spread via `...props` so native grouping + arrow-key single-selection work; wrapping `<label>` provides accessible name; decorations `aria-hidden`; focus ring never removed. No custom key handlers intercept native arrow navigation.
- **Layering probe**: input (`sr-only`, positioned), box (`absolute inset-0`), dot (`relative`, in-flow) — dot is later in DOM so it paints above the filled circle; dot centered by wrapper's `items-center justify-center`; wrapper keeps size via explicit `h/w`. Correct at unchecked and checked.
- **Responsive**: no viewport-conditional classes — control is size-stable at 375/768/1440; layout delegated to consumer `className` per page spec; `shrink-0` prevents circle deformation next to wrapping labels.
- **Interaction-spec compliance**: native input drives all selection (no internal JS state), controlled/uncontrolled both supported via spread props, label click selects, disabled non-interactive.
- **Typecheck**: `npx tsc --noEmit` → exit 0.

---

## Resolved During Review

None — no defects required correction. Files were not modified.

---

## Architecture Validation Checklist

| Check | Result | Evidence |
|---|---|---|
| CVA used for variants | ✓ | `radioVariants`, `radioDotVariants` via `cva()` (box has no variants → plain string is acceptable) |
| `defaultVariants` set | ✓ | `size: 'medium'` on both cva blocks |
| `forwardRef` | ✓ | `React.forwardRef<HTMLInputElement, RadioProps>`, `displayName = 'Radio'` |
| Spreads native props | ✓ | `{...props}` on the `<input>` |
| `className` merged last via `cn()` | ✓ | `cn('...', disabled ? ... , className)` on outer `<label>` |
| `VariantProps` exported | ✓ | `export type RadioVariants = VariantProps<typeof radioVariants>` |
| Variants in separate `.variants.ts` | ✓ | `radio.variants.ts` |
| No inline `style={{}}` for DS values | ✓ | none present (grep empty) |
| `size`/`type` reserved (not native attrs) | ✓ | `Omit<..., 'size' \| 'type'>`, `type="radio"` fixed |

**Overall: PASS.**
