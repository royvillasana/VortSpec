# Visual Verify Report — Radio

**Component**: Radio
**Source of truth**: Figma / Branch A (codified specs in `specs/radio/`)
**Date**: 2026-07-07
**Skill**: /visual-verify
**Files verified**: `src/components/ui/Radio.tsx`, `src/components/ui/radio.variants.ts`

> **Render limitation**: No browser/screenshot tool is available in this environment.
> Verification is SOURCE-OF-TRUTH: static analysis of code + Tailwind→token mapping
> (`tailwind.config.js` → `src/styles/tokens.css`) against the three specs. No pixel
> screenshots were captured; no rendered-pixel claims are made.
> **Story note**: No Storybook story exists for Radio (`Radio.stories.tsx` absent) — the
> component could not be browsed live at http://localhost:6006/.

---

## Checklist

### Variants & Sizes
| Item | Result | Notes |
|---|---|---|
| `size` variant present (small/medium/large) | ✓ | `radioVariants` + `radioDotVariants` cva, `defaultVariants.size = medium` |
| No color variant (single primary treatment) | ✓ | Matches spec — only `size` exists |
| small outer 16px (`h-4 w-4`) | ✓ | spacing `4` → `--spacing-16` = 16px |
| medium outer 20px (`h-5 w-5`) | ✓ | spacing `5` → `--spacing-20` = 20px |
| large outer 24px (`h-6 w-6`) | ✓ | spacing `6` → `--spacing-24` = 24px |
| small dot 6px (`h-1.5 w-1.5`) | ✓ | spacing `1.5` → `--spacing-6` = 6px |
| medium dot 8px (`h-2 w-2`) | ✓ | spacing `2` → `--spacing-8` = 8px |
| large dot 10px (`h-2.5 w-2.5`) | ✓ | spacing `2.5` → `--spacing-10` = 10px |

### States
| Item | Result | Notes |
|---|---|---|
| unchecked: white fill, neutral-300 border, dot hidden | ✓ | `bg-white border-neutral-300`, dot `hidden` |
| checked: primary fill+border, white dot visible | ✓ | `peer-checked:bg-primary peer-checked:border-primary`, dot `peer-checked:block bg-white` |
| focus: 2px primary ring, 2px offset around circle | ✓ | `peer-focus-visible:ring-2 ring-primary ring-offset-2` on box |
| disabled: opacity 0.65, cursor-not-allowed | ✓ | `peer-disabled:opacity-disabled`, label `cursor-not-allowed` |
| color transition 150ms ease-out | ✓ | `transition-colors duration-150 ease-out` (matches interaction spec) |

### Responsive (375 / 768 / 1440)
| Item | Result | Notes |
|---|---|---|
| Control size fixed per `size` prop, does not scale with viewport | ✓ | No viewport-conditional classes; identical at 375/768/1440 |
| Group layout is consumer's responsibility via `className` | ✓ | Component is `inline-flex`; no internal breakpoint logic (per page spec) |
| Long label wraps, circle stays vertically centered | ✓ | `inline-flex items-center` on label; `shrink-0` on control keeps circle fixed |

### Colors → Tokens
| Item | Result | Token |
|---|---|---|
| checked fill/border | ✓ | `bg-primary`/`border-primary` → `--theme-primary` (#087990) |
| unchecked fill / dot | ✓ | `bg-white` → `--primitive-neutral-white` (#ffffff) |
| unchecked border | ✓ | `border-neutral-300` → `--color-neutral-300` (#dee2e6) |
| label color | ✓ | `text-text` → `--color-text-default` (#212529) |
| focus ring color | ✓ | `ring-primary` → `--theme-primary` |
| disabled opacity | ✓ | `opacity-disabled` → `--opacity-disabled` (0.65) |

### Size / Spacing → Tokens
| Item | Result | Token |
|---|---|---|
| outer circle / inner dot sizing | ✓ | all via `spacing` theme map → `--spacing-*` |
| label gap 8px | ✓ | `gap-2` → spacing `2` → `--spacing-8` |
| border width 1px | ✓ | `border border-1` → `--stroke-width-1` (sanctioned 1px exception) |
| circle radius | ✓ | `rounded-full` (sanctioned exception for circular control + dot) |
| label font-size / line-height | ✓ | `text-body leading-body` → `--font-size-body` / `--line-height-body` |

### Accessibility
| Item | Result | Notes |
|---|---|---|
| Real native `<input type="radio">` preserved | ✓ | not a `div`/`role="radio"` reimplementation |
| Visually-hidden peer (`peer sr-only`) + sibling circle & dot | ✓ | matches sanctioned Radio pattern |
| `name` grouping / single-selection (native) | ✓ | `name`/`value` flow through `...props` |
| Label associated (wrapping `<label>`) | ✓ | click on label/text selects the input |
| Decorative circle & dot `aria-hidden` | ✓ | both spans `aria-hidden="true"` |
| Focus-visible ring never removed | ✓ | `peer-focus-visible:ring-2` |
| Arrow-key group navigation | ✓ | native (no custom JS intercepts keys) |

### Token Audit (grep)
`grep -nE '#[0-9a-fA-F]{3,8}|rgb\(|hsl\(|style=\{\{|\[[0-9]+px\]'` on both files → **0 matches (empty)**. No hardcoded hex, rgb/hsl, inline `style`, or arbitrary `[Npx]` values.

---

## Discrepancies

| # | Severity | Description | Resolution |
|---|---|---|---|
| — | — | None found | — |

Notes (non-defects): focus `ring-2` / `ring-offset-2` widths are Tailwind's literal 2px
(the ring *color* is token-mapped). These match the spec's explicit "2px ring, 2px offset"
and are identical to the sibling Checkbox — a DS-wide focus affordance, not a token violation.
Disabled state dims only the circle (`peer-disabled:opacity-disabled` on the box), not the
label text — this is intentional and identical to the sibling Checkbox pattern (DS convention),
so it was left unchanged.

---

**Result: PASS**
