# Radio — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens

---

### Overview

The Radio selects exactly one option from a group. All interaction is handled by the
native `<input type="radio">`; the component only styles the state. Radios sharing a
`name` are mutually exclusive.

---

### Trigger

- Pointer: click on the circle, the label text, or anywhere inside the wrapping `<label>`.
- Keyboard: `Tab` moves focus to the group; arrow keys move selection within the group.

---

### Flow

1. User focuses a radio group (Tab lands on the checked radio, or the first if none checked).
2. User presses an arrow key (or clicks an option) to select it.
3. The selected input becomes `:checked`:
   - Circle fill/border animate to `primary` (`transition-colors`, 150ms ease-out).
   - Inner white dot becomes visible (`peer-checked:block`).
4. The previously selected radio in the same `name` group deselects automatically (native).
5. `onChange` fires with the newly selected input's `value`.

---

### Timing

| Property | Value | Token |
|---|---|---|
| Circle color transition | 150ms, ease-out | `transition-colors duration-150 ease-out` |
| Dot appearance | Immediate (display swap) | — |

---

### Edge Cases

- **Disabled**: `disabled` radios are not focusable and do not respond to pointer or
  keyboard; rendered at `opacity-disabled` with `cursor-not-allowed`.
- **No selection**: a group may start with none checked; Tab focuses the first radio.
- **Controlled**: when `checked` is supplied, selection is driven by the consumer via
  `onChange`; the component adds no internal state.
- **Label click**: clicking the label toggles the input because the `<label>` wraps it.
- **Long label**: label text wraps naturally; the control stays vertically centered.

---

### Accessibility & Keyboard

| Key | Action |
|---|---|
| `Tab` | Move focus into / out of the radio group |
| `Arrow Down` / `Arrow Right` | Select next radio in group (native) |
| `Arrow Up` / `Arrow Left` | Select previous radio in group (native) |
| `Space` | Select the focused radio if not already selected |

- Focus is always visible via `peer-focus-visible:ring-2 ring-primary ring-offset-2`.
- Native radio role and checked state are exposed to assistive technology automatically.
- Decorative circle/dot are `aria-hidden`; the input is the single source of state.

---

### Implementation Tasks

- [x] Native input drives all selection — no custom JS state
- [x] `peer-checked:` toggles circle fill/border and dot visibility
- [x] `transition-colors duration-150 ease-out` on the circle
- [x] Focus ring via `peer-focus-visible`
- [x] Disabled inputs non-interactive, `peer-disabled` styling
- [x] Label wraps input so label clicks select the option
