# Radio — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Single-choice control. Renders a real native `<input type="radio">` visually hidden as
the `peer`, next to a custom circular box (`rounded-full`) with an inner filled dot shown
only when checked. Mirrors the Checkbox approach but circular. Browser-native grouping,
single-selection, and arrow-key navigation are preserved for inputs sharing a `name`.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--theme-primary` | `#087990` | `background-color` / `border-color` (checked circle) |
| `--primitive-neutral-white` | `#ffffff` | `background-color` (unchecked circle) / inner dot |
| `--color-neutral-300` | `#dee2e6` | `border-color` (unchecked circle) |
| `--color-text-default` | `#212529` | `color` (label) |
| `--spacing-4` | 16px | outer circle (small) `h`/`w` |
| `--spacing-20` | 20px | outer circle (medium) `h`/`w` |
| `--spacing-24` | 24px | outer circle (large) `h`/`w` |
| `--spacing-6` | 6px | inner dot (small) `h`/`w` |
| `--spacing-8` | 8px | inner dot (medium) `h`/`w` / label gap |
| `--spacing-10` | 10px | inner dot (large) `h`/`w` |
| `--stroke-width-1` | `1px` | `border-width` |
| `--opacity-disabled` | `0.65` | `opacity` (disabled) |
| `--font-family-base` | Roboto | `font-family` (label) |
| `--font-size-body` | `16px` | `font-size` (label) |
| `--line-height-body` | — | `line-height` (label) |

All references are via the Tailwind theme mapping in `tailwind.config.js`, which resolves to
these CSS variables. No hardcoded values.

---

### Variants

| Prop | Values | Default | Description |
|---|---|---|---|
| `size` | `small \| medium \| large` | `medium` | Outer circle + inner dot scale |

There is no color variant — the radio uses a single primary-selected treatment.

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `unchecked` | White fill, `neutral-300` border, dot hidden | Default |
| `checked` | `primary` fill + border, white inner dot visible | `checked` / native selection |
| `focus` | 2px ring in `primary`, offset 2px, around the circle | Keyboard focus (`peer-focus-visible`) |
| `disabled` | `opacity-disabled` (0.65), `cursor-not-allowed` | `disabled` prop |

---

### Sizes

| Size | Outer circle | Inner dot |
|---|---|---|
| `small` | 16px (`h-4 w-4`) | 6px (`h-1.5 w-1.5`) |
| `medium` | 20px (`h-5 w-5`) | 8px (`h-2 w-2`) |
| `large` | 24px (`h-6 w-6`) | 10px (`h-2.5 w-2.5`) |

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `size` | `small \| medium \| large` | `medium` | Control size |
| `label` | `React.ReactNode` | — | Optional label rendered right of the control |
| `checked` / `defaultChecked` | `boolean` | — | Native controlled / uncontrolled selection |
| `name` | `string` | — | Groups radios for single-selection (native) |
| `value` | `string` | — | Submitted value when selected |
| `disabled` | `boolean` | `false` | Disables interaction |
| `className` | `string` | — | Layout overrides only, merged last on the outer `<label>` |
| `...props` | `InputHTMLAttributes` (minus `size`, `type`) | — | Native input attributes spread onto the input |

---

### Accessibility

- Element: real native `<input type="radio">` — full radio semantics for AT.
- The `<label>` wraps the input, so clicking the label or text toggles selection; no
  explicit `htmlFor` needed.
- Focus ring is never removed — `peer-focus-visible:ring-2`.
- The decorative circle and dot are `aria-hidden="true"`; the native input carries state.
- Radios sharing a `name` form a group navigable with arrow keys (native).

---

### Do Not

- Do not hardcode colors, spacing, or radius — reference tokens via Tailwind theme.
- Do not remove the focus ring.
- Do not replace the native input with a `div`/`role="radio"` reimplementation.
- Do not use `size` as an HTML attribute — it is reserved for the variant.

---

### Implementation Tasks

- [x] Create `src/components/ui/radio.variants.ts` (CVA — sizing wrapper, box, dot)
- [x] Create `src/components/ui/Radio.tsx` (`forwardRef`, spreads props, `cn()` last on label)
- [x] Render native `<input type="radio">` as `peer sr-only`
- [x] Implement unchecked / checked circle via `peer-checked:` (bg + border)
- [x] Implement inner dot `hidden peer-checked:block`, centered, `bg-white`
- [x] Implement `small` / `medium` / `large` sizes for circle + dot
- [x] Wire focus ring (`peer-focus-visible`) and disabled (`peer-disabled`)
- [x] Optional `label` node, `text-body text-text`
- [x] Typecheck passes
