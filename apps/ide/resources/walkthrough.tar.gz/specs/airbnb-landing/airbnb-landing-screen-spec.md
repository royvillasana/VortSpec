# Screen Spec — Airbnb Landing (App)

> Replicates the Airbnb homepage **structure/layout** using the Design Engineering
> System components and tokens. Airbnb's coral brand color is intentionally **not**
> reproduced — it is not a system token, and hardcoded hex fails review. The screen
> is themed with system tokens (teal `primary`, gold `warning` star, neutral scale).
> Listing imagery is sourced from Unsplash.

## Intent

A browse/discovery landing page: a sticky top bar with brand + search, a scrollable
category strip, a responsive grid of listing cards, and a link-column footer.

## Component Gap Detection

| Region | Elements | Resolution |
|---|---|---|
| Top bar | logo, host link, globe, search pill | Compose `Logo`, `Button`, `Icon` (page chrome) |
| Category strip | icon + label, repeated; Filters button | Compose `Icon`, `Text`, `Button` (page chrome) |
| Listing grid | image, favourite, rating, title, meta, price | **New component `ListingCard`** (built below) |
| Footer | link columns, bottom bar | Compose `Text` (page chrome) |

Only `ListingCard` is a reusable gap → built spec-first. Search pill and category item
are page-level layout; flagged as future extraction candidates if reused elsewhere.

## Component Spec — `ListingCard` (molecule)

- **Composes:** `Icon` (star, heart), `Tag` (optional badge).
- **Root:** `<article data-component="ListingCard">`.
- **Props:** `image`, `imageAlt`, `title`, `location`, `meta` (dates/distance line),
  `price`, `priceUnit` (default "night"), `rating` (number), `badge?`, `favorite?`.
- **Tokens:** `rounded-md` image, `text-text` / `text-muted` copy, `text-warning`
  star, `neutral-100` image placeholder, `typography.body`. No hardcoded values.
- **A11y:** image has alt text; favourite is a real `<button>` with `aria-pressed`
  and `aria-label`; rating exposes an accessible label.

## Acceptance Criteria

- [x] Sticky top bar with brand, search pill, and host/globe affordances.
- [x] Horizontally scrollable category strip + Filters button.
- [x] Responsive listing grid (1 → 2 → 3 → 4 columns across breakpoints).
- [x] `ListingCard` component built with CVA + `cn` + `forwardRef`, token-referenced.
- [x] Footer with link columns and a bottom bar.
- [x] Every color/spacing/radius references a token; Unsplash images for listings.
- [x] `data-component` on component roots for the visual editor.
