# Select — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens

---

### Interaction Overview

Select lets the user pick one option (single) or several (multiple) from a fixed list.
It renders a **native `<select>`**, so opening, navigating, and committing a choice all
use the browser/OS-native menu and keyboard behaviour. The only custom motion is a short
color transition on border and background; there is no custom JS animation.

---

### Trigger

- **Pointer**: Click/tap the control opens the native option menu (single) or focuses the
  listbox (multiple). The overlaid caret is `pointer-events-none`, so clicks pass through to
  the `<select>`.
- **Keyboard**: `Tab` moves focus in; `Shift+Tab` moves out. `Space` / `Enter` / arrow keys
  open or move through options per the platform.
- **Programmatic**: A forwarded ref exposes the `<select>` node for `.focus()`.

---

### Flow

1. User focuses the control (pointer or keyboard) → focus-visible ring appears (primary,
   or danger when `error`).
2. **Single-select**: activating opens the native menu. Arrow keys / typeahead move the
   highlight; `Enter` (or click) commits and closes the menu. The chosen `label` shows in
   the control; `onChange` fires.
3. **Multiple-select**: the native listbox is always visible (taller). `Space` toggles the
   focused option; `Shift`/`Ctrl`(`Cmd`)+click or `Shift`+arrows extend the selection.
4. If a `placeholder` is set (single only), the disabled `value=""` option shows first until
   a real value is chosen.
5. On blur, the ring is removed; the selection persists.
6. When `disabled`, the control is non-interactive, greyed (`opacity-disabled`, neutral-100 bg)
   and skipped in tab order.

---

### Timing

| Property | Value |
|---|---|
| Border/background color transition | 150ms, `ease-out` |
| Focus ring | Immediate (no delay) |
| Native menu open/close | Platform-controlled |

Uses `transition-colors duration-150 ease-out`. Only color transitions are used (no
transforms), so reduced-motion preferences are respected by default.

---

### Edge Cases

- **Placeholder** → disabled `value=""` first option; not rendered in `multiple` mode.
- **Multiple** → native listbox renders; the caret Icon is hidden and caret padding removed.
- **No options** → an empty control renders (only the placeholder, if any); no crash.
- **Disabled option** → individual `<option disabled>` is non-selectable while others remain.
- **Error + focus** → focus ring uses danger color, not primary.
- **Long option labels** → the native menu handles overflow/scroll per platform.
- **Controlled vs uncontrolled** → both supported via native `value` / `defaultValue`.
- **Consumer `className`** → merged last on the outer wrapper; layout only, must not strip token styles.

---

### Accessibility & Keyboard

| Key | Action |
|---|---|
| `Tab` / `Shift+Tab` | Move focus in / out |
| `Space` / `Enter` | Open native menu (single) / toggle option (multiple) |
| `Arrow Up` / `Arrow Down` | Move highlight / change selection |
| Typeahead (letters) | Jump to matching option |
| `Home` / `End` | First / last option |
| `Esc` | Close menu without changing (single) |

- Focus is always visible via `focus-visible:ring-2` (+ offset).
- The `<label>` is associated via `htmlFor`; error/hint text is linked via `aria-describedby`.
- `aria-invalid` communicates the error state; the caret is `aria-hidden`.
- Native semantics mean screen readers announce role, value, position, and count automatically.

---

### Implementation Tasks

- [x] Native `<select>` open/commit behaviour preserved (no custom listbox)
- [x] Focus-visible ring on keyboard/pointer focus (primary; danger when error)
- [x] Caret is `pointer-events-none` so clicks reach the control
- [x] `multiple` renders native listbox and hides the caret
- [x] `placeholder` disabled option for single-select; suppressed for multiple
- [x] Color-only transition (150ms ease-out); no transform animation
- [x] Disabled removes interactivity and focus
- [x] `aria-invalid` reflects `error`; hint + error linked via `aria-describedby`
