# Select — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Select is the design system's single- and multiple-choice dropdown form field
(`form-item/*/select`, `form-item/*/select-multiple`). It renders a styled **native
`<select>`** — the most accessible dropdown — wrapped in the same label / hint / error
field pattern as Input. A caret Icon is overlaid on top of the appearance-stripped
control; in `multiple` mode the native listbox renders and the caret is hidden.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-white` | `#ffffff` | `background-color` (default) |
| `--color-neutral-100` | `#f8f9fa` | `background-color` (disabled) |
| `--color-neutral-300` | `#dee2e6` | `border-color` (default) |
| `--color-danger` | `#dc3545` | `border-color` + focus ring (error) + required mark + error text |
| `--color-primary` | `#0d6efd` | focus ring (default) |
| `--color-text-default` | `#212529` | `color` (label + selected value) |
| `--color-text-muted` | `#6c757d` | `color` (caret + hint) |
| `--font-family-base` | Roboto | `font-family` |
| `--font-size-body` | `16px` | `font-size` (control, label, hint, error) |
| `--font-weight-regular` | `400` | `font-weight` |
| `--radius-default` | `rounded` | `border-radius` |
| `--opacity-disabled` | — | `opacity` (disabled) |
| `--spacing-*` | 1 / 2 / 8 | `gap` (field), caret offset (`right-2`), caret room (`pr-8`) |

All references resolve to CSS variables via the Tailwind theme mapping in
`tailwind.config.js`. No hardcoded hex/px values.

---

### Variants

| Variant | Values | Description |
|---|---|---|
| single | (default) | Native single-select with an overlaid caret Icon; `pr-8` leaves caret room. Optional `placeholder` renders a disabled `value=""` first option. |
| multiple | `multiple` prop | Native multi-select listbox (taller); caret is hidden and caret padding removed. `placeholder` is not rendered. |

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | White bg, neutral-300 border, muted caret | — |
| `focus-visible` | 2px primary ring, offset (danger ring when error) | Keyboard/pointer focus |
| `error` | Danger border, danger focus ring, `aria-invalid`, danger error text below | `error` prop set |
| `disabled` | `opacity-disabled`, `not-allowed` cursor, neutral-100 bg | `disabled` attribute |

---

### Sizes

| Size | Padding | Font | Radius |
|---|---|---|---|
| `small` | `px-2 py-1` (8px / 4px) | body 16px | `rounded` |
| `medium` | `px-2.5 py-2` (10px / 8px) | body 16px | `rounded` |
| `large` | `px-3 py-2.5` (12px / 10px) | body 16px | `rounded` |

Single-select adds `pr-8` to leave room for the caret. Width fills the container (`w-full`).

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `options` | `SelectOption[]` | — | `{ value, label, disabled? }[]` rendered as `<option>`s (required) |
| `label` | `React.ReactNode` | — | Visible label associated via `htmlFor` |
| `hint` | `string` | — | Helper text below the control (hidden when `error` is set) |
| `error` | `string` | — | Error message; enables invalid styling + `aria-invalid` + `aria-describedby` |
| `placeholder` | `string` | — | Disabled `value=""` first option (single-select only) |
| `size` | `small \| medium \| large` | `medium` | Padding density |
| `multiple` | `boolean` | `false` | Native multi-select listbox; hides the caret |
| `required` | `boolean` | — | Native required + visible `*` mark on the label |
| `id` | `string` | `useId()` | Control id (label association + describedby); falls back to `React.useId()` |
| `className` | `string` | — | Layout overrides on the **outer wrapper**, merged last via `cn()` |
| native `<select>` attrs | — | — | `value`, `defaultValue`, `disabled`, `onChange`, `name`, ... spread onto the element |

Exports: `Select`, `SelectProps`, `SelectOption`.

---

### Accessibility

- Element: semantic native `<select>` — full keyboard and assistive-tech support out of the box.
- `label` is associated to the control via `htmlFor` / `id` (`id` falls back to `React.useId()`).
- The caret Icon is decorative: `aria-hidden` + `pointer-events-none` (never intercepts clicks).
- Error state sets `aria-invalid` and links the error text via `aria-describedby`; hint text is
  also linked via `aria-describedby`.
- `required` reflects to the native attribute and shows a visible `*` (the mark itself is `aria-hidden`).
- Visible focus indicator: `focus-visible:ring-2` (primary, danger when error) with offset.
- Disabled uses the native `disabled` attribute (removed from tab order).

---

### Do Not

- Do not hardcode colors, spacing, radius, or type values — reference tokens via the Tailwind theme.
- Do not use `style={{}}` or arbitrary `[..]` utilities.
- Do not replace the native `<select>` with a custom JS listbox — it sacrifices built-in accessibility.
- Do not show the caret Icon in `multiple` mode (the native listbox has no single trigger).
- Do not rely on `error` styling alone — the error string is rendered and linked via `aria-describedby`.
- Do not remove the focus ring.

---

### Implementation Tasks

- [x] Create `src/components/modules/select.variants.ts` (CVA `size`, `invalid`)
- [x] Create `src/components/modules/Select.tsx` (`forwardRef`, spreads props, `cn()` last on wrapper)
- [x] Render label / relative control container / hint / error field pattern
- [x] Styled native `<select>` with `appearance-none`, token border/bg/text, `w-full`
- [x] Implement `size` (small / medium / large) padding density
- [x] Implement `error` → danger border + danger focus ring + `aria-invalid` + linked error text
- [x] Render `options` as `<option>`s; optional `placeholder` → disabled `value=""` first option
- [x] `multiple` → native listbox, hide caret, drop caret padding
- [x] Overlay `caret-down-fill` Icon (`aria-hidden`, `pointer-events-none`, muted) for single-select
- [x] `id` via `React.useId()` fallback; `aria-describedby` merges hint + error + consumer value
- [x] Focus-visible ring (primary, danger when error) and disabled pattern
- [x] Export `SelectOption` type
