# Visual Verify Report — Select

- **Component:** `Select` (molecule) · **Design source:** `figma` (`ojko9pGfsDAvmUf2DA38d2`) · **Date:** 2026-07-07
- **Spec:** `specs/select/select-component-spec.md` + `select-interaction-spec.md`
- **Impl:** `src/components/modules/Select.tsx` + `select.variants.ts`

## Live-rendered? No — no Storybook story for Select.
Runtime pixel (375/768/1440) and axe are **not executable — verified from source**, NOT "failed".

## Checklist (source-verified)

### Variants — ✓
- single vs `multiple`: single-select adds `pr-8` + overlaid caret; `multiple` renders native listbox, hides caret, drops `pr-8` — matches spec.
- `size`: `px-2 py-1` / `px-2.5 py-2` / `px-3 py-2.5` — matches.
- `invalid`: `border-danger focus-visible:ring-danger` / `ring-primary`, auto from `error` — matches.
- `appearance-none` strips native chrome. `defaultVariants` medium / invalid:false.

### States — ✓
default (`border-neutral-300 bg-white`, muted caret), focus (`ring-2 ring-offset-2`), error (danger border/ring
+ `aria-invalid` + danger error text), disabled (`opacity-disabled bg-neutral-100 cursor-not-allowed`).
`transition-colors duration-150 ease-out`.

### Tokens — ✓
`bg-white`/`bg-neutral-100`, `border-neutral-300`/`border-1`, `rounded`, `text-text`/`text-danger`/`text-muted`,
`ring-primary`/`ring-danger`, spacing `gap-1`/`pr-8`/`right-2` (keys 1/8/2 mapped), `px/py` keys mapped,
type/opacity tokens. `top-1/2 -translate-y-1/2` are geometric 50% centering (not spacing tokens) — allowed.

### Token audit — ✓
Zero matches across `Select.tsx` + `select.variants.ts`.

### Accessibility (source) — ✓
Native `<select>` (full keyboard/AT); `<label htmlFor>` ↔ `id` (`useId` fallback); caret Icon `aria-hidden` +
`pointer-events-none`, hidden in `multiple`; `aria-invalid` from `error`; required `*` `aria-hidden`; visible focus
ring; consumer `aria-describedby` merged not clobbered.

## Discrepancies (with authoritative side + fix)

| # | Discrepancy | Authoritative | Fix applied |
|---|---|---|---|
| D1 | **Dangling `aria-describedby` idref**: `hintId` was gated on `hint` alone, but the hint `<p>` renders only when `hint && !error`. With both `hint` and `error` set, `aria-describedby` referenced a `…-hint` id whose node was not rendered. | Spec §Accessibility: hint "hidden when `error` is set" + linked via `aria-describedby` ⇒ idref must resolve. | **Fixed in `Select.tsx`**: `hintId = hint && !error ? \`${selectId}-hint\` : undefined;` so the id is only referenced when its node renders. `npx tsc --noEmit` exits 0. |

## Gate: **PASS** — D1 resolved inline; zero unresolved discrepancies. Runtime pixel/axe not executable (no story).
