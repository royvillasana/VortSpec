# Select — Page Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens

---

### Purpose

Documents how the Select molecule is composed within forms and screens. Select is a
self-contained field (label + native control + optional hint/error) — consumers drop it
into form layouts alongside Input, Textarea, Checkbox, and Radio to capture single or
multiple choices (country, category, tags, filters, settings).

---

### Component Inventory

| Component | Level | Role in composition |
|---|---|---|
| `Select` | Molecule | Labelled native `<select>` field with hint/error |
| `Icon` (`caret-down-fill`) | Atom | Decorative caret overlay (single-select only) |
| `<label>` | — | Rendered internally, associated via `htmlFor` |
| Hint / error text | — | Rendered internally, linked via `aria-describedby` |

Select composes the `Icon` atom; it needs no other design-system component.

---

### Usage Example

```tsx
import { Select, type SelectOption } from '@/components/modules/Select';

const countries: SelectOption[] = [
  { value: 'us', label: 'United States' },
  { value: 'ca', label: 'Canada' },
  { value: 'mx', label: 'Mexico' },
];

function ProfileForm() {
  return (
    <form className="flex flex-col gap-4">
      {/* Single-select with placeholder + hint */}
      <Select
        name="country"
        label="Country"
        placeholder="Select a country…"
        hint="Used for billing and tax."
        options={countries}
        required
      />

      {/* Single-select in an error state */}
      <Select
        name="plan"
        label="Plan"
        error="Please choose a plan."
        options={[
          { value: 'free', label: 'Free' },
          { value: 'pro', label: 'Pro' },
          { value: 'ent', label: 'Enterprise', disabled: true },
        ]}
      />

      {/* Multiple-select (native listbox, no caret) */}
      <Select
        name="tags"
        label="Tags"
        multiple
        options={[
          { value: 'design', label: 'Design' },
          { value: 'eng', label: 'Engineering' },
          { value: 'ops', label: 'Operations' },
        ]}
      />
    </form>
  );
}
```

---

### Responsive

- Select fills the width of its field container (`w-full`); the parent controls measure.
- Density (`size`) is chosen by context, not viewport — no size change across breakpoints.
- Multiple-select height is native (listbox rows); consumers may set a responsive height via
  `className` on the outer wrapper if needed.
- Stack fields with a vertical gap (e.g. `flex flex-col gap-4`) on the form container.

---

### Accessibility

- Every Select provides a `label` associated to the control via `htmlFor` / `id`.
- Error state: pass `error` — it sets `aria-invalid`, renders the message, and links it via
  `aria-describedby`; hint text is linked the same way.
- The caret is decorative (`aria-hidden`, `pointer-events-none`).
- Native `<select>` semantics announce role, value, and option count to assistive tech.
- Focus order follows DOM order; the focus ring is always visible.
- Keep label, control, and hint/error together within a `<form>` landmark for coherence.

---

### Implementation Tasks

- [x] Verify Select fills its field container (`w-full`)
- [x] Document single + multiple usage (placeholder, hint, error, disabled option)
- [x] Confirm internal `<label htmlFor>` association and `aria-describedby` wiring
- [x] Confirm density selection via `size` (not viewport-driven)
- [x] Confirm caret hidden in `multiple` mode
