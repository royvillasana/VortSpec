# Adversarial Review — Select

Date: 2026-07-07

## Verdict: PASS

The native-`<select>` approach, caret overlay, `multiple` handling, `size`/`invalid` variants, and token purity
are all correct. The one **Major** a11y defect — a dangling `aria-describedby` idref when both `hint` and `error`
are set — was **found and FIXED inline during this review**.

## Findings

| Severity | Area | Issue | Status |
|---|---|---|---|
| Major | A11y (dangling idref) | `hintId` was computed as `hint ? … : undefined` and always added to `aria-describedby` when `hint` was truthy, but the hint `<p id={hintId}>` renders only when `hint && !error`. With both props set, `aria-describedby` referenced a `…-hint` node that was never rendered → dangling idref, a real screen-reader defect. | **RESOLVED (fixed inline)** |
| Minor | Cleanup | `select.variants.ts` base lists both `border` and `border-1` (both → `--stroke-width-1`). Redundant, harmless. | Open (cosmetic) |

**Failure scenario (pre-fix):** `<Select hint="Pick one" error="Required" options={…} />` → `<select>` got
`aria-describedby="…-error …-hint"` while only the error `<p>` rendered.

**Fix applied:** `const hintId = hint && !error ? \`${selectId}-hint\` : undefined;` — the id is now only
referenced when its node renders. Error-only, hint-only, and hint+error combinations all resolve correctly.

## Architecture Validation (8 checks)
1. ✓ `.variants.ts` colocated. 2. ✓ CVA mirrors spec (`size`/`invalid`). 3. ✓ `defaultVariants` match spec.
4. ✓ `forwardRef<HTMLSelectElement>`. 5. ✓ `...props` spread on `<select>`. 6. ✓ `className` merged LAST via `cn()`.
7. ✓ `VariantProps` exported (`SelectVariants`). 8. ✓ No inline `style={{}}`.

## Token/Variant/State/A11y checklist
- Token audit: ✓ zero hex/rgb/hsl/px/arbitrary/inline-style.
- Variants: ✓ single/multiple + size + invalid. States: ✓ default/focus/error/disabled.
- A11y: ✓ label association, aria-invalid, decorative caret aria-hidden, aria-hidden asterisk, visible focus ring,
  and (post-fix) **non-dangling aria-describedby** in all prop combinations.

## Resolved During Review
- Fixed dangling `aria-describedby` hint idref in `Select.tsx` (see Findings). `npx tsc --noEmit` exits 0.

## Notes
Runtime pixel diff and axe **not executed** (no story). The dangling-idref is a structural (source-level) defect,
fully assertable and fixable without a runtime harness. Verified from source (spec ↔ code ↔ token model).
