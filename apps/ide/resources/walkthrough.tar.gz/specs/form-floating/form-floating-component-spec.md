# FormFloating — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

A floating-label form field (molecule). The label sits centered over the control
when the field is empty and unfocused, then shrinks and floats up to the top edge
when the control is focused or filled. The motion is driven entirely by CSS using
the Tailwind `peer` + `peer-placeholder-shown` + `peer-focus` technique — there is
**no JavaScript state**. It renders one of three controls (`input`, `textarea`,
`select`), keeps the label programmatically associated via `htmlFor`/`id`, and
supports an inline error state.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--primitive-neutral-white` | `#ffffff` | `background-color` (control) |
| `--color-neutral-300` | `#dee2e6` | `border-color` (default control) |
| `--color-neutral-100` | — | `background-color` (disabled control) |
| `--color-text-default` | `#212529` | `color` (control text) |
| `--color-text-muted` | — | `color` (resting / floated label) |
| `--theme-primary` | `#087990` | `color` (focused label) / `ring-color` (focus) |
| `--color-status-danger` | — | `border-color` + `ring-color` + label/message `color` (error) |
| `--spacing-12` | `12px` | `padding-x` (`px-3`) / label `left` (`left-3`) |
| `--spacing-20` | `20px` | `padding-top` (`pt-5`) — room for the floated label |
| `--spacing-4` | `4px` | `padding-bottom` (`pb-1`) / floated label `top` (`top-1`) |
| `--spacing-16` | `16px` | resting label `top` (`top-4`) |
| `--radius-8` | `8px` | `border-radius` (`rounded`) |
| `--stroke-width-1` | `1px` | `border-width` (`border-1`) |
| `--opacity-disabled` | `0.65` | `opacity` (disabled) |
| `--font-family-base` | Roboto | `font-family` (`font-base`) |
| `--font-size-body` | `16px` | `font-size` (`text-body`, control + label) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js`.
No hardcoded hex, px, rem, or arbitrary `[..]` values.

---

### Variants

Rendered control is selected by the `as` prop:

| Variant | `as` | Control | Label behaviour |
|---|---|---|---|
| Input (default) | `input` | `<input>` | Floats up on focus **or** when filled (`peer-placeholder-shown`) |
| Textarea | `textarea` | `<textarea>` | Same peer technique as input |
| Select | `select` | `<select>` + `<option>`s | Label stays floated (selects don't expose `:placeholder-shown` reliably) |

Because the visual variation is state-driven, the CVA has a single `error`
(boolean) variant that swaps border + focus ring color.

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `empty` | Label centered (`top-4`), neutral-300 border, muted label | Default, control empty (`peer-placeholder-shown`) |
| `floated / focus` | Label at `top-1`, primary color, primary focus ring | Control focused (`peer-focus`) |
| `filled` | Label stays at `top-1`, muted color | Control has a value (placeholder no longer shown) |
| `error` | Border + ring danger, label + message in danger | `error` prop set |
| `disabled` | `--opacity-disabled` (0.65), `not-allowed` cursor, neutral-100 fill | `disabled` prop (`:disabled`) |

The single-space `placeholder=" "` on the control is **required** so that
`:placeholder-shown` correctly distinguishes empty vs. filled.

---

### Sizes

FormFloating ships a single size. Vertical rhythm is fixed by the padding tokens
(`pt-5` / `pb-1` / `px-3`) that reserve space for the floated label. Layout width
is `w-full`; consumers control outer width via `className` on the wrapper.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `label` | `React.ReactNode` | — (required) | The floating label; associated via `htmlFor`/`id` |
| `as` | `'input' \| 'textarea' \| 'select'` | `'input'` | Which control to render |
| `options` | `{ value: string; label: string }[]` | — | Options for `as="select"` |
| `error` | `string` | — | Error message; sets `aria-invalid` + `aria-describedby` and danger styling |
| `id` | `string` | `React.useId()` | Control id; falls back to a generated id |
| `className` | `string` | — | Layout overrides only, merged last on the wrapper `<div>` |
| `...props` | `InputHTMLAttributes` | — | Native attributes spread onto the control (`name`, `value`, `onChange`, `disabled`, …) |

`ref` forwards to the underlying control (typed `HTMLInputElement`; cast internally
for `textarea` / `select`).

---

### Accessibility

- The `<label>` is always programmatically associated with the control via
  `htmlFor`/`id` — **never a placeholder-only label**. The single-space placeholder
  exists purely to drive the CSS float and carries no accessible name.
- `id` falls back to `React.useId()` so association is guaranteed without consumer wiring.
- Error text is rendered in a `<p id="{id}-error">`, linked via `aria-describedby`,
  with `aria-invalid` on the control.
- Focus is always visible via `focus-visible:ring-2` — never removed.
- The label carries `pointer-events-none` so it never intercepts clicks; clicking
  the label still focuses the control through `htmlFor`.

---

### Do Not

- Do not hardcode colors, spacing, or radius — reference tokens via the Tailwind theme.
- Do not drop the `placeholder=" "` (single space) — `:placeholder-shown` breaks without it.
- Do not use the placeholder as the accessible label — always render the `<label>`.
- Do not add JS state to move the label; the motion is pure CSS `peer-*`.
- Do not remove the focus ring.

---

### Implementation Tasks

- [x] Create `src/components/modules/form-floating.variants.ts` (CVA base control classes + `error` variant)
- [x] Create `src/components/modules/FormFloating.tsx` (`forwardRef`, spreads props, `cn()` last on the wrapper)
- [x] Render control with `peer` + `placeholder=" "` and top padding for the floated label
- [x] Sibling `<label>` floats via `peer-placeholder-shown` / `peer-focus` (no JS)
- [x] Support `as="input" | "textarea" | "select"`; render `options` for select (label stays floated)
- [x] Associate label via `htmlFor`/`id` with `React.useId()` fallback
- [x] Error state: `border-danger`, `aria-invalid`, `aria-describedby` + message
- [x] Verify with `tsc` (no type errors)
