# FormFloating — Usage / Composition Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./form-floating-component-spec.md

FormFloating is a molecule; this documents how it composes into forms and screens.

---

### Purpose

Provide a compact, space-efficient labelled field where the label doubles as a
placeholder-style hint until the user engages, then floats up to a persistent
label. Useful for dense forms, sign-in / sign-up, and settings where a permanent
label row above every field would waste vertical space.

---

### Component Inventory

| Component | Role |
|---|---|
| `FormFloating` (molecule) | Wrapper + control (`input` / `textarea` / `select`) + floating `<label>` + optional error message |

Composed from native form controls plus a token-driven CVA; no other design-system
component is required.

---

### Consumed By

| Consumer | Usage |
|---|---|
| Auth forms | Email / password fields with floating labels |
| Settings screens | Profile fields (name, bio via `textarea`, country via `select`) |
| Modals / drawers | Compact edit forms where vertical space is tight |

---

### Usage Example

```tsx
import { FormFloating } from '@/components/modules/FormFloating';

// Basic input
<FormFloating label="Email address" type="email" name="email" />

// Prefilled (label starts floated)
<FormFloating label="Full name" defaultValue="Ada Lovelace" name="name" />

// Textarea
<FormFloating as="textarea" label="Bio" name="bio" rows={4} />

// Select
<FormFloating
  as="select"
  label="Country"
  name="country"
  options={[
    { value: 'us', label: 'United States' },
    { value: 'mx', label: 'Mexico' },
    { value: 'ca', label: 'Canada' },
  ]}
/>

// Error state
<FormFloating
  label="Email address"
  type="email"
  value={email}
  onChange={(e) => setEmail(e.target.value)}
  error="Enter a valid email address"
/>

// Disabled
<FormFloating label="Account ID" defaultValue="ACME-001" disabled />

// Layout width via className on the wrapper
<FormFloating label="Search" className="max-w-md" />
```

---

### Composition Rules

- Pass the label text through the required `label` prop — never hand-wire a separate `<label>`.
- FormFloating owns its internal padding and label motion; consumers pass only layout
  (width, margins) via `className` on the wrapper.
- Stack multiple fields in a `<form>` / `<fieldset>`; field-to-field spacing is the consumer's responsibility.
- For `as="select"`, always provide `options`; the label stays floated so the current value is visible.

---

### Responsive

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Control is `w-full` and adapts to its container; set width via wrapper `className`. Padding tokens keep the floated label clear at every size. |

---

### Accessibility

- Every field has a programmatically associated `<label>` (via `htmlFor`/`id`), independent of the placeholder.
- Error messages are linked with `aria-describedby` and the control is marked `aria-invalid`.
- Focus is always visible; keyboard users `Tab` between fields.
- Group related fields in a `<fieldset>` + `<legend>` for a group name.

---

### Implementation Tasks

- [x] Verify input / textarea / select all float the label correctly
- [x] Verify prefilled values start with the label floated
- [x] Verify error state shows danger border + message and links `aria-describedby`
- [x] Verify disabled state is non-interactive and dimmed
- [x] Verify wrapper `className` controls layout width without breaking the float
