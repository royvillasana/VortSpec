# FormFloating — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./form-floating-component-spec.md
**Figma prototype**: Forms page — Floating-label field (empty / focus / filled / error / disabled)

---

### Interaction Overview

The user focuses the field and types. The label animates from its resting position
(centered over the control) up to the top edge, shrinking as it goes, and turns the
primary color while focused. When the user leaves a filled field, the label stays
up; when they leave an empty field, it drops back down. All motion is CSS — the
label is a sibling of the `peer` control and responds to `:focus` and
`:placeholder-shown` with no JavaScript.

---

### Trigger

| Trigger | Element | Result |
|---|---|---|
| Focus (`Tab` / click) | control | `peer-focus` → label floats up (`top-1`) + turns primary; focus ring appears |
| Typing (value present) | control | `:placeholder-shown` false → label stays up even after blur |
| Blur while empty | control | `:placeholder-shown` true → label drops back to `top-4`, muted |
| Blur while filled | control | Label remains floated at `top-1`, muted |

---

### Flow

```
Step 1: Field empty + unfocused → label centered over the control (top-4), muted.
Step 2: User focuses (Tab or click) → label transitions up to top-1 and to
        --theme-primary; primary focus ring appears (transition-all / transition-colors).
Step 3: User types → placeholder (single space) hidden; label is now anchored up
        because :placeholder-shown is false.
Step 4: User blurs → ring clears; label stays up (muted) because the field is filled.
Step 5: User clears the field and blurs → :placeholder-shown true again → label
        animates back down to the resting position.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Label position + size | default (`transition-all`) | default ease | `transition-all` on the label |
| Control border / ring | default (`transition-colors`) | default ease | `transition-colors` on the control |

Motion uses Tailwind's default transition timing; token-purity and a smooth,
consistent transition matter more than exact millisecond parity with Figma.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| Prefilled `value` / `defaultValue` | Placeholder not shown → label starts floated (up), muted |
| `as="select"` | No reliable `:placeholder-shown`; label stays floated at all times, turns primary on focus |
| `as="textarea"` | Same peer technique as input; extra top padding keeps the floated label clear of text |
| `error` set while focused | Border + ring danger; label danger (focus still shows primary via `peer-focus`) |
| `disabled` | `not-allowed` cursor, 0.65 opacity, neutral-100 fill; not focusable, no float |
| Empty label click | `pointer-events-none` on label → click passes through and focuses the control via `htmlFor` |

---

### Accessibility & Keyboard

- `Tab` / `Shift+Tab` — move focus to / from the control; the focus ring is always visible.
- The `<label>` is associated via `htmlFor`/`id`, so screen readers announce the field name.
- Error message is linked with `aria-describedby`; `aria-invalid` marks the control.
- The label never relies on the placeholder for its accessible name.
- Native keyboard behaviour of each control (`input` / `textarea` / `select`) is preserved.

---

### Implementation Tasks

- [x] Label float driven purely by `peer-placeholder-shown` / `peer-focus` (no JS)
- [x] `transition-all` on label + `transition-colors` on control for smooth motion
- [x] Prefilled value starts with label floated (placeholder-shown false)
- [x] Select keeps label floated; focus turns it primary
- [x] Textarea uses the same technique with top padding for the floated label
- [x] Disabled blocks interaction with `not-allowed` cursor + reduced opacity
