# Visual Verify Report — FormFloating

- **Design source:** `figma` (Branch A) · **Component:** `FormFloating` (molecule) · **Date:** 2026-07-07
- **Spec:** `specs/form-floating/form-floating-component-spec.md` + `form-floating-interaction-spec.md` · **Impl:** `src/components/modules/FormFloating.tsx` + `form-floating.variants.ts`
- See `specs/visual-verify-report.md` for shared context and the runtime-check environment limitation.

## Result: PASS (source-of-truth) — 0 open source-level discrepancies

Every spec task is checked (8 component + interaction). The `as` variant (input/textarea/select), the
single `error` boolean variant, the `empty/floated/filled/error/disabled` states driven purely by CSS
`peer-placeholder-shown` / `peer-focus` (no JS), and the always-rendered associated `<label>` all match
spec. Every utility resolves to a design token. Runtime dimensions remain **open** (see below).

## ⚠️ Runtime dimensions NOT executed (environment limit)

No browser driver (Playwright/Puppeteer NOT installed); Vite dev server :5173 is DOWN. **Live-viewport
pixel comparison (375/768/1440px)** and **runtime axe** CANNOT be executed and are NOT asserted — the label
float animation in particular is a runtime-only visual that source review cannot pixel-confirm. Below is
**source-of-truth verification**, authoritative for token/variant/state/semantic-ARIA. To close: install a
browser driver + render harness/Storybook, screenshot each viewport vs the Figma frame, run axe-core.

## Checklist (source-verified)

### Variants ✓
| Axis | Values | Impl | OK |
|---|---|---|---|
| `as` | input / textarea / select | branches render `<input>` / `<textarea>` / `<select>`+options (`:55-74`) | ✓ |
| `error` | true / false | `border-danger focus-visible:ring-danger` / `border-neutral-300 focus-visible:ring-primary` (`variants:25-28`) | ✓ |
Select branch keeps the label floated (`peer-focus:text-primary` only) since `:placeholder-shown` is unreliable for `<select>` (`:45-51`). ✓

### States ✓
`empty` (label at `top-4`, muted — `peer-placeholder-shown:top-4`), `floated/focus` (label `top-1`, primary
— `peer-focus:top-1 peer-focus:text-primary`), `filled` (label stays `top-1`), `error` (danger border/ring +
danger label + danger message), `disabled` (`opacity-disabled bg-neutral-100 cursor-not-allowed`). The
required `placeholder=" "` single space present on input/textarea (`:59,73`). ✓

### Tokens — utility → token ✓
| Utility | → token | OK |
|---|---|---|
| `bg-white` / `disabled:bg-neutral-100` | `--primitive-neutral-white` / `--color-neutral-100` | ✓ |
| `border-neutral-300` / `border` / `border-1` | `--color-neutral-300` / `--stroke-width-1` | ✓ |
| `rounded` | `--radius-8` | ✓ |
| `text-text` / `text-danger` | `--color-text-default` / `--color-status-danger` | ✓ |
| `text-muted` (resting/floated label) | `--color-text-muted` (alias `tailwind.config.js:50`) | ✓ |
| `text-primary` (focused label) / `ring-primary` / `ring-danger` | `--theme-primary` / `--color-status-danger` | ✓ |
| `px-3` / `left-3` | `--spacing-12` | ✓ |
| `pt-5` / `pb-1` / `top-1` / `top-4` / `mt-1` | `--spacing-20` / `--spacing-4` / `--spacing-4` / `--spacing-16` / `--spacing-4` | ✓ |
| `text-body` / `font-base` / `font-regular` / `opacity-disabled` | type/opacity tokens | ✓ |

Label `text-muted` resolves via the `muted` alias (systemic fix 2026-07-07). Token dimension **PASS**.

### Accessibility ✓
`<label htmlFor>` always rendered and associated to the control via `id` (`useId` fallback `:27-28`) — never
a placeholder-only label; the `placeholder=" "` carries no accessible name. `aria-invalid` + `aria-describedby`
→ error `<p id="{id}-error">` when `error` set (`:37-38,78-82`). Label `pointer-events-none` (`:43`). Focus
ring never removed. ✓

### Token audit (static, zero tolerance) ✓
Grep → **0 hits**. Sizing keys used: `1,3,4,5` (all mapped). No custom panel.

## Observations (non-blocking)
- **O-A — single size only (by design).** Spec states FormFloating ships one size; padding tokens (`pt-5`/`pb-1`/`px-3`) reserve the float room. No size axis expected — correct, not a gap.

## Gate
**Token · variant · state · semantic/ARIA dimensions: PASSED** — 0 open source-level discrepancies.
**Runtime dimensions (live-viewport pixel + axe): still not executable** in this environment.
