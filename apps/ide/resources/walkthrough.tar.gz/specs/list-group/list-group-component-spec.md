# ListGroup — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

A bordered vertical list that groups related rows into a single surface — used for
menus, navigation lists, settings rows, and selectable option lists. Each row can be
a static entry or an interactive action (link/button), carry a leading icon and a
trailing badge, and reflect `active` (current/selected) or `disabled` states.

---

### Composed Atoms

| Atom | Role |
|---|---|
| `Icon` (optional) | Consumer-supplied leading `icon` node; inherits the row foreground color |
| `Tag` (optional) | Common choice for the trailing `badge` slot (counts, status) |
| Inline text | The row `label` |

Icon and badge are passed by the consumer as nodes; `ListGroup` only owns layout and state.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--primitive-neutral-white` | `#ffffff` | `background-color` (container surface, `bg-white`) |
| `--color-neutral-300` | `#dee2e6` | `border-color` / `divide-color` (`border-neutral-300`, `divide-neutral-300`) |
| `--color-neutral-100` | `#f8f9fa` | `background-color` (action row hover, `hover:bg-neutral-100`) |
| `--theme-primary` | — | `background-color` (active row, `bg-primary`) + focus ring |
| `--primitive-neutral-white` | `#ffffff` | `color` (active row foreground, `text-white`) |
| `--color-text-default` | `#212529` | `color` (default row foreground, `text-text`) |
| `--stroke-width-1` | `1px` | `border-width` / `divider-width` (`border-1`, `divide-y`) |
| `--radius-8` | `8px` | `border-radius` (`rounded`) |
| `--spacing-12` | `13px` | horizontal padding (`px-3`) |
| `--spacing-8` | `8px` | vertical padding + row gap (`py-2`, `gap-2`) |
| `--opacity-disabled` | — | `opacity` (disabled row, `opacity-disabled`) |
| `--font-family-base` | — | `font-family` (`font-base`) |
| `--font-size-body` / `--line-height-body` | — | `font-size` / `line-height` (`text-body`, `leading-body`) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js` to these
CSS variables. No hardcoded values, no arbitrary utilities, no inline styles.

---

### Variants

Row type is inferred per item, not a prop enum.

| Variant | Trigger | Rendering |
|---|---|---|
| `static` | no `href` / `onClick` | `<div>` row — non-interactive, not focusable |
| `action` | `href` or `onClick` present (and not disabled) | `<a>` / `<button type="button">` — full width, left-aligned, hover surface, focus ring |

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | `text-text` on `bg-white` surface | — |
| `hover` | `bg-neutral-100` surface | pointer over an action row (not active) |
| `active` | `bg-primary text-white`; icon/badge inherit white | item `active: true` |
| `focus` | inset `ring-2 ring-primary` (keyboard) | action row focused via keyboard |
| `disabled` | `opacity-disabled`, `pointer-events-none`, `aria-disabled` | item `disabled: true` |

Active rows do not show the hover surface (compound-variant rule). A disabled action row
degrades to a non-interactive element.

---

### Sizes

Single intrinsic size. Row padding (`px-3 py-2`), gap (`gap-2`), container radius
(`rounded`), and border (`border-1`) are fixed by token. The list grows with its content
and fills its container width.

---

### Props / API

**`ListGroupProps extends React.HTMLAttributes<HTMLUListElement>`**

| Prop | Type | Default | Description |
|---|---|---|---|
| `items` | `ListGroupItem[]` | — | The rows to render, top to bottom |
| `className` | `string` | — | Layout overrides only, merged last via `cn()` |
| `...props` | `HTMLAttributes<HTMLUListElement>` | — | Native `<ul>` attributes spread; `ref` forwarded to the `<ul>` |

**`ListGroupItem`**

| Field | Type | Default | Description |
|---|---|---|---|
| `label` | `ReactNode` | — | Row content |
| `icon` | `ReactNode` | — | Optional leading icon node |
| `badge` | `ReactNode` | — | Optional trailing node, pushed right with `ml-auto` |
| `active` | `boolean` | `false` | Selected/current row |
| `disabled` | `boolean` | `false` | Dimmed + non-interactive |
| `href` | `string` | — | Renders the row as `<a>` |
| `onClick` | `() => void` | — | Renders the row as `<button>` |

---

### Accessibility

- Action rows are real `<a>` / `<button type="button">` elements — natively focusable,
  keyboard-operable, with a visible inset focus ring (`focus-visible:ring-2 ring-primary`).
- `active` rows expose `aria-current` so assistive tech announces the current selection.
- `disabled` rows set `aria-disabled` and block pointer interaction (`pointer-events-none`);
  disabled action rows degrade to a non-interactive element rather than a focusable control.
- State is never conveyed by color alone — active/disabled carry ARIA semantics.
- Rows are list items (`<li>`) within a single `<ul>` for correct list semantics.

---

### Do Not

- Do not hardcode colors, spacing, radius, or stroke — reference tokens via the Tailwind theme.
- Do not use inline `style={{}}` or arbitrary `[...]` utilities for design-system values.
- Do not make a disabled row focusable or clickable.
- Do not rely on the active background color alone — keep `aria-current` for selection.

---

### Implementation Tasks

- [x] Create `src/components/modules/list-group.variants.ts` (CVA `listGroupItemVariants` with `interactive` / `active` / `disabled` axes + hover compound variant)
- [x] Create `src/components/modules/ListGroup.tsx` (`forwardRef<HTMLUListElement>`, spreads props, `cn()` last)
- [x] Export `ListGroupItem` and `ListGroupProps` types
- [x] Render static rows as `<div>` and action rows as `<a>` / `<button>`
- [x] Implement `active` (`bg-primary text-white` + `aria-current`) and `disabled` (`opacity-disabled`, `pointer-events-none`, `aria-disabled`)
- [x] Wire leading `icon` slot and trailing `badge` slot (`ml-auto`)
- [x] Apply container border/divider/radius on the `<ul>` with token utilities
- [x] Verify token-only styling and `tsc` clean
