# ListGroup — Usage / Composition Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./list-group-component-spec.md

Molecules have no page of their own; this documents how ListGroup composes into
higher-order components and screens.

---

### Purpose

Provide a single bordered surface for a set of related rows — navigation lists, menus,
settings, and selectable option lists — with consistent spacing, dividers, and state
handling (active/disabled/action).

---

### Component Inventory

| Component | Role |
|---|---|
| `ListGroup` | Container `<ul>` + row renderer (this molecule) |
| `Icon` (atom) | Optional leading glyph per row |
| `Tag` (atom) | Common trailing `badge` (counts, status labels) |

---

### Usage Example

```tsx
import { ListGroup, type ListGroupItem } from '@/components';
import { Icon } from '@/components/ui/Icon';
import { Tag } from '@/components/ui/Tag';

const items: ListGroupItem[] = [
  {
    label: 'Inbox',
    icon: <Icon name="info" size="small" aria-hidden />,
    badge: <Tag variant="primary" size="small">12</Tag>,
    active: true,
    href: '#inbox',
  },
  { label: 'Starred', icon: <Icon name="star" size="small" aria-hidden />, href: '#starred' },
  { label: 'Drafts', onClick: () => save() },
  { label: 'Archive (disabled)', disabled: true, href: '#archive' },
  { label: 'Read-only note' }, // static row
];

<ListGroup items={items} aria-label="Mailboxes" className="max-w-sm" />
```

- The active row shows `bg-primary text-white` with `aria-current`; its icon and badge
  inherit white.
- Layout (max width, margins, block placement) is applied via `className`; the list owns
  its internal padding, gaps, border, and dividers.

---

### Consumed By

| Consumer | Usage |
|---|---|
| Sidebars / nav panels | Vertical navigation with active-route highlighting |
| Settings screens | Grouped setting rows with trailing status badges |
| Menus / pickers | Selectable option lists |

---

### Composition Rules

- Choose row type by behavior: give a row `href`/`onClick` only when it should act.
- Use `active` for the current selection/route, paired with `aria-current` (built in).
- Keep the trailing `badge` short (count or one-word status); prefer `<Tag>`.
- Do not nest a `ListGroup` inside a row; keep lists flat.

---

### Responsive

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | List fills its container width; padding, gap, radius, and dividers are fixed by token. Labels reflow/wrap as width changes; badges stay right-aligned. |

---

### Accessibility

- Rows are `<li>` within one `<ul>`; provide an `aria-label` on the `<ul>` when the list
  is a navigation region.
- Action rows are keyboard-focusable with a visible ring; disabled rows are out of the
  tab order and marked `aria-disabled`.
- Selection is announced via `aria-current`, never by color alone.

---

### Implementation Tasks

- [x] Verify a mixed list (static + link + button + disabled) renders correct semantics
- [x] Verify active row shows `bg-primary`/`text-white` with `aria-current`
- [x] Verify leading icon + trailing badge (`<Tag>`) layout on one baseline
- [x] Verify keyboard focus ring and tab order (disabled rows skipped)
- [x] Verify token-only styling and container border/divider/radius
