# ListGroup — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./list-group-component-spec.md
**Figma prototype**: List Group page — active / disabled / action row states

---

### Interaction Overview

`ListGroup` renders a bordered vertical list of rows. Static rows are presentational;
action rows (those with `href` or `onClick`) are native `<a>` / `<button>` controls that
respond to hover, focus, and activation. A list can freely mix static and action rows.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Pointer hover | action row | Row has `href`/`onClick`, not `active`, not `disabled` → `bg-neutral-100` |
| Click / tap | action row | Fires `onClick`, or follows `href` |
| Keyboard focus | action row | `Tab` moves focus; visible inset `ring-primary` shown |
| `Enter` / `Space` | action `<button>` | Activates the row (`Space` also for `<a>` scroll defaults) |
| `Enter` | action `<a>` | Follows the link |

Static and disabled rows expose no interactions.

---

### Flow

```
Step 1: Component mounts → <ul> renders each item as an <li>.
Step 2: Per item → resolve isAction (href|onClick), active, disabled.
Step 3: Action + not disabled → render <a>/<button> (interactive variant, focus ring).
        Otherwise → render <div> (static). Disabled action degrades to <div>.
Step 4: active → bg-primary text-white + aria-current="true"; icon/badge inherit white.
Step 5: disabled → opacity-disabled + pointer-events-none + aria-disabled.
Step 6: User hovers an idle action row → bg-neutral-100.
Step 7: User Tabs to an action row → inset primary ring; Enter/Space activates it.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Hover surface | instant | — | `hover:bg-neutral-100` (no explicit transition) |
| Focus ring | instant | — | `focus-visible:ring-2` |

No timed animations are introduced.

---

### Animation Details

None. State changes are immediate token swaps (background / ring / opacity).

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| Mixed static + action rows | Each row resolves independently; only action rows are focusable |
| Row with `badge` | Badge (e.g. `<Tag>`) is pushed right via `ml-auto`; inherits white when active |
| Row with `icon` and `badge` | Icon leads, label center, badge trails on one baseline (`items-center`) |
| `active` action row | Keeps `bg-primary` (no hover surface); `aria-current="true"` set |
| `disabled` action row | Rendered as non-interactive `<div>`, `aria-disabled`, not focusable |
| Both `href` and `onClick` | `href` wins → renders `<a>` (native navigation) |
| Long label | Wraps within the row; padding/gap preserved, badge stays right |
| Empty `items` | Renders an empty bordered `<ul>` |

---

### Accessibility & Keyboard

| Key | Action |
|---|---|
| `Tab` | Move focus to the next action row |
| `Shift + Tab` | Move focus to the previous action row |
| `Enter` | Activate focused row (`onClick`) / follow link |
| `Space` | Activate focused `<button>` row |

- Focus is visible via an inset `ring-2 ring-primary` on action rows.
- `aria-current` marks the active row; `aria-disabled` marks disabled rows.
- Disabled rows are removed from the tab order (non-interactive element).

---

### Implementation Tasks

- [x] Resolve row type per item (`isAction = href || onClick`)
- [x] Render action rows as `<a>` / `<button>` with hover + inset focus ring
- [x] Suppress hover surface on `active` rows (compound variant)
- [x] Set `aria-current` on active rows and `aria-disabled` on disabled rows
- [x] Degrade disabled action rows to a non-interactive element (out of tab order)
- [x] Confirm no timed animations/transitions are introduced
