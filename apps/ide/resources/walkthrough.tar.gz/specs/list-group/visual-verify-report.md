# Visual Verify Report — ListGroup

- **Design source:** `figma` (Branch A) · **Component:** `ListGroup` (molecule) · **Date:** 2026-07-07
- **Spec:** `specs/list-group/list-group-component-spec.md` + `list-group-interaction-spec.md` ·
  **Impl:** `src/components/modules/ListGroup.tsx` + `list-group.variants.ts`
- See `specs/visual-verify-report.md` for shared context and the runtime-check environment limitation.

## Result: PASS (source-of-truth) — 0 open source-level discrepancies

Every spec task is checked. Row variants (static / action), all five states, the active-suppresses-hover
compound rule, list semantics, ARIA wiring, and architecture all verify against the spec + token map.
Every color / spacing / radius / border / type utility resolves to a token via `tailwind.config.js`.
No hardcoded values and — notably — **no `text-muted` dead-class defect** (this component uses
`text-text` / `text-white`, both of which compile correctly).

---

## ⚠️ Runtime dimensions NOT executed (environment limit)

This environment has NO browser driver (Playwright/Puppeteer NOT installed) and no render harness for
these components, so the Figma-flow **live-viewport pixel comparison (375/768/1440px)** and **runtime
axe audit** CANNOT be executed and are NOT asserted. Everything here is a **source-of-truth
verification** (spec ↔ code ↔ token model), authoritative for token/variant/state-wiring/ARIA
dimensions. To close runtime dims: install a browser driver + Storybook/harness, screenshot each
viewport vs the Figma frame, run axe-core.

---

## Checklist (source-verified)

### Variants ✓
| Variant | Trigger | Rendering | OK |
|---|---|---|---|
| static | no `href`/`onClick` (or disabled) | `<div>` — non-interactive, not focusable | ✓ |
| action | `href` or `onClick`, not disabled | `<a>` (href wins) / `<button type="button">` — full width, focus ring | ✓ |

`isAction = href || onClick`; a **disabled action row degrades to a non-interactive `<div>`** (out of
tab order) exactly per spec ✓. Leading `icon` slot and trailing `badge` slot (`ml-auto`) wired ✓.

### States ✓
| State | Wiring | OK |
|---|---|---|
| default | `text-text` on `bg-white` | ✓ |
| hover | `hover:bg-neutral-100` via compound variant (interactive && !active) | ✓ |
| active | `bg-primary text-white` (+ `aria-current="true"`); icon/badge inherit white | ✓ |
| focus | `focus-visible:ring-2 ring-primary ring-inset` (inset ring) | ✓ |
| disabled | `opacity-disabled pointer-events-none` + `aria-disabled` | ✓ |

Active rows correctly do **not** show the hover surface — the compound variant only adds
`hover:bg-neutral-100` when `interactive && !active` ✓.

### Tokens ✓
| Utility | → token | OK |
|---|---|---|
| `bg-white` | `--primitive-neutral-white` | ✓ |
| `border` / `border-1` | `--stroke-width-1` (1px, allowed) | ✓ |
| `border-neutral-300` / `divide-neutral-300` | `--color-neutral-300` | ✓ |
| `divide-y` | `--stroke-width-1` (borderWidth DEFAULT, 1px) | ✓ |
| `hover:bg-neutral-100` | `--color-neutral-100` | ✓ |
| `bg-primary` (active) | `--theme-primary` | ✓ |
| `text-white` (active fg) | `--primitive-neutral-white` | ✓ |
| `text-text` (default fg) | `--color-text-default` | ✓ |
| `ring-primary` | `--theme-primary` | ✓ |
| `rounded` | `--radius-8` | ✓ |
| `px-3` | `--spacing-12` (12px) | ✓ |
| `py-2` / `gap-2` | `--spacing-8` (8px) | ✓ |
| `text-body` / `leading-body` / `font-base` | body size / line-height / family tokens | ✓ |
| `opacity-disabled` | `--opacity-disabled` | ✓ |

`ring-2` is a fixed 2px focus-indicator width (Tailwind default, not spacing) — allowed like
outline-width. `ring-inset`, `overflow-hidden`, `flex`, `items-center`, `w-full`, `text-left`,
`min-w-0`, `ml-auto`, `inline-flex`, `shrink-0` are structural — no token dimension.

### Accessibility ✓
- Rows are `<li>` within a single `<ul>` — correct list semantics ✓.
- Action rows are real `<a>` / `<button type="button">` — natively focusable/keyboard-operable, with a
  visible inset `focus-visible:ring-2 ring-primary` ✓.
- `active` rows expose `aria-current="true"` (selection not by color alone) ✓.
- `disabled` rows set `aria-disabled` and block interaction (`pointer-events-none`); disabled action
  rows degrade to a non-interactive `<div>` (removed from tab order) ✓.

### Architecture ✓
CVA in `list-group.variants.ts` (with `compoundVariants` for the hover rule) ✓ · `cn()` used, consumer
`className` merged **last**, native `<ul>` props spread ✓ · `forwardRef<HTMLUListElement>` ✓ ·
`ListGroupItem` / `ListGroupProps` types exported ✓ · no inline `style={{}}` ✓.

### Token audit (hardcode, zero-tolerance) ✓
Zero hardcoded hex / `rgb()` / `hsl()` / arbitrary `[..]`; zero inline `style={{}}`; only literal px is
the `1px` border/divider (allowed). Every color/spacing/radius/type utility resolves to a `var(--…)`.
**Clean.**

---

## Observations (non-blocking)
- **O-A — active `<div>` static rows.** A static (non-action) row marked `active` renders `aria-current`
  on a `<div>`. Valid; announced as current by AT. No action needed.

## Gate
**Variant · state · ARIA · architecture · token dimensions: PASSED — 0 open source-level
discrepancies.** **Runtime dimensions (live-viewport pixel + axe): still not executable** in this
environment (no render harness / browser driver) — the only items left before the gate is fully green.
