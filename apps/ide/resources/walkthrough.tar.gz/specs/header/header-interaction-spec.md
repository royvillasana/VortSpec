# Header — Interaction Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./header-component-spec.md
**Figma prototype**: Sections / Header — Sticky property (static, sticky)

---

### Interaction Overview

The user scans and navigates from the top bar: hovering or focusing a nav link reveals its underline, tabbing moves focus in a predictable order (logo → links → CTA), and — when `sticky` — the bar stays pinned to the top of the viewport as the page scrolls.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Hover | Nav link (`Text` link) | — |
| Keyboard focus | Logo, nav links, CTA | `Tab` / `Shift+Tab` |
| Click / tap | Logo, nav link, CTA | — |
| Scroll | Page | `sticky` = `true` |

---

### Flow

Describe each step in sequence.

```
Step 1: Pointer enters a nav link → underline appears (owned by Text link variant, 150ms ease).
Step 2: Keyboard focus enters the header → focus ring shows on the current target; order is logo → nav links (source order) → CTA.
Step 3: Enter / Space (or click) on a link → navigates to its href.
Step 4: CTA press → the injected Button's own interaction runs (hover/active/click).
Step 5: [sticky=true] Page scrolls → header remains fixed at top-0, painted above content via z-10.
        [sticky=false] Header scrolls away with the document.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Nav link underline on hover/focus | 150ms | ease | owned by `Text` link variant |
| CTA color / brightness | 150ms | ease | owned by `Button` |
| Sticky pin | instant | — | `position: sticky` (no transition) |

The Figma `Sticky` property maps to the `sticky` prop → `sticky top-0 z-10`; the pinned behavior is driven by CSS positioning, not JS.

---

### Animation Details

The Header adds no bespoke animation of its own. All motion is inherited from composed atoms:

**Nav link underline** — the `Text` `link` variant reveals an underline on `:hover` / `:focus-visible` (150ms ease).

**CTA** — the injected `Button` runs its own hover/active color and brightness transitions.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| `navItems` empty | `<nav aria-label="Primary">` renders with only the CTA (if any) |
| No `cta` | Trailing group omits the CTA; nav still renders |
| Custom `logo` passed | Replaces the default `Logo` entirely; brand group still leads |
| Long `title` | Flows in the brand group; consumer manages truncation via `className` |
| `sticky` over scrollable content | Bar stays at `top-0`; `z-10` keeps it above page content |

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375px | `justify-between` keeps brand left / nav+CTA right; nav links may wrap or be trimmed by the consumer for narrow widths |
| 768px | Full bar: logo + title left, nav links + CTA right |
| 1440px | Full-bleed bar (`w-full`); intrinsic height; content aligned via `justify-between` |

The bar itself is always full-width; collapsing the nav to a menu at small widths is the consuming screen's responsibility (see the page/composition spec).

---

### Implementation Tasks

- [x] Nav links render as focusable anchors in source order
- [x] Focus order verified: logo → nav links → CTA
- [x] Underline hover/focus inherited from `Text` link variant
- [x] `sticky` prop pins the bar (`sticky top-0 z-10`)
- [x] Empty `navItems` / missing `cta` handled gracefully
