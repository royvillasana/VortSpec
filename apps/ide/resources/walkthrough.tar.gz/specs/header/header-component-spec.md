# Header — Component Spec

**Version**: 1.0
**Status**: Implemented
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Frame URL**: Sections / Header
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Organism that renders the top navigation/documentation bar spanning the full page width — it composes the system `Logo`, an optional page title/breadcrumb, a primary navigation list, and a trailing CTA into a single `<header>` landmark that anchors every screen.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--primitive-neutral-white` | `#ffffff` | `background-color` (bar surface, `bg-white`) |
| `--stroke-width-1` | `1px` | `border-width` (bottom border, `border-1`) |
| `--spacing-16` | `16px` | `padding-inline` (`px-4`) + `gap` (`gap-4`) |
| `--spacing-8` | `8px` | `padding-block` (`py-2`) |
| `--theme-primary` | `#087990` | `color` (nav links, via `Text` `link` variant) |

All references resolve through the Tailwind theme mapping in `tailwind.config.js` to these CSS variables. Nav link color, hover underline, and typography are owned by the `Text` atom (`link` variant); the CTA color is owned by the injected `Button`. No hardcoded values.

---

### Variants

The Header has a single structural variant driven by the `sticky` boolean (mirrors the Figma `Sticky` property).

| Variant | Description |
|---|---|
| `static` (default) | Bar flows in normal document order |
| `sticky` | Bar pins to the top of the viewport (`sticky top-0 z-10`) |

Content composition (logo / title / navItems / cta) is supplied by the consumer via props, not variant flags.

---

### States

The Header surface itself is non-interactive; its interactive states live in the atoms it composes.

| State | Visual Change | Trigger |
|---|---|---|
| `default` | Base bar appearance | — |
| `nav-link hover` | Underline on the hovered `Text` link | Mouse enter (owned by `Text`) |
| `nav-link focus` | Focus ring on the link (owned by `Text`) | Keyboard focus |
| `cta hover/focus/active` | Owned by the injected `Button` | Pointer / keyboard |
| `scrolled` (sticky only) | Bar remains fixed at `top-0` above content (`z-10`) | Page scroll |

---

### Sizes

The Header has no size prop; it is full-bleed (`w-full`) and its height is intrinsic to its padding and content.

| Dimension | Value | Token |
|---|---|---|
| Padding V | 8px | `--spacing-8` (`py-2`) |
| Padding H | 16px | `--spacing-16` (`px-4`) |
| Item gap | 16px | `--spacing-16` (`gap-4`) |
| Bottom border | 1px | `--stroke-width-1` |

The composed `Logo` is rendered at `size="small"` by default.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `logo` | `ReactNode` | `<Logo size="small" href="/" />` | Brand mark in the leading group |
| `title` | `ReactNode` | — | Optional page title / breadcrumb next to the logo |
| `navItems` | `Array<{ label: string; href: string }>` | `[]` | Primary nav links, each rendered as a `Text` `link` |
| `cta` | `ReactNode` | — | Trailing call-to-action (e.g. a `Button`) |
| `sticky` | `boolean` | `false` | Pins the bar to the top (`sticky top-0 z-10`) |
| `className` | `string` | — | Layout overrides only, merged last via `cn()` |
| `...props` | `HTMLAttributes<HTMLElement>` (minus `title`) | — | Native attributes spread onto `<header>` |

---

### Composed Atoms

| Atom | Slot | Spec |
|---|---|---|
| `Logo` | Leading brand group (default when `logo` omitted) | `specs/logo/logo-component-spec.md` |
| `Text` (`link` variant) | One per `navItems` entry inside `<nav>` | `specs/text/text-component-spec.md` |
| `Button` | Typical `cta` payload (trailing) | `specs/button/button-component-spec.md` |

---

### Content Rules

- Nav labels: 1–2 words, sentence case, no trailing punctuation.
- Provide a real `href` per nav item — links, not buttons.
- `title` is short (page name or breadcrumb), never a full sentence.
- Keep the trailing group to a single primary CTA.

---

### Accessibility

- Root element is a semantic `<header>` landmark.
- Navigation is a `<nav aria-label="Primary">` so assistive tech can distinguish it from other nav regions.
- Nav links are real anchors (via `Text` `link`) — keyboard focusable in source order.
- Focus order: logo → nav links (in order) → CTA.
- Bar surface (`white`) and nav link color (`primary`) meet WCAG AA contrast.

---

### Do Not

- Do not hardcode colors, spacing, or the border width — reference tokens via the Tailwind theme.
- Do not render nav items as `<button>` or `<div>` — they must be anchors.
- Do not add a second `<nav>` without a distinct `aria-label`.
- Do not remove the `aria-label="Primary"` from the nav region.

---

### Implementation Tasks

- [x] Create `src/components/sections/header.variants.ts` (CVA, `sticky` boolean)
- [x] Create `src/components/sections/Header.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Render semantic `<header>` with brand group `<div>` and `<nav aria-label="Primary">`
- [x] Default `logo` to `<Logo size="small" href="/" />`
- [x] Map `navItems` to `Text` `link` variants keyed by `href`
- [x] Render `title` next to the logo and `cta` after the nav links
- [x] Wire `sticky` → `sticky top-0 z-10`
- [x] Verify all surface/spacing/border values reference tokens (no hardcoded hex/px)
