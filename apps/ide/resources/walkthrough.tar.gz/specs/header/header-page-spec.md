# Header — Placement / Composition Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./header-component-spec.md

Organisms have no page of their own; this documents how Header anchors templates and screens, how its navigation collapses responsively, and the landmark structure it contributes.

---

### Purpose

Define where the Header sits in a page's landmark structure, which templates and screens it anchors, and how its navigation behaves across breakpoints.

---

### Component Inventory

Atoms the Header composes.

| Component | Spec file | Status |
|---|---|---|
| `Logo` | `specs/logo/logo-component-spec.md` | Implemented |
| `Text` (`link`) | `specs/text/text-component-spec.md` | Implemented |
| `Button` | `specs/button/button-component-spec.md` | Implemented |

---

### Anchors These Templates / Screens

| Template / Screen | Usage |
|---|---|
| Dashboard shell | Top bar with logo, nav, and account/CTA; typically `sticky` |
| Documentation layout | Logo + page `title`/breadcrumb, section nav links |
| Marketing / landing | Logo left, nav links + primary CTA right |

---

### Layout Structure

The Header is the first landmark in the page, above `<main>`.

```
<Page>
  <Header sticky>                         ← full-width bar, top-0 z-10
    <div class="brand">                   ← flex items-center gap-4
      <Logo size="small" href="/" />
      {title}                             ← optional page title / breadcrumb
    </div>
    <nav aria-label="Primary">            ← flex items-center gap-4
      {navItems → Text link}              ← one anchor per item, source order
      {cta}                               ← trailing Button
    </nav>
  </Header>
  <main id="main-content"> … </main>
  <Footer />
</Page>
```

Internal bar layout: `flex w-full items-center justify-between gap-4`, `bg-white`, `border-b border-1`, `px-4 py-2`.

---

### Responsive Breakpoints

| Breakpoint | Layout change |
|---|---|
| 375px (mobile) | Bar stays full-width; brand group left, `justify-between` pushes nav+CTA right. Consuming screen collapses `navItems` into a menu/hamburger when links exceed the available width. |
| 768px (tablet) | Full inline nav: logo + optional title left, nav links + CTA right. |
| 1024px (desktop) | Same as tablet; extra horizontal room absorbed by `justify-between`. |
| 1440px (wide) | Full-bleed bar; content spans the viewport with intrinsic height. |

The Header renders links inline by default; the hamburger collapse is owned by the screen composing it, not the organism.

---

### Spacing System

All spacing uses the base token scale.

| Region | Value | Token |
|---|---|---|
| Bar padding V | 8px | `--spacing-8` (`py-2`) |
| Bar padding H | 16px | `--spacing-16` (`px-4`) |
| Brand group gap | 16px | `--spacing-16` (`gap-4`) |
| Nav group gap | 16px | `--spacing-16` (`gap-4`) |
| Bottom border | 1px | `--stroke-width-1` |
| Header bottom margin | 0 | — (sits flush above `<main>`) |

---

### Data Flow

| Slot | Data source | Type |
|---|---|---|
| `logo` | Default `Logo` or prop | `ReactNode` |
| `title` | Prop | `ReactNode` (page title / breadcrumb) |
| `navItems` | Prop | `Array<{ label; href }>` |
| `cta` | Prop | `ReactNode` (usually a `Button`) |
| `sticky` | Prop | `boolean` |

---

### Landmark & Accessibility Structure

- Header is the page's `<header>` banner landmark, placed before `<main>`.
- Contains a single `<nav aria-label="Primary">` region; any secondary nav elsewhere on the page must use a distinct label.
- Nav links are real anchors — focusable in source order; focus order is logo → nav links → CTA.
- Provide a skip link (`Skip to content`) targeting `<main id="main-content">` so keyboard users can bypass the bar.
- Bar surface (`white`) vs. nav link (`primary`) meets WCAG AA contrast.

---

### Implementation Tasks

**Composition**
- [x] Place `Header` as the first landmark, above `<main>`
- [x] Render brand group (`Logo` + optional `title`) and `<nav aria-label="Primary">`
- [x] Map `navItems` to `Text` link anchors in source order
- [x] Render trailing `cta` (typically `Button`) after nav links

**Behavior**
- [x] Apply `sticky top-0 z-10` when `sticky` is set
- [x] Keep the bar full-width (`w-full`) with `justify-between` alignment

**Accessibility**
- [x] Verify focus order: logo → nav links → CTA
- [x] Confirm single `<nav aria-label="Primary">` landmark
- [x] Pair with a skip link to `<main id="main-content">`

**QA**
- [x] Visual QA at 375px / 768px / 1440px against the Figma Header frame
- [x] All surface/spacing/border values verified as token references (no hardcoded values)
