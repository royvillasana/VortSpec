# Checkbox — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./checkbox-component-spec.md
**Figma prototype**: Forms page — Checkbox State property (unchecked, checked, indeterminate, focus, disabled)

---

### Interaction Overview

The user toggles a boolean option on or off. State is driven by the native
`<input type="checkbox">`; the custom visual box mirrors it through CSS `peer-*`
pseudo-class variants — no JavaScript toggling. The optional `indeterminate`
(mixed) state is a DOM property set by the consumer and never toggled by the user.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Click / tap on box | `<label>` wrapper | Not disabled |
| Click / tap on label text | `<label>` wrapper | Not disabled |
| `Space` | Native input | Focused, not disabled |
| Focus | Native input | Keyboard `Tab` |

---

### Flow

```
Step 1: Pointer enters the control → cursor is a pointer (or not-allowed when disabled).
Step 2: Click on box or label → native input toggles checked ⇄ unchecked; onChange fires.
Step 3: Box background/border transition to --theme-primary (checked) or back to white
        (unchecked) over 150ms; the check glyph fades between hidden/block.
Step 4: Keyboard focus (Tab) → 2px focus ring on the box (peer-focus-visible).
Step 5: Space → toggles the focused control (native), same visual transition as click.
Step 6: When the consumer sets indeterminate=true → dash glyph shown, check hidden,
        box filled; user interaction (click/Space) clears indeterminate to checked
        per native behaviour and fires onChange.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| Box fill / border on toggle | 150ms | ease-out | `transition-[background-color,border-color,color]` |
| Glyph show / hide | instant | — | `hidden` ⇄ `block` via peer variant |

Figma `State` property (unchecked / checked / indeterminate / focus / disabled) maps
to CSS pseudo-classes (`:checked`, `:indeterminate`, `:focus-visible`, `:disabled`) on
the native input — states are browser-driven, not JS.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| `indeterminate` + `checked` both set | Dash shown (indeterminate wins), matching native DOM precedence |
| User clicks an indeterminate checkbox | Native clears indeterminate → becomes checked; `onChange` fires |
| Controlled input without `onChange` | React warns; the box appears frozen — provide `onChange` or use `defaultChecked` |
| `disabled` | Pointer events blocked, `not-allowed` cursor, 0.65 opacity; no toggle, no focus |
| Label omitted | Box renders alone; provide `aria-label` on the input for a11y |

---

### Accessibility & Keyboard

- `Tab` / `Shift+Tab` — move focus to / from the native input; ring appears on the box.
- `Space` — toggles the focused checkbox (native behaviour, not re-implemented).
- Clicking the wrapping `<label>` (box or text) toggles and focuses the input.
- `indeterminate` is set on the DOM node, so screen readers announce "mixed".
- Focus ring is always visible on keyboard focus (`peer-focus-visible:ring-2`).

---

### Implementation Tasks

- [x] Toggle driven purely by native input + `peer-*` variants (no JS state)
- [x] Box fill/border transition on toggle (150ms ease-out)
- [x] `Space` toggles; label click toggles; focus ring on box
- [x] `indeterminate` DOM property set via effect; dash glyph precedence over check
- [x] Disabled blocks interaction with `not-allowed` cursor + reduced opacity
