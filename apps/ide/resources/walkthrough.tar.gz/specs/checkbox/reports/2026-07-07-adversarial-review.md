# Adversarial Review — Checkbox

Date: 2026-07-07

**Component**: `src/components/ui/Checkbox.tsx` + `src/components/ui/checkbox.variants.ts`
**Reviewer**: /adversarial-review (source-of-truth; no browser render available)

## Verdict

**PASS** — 1 minor issue found and resolved inline during review; no Blocker findings remain.
`npx tsc --noEmit` clean after the fix.

---

## Findings

| # | Severity | Area | Finding | Status |
|---|---|---|---|---|
| 1 | Minor | State coverage / visual | Disabled dimmed the box only; label text kept full opacity — a labelled disabled checkbox read half-disabled, diverging from the spec's whole-control `--opacity-disabled` (0.65). | Resolved (fixed inline) |
| 2 | Info | A11y (no visible label) | When `label` is omitted the box renders alone; accessible name then depends on the consumer passing `aria-label`. Matches spec ("Label omitted → provide aria-label") and is spread via `{...props}` — consumer-level responsibility, no code change. | Accepted (by design) |
| 3 | Info | Focus ring offset color | `ring-offset-2` inherits Tailwind's default white offset color (not a token). Acceptable — box sits on light surfaces, spec specifies only offset width, and ring color is tokenized (`ring-primary`). | Accepted |

### Adversarial probes that PASSED (no finding)
- **Peer combinator**: input is `peer` and the first child; box span + both Icons are *following siblings* in the same wrapper → `peer-*` general-sibling combinator resolves. No nesting breaks it.
- **Native input real, not faux**: `<input type="checkbox">` kept, `peer sr-only` (never `display:none`/`hidden`) → focusable, keyboard `Space`/`Tab` native, semantics intact. No `div[role=checkbox]`.
- **Indeterminate as DOM property**: set via `useEffect` on a merged ref, not as an attribute → AT announces "mixed".
- **Indeterminate > checked precedence**: check glyph carries `peer-indeterminate:hidden`; Tailwind orders the `indeterminate` variant after `checked`, so the compiled rule hides the check when both are set (spec edge case honored).
- **Icon glyph color**: `Icon` roots `fill-current`; `text-white` on the glyph → white fill on the primary-filled box (not default black).
- **Icon size override**: `cn()` = twMerge, so `checkboxIconVariants` (h-3/4/5) overrides the Icon's own default `h-5 w-5` deterministically.
- **Token audit**: grep for hex/rgb/hsl/inline-style/`[Npx]` on both files → empty. Box sizes 16/20/24 come from spacing-token utilities (`h-4/5/6`), not arbitrary px.
- **Ref merge**: forwarded ref (function or object) + internal ref both populated; no clobbering.
- **Responsive**: box size is viewport-independent per `size` token; no 375/768/1440 breakpoint drift. Label wrap is consumer `className` responsibility per spec.
- **Interaction-spec compliance**: toggle is native + `peer-*` only (no JS state); 150ms ease-out fill transition present; disabled blocks interaction with `not-allowed` cursor.

---

## Resolved During Review

- **Finding #1** — added `disabled && 'opacity-disabled'` to the label-text span via `cn()`, so the whole control reads at 0.65 opacity when disabled (box already handled by `peer-disabled:opacity-disabled`). `tsc` clean.

---

## Architecture Validation Checklist

| Check | Result |
|---|---|
| CVA for variants (`.variants.ts`) | ✓ `checkboxBoxVariants` + `checkboxIconVariants` |
| `defaultVariants` set | ✓ `size: 'medium'` on both |
| `forwardRef` | ✓ forwards to native `<input>` |
| Spreads native props | ✓ `{...props}` on the input |
| `className` merged last via `cn()` | ✓ on the outer `<label>` (layout overrides win) |
| `VariantProps` exported | ✓ `export type CheckboxVariants` |
| No inline `style={{}}` for DS values | ✓ none present |
| Tokens only (no hardcoded hex/px) | ✓ grep empty; all utilities map to `var(--token)` |
| Separate `.variants.ts` file | ✓ |

---

## Shared / Out-of-scope concerns

None. No defects found in shared config (`tailwind.config.js`), `tokens.css`, `Icon`, or `cn` — all consumed correctly by Checkbox. Only outstanding non-defect: **no Storybook story** for Checkbox (blocks live Verify sign-off; recommend adding before commit).
