# Checkbox — Usage / Composition Spec

**Version**: 1.0
**Status**: Ready
**Related Component Spec**: ./checkbox-component-spec.md

Atoms have no page of their own; this documents how Checkbox composes into
higher-order components and screens.

---

### Purpose

Provide a single, consistent boolean/mixed toggle for use in forms, filters,
settings, tables (row selection), and "accept terms" confirmations.

---

### Component Inventory

| Component | Role |
|---|---|
| `Checkbox` (atom) | The control itself — native input + custom box + optional label |
| `Icon` (atom) | Renders the `check` and `dash` glyphs inside the box |

---

### Consumed By

| Consumer | Usage |
|---|---|
| Forms / Fieldsets | Individual boolean options, "accept terms" |
| Filter panels | Multi-select facets |
| Tables | Row selection; header "select all" uses `indeterminate` for partial selection |
| Settings screens | On/off preferences with a descriptive label |

---

### Usage Example

```tsx
import { Checkbox } from '@/components';

// Basic labelled checkbox
<Checkbox label="Email me product updates" defaultChecked />

// Sizes
<Checkbox size="small" label="Small" />
<Checkbox size="medium" label="Medium" />
<Checkbox size="large" label="Large" />

// Controlled "select all" with indeterminate parent
<Checkbox
  label="Select all"
  checked={allSelected}
  indeterminate={someSelected && !allSelected}
  onChange={(e) => toggleAll(e.target.checked)}
/>

// Disabled
<Checkbox label="Unavailable option" disabled />
```

---

### Composition Rules

- Checkbox owns the box ↔ label gap (`--spacing-8`); consumers pass only layout via `className`.
- Use the built-in `label` prop for the associated text — do not hand-wire a separate `<label htmlFor>`.
- For a group, stack Checkboxes in a `<fieldset>` with a `<legend>`; the fieldset spacing is the consumer's responsibility.
- Use `indeterminate` only for parent/summary rows; leaf options are `checked` or `unchecked`.

---

### Responsive

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | Box size is fixed per `size` token; label wraps per consumer `className`. Hit target stays ≥ box size; pair with adequate line spacing on touch. |

---

### Accessibility

- Every checkbox needs an accessible name: pass `label`, or `aria-label` when used without visible text.
- Group related checkboxes in a `<fieldset>` + `<legend>` for a group name.
- "Select all" parents use `indeterminate` so assistive tech announces "mixed".
- Focus ring is never removed; keyboard users can `Tab` to and `Space` to toggle.

---

### Implementation Tasks

- [x] Verify labelled Checkbox renders with correct box ↔ label spacing
- [x] Verify `indeterminate` parent + child pattern in a "select all" composition
- [x] Verify sizes align on the label baseline
- [x] Verify disabled state is non-interactive and dimmed
