# Checkbox — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

An accessible, token-driven checkbox control. It lets a user turn a single option
on or off, and also expresses a third **indeterminate** (mixed) state used by
"select all" parents whose children are partially selected. The control is built
on a real native `<input type="checkbox">` so it keeps browser semantics and
keyboard behaviour, with a custom-styled box for pixel-accurate visuals.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--theme-primary` | `#087990` | `background-color` / `border-color` / `ring-color` (checked / indeterminate / focus) |
| `--primitive-neutral-white` | `#ffffff` | `background-color` (unchecked box) / `color` (glyph on fill) |
| `--color-neutral-300` | `#dee2e6` | `border-color` (unchecked box) |
| `--color-text-default` | `#212529` | `color` (label) |
| `--spacing-8` | `8px` | `gap` (box ↔ label) |
| `--spacing-16/20/24` | 16 / 20 / 24px | box `height` / `width` (small / medium / large) |
| `--spacing-12/16/20` | 12 / 16 / 20px | glyph `height` / `width` (small / medium / large) |
| `--radius-4` | `4px` | `border-radius` (box) |
| `--stroke-width-1` | `1px` | `border-width` (box) |
| `--opacity-disabled` | `0.65` | `opacity` (disabled) |
| `--font-family-base` | Roboto | `font-family` (label) |
| `--font-size-body` | `16px` | `font-size` (label) |

All references are via the Tailwind theme mapping in `tailwind.config.js`, which
resolves to these CSS variables. No hardcoded values.

---

### Variants

The Checkbox has no color/type variants — only **size**. Visual variation is driven
entirely by the native input's state, reflected through Tailwind `peer-*` variants.

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `unchecked` | White box, `--color-neutral-300` border, no glyph | Default |
| `checked` | `--theme-primary` fill + border, white **check** glyph | `checked` prop / user toggle |
| `indeterminate` | `--theme-primary` fill + border, white **dash** glyph | `indeterminate` prop (DOM property) |
| `focus` | 2px ring in `--theme-primary`, offset 2px, on the box | Keyboard focus (`peer-focus-visible`) |
| `disabled` | `--opacity-disabled` (0.65), `cursor: not-allowed` | `disabled` prop (`peer-disabled`) |

`indeterminate` visually supersedes `checked` (dash shown, check hidden) — matching
the native DOM precedence.

---

### Sizes

| Size | Box | Glyph | Token |
|---|---|---|---|
| `small` | 16×16px | 12×12px | `--spacing-16` / `--spacing-12` |
| `medium` | 20×20px | 16×16px | `--spacing-20` / `--spacing-16` |
| `large` | 24×24px | 20×20px | `--spacing-24` / `--spacing-20` |

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `size` | `small \| medium \| large` | `medium` | Box + glyph size |
| `indeterminate` | `boolean` | `false` | Mixed state; set on the DOM node via effect |
| `label` | `React.ReactNode` | — | Optional text rendered to the right of the box |
| `checked` / `defaultChecked` | `boolean` | — | Native controlled / uncontrolled checked state |
| `disabled` | `boolean` | `false` | Disables interaction |
| `className` | `string` | — | Layout overrides only, merged last on the outer `<label>` |
| `...props` | `InputHTMLAttributes` | — | Native input attributes spread (`name`, `value`, `onChange`, …) |

`ref` forwards to the underlying `<input type="checkbox">`.

---

### Accessibility

- Element: real native `<input type="checkbox">`, visually hidden with `sr-only`
  (never `display:none`) so it stays focusable and keeps built-in semantics.
- The `<label>` wraps the input, so clicking the box or the label toggles the control
  and the label is programmatically associated (no `htmlFor`/`id` wiring required).
- `Space` toggles the control (native behaviour); `Tab` moves focus.
- The `indeterminate` state is reflected on the actual DOM node (`input.indeterminate`),
  so assistive tech announces "mixed".
- Visible focus ring on the custom box via `peer-focus-visible:ring-2` — never removed.
- The custom box and glyphs are decorative (`aria-hidden`); the accessible state comes
  from the native input.

---

### Do Not

- Do not hardcode colors, spacing, or radius — reference tokens via Tailwind theme.
- Do not use `display:none` / `hidden` on the input (breaks focus + semantics) — use `sr-only`.
- Do not set `indeterminate` as an attribute; it is a DOM property set via effect.
- Do not remove the focus ring.
- Do not replace the native input with a `div[role=checkbox]`.

---

### Implementation Tasks

- [x] Create `src/components/ui/checkbox.variants.ts` (CVA — box + icon sizing per size)
- [x] Create `src/components/ui/Checkbox.tsx` (`forwardRef`, spreads props, `cn()` last on the label)
- [x] Render native `<input type="checkbox">` as `peer sr-only`
- [x] Custom box reflects state via `peer-checked` / `peer-indeterminate` / `peer-focus-visible` / `peer-disabled`
- [x] Check glyph on checked, dash glyph on indeterminate
- [x] Merge forwarded + internal ref; set `indeterminate` DOM property via `useEffect`
- [x] Implement `small` / `medium` / `large` sizes
- [x] Wire optional `label` + full-control click target via wrapping `<label>`
