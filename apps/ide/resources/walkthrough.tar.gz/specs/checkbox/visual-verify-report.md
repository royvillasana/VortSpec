# Visual Verify Report — Checkbox

**Component**: Checkbox
**Source**: Figma (Branch A)
**Date**: 2026-07-07
**Skill**: /visual-verify

> **Render limitation**: No browser/screenshot tool is available in this environment.
> Verification is SOURCE-OF-TRUTH: implementation code + Tailwind→token mapping compared
> against the codified Figma spec (`specs/checkbox/`), plus static analysis. No pixel
> screenshots were captured or claimed.
> **Storybook note**: No Checkbox story exists yet — the component could not be exercised
> live at http://localhost:6006/. Recommend adding `Checkbox.stories.tsx` before Verify sign-off.

---

## Checklist (375 / 768 / 1440 — box size is viewport-independent per `size` token)

### Variants & Sizes
- [✓] No color/type variants (size-only), matches spec
- [✓] `small` box 16px — `h-4 w-4` → `--spacing-16` (token utility, not arbitrary px)
- [✓] `medium` box 20px — `h-5 w-5` → `--spacing-20`
- [✓] `large` box 24px — `h-6 w-6` → `--spacing-24`
- [✓] Glyph 12/16/20 — `h-3/4/5` → `--spacing-12/16/20` (via `checkboxIconVariants`; twMerge overrides Icon default)
- [✓] `defaultVariants.size = medium` on both CVA definitions

### States (unchecked / checked / indeterminate / hover / focus / disabled)
- [✓] `unchecked` — `bg-white` (`--primitive-neutral-white`) + `border-neutral-300` (`--color-neutral-300`), no glyph
- [✓] `checked` — `peer-checked:bg-primary` + `peer-checked:border-primary` (`--theme-primary`), white check glyph
- [✓] `indeterminate` — `peer-indeterminate:bg-primary/border-primary`, white dash glyph; check hidden via `peer-indeterminate:hidden`
- [✓] indeterminate precedence over checked — Tailwind emits `indeterminate` after `checked`, so `peer-indeterminate:hidden` wins on the check glyph (spec edge case)
- [✓] hover — cursor `pointer` (or `not-allowed` when disabled); fill transition on toggle
- [✓] `focus` — `peer-focus-visible:ring-2 ring-primary ring-offset-2` on the box
- [✓] `disabled` — `peer-disabled:opacity-disabled` (`--opacity-disabled` 0.65) on box + `cursor-not-allowed`; label text also dims (fixed)
- [✓] toggle transition 150ms ease-out — `transition-[background-color,border-color,color] duration-150 ease-out`

### Colors → Tokens
- [✓] Every color utility resolves to `var(--token)`: `bg-white`, `border-neutral-300`, `text-white`, `bg-primary`, `border-primary`, `ring-primary`, `text-text`

### Size / Spacing → Tokens
- [✓] Box + glyph dims from spacing token utilities (no arbitrary `[16px]`)
- [✓] box↔label gap `gap-2` → `--spacing-8` (matches spec)

### Radius / Border → Tokens
- [✓] `rounded-sm` → `--radius-4`
- [✓] `border border-1` → `--stroke-width-1` (1px, sanctioned exception)

### Accessibility
- [✓] Real native `<input type="checkbox">` preserved, `peer sr-only` (not display:none) — stays focusable
- [✓] `<label>` wraps input — label associated, box+text toggle the control
- [✓] focus-visible ring on custom box via `peer-focus-visible` (peer is a prior sibling — combinator intact, no nesting)
- [✓] checked/mixed state conveyed by native input; `indeterminate` set as DOM property via effect (announces "mixed")
- [✓] custom box + glyphs `aria-hidden`

### Token Audit
- [✓] `grep -nE '#[0-9a-fA-F]{3,8}|rgb\(|hsl\(|style=\{\{|\[[0-9]+px\]'` on `Checkbox.tsx` + `checkbox.variants.ts` → **empty** (0 matches)

### Architecture
- [✓] CVA, forwardRef, `{...props}` spread on input, `className` via `cn()` last on `<label>`, `VariantProps` exported, no inline DS `style={{}}`

---

## Discrepancies

| # | Severity | Description | Resolution |
|---|---|---|---|
| 1 | Minor | Disabled state dimmed only the custom box (`peer-disabled:opacity-disabled`); label text stayed at full opacity, so a labelled disabled checkbox read inconsistently vs spec (whole-control 0.65). | Fixed inline — label text span now applies `opacity-disabled` when `disabled`. Box stays 0.65 via `peer-disabled`; text 0.65 via prop. |

### Non-blocking observations (no change)
- `ring-offset-2` uses Tailwind's default ring-offset color (white); acceptable since the box sits on light surfaces and the spec specifies only offset width. Ring width 2px is inherent to the design (no 2px stroke token exists); ring **color** is tokenized (`ring-primary`).
- No `font-family` on the label span; relies on the global `--font-family-base` inheritance (consistent with other atoms).

---

**Result: PASS** (1 minor discrepancy found and fixed inline; `npx tsc --noEmit` clean)
