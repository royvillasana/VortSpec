# Visual Verify Report — CodeBlock

- **Design source:** `figma` (Branch A) · **Component:** `CodeBlock` (molecule) · **Date:** 2026-07-07
- **Spec:** `specs/code-block/code-block-component-spec.md` + `code-block-interaction-spec.md` ·
  **Impl:** `src/components/modules/CodeBlock.tsx` + `code-block.variants.ts` · **Composes:** none (native `<figure>/<pre>/<code>`)
- See `specs/visual-verify-report.md` for shared context and the runtime-check environment limitation.

## Result: PASS (source-of-truth) — 0 open source-level discrepancies

The surface, tones, structure, and static-only interaction model are all correct. The former `text-muted`
leak on the filename `<figcaption>` is now **RESOLVED**: a top-level alias `colors.muted:
'var(--color-text-muted)'` was added to `tailwind.config.js` on 2026-07-07 (compile-verified with Tailwind
3.4.19), so the caption's `text-muted` class now emits `color: var(--color-text-muted)` and the muted color
(`--color-text-muted`) is applied correctly. No component code changed. The token dimension **PASSES**.
Runtime dimensions (pixel + axe) remain open.

---

## ⚠️ Runtime dimensions NOT executed (environment limit)

This environment has NO browser driver (Playwright/Puppeteer NOT installed) and (mostly) no render
harness, so the Figma-flow **live-viewport pixel comparison (375 / 768 / 1440px)** and **runtime axe
audit** CANNOT be executed and are NOT asserted. Everything below is a **source-of-truth
verification** (spec ↔ code ↔ token model), authoritative for token / variant / state-wiring / ARIA
dimensions. To close runtime dims: install a browser driver + Storybook/harness, screenshot each
viewport vs the Figma frame, and run axe-core.

---

## Discrepancies

### D1 — filename `<figcaption>` uses `text-muted` → muted token not applied ✗ (Blocker, token dimension)

**✅ RESOLVED 2026-07-07** — fixed by adding `colors.muted: 'var(--color-text-muted)'` to
`tailwind.config.js` (compile-verified); no component code changed. `text-muted` now resolves to
`--color-text-muted` on the caption. The original finding is retained below for the audit trail.

`CodeBlock.tsx:21` styles the caption `font-base text-body font-regular leading-body text-muted`. The
muted color in `tailwind.config.js` is nested as `colors.text.muted` and is exposed **only** as
`text-text-muted`; the bare `text-muted` has no matching color key and emits no rule.

Empirically confirmed against this exact config (Tailwind 3.4.19):
- `text-muted` → **no output**
- `text-text-muted` → `color: var(--color-text-muted)` ✓

**Impact:** the filename caption renders in the inherited/ambient color instead of the spec's
`--color-text-muted` (#6c757d). Everything else on the caption (`font-base`, `text-body`,
`font-regular`, `leading-body`) is correct.

**Fix (verify-only — not applied):** change `text-muted` → **`text-text-muted`** on the
`<figcaption>`. This is the same **systemic** naming bug flagged in the Breadcrumb report (~30
`text-muted` usages across the codebase vs the correct `text-text-muted` in `Table.tsx`); recommend a
system-wide sweep.

---

## Checklist (source-verified)

### Variants ✓ (both tones)
| `tone` | Surface class → token | Code color → token | OK |
|---|---|---|---|
| `neutral` (default) | `bg-neutral-100` → `--color-neutral-100` | `text-text` → `--color-text-default` | ✓ |
| `dark` | `bg-near-black` → `--primitive-neutral-near-black` | `text-white` → `--primitive-neutral-white` | ✓ |

`defaultVariants.tone = 'neutral'` ✓. Base already sets the neutral pair; the `neutral` variant
re-states it (harmless).

### States ✓
Static presentational molecule — only `default`. Interaction spec confirms no interactive states; the
sole behavior is native horizontal scroll (`overflow-x-auto`). No copy button exists in this spec, so
the generic "copy-button state / aria-label" check is **N/A** (not a gap — this component's spec
defines no copy affordance). Nothing in the code adds hover/focus/transition. Correct.

### Tokens (audit)
| Utility | → token | OK |
|---|---|---|
| `bg-neutral-100` | `--color-neutral-100` | ✓ |
| `bg-near-black` (dark) | `--primitive-neutral-near-black` | ✓ |
| `text-text` | `--color-text-default` | ✓ |
| `text-white` (dark) | `--primitive-neutral-white` | ✓ |
| `rounded` | `--radius-8` | ✓ |
| `p-3` | `--spacing-12` (12px) | ✓ |
| `m-0` | `--spacing-0` | ✓ |
| `gap-1` (caption ↔ pre) | `--spacing-4` | ✓ |
| `font-mono` | `--font-family-mono` (token exists — documented mono exception, fully resolved) | ✓ |
| `text-body` | `--font-size-body` | ✓ |
| `leading-body` | `--line-height-body` | ✓ |
| `font-regular` | `--font-weight-regular` | ✓ |
| `text-muted` (figcaption) | → --color-text-muted (resolves via colors.muted alias, added 2026-07-07) | ✓ |

Structural utilities `block`, `w-full`, `flex`, `flex-col`, `overflow-x-auto` carry no DS value — not
leaks. `font-mono` now resolves to the `--font-family-mono` token, so the historical "intentional
mono exception" is fully token-backed.

### Accessibility ✓
- Semantic structure `<figure>` → optional `<figcaption>` → `<pre>` → `<code>` exactly per spec ✓.
- The `<figcaption>` labels the snippet for AT ✓ (color bug D1 does not affect labelling).
- `overflow-x-auto` keeps long lines reachable via horizontal scroll without clipping ✓.

### Token audit ✓
Zero hardcoded hex / inline `style`; only "hardcoded" family is the intentional, now token-backed
`font-mono`. The `text-muted` caption class now resolves to `--color-text-muted` after the `colors.muted`
alias was added to `tailwind.config.js` on 2026-07-07 (compile-verified; D1), so the muted token is
applied — passes the zero-tolerance token audit; no hardcodes, gate clean.

---

## Observations (non-blocking)

- **O-A — stale spec value.** The component spec's token table lists `--spacing-12` as "13px"; the
  authoritative token is **12px** (`tokens.css` corrected 13px→12px on 2026-07-06). The code (`p-3` →
  `--spacing-12`) is correct; only the spec's doc comment is stale. Update the spec table.
- **O-B — redundant neutral tone classes.** The CVA base sets `bg-neutral-100 text-text` and the
  `neutral` variant repeats it. Harmless duplication (same tokens); optional cleanup.
- **O-C — ref target.** `forwardRef<HTMLElement>` is applied to `<pre>` (cast to `HTMLPreElement`) and
  `{...props}` spreads onto `<pre>`, while `className` merges onto `<figure>` — matches the spec's
  Props/API notes exactly.

---

## Gate

**Token dimension: PASSED — 0 open discrepancies (D1 resolved 2026-07-07)** via the `colors.muted` alias in
`tailwind.config.js` (compile-verified); `text-muted` now applies `--color-text-muted` on the filename
caption. **Runtime dimensions (live-viewport pixel + axe): not executable** in this environment (no render
harness / browser driver).
