# CodeBlock — Interaction Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./code-block-component-spec.md
**Figma prototype**: Code blocks page — static (Tone property only, no interactive states)

---

### Interaction Overview

`CodeBlock` is a static presentational molecule. It renders a code snippet on a neutral or dark surface with an optional filename caption; the only user interaction is native horizontal scrolling when a line overflows.

---

### Trigger

| Trigger | Element | Condition |
|---|---|---|
| Horizontal scroll | `<pre>` | Code line width exceeds the container (`overflow-x-auto`) |

---

### Flow

```
Step 1: Component mounts → <figure> renders; tone sets surface + code color.
Step 2: If filename is provided → a muted <figcaption> renders above the snippet.
Step 3: <pre><code> renders the `code` string (or children fallback) in font-mono.
Step 4: If a line exceeds the container width → a horizontal scrollbar appears (overflow-x-auto); user scrolls to read.
Step 5: No other state changes occur; the component is otherwise fully declarative.
```

---

### Timing

| Transition | Duration | Easing | CSS |
|---|---|---|---|
| — | — | — | No transitions (static molecule) |

---

### Animation Details

None. `CodeBlock` renders no animations or transitions.

---

### Edge Cases

| Scenario | Behavior |
|---|---|
| No `code`, has `children` | Renders `children` as the snippet |
| Neither `code` nor `children` | Empty `<code>` renders (no crash) |
| No `filename` | `<figcaption>` is not rendered |
| Very long line | Horizontal scroll via `overflow-x-auto`; no wrap, no clip |
| `tone="dark"` | Near-black surface, white code text |

---

### Responsive Behavior

| Viewport | Change |
|---|---|
| 375 / 768 / 1440 | `<figure>` fills its container width; padding (`p-3`) and radius are fixed by token. Overflowing lines scroll horizontally rather than reflowing the layout. |

---

### Implementation Tasks

- [x] Render `code` with `children` fallback in `font-mono`
- [x] Conditionally render `filename` caption
- [x] Apply `overflow-x-auto` for long-line horizontal scroll
- [x] Confirm no transitions/animations are introduced
- [x] Verify tones at 375 / 768 / 1440
