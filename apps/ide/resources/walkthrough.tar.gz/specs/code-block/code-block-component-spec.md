# CodeBlock — Component Spec

**Version**: 1.0
**Status**: Implemented
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Formatted code-snippet container with a neutral (or dark) surface and optional filename label — used to present usage examples and code in documentation as a semantic `<figure>`.

---

### Composed Atoms

| Atom | Role |
|---|---|
| — | No atom composition; renders native `<figure>`, `<figcaption>`, `<pre>`, `<code>` |
| Caption text | Optional `filename` styled with the body + muted tokens |

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-neutral-100` | `#f8f9fa` | `background-color` (neutral tone) |
| `--primitive-neutral-near-black` | `#1a1916` | `background-color` (dark tone) |
| `--color-text-default` | `#212529` | `color` (neutral tone code, `text-text`) |
| `--primitive-neutral-white` | `#ffffff` | `color` (dark tone code, `text-white`) |
| `--color-text-muted` | `#6c757d` | `color` (filename caption, `text-muted`) |
| `--font-family-base` | Roboto | `font-family` (filename caption, `font-base`) |
| `--font-size-body` | `16px` | `font-size` (caption, `text-body`) |
| `--font-weight-regular` | `400` | `font-weight` (`font-regular`) |
| `--line-height-body` | `1.5` | `line-height` (caption, `leading-body`) |
| `--radius-8` | `8px` | `border-radius` (`rounded`) |
| `--spacing-12` | `12px` | `padding` (`p-3`) |
| `--spacing-4` | `4px` | `gap` (caption ↔ pre, `gap-1`) |

**Font exception:** the code itself uses `font-mono` (a monospace stack), the single intentional deviation from the base `--font-family-base` token — monospace is required for code legibility and column alignment. All other values reference tokens; no hardcoded colors, spacing, or radius.

---

### Variants

Mirrors the Figma `Tone` property.

| `tone` | Surface | Code color |
|---|---|---|
| `neutral` (default) | `bg-neutral-100` | `text-text` |
| `dark` | `bg-near-black` | `text-white` |

---

### States

`CodeBlock` is a static presentational molecule — no interactive states.

| State | Visual Change | Trigger |
|---|---|---|
| `default` | Base appearance | — |

---

### Sizes

Single intrinsic size. Padding (`p-3`) and radius (`rounded`) are token-fixed; the block grows with content and scrolls horizontally (`overflow-x-auto`) when the code exceeds the container width.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `tone` | `"neutral" \| "dark"` | `"neutral"` | Surface + code color set |
| `code` | `string` | — | Code string to render; falls back to `children` when omitted |
| `filename` | `string` | — | Optional label rendered as `<figcaption>` (muted) |
| `children` | `ReactNode` | — | Code content used when `code` is not provided |
| `className` | `string` | — | Layout overrides only, merged last (applied to `<figure>`) |
| `...props` | `HTMLAttributes<HTMLElement>` | — | Native attributes spread onto `<pre>` |

---

### Content Rules

- `code`/`children`: the exact snippet to display; preserve whitespace and indentation.
- `filename`: short path or label (e.g., `Button.tsx`); optional.
- Do not add syntax-highlight markup that overrides token colors.

---

### Accessibility

- Semantic structure: `<figure>` → optional `<figcaption>` → `<pre>` → `<code>`.
- The filename `<figcaption>` labels the snippet for assistive tech.
- `overflow-x-auto` keeps long lines reachable via horizontal scroll without clipping.
- Code text meets contrast against both the neutral and dark surfaces.

---

### Do Not

- Do not hardcode colors, spacing, or radius — reference tokens via Tailwind theme.
- Do not replace `font-mono` on the code with a proportional font (breaks legibility/alignment).
- Do not collapse or normalize whitespace inside the code content.

---

### Implementation Tasks

- [x] Create `src/components/modules/code-block.variants.ts` (CVA: `codeBlockVariants` with `tone`)
- [x] Create `src/components/modules/CodeBlock.tsx` (`forwardRef` to `<pre>`, spreads props, `cn()` last)
- [x] Implement `neutral` and `dark` tones (surface + code color)
- [x] Render `<figure>/<figcaption>/<pre>/<code>` structure
- [x] Support `code` prop with `children` fallback
- [x] Apply `font-mono`, `overflow-x-auto`, `rounded`, `p-3`
- [x] Verify token-only styling (mono font documented as the sole exception)
