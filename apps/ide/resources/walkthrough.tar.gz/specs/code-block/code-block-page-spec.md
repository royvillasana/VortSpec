# CodeBlock — Usage / Composition Spec

**Version**: 1.0
**Status**: Implemented
**Related Component Spec**: ./code-block-component-spec.md

Molecules have no page of their own; this documents how CodeBlock composes into higher-order components and screens.

---

### Consumed By

| Consumer | Usage |
|---|---|
| Documentation screens | Usage examples and code snippets in prose |
| Component doc pages | "How to use" example blocks |
| `DESIGN.md` viewers | Rendered token/component code samples |

---

### Composition Rules

- Layout (margin, max-width, block placement) is applied via `className` on the `<figure>`.
- Pass the snippet through `code` for strings; use `children` for JSX-composed content.
- Choose `tone="dark"` for emphasis/hero examples, `neutral` for inline docs.
- Keep the `filename` label short so it reads as a caption, not a heading.

---

### Accessibility

- Preserve the `<figure>/<figcaption>` pairing so the snippet has an accessible label.
- Ensure long examples remain reachable via horizontal scroll (do not disable overflow).

---

### Implementation Tasks

- [x] Verify CodeBlock renders inside documentation prose with correct spacing
- [x] Verify neutral and dark tones read correctly against page background
- [x] Verify filename caption labels the snippet
