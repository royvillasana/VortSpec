# Adversarial Review — CodeBlock

**Date**: 2026-07-07
**Component**: CodeBlock (molecule) — formatted code snippet on a neutral/dark surface
**Files reviewed**: `src/components/modules/CodeBlock.tsx`, `src/components/modules/code-block.variants.ts`
**Specs**: `code-block-component-spec.md`, `code-block-interaction-spec.md`, `code-block-page-spec.md`
**Method**: Source-of-truth + static analysis (no browser/screenshot tool available)

## Verdict

**PASS** — one High-severity variant-cascade bug found and fixed inline; one minor spec-doc staleness corrected. No unresolved Blocker findings. TypeScript compiles clean.

---

## Findings

| # | Severity | Area | Finding | Status |
|---|---|---|---|---|
| 1 | High | Variant coverage / CVA | `cva` base included `bg-neutral-100 text-text`; the `dark` variant added `bg-near-black text-white` without tailwind-merge, so dark tone carried conflicting bg/text classes. CSS source order (`near-black` defined before `neutral` in theme) makes `.bg-neutral-100` win → `tone="dark"` renders neutral surface. | Fixed |
| 2 | Minor | Spec accuracy | Component-spec token table listed `--spacing-12` as `13px`; token was corrected to `12px` on 2026-07-06. Stale doc value. | Fixed |
| 3 | Info | Token audit | Grep for hex/rgb/hsl/inline-style/`[px]` across both files → 0 matches. All color/spacing/radius/font values resolve to `var(--token)` via Tailwind utilities. `font-mono` is the sanctioned exception. | Clean |
| 4 | Info | a11y adversarial | No icon-only controls exist (no copy button), so no missing `aria-label` risk. `<figure>/<figcaption>` provides the snippet an accessible label; `<pre><code>` preserves whitespace. | Clean |
| 5 | Info | Responsive (375) | `<pre overflow-x-auto>` inside `w-full` figure: long lines scroll horizontally, do not clip or force layout reflow at 375. No `truncate`/`overflow-hidden`. | Clean |
| 6 | Info | Interaction-spec compliance | Spec mandates a static molecule with no transitions/animations and native horizontal scroll only. Implementation has zero transition/animation classes and no interactive state. | Compliant |

---

## Resolved During Review

- **code-block.variants.ts** — removed `bg-neutral-100` and `text-text` from the CVA base string; tone colors now live exclusively in the `neutral` / `dark` variants (`defaultVariants.tone = 'neutral'` preserves the default surface). Eliminates the dark-tone background-conflict bug.
- **code-block-component-spec.md** — token table `--spacing-12` value `13px` → `12px` to match `src/styles/tokens.css`.
- **Verification** — `npx tsc --noEmit` passes with no errors after the fixes.

---

## Architecture Validation Checklist

| Requirement | Result | Evidence |
|---|---|---|
| CVA used for variants (separate `.variants.ts`) | ✓ | `codeBlockVariants = cva(...)` in `code-block.variants.ts` |
| `defaultVariants` declared | ✓ | `defaultVariants: { tone: 'neutral' }` |
| `forwardRef` used | ✓ | `React.forwardRef<HTMLElement, CodeBlockProps>` → forwarded to `<pre>` |
| Native props spread | ✓ | `{...props}` spread onto `<pre>` |
| `className` merged last via `cn()` | ✓ | `cn('m-0 flex w-full flex-col gap-1', className)` on `<figure>` |
| `VariantProps` exported | ✓ | `export type CodeBlockVariants = VariantProps<typeof codeBlockVariants>` |
| No inline `style={{}}` for DS values | ✓ | None present (token audit empty) |
| `displayName` set | ✓ | `CodeBlock.displayName = 'CodeBlock'` |
| Token-only styling (mono exception documented) | ✓ | All utilities map to `var(--token)`; `font-mono` sanctioned |

---

*No shared config/token/other-component edits were required. No unresolved or shared defects.*
