# Switch — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens

---

### Overview

The Switch toggles a single boolean setting. Interaction is entirely delegated to the
underlying native `<input type="checkbox">`; the custom track and thumb are purely
presentational and react to the input's state through peer pseudo-classes. There is no
JavaScript state machine — checked state is owned by the input (controlled via `checked` +
`onChange`, or uncontrolled via `defaultChecked`).

---

### Trigger

The switch toggles on any of:

- **Pointer**: click/tap anywhere on the `<label>` (track, thumb, or label text).
- **Keyboard**: `Space` while the input is focused.

Each toggle flips the native `checked` value and fires the standard `change` event, so the
caller's `onChange` receives a normal React change event.

---

### Flow

1. User focuses or points at the control.
2. On activation the native `checked` value flips.
3. **Track color** cross-fades: `bg-neutral-300` → `bg-primary` (on) or back (off) via
   `transition-colors`.
4. **Thumb** slides horizontally: off inset (`left-1`) → `translate-x-*` (on) via
   `transition-transform`, or back on toggle off.
5. Both transitions run concurrently over `150ms ease-out`, landing the thumb `4px` from the
   opposite edge.

---

### Timing

| Property | Value | Token / Utility |
|---|---|---|
| Track color fade | `150ms` `ease-out` | `transition-colors duration-150 ease-out` |
| Thumb slide | `150ms` `ease-out` | `transition-transform duration-150 ease-out` |
| Focus ring | instant | `peer-focus-visible:ring-2` |

---

### Edge Cases

- **Disabled**: pointer and keyboard toggling are blocked by the native `disabled`
  attribute; the control drops out of the tab order and shows `opacity-disabled` +
  `cursor-not-allowed`. No `change` event fires.
- **Controlled without `onChange`**: React marks the input read-only; document that a
  controlled `checked` requires an `onChange` handler (or use `defaultChecked`).
- **Rapid toggling**: transitions are interruptible — the thumb animates from its current
  position to the new target, so mid-slide toggles never snap.
- **Reduced motion**: transitions are cosmetic; the on/off state is conveyed by position and
  color, so functionality is unaffected if motion is reduced by the platform.
- **Long label**: the label text sits in normal flow to the right; the control stays a fixed
  size (`shrink-0`) and does not distort.

---

### Accessibility & Keyboard

| Key / Action | Result |
|---|---|
| `Tab` | Move focus to the switch (native input) |
| `Shift+Tab` | Move focus to the previous control |
| `Space` | Toggle the switch on/off |

- `role="switch"` on the native input → announced as a switch; `aria-checked` is reflected
  automatically from the native checked state (no manual sync).
- The `<label>` wraps the input, giving it an accessible name from `label` (or `aria-label`).
- Focus is always visible on the track (`ring-2 ring-primary ring-offset-2`).
- Track and thumb are `aria-hidden` — only the input surfaces to assistive tech.

---

### Implementation Tasks

- [x] Delegate all toggle behaviour to the native checkbox (no custom handlers)
- [x] Reflect on/off via `peer-checked:bg-primary` (track) + `peer-checked:translate-x-*` (thumb)
- [x] Animate track (`transition-colors`) and thumb (`transition-transform`) at `150ms ease-out`
- [x] Block interaction + fade via native `disabled` and `peer-disabled:*`
- [x] Expose visible focus ring through `peer-focus-visible:*`
- [x] Confirm `Space` toggles and `role="switch"` state is announced
