# Visual Verify Report — Switch

**Component**: Switch
**Branch / Source**: Branch A — Figma (codified specs in `specs/switch/`)
**Date**: 2026-07-07
**Skill**: `/visual-verify`

> **Render limitation**: No browser/screenshot tool is available in this environment. This is a
> **source-of-truth** verification — implementation code and its token mapping are checked against
> the authoritative Figma-derived specs plus static analysis. No pixel/screenshot claims are made.
>
> **Story note**: No Storybook story exists for `Switch` yet; interactive/visual QA in Storybook
> (`http://localhost:6006/`) could not be exercised.

---

## Checklist

### Variants
| Check | Result | Notes |
|---|---|---|
| Single visual variant (track + thumb), no color/type axis | ✓ | Only a `size` axis in both CVA definitions |

### Sizes (track / thumb / travel → tokens)
| Check | Result | Notes |
|---|---|---|
| `small` track `w-6 h-4` (24×16) | ✓ | `w-6`→--spacing-24, `h-4`→--spacing-16 |
| `small` thumb `w-2 h-2` (8×8), travel `translate-x-2` (8px) | ✓ | 24 − 2·4 − 8 = 8 |
| `medium` track `w-8 h-5` (32×20) | ✓ | `w-8`→--spacing-32, `h-5`→--spacing-20 |
| `medium` thumb `w-3 h-3` (12×12), travel `translate-x-3` (12px) | ✓ | 32 − 2·4 − 12 = 12 |
| `large` track `w-8 h-6` (32×24) | ✓ | `h-6`→--spacing-24 |
| `large` thumb `w-4 h-4` (16×16), travel `translate-x-2` (8px) | ✓ | 32 − 2·4 − 16 = 8 |
| Uniform 4px inset (`left-1`/`top-1`) → vertical centering | ✓ | (trackH − thumbH)/2 = 4 for all sizes |
| Thumb travel is a spacing utility, not arbitrary px | ✓ | `translate-x-2`/`-3` map to --spacing-8 / --spacing-12 |

### States
| Check | Result | Notes |
|---|---|---|
| Off — track `bg-neutral-300`, thumb at `left-1` | ✓ | --color-neutral-300 |
| On — `peer-checked:bg-primary` + `peer-checked:translate-x-*` | ✓ | --theme-primary |
| Focus — `peer-focus-visible:ring-2 ring-primary ring-offset-2` | ✓ | On track span |
| Disabled — `peer-disabled:opacity-disabled` + `peer-disabled:cursor-not-allowed` | ✓ | + label cursor now conditional (fixed) |
| Hover | n/a | No hover visual defined in spec for the switch |
| Transitions `150ms ease-out` (colors + transform) | ✓ | `transition-colors`/`transition-transform duration-150 ease-out` |

### Colors → Tokens
| Check | Result | Notes |
|---|---|---|
| Track off `bg-neutral-300` | ✓ | var(--color-neutral-300) |
| Track on `bg-primary` | ✓ | var(--theme-primary) |
| Thumb `bg-white` | ✓ | var(--primitive-neutral-white) |
| Thumb `shadow` | ✓ | var(--shadow-default) |
| Focus ring `ring-primary` | ✓ | var(--theme-primary) |
| Label `text-text` | ✓ | var(--color-text-default) |

### Size / Spacing → Tokens
| Check | Result | Notes |
|---|---|---|
| `gap-2` control↔label | ✓ | --spacing-8 |
| `left-1`/`top-1` inset | ✓ | --spacing-4 (4px) |
| `rounded-full` track + thumb | ✓ | Sanctioned exception |

### Typography → Tokens
| Check | Result | Notes |
|---|---|---|
| `font-base font-regular text-body leading-body` | ✓ | --font-family-base / --font-weight-regular / --font-size-body / --line-height-body |

### Accessibility
| Check | Result | Notes |
|---|---|---|
| Native `<input type="checkbox" role="switch">` | ✓ | Keyboard + form associable; aria-checked reflected by native checked |
| Label associates / names the control | ✓ | `<label>` wraps the input; `label` prop or `aria-label` |
| Focus-visible ring | ✓ | `peer-focus-visible:ring-2 ring-primary ring-offset-2` |
| Decorative track + thumb `aria-hidden` | ✓ | Both spans |
| Disabled sets native `disabled` (drops tab order) | ✓ | `disabled` passed to input |

### Token Audit
| Check | Result | Notes |
|---|---|---|
| Hex / rgb() / hsl() / inline style / `[Npx]` on both files | ✓ empty | grep exit 1 (no matches) after fix |

### Responsive (375 / 768 / 1440)
| Check | Result | Notes |
|---|---|---|
| Fixed `shrink-0` control, does not scale with viewport | ✓ | `shrink-0` on control wrapper + `block shrink-0` track |
| Composes into `flex items-center justify-between` settings rows | ✓ | Inline-flex label; label text in normal flow |
| Touch target extended across label via wrapping `<label>` | ✓ | Entire label toggles the input |

---

## Discrepancies

| # | Severity | Description | Resolution |
|---|---|---|---|
| 1 | Minor | Outer `<label>` hardcoded `cursor-pointer` unconditionally, so a disabled switch showed the pointer cursor over the label text (only the track flipped to `cursor-not-allowed`). Spec's Disabled state calls for `cursor-not-allowed`. | Fixed inline: cursor made conditional — `disabled ? 'cursor-not-allowed' : 'cursor-pointer'` on the label, still merged before consumer `className`. |

---

**Result: PASS** — 1 minor discrepancy found and fixed inline; token audit clean; `tsc --noEmit` exit 0.
