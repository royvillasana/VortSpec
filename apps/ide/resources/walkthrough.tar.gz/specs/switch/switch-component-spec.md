# Switch — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Toggle switch control for binary on/off settings that take effect immediately (e.g.
enable/disable a preference). Built on a **real native `<input type="checkbox">`** with
`role="switch"` so it is fully keyboard operable, form-associable, and screen-reader
announced. The native input is rendered visually-hidden (`peer sr-only`) beside a custom
pill **track** with a sliding **thumb**; all visual state is driven by peer pseudo-classes
(`peer-checked`, `peer-focus-visible`, `peer-disabled`).

Use a Switch for immediate settings. For choices that require a submit action or that are
mutually exclusive, prefer a checkbox or radio group instead.

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-neutral-300` | neutral 300 | `background-color` (track, off) |
| `--theme-primary` | `#087990` | `background-color` (track, on) / focus ring |
| `--primitive-neutral-white` | `#ffffff` | `background-color` (thumb) |
| `--shadow-default` | shadow | `box-shadow` (thumb elevation) |
| `--radius` (rounded-full) | full | `border-radius` (track + thumb pill) |
| `--spacing-4` (`1`) | `4px` | thumb inset (`left-1` / `top-1`) |
| `--spacing-8` (`2`) | `8px` | thumb travel small/large (`translate-x-2`) |
| `--spacing-12` (`3`) | `12px` | thumb travel medium (`translate-x-3`) |
| `--spacing-16`–`--spacing-24` | `16–24px` | track/thumb dimensions |
| `--opacity-disabled` | disabled | `opacity` (disabled state) |
| `--font-family-base` | base | `font-family` (label) |
| `--font-size-body` / `--line-height-body` | body | label typography |
| `--color-text-default` | text | label color |

All values are consumed through Tailwind utilities that map to these tokens. No hex, px,
rem, arbitrary `[..]` values, or inline `style` are used.

---

### Variants

Single visual variant (the standard track + thumb switch). Behavioural/visual differences
are expressed through **size** and **state** only — there is no color/type axis.

---

### States

| State | Trigger | Visual |
|---|---|---|
| **Off** (default) | `checked = false` | Track `bg-neutral-300`, thumb at left inset (`left-1`) |
| **On** | `checked = true` | Track `peer-checked:bg-primary`, thumb slides right (`peer-checked:translate-x-*`) |
| **Focus** | Keyboard focus on the input | Track shows `peer-focus-visible:ring-2 ring-primary ring-offset-2` |
| **Disabled** | `disabled` | `peer-disabled:opacity-disabled`, `peer-disabled:cursor-not-allowed`, no pointer events |

The track color transition (`transition-colors`) and thumb slide (`transition-transform`)
both animate over `150ms ease-out`.

---

### Sizes

Thumb inset is a uniform `4px` (`left-1` / `top-1`) on every side and size, so the thumb
is vertically centered and travel is `trackWidth − 2·inset − thumbWidth`.

| Size | Track (w × h) | Thumb (w × h) | Checked travel |
|---|---|---|---|
| `small` | `w-6 h-4` (24 × 16) | `w-2 h-2` (8 × 8) | `translate-x-2` (8px) |
| `medium` (default) | `w-8 h-5` (32 × 20) | `w-3 h-3` (12 × 12) | `translate-x-3` (12px) |
| `large` | `w-8 h-6` (32 × 24) | `w-4 h-4` (16 × 16) | `translate-x-2` (8px) |

---

### Props / API

```ts
interface SwitchProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size' | 'type'>,
    SwitchVariants {
  label?: React.ReactNode; // optional text rendered to the right of the control
}
// SwitchVariants: { size?: 'small' | 'medium' | 'large' }
```

- Extends the native input attributes, so `checked`, `defaultChecked`, `onChange`, `name`,
  `value`, `required`, `disabled`, `aria-*` all pass straight through via `...props`.
- `forwardRef<HTMLInputElement>` — the ref points at the **native input**.
- Consumer `className` is merged **last** on the outer `<label>` for layout overrides.
- Named export only: `export { Switch }`.

---

### Accessibility

- Real native `<input type="checkbox" role="switch">` — announced as a switch with on/off
  state; `aria-checked` is reflected automatically by the native checked state.
- The `<label>` **wraps** the input, so clicking the track, thumb, or label text toggles it
  and the accessible name is derived from `label` (or a caller-supplied `aria-label`).
- Fully keyboard operable: `Tab` to focus, `Space` to toggle (native checkbox behaviour).
- Visible focus indicator: `ring-2 ring-primary ring-offset-2` on the track via
  `peer-focus-visible`.
- Decorative track and thumb spans are `aria-hidden` so only the input is in the a11y tree.
- Disabled state sets the native `disabled` attribute (removes it from the tab order).

---

### Do Not

- Do **not** rebuild the toggle from a `<div>` + click handler — the native input is
  required for keyboard, form, and screen-reader support.
- Do **not** hardcode colors, sizes, or the `150ms` timing — reference tokens only.
- Do **not** use `after:`/pseudo-element thumbs requiring `content-['']` (arbitrary value).
- Do **not** place the thumb inside the track: `peer-checked:` only reaches later **siblings**
  of the peer input, so track and thumb are both siblings inside the relative wrapper.
- Do **not** use a Switch for actions that need a separate submit step.

---

### Implementation Tasks

- [x] Create `switch.variants.ts` with `switchTrackVariants` + `switchThumbVariants` (cva, size axis)
- [x] Export `SwitchVariants = VariantProps<typeof switchTrackVariants>`
- [x] Build `Switch.tsx` with `forwardRef<HTMLInputElement>` and `displayName = 'Switch'`
- [x] Render native `<input type="checkbox" role="switch" className="peer sr-only">`
- [x] Render track + thumb as `aria-hidden` peer siblings inside a `relative` wrapper
- [x] Wire off/on/focus/disabled states via peer pseudo-classes
- [x] Add optional `label` slot and merge consumer `className` last on the `<label>`
- [x] Verify token purity (no hex/px/rem/arbitrary/style) and typecheck
