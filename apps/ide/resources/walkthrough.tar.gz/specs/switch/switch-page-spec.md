# Switch — Page / Usage Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens

---

### Purpose

Documents how the Switch atom is composed into settings surfaces — preference lists,
account/notification panels, and inline toggles within forms. The Switch is a leaf atom; it
composes into rows and settings groups but does not itself contain other components.

---

### Component Inventory

| Element | Component | Notes |
|---|---|---|
| Toggle control | `Switch` (atom) | Native checkbox + track + thumb |
| Inline label | `Switch` `label` prop | Optional text to the right of the control |
| Settings row | Layout (consumer) | `flex items-center justify-between` row wrapping a `Switch` |

---

### Usage Example

```tsx
import { Switch } from '@/components';

// Uncontrolled, with an inline label
<Switch label="Enable notifications" defaultChecked />

// Controlled
const [on, setOn] = React.useState(false);
<Switch
  label="Dark mode"
  checked={on}
  onChange={(e) => setOn(e.target.checked)}
/>

// Sizes
<Switch size="small" label="Compact" />
<Switch size="medium" label="Default" />
<Switch size="large" label="Prominent" />

// Disabled
<Switch label="Beta features" disabled />

// Standalone control with an external label (settings row)
<div className="flex items-center justify-between">
  <span>Auto-sync</span>
  <Switch aria-label="Auto-sync" checked={sync} onChange={onSyncChange} />
</div>
```

---

### Responsive

- The control is a fixed, `shrink-0` size and does not scale with the viewport.
- In settings rows, the label takes the remaining width and wraps; the switch stays pinned
  to the row's trailing edge (`justify-between`).
- Touch targets: the wrapping `<label>` extends the hit area across the label text, aiding
  tap accuracy on small screens.

---

### Accessibility

- Every Switch must have an accessible name — either the `label` prop or an `aria-label`
  when the visible label lives outside the component.
- Group related switches under a section heading or `fieldset`/`legend` at the page level.
- Do not rely on color alone: the thumb **position** also communicates on/off.
- Keyboard: reachable via `Tab`, toggled via `Space`; focus ring is always visible.

---

### Implementation Tasks

- [x] Verify `Switch` composes cleanly into `flex items-center justify-between` settings rows
- [x] Confirm `label` prop and external-label (`aria-label`) patterns both name the control
- [x] Confirm fixed sizing (`shrink-0`) holds across viewports
- [x] Confirm keyboard reachability and visible focus in a list of switches
