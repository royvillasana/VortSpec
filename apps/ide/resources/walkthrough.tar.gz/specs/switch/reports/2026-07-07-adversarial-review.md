# Adversarial Review — Switch

**Date**: 2026-07-07
**Skill**: `/adversarial-review`
**Files**: `src/components/ui/Switch.tsx`, `src/components/ui/switch.variants.ts`
**Source of truth**: `specs/switch/` (Figma-codified)

> Environment note: no browser/screenshot tool. Review is source-of-truth (code + token mapping vs
> spec) plus static analysis. No Storybook story exists for `Switch`.

---

## Verdict

**APPROVED (with 1 minor issue resolved during review).** No Blocker or Major findings. The
component is a faithful, token-pure implementation of the three specs and passes the full
Architecture Validation Checklist.

---

## Findings

| # | Severity | Area | Finding | Status |
|---|---|---|---|---|
| 1 | Minor | State coverage / interaction | Disabled state: outer `<label>` used unconditional `cursor-pointer`; over the label text a disabled switch showed a pointer cursor instead of `cursor-not-allowed` (only the track span flipped via `peer-disabled:cursor-not-allowed`). | Resolved (fixed inline) |
| 2 | Nit | Token model | `ring-2` / `ring-offset-2` widths and `rounded-full` are raw Tailwind defaults, not `var(--token)` mappings. | Accepted — sanctioned exceptions (`rounded-full`; focus-ring width/offset are the spec-mandated focus utilities, analogous to the 1px-border allowance). No change. |
| 3 | Info | Accessibility (assistive-tech behavior) | `role="switch"` on a native checkbox relies on the browser exposing the checkbox `checked` state as the switch on/off. This is the sanctioned pattern per spec and is correct in evergreen browsers; flagged only for awareness. | Accepted — no change. |

### Adversarial probes run (no defect found)
- **Variant coverage**: only a `size` axis exists; matches spec's "single visual variant." All three sizes present in both track and thumb CVA. ✓
- **State coverage**: off / on / focus / disabled all wired via peer pseudo-classes; no hover state is defined by the spec, so none is expected. ✓
- **Token audit**: `grep -nE '#[0-9a-fA-F]{3,8}|rgb\(|hsl\(|style=\{\{|\[[0-9]+px\]'` on both files → empty (exit 1). Every color/spacing/radius/font utility resolves to a `var(--token)` via `tailwind.config.js`. ✓
- **Thumb travel is not arbitrary px**: `translate-x-2` / `translate-x-3` map to `--spacing-8` / `--spacing-12`; geometry (trackW − 2·inset − thumbW) checks out for all three sizes. ✓
- **Accessibility adversarial**: real native input (not a div+handler), `role="switch"`, wrapping `<label>` for name + hit area, `aria-hidden` on decorative spans, visible `peer-focus-visible` ring, native `disabled` removes from tab order. No name-source gap: `label` prop or caller `aria-label`. ✓
- **Peer-sibling correctness**: input carries `peer`; track and thumb are later siblings inside the `relative` wrapper, so `peer-checked:` reaches both — matches the spec "Do Not put thumb inside track." ✓
- **Responsive**: `shrink-0` control holds a fixed size; label flows in normal text and composes into `justify-between` rows. ✓
- **Interaction-spec compliance**: no JS state machine — behavior delegated entirely to the native checkbox; `transition-colors` + `transition-transform` both `duration-150 ease-out`; interruptible transforms handle rapid toggling. ✓

---

## Resolved During Review

| Change | File | Detail |
|---|---|---|
| Conditional disabled cursor | `src/components/ui/Switch.tsx` | Replaced unconditional `cursor-pointer` on the `<label>` with `disabled ? 'cursor-not-allowed' : 'cursor-pointer'`, kept before consumer `className` in `cn()`. `tsc --noEmit` → exit 0; token audit still clean. |

---

## Architecture Validation Checklist

| Requirement | Result | Evidence |
|---|---|---|
| CVA used for variants (separate `.variants.ts`) | ✓ | `switchTrackVariants` + `switchThumbVariants` in `switch.variants.ts` |
| `defaultVariants` defined | ✓ | `size: 'medium'` on both CVA definitions |
| `forwardRef` (ref → native input) | ✓ | `forwardRef<HTMLInputElement, SwitchProps>`, `ref` on `<input>` |
| Spreads remaining props | ✓ | `{...props}` on the native `<input>` |
| `className` merged last via `cn()` | ✓ | `cn('…', disabled ? … : …, className)` on outer `<label>` |
| `VariantProps` type exported | ✓ | `export type SwitchVariants = VariantProps<typeof switchTrackVariants>` |
| No inline `style` for DS values | ✓ | None present; audit grep empty |
| `displayName` set | ✓ | `Switch.displayName = 'Switch'` |
| Named export | ✓ | `export { Switch }` |
| Token purity (no hex/px/rem/arbitrary) | ✓ | grep exit 1 on both files |

---

## Shared / Out-of-Scope Concerns

None. No shared config, tokens, or sibling components required changes. `rounded-full` and the
focus-ring width/offset are pre-agreed sanctioned exceptions.
