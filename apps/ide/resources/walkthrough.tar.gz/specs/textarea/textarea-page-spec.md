# Textarea — Page Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens

---

### Purpose

Documents how the Textarea atom is composed within forms and screens. Textarea is a
leaf form control — it is placed inside labelled field groups (label + control + optional
helper/error text) and composed by molecules/organisms such as comment boxes, feedback
forms, and settings panels.

---

### Component Inventory

| Component | Level | Role in composition |
|---|---|---|
| `Textarea` | Atom | The multi-line input control |
| `<label>` (consumer) | — | Associates a visible label via `htmlFor` |
| Helper / error text (consumer) | — | Linked via `aria-describedby` |

Textarea depends on no other design-system component; it is a standalone atom.

---

### Usage Example

```tsx
import { Textarea } from '@/components/ui/Textarea';

function FeedbackField() {
  const errorId = 'feedback-error';
  const invalid = false;

  return (
    <div>
      <label htmlFor="feedback">Your feedback</label>
      <Textarea
        id="feedback"
        name="feedback"
        rows={4}
        placeholder="Tell us what you think…"
        size="medium"
        invalid={invalid}
        aria-describedby={invalid ? errorId : undefined}
        resize="vertical"
      />
      {invalid && <p id={errorId}>Feedback is required.</p>}
    </div>
  );
}
```

---

### Responsive

- Textarea fills the width of its field container (`w-full`); the field container
  controls measure via layout utilities on the wrapping element.
- No size prop change is required across breakpoints; density (`size`) is chosen by
  context, not viewport.
- Height is driven by `rows` and the `resize` affordance; consumers may set a
  responsive height via `className` if needed.

---

### Accessibility

- Every Textarea must have an associated `<label>` (consumer responsibility).
- Error state: set `invalid` and link the error message via `aria-describedby`.
- Focus order follows DOM order; the focus ring is always visible.
- Field groups should keep label, control, and helper/error text in a single landmark
  (`<form>` region) for screen-reader coherence.

---

### Implementation Tasks

- [x] Verify Textarea fills its field container (`w-full`)
- [x] Document labelled field-group composition (label + control + error text)
- [x] Confirm `aria-describedby` wiring for error text
- [x] Confirm density selection via `size` (not viewport-driven)
