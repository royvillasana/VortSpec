# Textarea — Component Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens
**Owner**: Design Engineering

---

### Purpose

Textarea is the design system's multi-line plain-text editing control. It renders a
styled native `<textarea>` with size and validity variants. It is distinct from the
Text/Paragraph display blocks — those render read-only prose, whereas Textarea is an
interactive form control for capturing multi-line user input (comments, descriptions,
messages, notes).

---

### Design Tokens Used

| Token | Value | CSS Property |
|---|---|---|
| `--color-white` | `#ffffff` | `background-color` (default) |
| `--color-neutral-100` | `#f8f9fa` | `background-color` (disabled) |
| `--color-neutral-300` | `#dee2e6` | `border-color` (default) |
| `--color-danger` | `#dc3545` | `border-color` + focus ring (invalid) |
| `--color-primary` | `#0d6efd` | focus ring (default) |
| `--color-text-default` | `#212529` | `color` (typed text) |
| `--color-text-muted` | `#6c757d` | `color` (placeholder) |
| `--font-family-base` | Roboto | `font-family` |
| `--font-size-body` | `16px` | `font-size` |
| `--font-weight-regular` | `400` | `font-weight` |
| `--radius-default` | `rounded` | `border-radius` |
| `--opacity-disabled` | — | `opacity` (disabled) |

All references are via the Tailwind theme mapping in `tailwind.config.js`, which resolves
to these CSS variables. No hardcoded values.

---

### Variants

| Property | Values | Description |
|---|---|---|
| `size` | `small` \| `medium` \| `large` | Padding density of the control |
| `invalid` | `true` \| `false` | Error styling: danger border + danger focus ring, `aria-invalid` |

---

### States

| State | Visual Change | Trigger |
|---|---|---|
| `default` | White bg, neutral-300 border | — |
| `focus-visible` | 2px primary ring, offset (danger ring when invalid) | Keyboard focus |
| `invalid` | Danger border, danger focus ring | `invalid` prop = true |
| `disabled` | `opacity-disabled`, `not-allowed` cursor, neutral-100 bg | `disabled` attribute |

---

### Sizes

| Size | Padding | Font | Radius |
|---|---|---|---|
| `small` | `px-2 py-1` (8px / 4px) | body 16px | `rounded` |
| `medium` | `px-2.5 py-2` (10px / 8px) | body 16px | `rounded` |
| `large` | `px-3 py-2.5` (12px / 10px) | body 16px | `rounded` |

Width fills the container (`w-full`). Height is driven by native `rows` and the resize affordance.

---

### Props / API

| Prop | Type | Default | Description |
|---|---|---|---|
| `size` | `small \| medium \| large` | `medium` | Padding density |
| `invalid` | `boolean` | `false` | Error styling + `aria-invalid` |
| `resize` | `none \| vertical \| both` | `vertical` | Maps to `resize-none` / `resize-y` / `resize` |
| `rows`, `placeholder`, `value`, `disabled`, `onChange`, ... | native | — | `TextareaHTMLAttributes<HTMLTextAreaElement>` spread |
| `aria-invalid`, `aria-describedby` | native ARIA | — | Passthrough (aria-invalid also set from `invalid`) |
| `className` | `string` | — | Layout overrides only, merged last via `cn()` |

---

### Accessibility

- Element: semantic native `<textarea>`.
- Label association is the consumer's responsibility (`<label htmlFor>` or wrapping label).
- `aria-invalid` is set automatically when `invalid` is true; a consumer-supplied value is honored via spread.
- `aria-describedby` passthrough links the control to helper/error text.
- Visible focus indicator: `focus-visible:ring-2` (primary, or danger when invalid) with offset.
- Disabled state uses the native `disabled` attribute (removed from tab order).
- Contrast for text, placeholder, and borders meets WCAG AA against the intended surface.

---

### Do Not

- Do not hardcode colors, spacing, radius, or type values — reference tokens via Tailwind theme.
- Do not use `style={{}}` or arbitrary `[..]` utilities.
- Do not use Textarea for read-only display copy — use Text (single-line) or Paragraph (block prose).
- Do not rely on `invalid` alone to convey errors — pair with visible, associated error text.
- Do not remove the focus ring.

---

### Implementation Tasks

- [x] Create `src/components/ui/textarea.variants.ts` (CVA `size`, `invalid`)
- [x] Create `src/components/ui/Textarea.tsx` (`forwardRef`, spreads props, `cn()` last)
- [x] Render styled native `<textarea>` with `w-full`, token border/bg/text
- [x] Implement `size` (small / medium / large) padding
- [x] Implement `invalid` — danger border + danger focus ring + `aria-invalid`
- [x] Implement `resize` prop → `resize-none` / `resize-y` / `resize` (default vertical)
- [x] Focus-visible ring (primary, danger when invalid) and disabled pattern
- [x] Support `aria-describedby` / native attribute passthrough via spread
