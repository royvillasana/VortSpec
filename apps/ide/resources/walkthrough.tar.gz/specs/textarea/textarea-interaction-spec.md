# Textarea — Interaction Spec

**Version**: 1.0
**Status**: Ready
**Design source**: Figma
**Figma file**: https://www.figma.com/design/ojko9pGfsDAvmUf2DA38d2/Design-Engineering-System
**Token collection**: Tokens

---

### Interaction Overview

Textarea captures multi-line plain text. Users focus it, type across multiple lines,
and optionally resize its height. Validity is reflected visually and via `aria-invalid`.
All motion is limited to a short color transition on border and background; there is no
custom JS animation.

---

### Trigger

- **Pointer**: Click/tap anywhere inside the control focuses it and places the caret.
- **Keyboard**: `Tab` moves focus into the control; `Shift+Tab` moves out.
- **Programmatic**: A forwarded ref allows `.focus()` / `.select()` from the consumer.

---

### Flow

1. User focuses the textarea (pointer or keyboard) → focus-visible ring appears
   (primary, or danger when `invalid`).
2. User types → characters wrap across lines; caret and native selection behave as a
   standard textarea. `onChange` fires with each edit.
3. `Enter` inserts a newline (it does not submit).
4. User may drag the resize handle to grow/shrink height per the `resize` affordance.
5. On blur, the ring is removed; the entered value persists.
6. When `disabled`, the control is non-interactive, greyed (`opacity-disabled`,
   neutral-100 bg) and skipped in tab order.

---

### Timing

| Property | Value |
|---|---|
| Border/background color transition | 150ms, `ease-out` |
| Focus ring | Immediate (no delay) |

Uses `transition-colors duration-150 ease-out`. Respect the user's reduced-motion
preference — only color transitions are used, no transforms.

---

### Edge Cases

- **Long content** beyond visible height → native vertical scroll appears inside the control.
- **`resize: 'none'`** → user cannot drag-resize; height stays at `rows`.
- **Invalid + focus** → focus ring uses danger color, not primary.
- **Disabled** → no focus, no caret, no resize.
- **Controlled vs uncontrolled** → both supported via native `value` / `defaultValue`.
- **Consumer `className`** → merged last; may override layout (e.g. fixed height) but should not strip token styles.

---

### Accessibility & Keyboard

| Key | Action |
|---|---|
| `Tab` / `Shift+Tab` | Move focus in / out |
| Character keys | Insert text at caret |
| `Enter` | Insert newline (never submits) |
| Arrow keys / `Home` / `End` | Caret navigation |
| `Ctrl/Cmd+A` | Select all |

- Focus is always visible via `focus-visible:ring-2` (+ offset).
- `aria-invalid` communicates error state to assistive tech; pair with associated
  error text via `aria-describedby`.
- Label must be associated by the consumer (`<label htmlFor>` or wrapping).

---

### Implementation Tasks

- [x] Focus-visible ring on keyboard/pointer focus (primary; danger when invalid)
- [x] `onChange` and native controlled/uncontrolled value handling via spread
- [x] Color-only transition (150ms ease-out); no transform animation
- [x] `resize` affordance wired to `resize-none` / `resize-y` / `resize`
- [x] Disabled removes interactivity and focus
- [x] `aria-invalid` reflects `invalid`; `aria-describedby` passthrough
