# Token Gaps — Figma Variables not yet in `src/styles/tokens.css`

Read from the authoritative Figma Variables API (Desktop Bridge) on **2026-07-06**.
These Variables exist in the *Design Engineering System* file but are **not** mirrored in
the project token file, because the 11 currently-built components do not consume them.
This is a scope gap, not a defect — `tokens.css` is intentionally scoped to the
implemented subset (see `design.md` → D6).

**When to act:** if a new component needs any of these, re-run `/sync-tokens` to pull the
Variable into `tokens.css` + `tailwind.config.js`, then update `design.md` and `DESIGN.md`.

---

## Completeness snapshot

| Category | In Figma | In `tokens.css` | Gap |
|---|---|---|---|
| Primitive brand ramps | 18 | 3 | 15 |
| Semantic colors | 47 | ~19 | ~28 |
| Spacing steps | 20 | 9 | 11 |
| Radius steps | 5 | 2 | 3 |
| Stroke | 1 | 1 | 0 ✅ |
| Effects (shadow) | 4 | 0 | 4 |
| Typography (Text Styles) | H1–H6 + Body | mirrored | 0 ✅ |

---

## Colors

### Brand ramps — `Primitive / Color` (only `-500` steps + `primary/600` are used)
- `brand-primary/100` `#E6F2F4`, `/200` `#9CC9D3`, `/300` `#6BAFBC`, `/400` `#3994A6`,
  `/700` `#054956`, `/800` `#03303A`, `/900` `#02181D`
- `brand-secondary/100` `#FCF2EB`, `/200` `#F3CAB0`, `/300` `#ECB088`, `/400` `#E69561`,
  `/600` `#B3622E`, `/700` `#864A22`, `/800` `#5A3117`, `/900` `#2D190B`

### Neutral / accent — `Semantic / Color`
- `color/neutral/300` `#DEE2E6` (border candidate — Header currently uses Tailwind neutral)
- `color/neutral/900` `#1A1E21`
- `color/neutral/muted` `#BABBBC`
- `color/accent/purple` `#7B61FF`
- `primitive/red/600` `#B02A37`, `primitive/green/600` `#146C43`, `primitive/purple/500` `#6F42C1`
- `primitive/cyan/100` `#CFF4FC`, `/200` `#9EEAF9`, `/800` `#055160`

### Status tints — `Semantic / Color`
- `color/status/secondary/dark` `#2D190B`, `secondary/light` `#F3CAB0`
- `color/status/info/light` `#3DD5F3`, `info/medium` `#25CFF2`
- `color/status/warning/light` `#FFCD39`

### Explicit button hover/border colors — `Semantic / Color`
The implementation uses a `brightness()` filter instead (see `design.md` → D3). Adopt
these for exact Figma parity:
- `component/button/danger/background/hover` `#BB2D3B`, `.../border/active` `#A52834`
- `component/button/success/background/hover` `#157347`, `.../border/active` `#13653F`
- `component/button/info/background/hover` `#31D2F2`
- `component/button/warning/background/hover` `#FFCA2C`, `.../border/hover` `#FFC720`
- `component/button/secondary/background/hover` `#5C636A`, `.../border/hover` `#B3622E`, `.../border/active` `#51585E`
- `component/button/dark/background/hover` `#1C1F23`
- `component/button/light/background/hover` `#D3D4D5`
- *(in use)* `component/button/primary/background/hover` `#066173` → `--button-primary-background-hover`

## Spacing — `Primitive / Spacing` (unused steps)
`18, 19, 28, 32, 50, 72, 80, 82, 100, 190, 225` (px)

## Radius — `Primitive / Radius` (unused steps)
`none` (0), `5`, `6`

## Shadow — `Primitive / Effects` (no code token yet)
Default elevation, composed from four Variables:
- `shadow/default/offset-x` `0`, `offset-y` `8`, `radius` `16`, `spread` `0`
- `shadow/default/color` `#00000026` (rgba(0,0,0,0.15))
- → CSS: `box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.15);`

No implemented component applies a shadow, so no `--shadow-*` token exists. Add one when
an elevated surface (modal, dropdown, floating panel) is built.
</content>
