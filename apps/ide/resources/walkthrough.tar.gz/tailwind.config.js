/** @type {import('tailwindcss').Config} */
// Every value maps to a CSS custom property from src/styles/tokens.css.
// No hardcoded hex or pixel values live here — tokens are the single source of truth.
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}', './.storybook/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        white: 'var(--primitive-neutral-white)',
        black: 'var(--primitive-neutral-black)',
        'near-black': 'var(--primitive-neutral-near-black)',
        yellow: {
          100: 'var(--primitive-yellow-100)',
          200: 'var(--primitive-yellow-200)',
          800: 'var(--primitive-yellow-800)',
        },
        primary: {
          DEFAULT: 'var(--theme-primary)',
          hover: 'var(--button-primary-background-hover)',
        },
        secondary: {
          DEFAULT: 'var(--theme-secondary)',
          emphasis: 'var(--color-status-secondary-emphasis)',
        },
        success: 'var(--color-status-success)',
        danger: 'var(--color-status-danger)',
        warning: {
          DEFAULT: 'var(--color-status-warning)',
          emphasis: 'var(--color-status-warning-emphasis)',
        },
        info: {
          DEFAULT: 'var(--color-status-info)',
          emphasis: 'var(--color-status-info-emphasis)',
        },
        neutral: {
          100: 'var(--color-neutral-100)',
          300: 'var(--color-neutral-300)',
          600: 'var(--color-neutral-600)',
          900: 'var(--color-neutral-900)',
          muted: 'var(--color-neutral-muted)',
        },
        text: {
          DEFAULT: 'var(--color-text-default)',
          muted: 'var(--color-text-muted)',
        },
        // Alias: exposes the muted text color as the flat utility `text-muted`
        // (in addition to `text-text-muted`). Nesting `text.muted` above only
        // generates `text-text-muted`, so the widely-used `text-muted` class was
        // a dead class until this alias. Both now resolve to --color-text-muted.
        muted: 'var(--color-text-muted)',
        // Brand ramps (Primitive/Color) — tints/shades for subtle surfaces & marks.
        'brand-primary': {
          100: 'var(--brand-primary-100)',
          200: 'var(--brand-primary-200)',
          300: 'var(--brand-primary-300)',
          400: 'var(--brand-primary-400)',
          500: 'var(--brand-primary-500)',
          600: 'var(--brand-primary-600)',
          700: 'var(--brand-primary-700)',
          800: 'var(--brand-primary-800)',
          900: 'var(--brand-primary-900)',
        },
        'brand-secondary': {
          100: 'var(--brand-secondary-100)',
          200: 'var(--brand-secondary-200)',
          300: 'var(--brand-secondary-300)',
          400: 'var(--brand-secondary-400)',
          500: 'var(--brand-secondary-500)',
          600: 'var(--brand-secondary-600)',
          700: 'var(--brand-secondary-700)',
          800: 'var(--brand-secondary-800)',
          900: 'var(--brand-secondary-900)',
        },
        accent: {
          purple: 'var(--color-accent-purple)',
        },
        // Status tints (Semantic/Color) — for subtle status surfaces.
        'info-light': 'var(--color-status-info-light)',
        'info-medium': 'var(--color-status-info-medium)',
        'warning-light': 'var(--color-status-warning-light)',
        'secondary-light': 'var(--color-status-secondary-light)',
        'secondary-dark': 'var(--color-status-secondary-dark)',
      },
      spacing: {
        0: 'var(--spacing-0)',
        1: 'var(--spacing-4)',
        1.5: 'var(--spacing-6)',
        2: 'var(--spacing-8)',
        2.5: 'var(--spacing-10)',
        3: 'var(--spacing-12)',
        4: 'var(--spacing-16)',
        5: 'var(--spacing-20)',
        6: 'var(--spacing-24)',
        7: 'var(--spacing-28)',
        8: 'var(--spacing-32)',
        12.5: 'var(--spacing-50)',
        18: 'var(--spacing-72)',
        20: 'var(--spacing-80)',
      },
      borderRadius: {
        none: 'var(--radius-none)',
        xs: 'var(--radius-4)',
        sm: 'var(--radius-4)',
        DEFAULT: 'var(--radius-8)',
        md: 'var(--radius-8)',
        lg: 'var(--radius-6)',
      },
      boxShadow: {
        DEFAULT: 'var(--shadow-default)',
        md: 'var(--shadow-default)',
      },
      borderWidth: {
        DEFAULT: 'var(--stroke-width-1)',
        1: 'var(--stroke-width-1)',
      },
      fontFamily: {
        base: 'var(--font-family-base)',
        sans: 'var(--font-family-base)',
        mono: 'var(--font-family-mono)',
      },
      fontSize: {
        h1: ['var(--font-size-h1)', { lineHeight: 'var(--line-height-heading)' }],
        h2: ['var(--font-size-h2)', { lineHeight: 'var(--line-height-heading)' }],
        h3: ['var(--font-size-h3)', { lineHeight: 'var(--line-height-heading)' }],
        h4: ['var(--font-size-h4)', { lineHeight: 'var(--line-height-heading)' }],
        h5: ['var(--font-size-h5)', { lineHeight: 'var(--line-height-heading)' }],
        h6: ['var(--font-size-h6)', { lineHeight: 'var(--line-height-heading)' }],
        body: ['var(--font-size-body)', { lineHeight: 'var(--line-height-body)' }],
      },
      lineHeight: {
        heading: 'var(--line-height-heading)',
        body: 'var(--line-height-body)',
      },
      fontWeight: {
        regular: 'var(--font-weight-regular)',
      },
      opacity: {
        disabled: 'var(--opacity-disabled)',
      },
    },
  },
  plugins: [],
};
